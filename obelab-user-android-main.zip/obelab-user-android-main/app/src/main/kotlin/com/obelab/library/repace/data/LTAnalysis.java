package com.obelab.library.repace.data;

public class LTAnalysis {
    public boolean isNext;
    public double lactate;
    public double speed;
    public double onset;
    public double threshold;
}

