package com.obelab.library.repace.data;

public class LTExercise {
    public double threshold;
}
