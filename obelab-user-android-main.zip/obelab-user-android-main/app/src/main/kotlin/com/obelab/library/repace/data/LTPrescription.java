package com.obelab.library.repace.data;

public class LTPrescription {
    public int type;        // 1: 저강도, 2: 양극화
    public double leSpeed;
    public int leWeek;
    public int leTime;
    public int leMin;
    public double ptSpeed;
    public int ptWeek;
    public int ptTime;
    public int ptMin;
    public double  ptIndex;
}
