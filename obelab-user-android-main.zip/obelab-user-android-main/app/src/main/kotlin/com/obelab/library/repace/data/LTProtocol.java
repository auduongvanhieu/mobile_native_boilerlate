package com.obelab.library.repace.data;

public class LTProtocol {
    public int protocol;        // 1: Protocol 0.4, 2: Protocol 0.5
    public double startSpeed;   // 시작 속도
    public int heartRate;       // 기준 심박수
}
