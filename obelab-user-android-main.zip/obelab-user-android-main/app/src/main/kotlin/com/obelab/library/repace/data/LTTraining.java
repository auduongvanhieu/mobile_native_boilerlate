package com.obelab.library.repace.data;

public class LTTraining {
    public int section;
    public int time;
    public double speed;
    public int heartRate;

    public LTTraining(int section, int time, double speed, int heartRate) {
        this.section = section;
        this.time = time;
        this.speed = speed;
        this.heartRate = heartRate;
    }
}
