package com.obelab.repace.features.home;

import android.app.Activity;

public class HomeActivity extends Activity {
}
