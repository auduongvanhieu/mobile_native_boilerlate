package com.obelab.repace.model

data class BluetoothDeviceModel(
    val name: String,
    val MACAddress: String
)