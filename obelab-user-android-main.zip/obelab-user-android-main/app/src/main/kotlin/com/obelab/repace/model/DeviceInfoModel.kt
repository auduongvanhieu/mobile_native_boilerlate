package com.obelab.repace.model

import java.io.Serializable

class DeviceInfoModel  (
    var address: String,
    var name: String
): Serializable