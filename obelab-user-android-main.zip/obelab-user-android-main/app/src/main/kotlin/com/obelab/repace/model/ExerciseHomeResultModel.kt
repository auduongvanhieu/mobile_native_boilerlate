package com.obelab.repace.model

data class ExerciseHomeResultModel(
    val heartRateAvg: Int?,
    val smo2Avg: Int?,
    val rxExercise: Int?
)