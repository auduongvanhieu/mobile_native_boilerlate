package com.obelab.repace.model

import com.obelab.repace.core.functional.Functions

data class ExerciseSpeedModel(
    var speed: Double,
)