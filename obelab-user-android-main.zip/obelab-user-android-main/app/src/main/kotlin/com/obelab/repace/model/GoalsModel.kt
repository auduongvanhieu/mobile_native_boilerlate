package com.obelab.repace.model

data class GoalsModel (
    var trophy_cnt: Int,
    var medal_cnt: Int,
    var badge_cnt: Int
)