package com.obelab.repace.model

data class InstructionModel(
    var content: String,
    var imgSource: Int
)