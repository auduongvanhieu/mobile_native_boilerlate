package com.obelab.repace.model

import java.io.Serializable

class LtTestDataOutDoorModel(
    var stage: Int,
    var speed: Double,
    var distance: Float
): Serializable