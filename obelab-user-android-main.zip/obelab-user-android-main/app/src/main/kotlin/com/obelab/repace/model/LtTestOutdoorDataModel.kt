package com.obelab.repace.model

import java.io.Serializable

data class LtTestOutdoorDataModel(
    val Stage:Int,
    val Speed: Double,
    val Distance: Double,
): Serializable