package com.obelab.repace.model

data class LtTestPerformanceModel(
    var stage: Int,
    var speed: Double,
    var distance: Double
)