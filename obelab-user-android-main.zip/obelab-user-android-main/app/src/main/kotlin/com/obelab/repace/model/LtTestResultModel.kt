package com.obelab.repace.model

class LtTestResultModel(
    val totalStages: Int,
    val lactateOnset: Double,
    val smO2AtLactate4mmol: Int
)