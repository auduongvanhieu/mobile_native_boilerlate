package com.obelab.repace.model

data class MailSupportModel(
    var id: Int,
    var value: String,
    var parentId: Int,
    var name: String,
    var code: String
)