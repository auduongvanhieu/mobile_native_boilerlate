package com.obelab.repace.model

// Repace command
object RepaceCmd {
    const val CMD_MEASURE_START = 0x01
    const val CMD_MEASURE_STOP = 0x02
    const val CMD_GAIN_START = 0x03
}