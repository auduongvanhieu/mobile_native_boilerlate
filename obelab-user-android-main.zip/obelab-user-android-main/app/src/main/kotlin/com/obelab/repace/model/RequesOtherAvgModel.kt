package com.obelab.repace.model

data class RequesOtherAvgModel(
    var id: String,
    var cumulative:Boolean,
)
