package com.obelab.repace.model

data class RequesOtherInfoModel(
    var id: String,
)
