package com.obelab.repace.model

data class RequesOtherLTTestModel(
    var id: String,
    var cumulative:Boolean,
)
