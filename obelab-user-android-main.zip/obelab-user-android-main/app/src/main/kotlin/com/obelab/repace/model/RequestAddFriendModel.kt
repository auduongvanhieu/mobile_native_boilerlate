package com.obelab.repace.model

/**
 *
 */
data class RequestAddFriendModel(
    var friendId: Int,
//    var friendId:Int
)