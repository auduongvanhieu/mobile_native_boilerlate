package com.obelab.repace.model

data class RequestCalendarModel(
    var month: Int,
    var year: Int
)