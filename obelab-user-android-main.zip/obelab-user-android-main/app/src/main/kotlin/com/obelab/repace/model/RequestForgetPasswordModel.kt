package com.obelab.repace.model

data class RequestForgetPasswordModel(
    var mail: String
)