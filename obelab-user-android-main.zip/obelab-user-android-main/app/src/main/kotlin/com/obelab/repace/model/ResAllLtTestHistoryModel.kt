package com.obelab.repace.model

class ResAllLtTestHistoryModel (
//    var result: LTTestHistoryOnsetModel,
    val id:Int,
    val date: String,
    val smO2Avg: Double,
    val distance: Double,
    val duration: Double,
    val speedMax: Double,
    val speedAvg: Double,
    val lactateOnset: Double,
    val stage: Double,


)