package com.obelab.repace.model

class ResDistanceModel (
    var distanceList: Array<String>,
)