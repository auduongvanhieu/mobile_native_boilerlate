package com.obelab.repace.model

data class ResFAQsModel(
    var data: ArrayList<FAQModel>
)