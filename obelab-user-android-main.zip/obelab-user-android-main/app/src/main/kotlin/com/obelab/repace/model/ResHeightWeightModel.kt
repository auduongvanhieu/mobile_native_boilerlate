package com.obelab.repace.model

data class ResHeightWeightModel(
    var heightList: MutableList<Double>,
    var weightList: MutableList<Double>
)