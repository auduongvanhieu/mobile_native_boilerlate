package com.obelab.repace.model

data class ResMemberTokenModel(
    var token: String?,
) {
    constructor() : this( "")
}