package com.obelab.repace.model

data class ResOtherAvgModel(
    var heartRateAvg: Double,
    var smo2Avg:Double,
    var rxExercise:Double,
)
