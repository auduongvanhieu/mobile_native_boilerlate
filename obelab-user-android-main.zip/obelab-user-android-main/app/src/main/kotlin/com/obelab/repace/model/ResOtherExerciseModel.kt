package com.obelab.repace.model

data class ResOtherExerciseModel(
    var type: Int,
    var leSpeed: Double,
    var leWeek: Int,
    var leTime: Int,
    var leMin: Int,
    var ptSpeed: Double,
    var ptWeek: Int,
    var ptTime: Int,
    var ptMin: Int,
    var ptIndex: Double,
)
