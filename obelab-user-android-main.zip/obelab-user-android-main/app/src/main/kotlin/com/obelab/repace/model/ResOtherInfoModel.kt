package com.obelab.repace.model

data class ResOtherInfoModel (
    var email: String?,
    var nickname: String?,
    var avatar: String?,
    var height:Double?,
    var weight:Double?,
    var birthday:String,
    var gender:String,
)
