package com.obelab.repace.model

data class ResOtherLTTestModel(
    var totalStages: Double,
    var lactateOnset:Double,
    var smO2AtLactate4mmol:Double,
)
