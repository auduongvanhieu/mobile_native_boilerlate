package com.obelab.repace.model

data class ResponseExerciseResultModel(
    var medal: Boolean,
    var badge: Boolean,
)