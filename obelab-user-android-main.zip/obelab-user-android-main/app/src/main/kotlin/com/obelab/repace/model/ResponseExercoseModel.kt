package com.obelab.repace.model

data class ResponseExercoseModel(
    var data: ArrayList<DayExerciseModel>
)