package com.obelab.repace.model

/**
 *
 */
data class SearchFriendModel(
    val data : ArrayList<FriendRequestModel>?,
)