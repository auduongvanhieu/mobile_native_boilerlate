package com.obelab.repace.model

import java.io.Serializable

data class SmO2ChartModel(
    val name:String,
    val score: Double,
) : Serializable