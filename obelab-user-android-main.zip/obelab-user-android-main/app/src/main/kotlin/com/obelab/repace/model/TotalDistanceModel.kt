package com.obelab.repace.model

data class TotalDistanceModel(
    val totalDistance: Double,

)