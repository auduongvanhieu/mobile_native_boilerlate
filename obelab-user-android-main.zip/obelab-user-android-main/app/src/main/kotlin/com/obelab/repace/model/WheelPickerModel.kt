package com.obelab.repace.model

data class WheelPickerModel (
    val unit: String,
    val values: MutableList<Double>
    )