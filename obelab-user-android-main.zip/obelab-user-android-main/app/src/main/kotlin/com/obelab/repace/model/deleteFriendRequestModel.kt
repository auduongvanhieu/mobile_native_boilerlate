package com.obelab.repace.model

data class DeleteFriendRequestModel(
    var id: Int?
){
    constructor() :this(null)
}