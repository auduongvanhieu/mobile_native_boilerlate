# REPACE ios project

### Tips
- Convert HexColor to CGColor: https://www.uicolor.io
- Swift UI programmatically: https://github.com/lanqy/swift-programmatically
- Convert Json to struct: https://app.quicktype.io/
- How to use scrollview: https://fluffy.es/scrollview-storyboard-xcode-11/
- Choose color and image from box: type #colorLiteral() and #imageLiteral()
- Generate fake gps: http://www.bikehike.co.uk/mapview.php
- Generate .netrc file to pod Mapbox:
    + open terminal
    + vi .netrc
    + touch .netrc
    + open .netrc
    + copy content in .netrc from project to this file
    + pod install at ios folder
### Fix font can not import
- https://www.glyphrstudio.com/online -> Font setting -> Change name
### Convert Byte To Int
- https://www.scadacore.com/tools/programming-calculators/online-hex-converter/
### Color
- Hex Opacity Values
    100% — FF
    95% — F2
    90% — E6
    85% — D9
    80% — CC
    75% — BF
    70% — B3
    65% — A6
    60% — 99
    55% — 8C
    50% — 80
    45% — 73
    40% — 66
    35% — 59
    30% — 4D
    25% — 40
    20% — 33
    15% — 26
    10% — 1A
    5% — 0D
    0% — 00
