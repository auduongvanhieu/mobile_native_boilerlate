import UIKit
import IQKeyboardManagerSwift
import Firebase
import GoogleSignIn
import FBSDKCoreKit
import AppCenter
import AppCenterAnalytics
import AppCenterCrashes
import FirebaseMessaging
import RealmSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
  let gcmMessageIDKey = "gcm.Message_ID"
  override init() {
    super.init()
    UIFont.overrideInitialize()
  }
  
  var viewModel = LTTestCompleteViewModel()
  
  static let shared: AppDelegate = { guard let appD = UIApplication.shared.delegate as? AppDelegate else { return AppDelegate() }
    return appD
  }()
  
  var window: UIWindow?
  
  func application( _ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? ) -> Bool {
    
    UIApplication.shared.isIdleTimerDisabled = true
    WatchKitConnection.shared.startSession()
    // Override point for customization after application launch.
    AnalyticsManager.shared.setup()
    // -Facebook
    ApplicationDelegate.shared.application(
      application, didFinishLaunchingWithOptions: launchOptions
    )
    // Other
    IQKeyboardManager.shared.enable = true
    let rootVC = AppNavigator.shared.rootViewController
    window?.rootViewController = rootVC
    // S3
    AWSS3Manager.initializeS3()
    // Google Signin
    FirebaseApp.configure()
    if LocalDataManager.token != nil {
      setupPushNotification()
    }
    Messaging.messaging().delegate = self
    // App center
    AppCenter.start(withAppSecret: "2fcf306f-ece3-499c-98cb-27112cf80c92", services: [Analytics.self, Crashes.self])
    migrationRealm()
    return true
  }
  
  func migrationRealm() {
    let config = Realm.Configuration(
      // Set the new schema version. This must be greater than the previously used
      // version (if you've never set a schema version before, the version is 0).
      schemaVersion: 1,
      
      // Set the block which will be called automatically when opening a Realm with
      // a schema version lower than the one set above
      migrationBlock: { migration, oldSchemaVersion in
        // We haven’t migrated anything yet, so oldSchemaVersion == 0
        if oldSchemaVersion < 1 {
          // Nothing to do!
          // Realm will automatically detect new properties and removed properties
          // And will update the schema on disk automatically
          migration.enumerateObjects(ofType: ResultExerciseObject.className()) { _, newObject in
            // combine name fields into a single field
            guard let newObject = newObject else { return }
            newObject["isAttachCreatedAt"] = true
          }
          migration.enumerateObjects(ofType: RxExerciseResultObject.className()) { _, newObject in
            // combine name fields into a single field
            guard let newObject = newObject else { return }
            newObject["isAttachCreatedAt"] = true
          }
          migration.enumerateObjects(ofType: LTTestResultObject.className()) { _, newObject in
            // combine name fields into a single field
            guard let newObject = newObject else { return }
            newObject["isAttachCreatedAt"] = true
          }
        }
      })
    
    // Tell Realm to use this new configuration object for the default Realm
    Realm.Configuration.defaultConfiguration = config
    
    // Now that we've told Realm how to handle the schema change, opening the file
    // will automatically perform the migration
    
    do {
      let realm = try Realm()
      Functions.showLog(title: "migrationRealm", message: realm)
    } catch let err {
      Functions.showLog(title: "MigrationRealm error", message: err)
    }
  }
  
  func setupPushNotification() {
    let application: UIApplication = UIApplication.shared
    if #available(iOS 10.0, *) {
      // For iOS 10 display notification (sent via APNS)
      UNUserNotificationCenter.current().delegate = self
      
      let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
      UNUserNotificationCenter.current().requestAuthorization(
        options: authOptions,
        completionHandler: { _, _ in }
      )
    } else {
      let settings: UIUserNotificationSettings =
      UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
      application.registerUserNotificationSettings(settings)
    }
    application.registerForRemoteNotifications()
  }
  
  func applicationWillEnterForeground(_ application: UIApplication) {
    if let navi = window?.rootViewController as? UINavigationController,
       let mainViewController = navi.visibleViewController as? MainViewController {
      if mainViewController.openFlag == true {
        mainViewController.closeSideMenu()
      }
    }
  }
  
  func application( _ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any ) -> Bool {
    return ApplicationDelegate.shared.application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
  }
  
  @available(iOS 9.0, *)
  func application(_ application: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any]) -> Bool {
    return ApplicationDelegate.shared.application( application, open: url, options: options) || GIDSignIn.sharedInstance.handle(url)
  }

}
extension AppDelegate: MessagingDelegate {
  func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
    Functions.showLog(title: "Firebase registration token: \(String(describing: fcmToken))", message: "")
    Constants.FCM_TOKEN = fcmToken ?? ""
    let dataDict: [String: String] = ["token": fcmToken ?? ""]
    NotificationCenter.default.post(
      name: Notification.Name("FCMToken"),
      object: nil,
      userInfo: dataDict
    )
    // TODO: If necessary send token to application server.
    // Note: This callback is fired at each app startup and whenever a new token is generated.
  }
}
extension AppDelegate : UNUserNotificationCenterDelegate {
  func application(_ application: UIApplication,
                   didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    Messaging.messaging().apnsToken = deviceToken;
  }
  
  func application(application : UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler _: @escaping (UIBackgroundFetchResult) -> Void) {
        Messaging.messaging().appDidReceiveMessage(userInfo)
  }
  
  func userNotificationCenter(_ center: UNUserNotificationCenter,
                              willPresent notification: UNNotification,
    withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    let userInfo = notification.request.content.userInfo

    Messaging.messaging().appDidReceiveMessage(userInfo)

    // Change this to your preferred presentation option
    completionHandler([.badge, .alert, .sound])
  }

  func userNotificationCenter(_ center: UNUserNotificationCenter,
                              didReceive response: UNNotificationResponse,
                              withCompletionHandler completionHandler: @escaping () -> Void) {
    let userInfo = response.notification.request.content.userInfo

    Messaging.messaging().appDidReceiveMessage(userInfo)

    completionHandler()
  }
}
