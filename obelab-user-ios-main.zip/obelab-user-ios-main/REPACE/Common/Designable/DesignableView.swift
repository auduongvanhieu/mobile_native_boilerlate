//
//  DesignableView.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/1/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

@IBDesignable class DesignableView: UIView {
    
    var xCornerRadius: CGFloat = 0
    var xShadowOpacity: Float = 0
    var xShadowRadius: CGFloat = 0
    var xShadowColor: UIColor = UIColor.clear
    var xBorderWidth: CGFloat = 0
    var xBorderColor: UIColor = UIColor.clear
    
    override func draw(_ rect: CGRect) {
        layer.masksToBounds = true
        
        self.layer.cornerRadius = xCornerRadius
        self.layer.shadowOpacity = xShadowOpacity
        self.layer.shadowRadius = xShadowRadius
        self.layer.shadowColor = xShadowColor.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        
        self.layer.borderWidth = xBorderWidth
        self.layer.borderColor = xBorderColor.cgColor
    }
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            
         self.xCornerRadius = cornerRadius
        }
    }
     
     @IBInspectable var shadowOpacity: Float = 0 {
         didSet {
             
             self.xShadowOpacity = shadowOpacity
         }
     }
     
     @IBInspectable var shadowRadius: CGFloat = 0 {
         didSet {
             
             self.xShadowRadius = shadowRadius
         }
     }
     
     @IBInspectable var shadowColor: UIColor = UIColor.clear {
         didSet {
             self.xShadowColor = shadowColor
         }
     }

    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            self.xBorderWidth = borderWidth
        }
    }
    
    @IBInspectable var borderColor: UIColor = UIColor.clear {
        didSet {
            self.xBorderColor = borderColor
        }
    }

}
