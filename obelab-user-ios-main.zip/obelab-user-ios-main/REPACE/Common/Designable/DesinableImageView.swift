//
//  DesinableImageView.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/1/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

@IBDesignable class DesignableImageView: UIImageView {
    var xShadowOpacity: Float = 0
    var xShadowRadius: CGFloat = 0
    var xShadowColor: UIColor = UIColor.clear
    
    override func draw(_ rect: CGRect) {
        
        self.layer.shadowOpacity = xShadowOpacity
        self.layer.shadowRadius = xShadowRadius
        self.layer.shadowColor = xShadowColor.cgColor
        self.layer.shadowOffset = CGSize(width: 0, height: 0)
        
        layer.masksToBounds = true
    }
   
   @IBInspectable var cornerRadius: CGFloat = 0 {
       didSet {
        self.layer.cornerRadius = cornerRadius
       }
   }
    
    @IBInspectable var shadowOpacity: Float = 0 {
        didSet {
            
            self.xShadowOpacity = shadowOpacity
        }
    }
    
    @IBInspectable var shadowRadius: CGFloat = 0 {
        didSet {
            
            self.xShadowRadius = shadowRadius
        }
    }
    
    @IBInspectable var shadowColor: UIColor = UIColor.clear {
        didSet {
            self.xShadowColor = shadowColor
        }
    }
}
