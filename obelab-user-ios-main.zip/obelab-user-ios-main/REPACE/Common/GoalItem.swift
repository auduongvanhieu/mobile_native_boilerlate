//
//  GoalItem.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/15/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class GoalItem: UIView {

    let nibName = "GoalItem"
    
    @IBOutlet weak var ivImage: DesignableImageView!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var lbTimes: UILabel!
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func setLevel(level: Int) {
        lbTimes.text = String(level)
    }
    
    func setDescription(_ desc: String) {
        lbDescription.text = String(desc)
    }
    
    func setTextColor(_ color: UIColor) {
        lbDescription.textColor = color
        lbTimes.textColor = color
    }
    
    func setImage(_ img: UIImage) {
        ivImage.image = img
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }

}
