//
//  MeasureItem.swift
//  REPACE
//
//  Created by Van Huy Pham on 10/29/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

protocol HeaderBackDelegate: NSObjectProtocol {
    func onClickShare()
    func onClickBack()
}

class HeaderBack: UIView {
    @IBOutlet weak var btnLeftAction: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var btnRightAction: UIButton!
    
    let nibName = "HeaderBack"
    weak var delegate: HeaderBackDelegate?
    
    func setTitle(title: String) {
        self.titleLabel.text = title
    }

    @IBAction func onClickBack(_ sender: Any) {
        AppNavigator.shared.pop()
        delegate?.onClickBack()
    }
    
    @IBAction func onClickRight(_ sender: Any) {
        if rightButton == 1 {
            if LocalDataManager.volumeTurnOn {
                LocalDataManager.volumeTurnOn = false
                self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_volume_off"), for: .normal)
            } else {
                LocalDataManager.volumeTurnOn = true
                self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_volume_on"), for: .normal)
            }
        } else if rightButton == 2 {
            self.delegate?.onClickShare()
        } else if rightButton == 3 {
            AppNavigator.shared.navigate(to: MainRoutes.addFriends, with: .push)
        } else if rightButton == 4 {
            AppNavigator.shared.navigate(to: AuthRoutes.pairing(goToHome: true), with: .push)
        }
    }
    
    @IBInspectable var hideLeftButton: Bool = false {
        didSet {
            self.btnLeftAction.isHidden = hideLeftButton
        }
    }
    
    @IBInspectable var title: String = "" {
        didSet {
            self.titleLabel.text = title
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    @IBInspectable var rightButton: Int = 0 {
        didSet {
            switch rightButton {
            case 1 :
                if LocalDataManager.volumeTurnOn {
                    self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_volume_on"), for: .normal)
                } else {
                    self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_volume_off"), for: .normal)
                }
                self.btnRightAction.isHidden = false
            case 2 :
                self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_share"), for: .normal)
                self.btnRightAction.isHidden = false
            case 3 :
                self.btnRightAction.setImage(#imageLiteral(resourceName: "ic_user-plus"), for: .normal)
                self.btnRightAction.isHidden = false
            case 4 :
                if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
                    self.btnRightAction.setImage(UI.Icon.ic_bluetooth_on, for: .normal)
                } else {
                    self.btnRightAction.setImage(UI.Icon.ic_bluetooth_off, for: .normal)
                }
                self.btnRightAction.isHidden = false
            default:
                self.btnRightAction.isHidden = true
            }
        }
    }
    
    func getBackgroundImage(backgroundColor: UIColor? = .screenBackground) -> UIImage? {
        let imageSize = self.bounds.size
        UIGraphicsBeginImageContextWithOptions(imageSize, false, 0)
        let currentView = UIView(frame: CGRect(x: 0, y: 0, width: imageSize.width, height: imageSize.height))
        currentView.backgroundColor = backgroundColor
        if let context = UIGraphicsGetCurrentContext() {
            currentView.layer.render(in: context)
        }
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img
    }
    
    func toImage() -> UIImage? {
        hideLeftButton = true
        let headerImage = self.takeScreenshot()
        hideLeftButton = false
        if let image = getBackgroundImage() {
            return merge2Images(backgroundImage: image, topImage: headerImage)
        }
        return nil
    }
    
    func merge2Images(backgroundImage: UIImage, topImage: UIImage) -> UIImage? {
        let size = CGSize(width: backgroundImage.size.width, height: backgroundImage.size.height)
        UIGraphicsBeginImageContext(size)
        let areaSize = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        backgroundImage.draw(in: areaSize)
        topImage.draw(in: areaSize, blendMode: .normal, alpha: 1)
        let mergedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return mergedImage
    }
}
