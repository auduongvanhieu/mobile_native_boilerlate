//
//  MeasureItem.swift
//  REPACE
//
//  Created by Van Huy Pham on 10/29/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class MeasureItem: UIView {
    @IBOutlet weak var heartrateLabel: UILabel!
    @IBOutlet weak var smO2Label: UILabel!
    @IBOutlet weak var rxExerciseLabel: UILabel!
    @IBOutlet weak var lblExerciseUnit: UILabel!
    let nibName = "MeasureItem"
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    func bindToData(model: ExerciseAverage, exerciseUnit: String?) {
        if let heartRateAvg = model.heartRateAvg, heartRateAvg > 0 {
            heartrateLabel.text = "\(heartRateAvg.toInt)"
            heartrateLabel.textAlignment = .right
        } else {
            heartrateLabel.text = "-"
            heartrateLabel.textAlignment = .center
        }
        if let smo2Avg = model.smo2Avg, smo2Avg > 0 {
            smO2Label.text = "\(smo2Avg.toInt)"
            smO2Label.textAlignment = .right
        } else {
            smO2Label.text = "-"
            smO2Label.textAlignment = .center
        }
        if let rxExercise = model.rxExercise, rxExercise > 0 {
            rxExerciseLabel.text = "\(rxExercise)"
            rxExerciseLabel.textAlignment = .right
        } else {
            rxExerciseLabel.text = "-"
            rxExerciseLabel.textAlignment = .center
        }
        lblExerciseUnit.text = exerciseUnit
    }
}
