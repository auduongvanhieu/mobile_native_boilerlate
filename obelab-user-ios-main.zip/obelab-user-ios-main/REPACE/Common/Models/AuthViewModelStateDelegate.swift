//
//  AuthViewModelStateDelegate.swift
//  REPACE
//
//  Created by German on 5/20/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit
import Toaster

enum AuthViewModelState {
    case network(state: NetworkState)
}

protocol NetworkStatusDelegate: class {
  func networkStatusChanged(to networkStatus: NetworkState)
}

protocol AuthViewModelStateDelegate: NetworkStatusDelegate {
  func didUpdateState(to state: AuthViewModelState)
}

extension AuthViewModelStateDelegate where Self: UIViewController {
  func didUpdateState(to state: AuthViewModelState) {
    switch state {
    case .network(let networkStatus):
      networkStatusChanged(to: networkStatus)
    }
  }
}

extension NetworkStatusDelegate where Self: UIViewController {
  func networkStatusChanged(to networkStatus: NetworkState) {
    let viewController = self as? ActivityIndicatorPresenter
    switch networkStatus {
    case .loading:
        viewController?.showActivityIndicator(true)
    case .hideLoading:
        viewController?.showActivityIndicator(false)
    case .loadingPercent(let percent):
        viewController?.showPercentLabel(percent: percent)
    case .error(let errorDescription):
        if errorDescription == "disconnect_network".localized {
            showAlertDisconnectInternet()
        } else {
            showMessage(title: "Error", message: errorDescription)
        }
    default:
      break
    }
  }
    
    func showAlertDisconnectInternet() {
        showMessage(title: "", message: "disconnect_network".localized, buttonTitle: "cancel".localized, handle: nil) { _ in
            self.checkInternetConnection()
        }
    }
    
    func checkInternetConnection() {
        if Connectivity.isConnectedToInternet == false {
            self.showAlertDisconnectInternet()
        } else {
            if let viewController = self as? BaseViewController {
                viewController.showToast(message: "connection_restore".localized)
            }
        }
    }
}
