//
//  ExerciseModelService.swift
//  REPACE
//
//  Created by BM Johnny on 31/03/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift
import Network

class ExerciseModelService: NSObject {

    var object: ResultExerciseObject!
    var monitor: AnyObject?
    
    func uploadFile(object: ResultExerciseObject, updatePercent: ((Double) -> Void)?, failAPI: ((String) -> Void)?) {
        self.object = object
        RealmHelper.share.loadS3File {[weak self] (text) in
            self?.updateBLEData(text: text, failAPI: failAPI, updatePercent: updatePercent)
        }
        if #available(iOS 12.0, *) {
            monitor = NWPathMonitor()
            if let monitor = monitor as? NWPathMonitor {
                monitor.pathUpdateHandler = { path in
                    if path.status != .satisfied {
                        Functions.showLog(title: "ExerciseModelService Internet is disconnected", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Internet is disconnected", content: "")
                    } else if path.usesInterfaceType(.cellular) {
                        Functions.showLog(title: "ExerciseModelService Connect Internet by Cellular", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Connect Internet by Cellular", content: "")
                    } else if path.usesInterfaceType(.wifi) {
                        Functions.showLog(title: "ExerciseModelService Connect Internet by WIFI", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Connect Internet by WIFI", content: "")
                    } else if path.usesInterfaceType(.wiredEthernet) {
                        Functions.showLog(title: "ExerciseModelService Connect Internet by Ethernet", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Connect Internet by Ethernet", content: "")
                    } else if path.usesInterfaceType(.other) {
                        Functions.showLog(title: "ExerciseModelService Connect Internet by Other", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Connect Internet by Other", content: "")
                    } else if path.usesInterfaceType(.loopback) {
                        Functions.showLog(title: "ExerciseModelService Connect Internet by Loop Back", message: path)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService Connect Internet Loop Back", content: "")
                    }
                }
                monitor.start(queue: DispatchQueue.global(qos: .background))
            }
        } else {
            // Fallback on earlier versions
        }
    }
    
     private func updateBLEData(text: String, failAPI: ((String) -> Void)?, updatePercent: ((Double) -> Void)?) {
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let directory = FileHelper.getS3MeasureFileDirectory()
            let dirURL = dir.appendingPathComponent(directory)
            if FileManager.default.fileExists(atPath: dirURL.path) == false {
                do {
                    // Create folder
                    try FileManager.default.createDirectory(atPath: dirURL.path, withIntermediateDirectories: true, attributes: nil)
                } catch {
                    Functions.showLog(title: "Create document folder fail", message: "")
                    failAPI?("Create document folder fail")
                }
            }
            do {
                let fileName = FileHelper.getMeasureFileName()
                let s3FileName = FileHelper.getS3MeasureFileName(fileName: fileName)
                let fileURL = dir.appendingPathComponent(s3FileName)
                try text.write(to: fileURL, atomically: false, encoding: .utf8)
                self.object.bleData = fileName
                if BluetoothHelper.ltTestResult != nil {
                    BluetoothHelper.ltTestResult?.bleData = fileName
                }
                if BluetoothHelper.exerciseResult != nil {
                    BluetoothHelper.exerciseResult?.bleData = fileName
                }
                // Save Local DB
                self.object.save { realm in
                    if realm != nil {
                        FileHelper.writeStringToLogFile(title: "updateBLEData ExerciseModelService save local data success", content: "")
                        // Upload to server
                        self.uploadExerciseData(failAPI: failAPI, updatePercent: updatePercent)
                    } else {
                        FileHelper.writeStringToLogFile(title: "updateBLEData ExerciseModelService save local data fail", content: "")
                        failAPI?("Save local data fail")
                    }
                }
            } catch {
                Functions.showLog(title: "write string to file error", message: error)
                FileHelper.writeStringToLogFile(title: "updateBLEData ExerciseModelService write string to file fail", content: "")
                failAPI?("Write string to file fail")
            }
        } else {
            FileHelper.writeStringToLogFile(title: "updateBLEData ExerciseModelService create local document fail", content: "")
            failAPI?("Create local document fail")
        }
    }
    
    func uploadExerciseData(failAPI: ((String) -> Void)?, updatePercent: ((Double) -> Void)?) {
        if object != nil {
            if object.isInvalidated == false {
                RealmHelper.share.saveExercise(isLTTest: object.isKind(of: LTTestResultObject.self), idExercise: object.id, isFailByConnection: { isFailByConnection in
                    Functions.showLog(title: "Mytv ExerciseModelService uploadExerciseData isFailByConnection error", message: isFailByConnection)
                    if let isFailByConnection = isFailByConnection as? Bool {
                        self.didFailUploadingData(isFailByConnection: isFailByConnection)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService upload local data fail exercise id \(self.object.id) with isFailByConnection = \(isFailByConnection)", content: "")
                    } else if let errStr = isFailByConnection as? String {
                        failAPI?(errStr)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService upload local data fail exercise id \(self.object.id) with isFailByConnection = \(errStr)", content: "")
                    } else if let err = isFailByConnection as? Error {
                        failAPI?(err.localizedDescription)
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService upload local data fail exercise id \(self.object.id) with isFailByConnection = \(err.localizedDescription)", content: "")
                    } else {
                        failAPI?("Unknown error")
                        FileHelper.writeStringToLogFile(title: "ExerciseModelService upload local data fail exercise id \(self.object.id) with isFailByConnection Unknown error", content: "")
                    }
                }, completion: { res in
                    if #available(iOS 12.0, *) {
                        if let monitor = self.monitor as? NWPathMonitor {
                            monitor.cancel()
                        }
                    } else {
                        // Fallback on earlier versions
                    }
                    self.monitor = nil
                    self.didFinishUploadingData(res: res)
                    FileHelper.writeStringToLogFile(title: "ExerciseModelService upload local data success", content: "")
                }, updatePercent: updatePercent)
            } else {
                failAPI?("Object is invalidate")
                FileHelper.writeStringToLogFile(title: "ExerciseModelService uploadExerciseData object is invalidate", content: "")
            }
        } else {
            failAPI?("Object is nil")
            FileHelper.writeStringToLogFile(title: "ExerciseModelService uploadExerciseData object is nil", content: "")
        }
    }
    
    func updateCreatedAt() {
        if let object = object,
            object.isInvalidated == false {
            Functions.showLog(title: "ExerciseModelService updateCreatedAt", message: object)
            FileHelper.writeStringToLogFile(title: "ExerciseModelService add create at Time when post data", content: "")
            object.addPostCreatedAt()
        }
    }
    
    // Sub class overrite when upload fail (show alert)
    func didFailUploadingData(isFailByConnection: Bool) {
        
    }
    // Sub class overrite and do when upload success
    func didFinishUploadingData(res: Any) {
        
    }
    
    deinit {
        if #available(iOS 12.0, *) {
            if let monitor = monitor as? NWPathMonitor {
                monitor.cancel()
            }
        } else {
            // Fallback on earlier versions
        }
        monitor = nil
    }
}
