//
//  NetworkState.swift
//  REPACE
//
//  Created by German on 5/20/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import Foundation

enum NetworkState: Equatable {
    case idle, loading, hideLoading, error(_ error: String), loadingPercent(percent: Double?)
}
