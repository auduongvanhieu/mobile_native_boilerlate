//
//  ActivityIndicatorPresenter.swift
//  REPACE
//
//  Created by Germán Stábile on 5/21/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import UIKit

protocol ActivityIndicatorPresenter: class {
    var activityIndicator: UIActivityIndicatorView { get }
    var labelPercent: UILabel { get }
    func showActivityIndicator(_ show: Bool)
    func showPercentLabel(percent: Double?)
}

extension ActivityIndicatorPresenter where Self: UIViewController {
    func showActivityIndicator(_ show: Bool) {
        view.isUserInteractionEnabled = !show
        
        guard show else {
            activityIndicator.removeFromSuperview()
            labelPercent.removeFromSuperview()
            return
        }
        
        if activityIndicator.superview == nil {
            view.addSubview(activityIndicator)
        }
        activityIndicator.color = .white
        activityIndicator.transform = CGAffineTransform(scaleX: 2, y: 2)
        activityIndicator.frame = view.bounds
        activityIndicator.startAnimating()
    }
    
    func showPercentLabel(percent: Double?) {
//        if let percent = percent, percent > 0 && percent < 100 {
//            if labelPercent.superview == nil {
//                view.addSubview(labelPercent)
//                labelPercent.translatesAutoresizingMaskIntoConstraints = false
//                labelPercent.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//                labelPercent.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 35).isActive = true
//                labelPercent.textColor = .white
//                labelPercent.textAlignment = .center
//                labelPercent.font = UIFont.boldSystemFont(ofSize: 17.0)
//            }
//            labelPercent.text = "\(percent.to1Decimal) %"
//        } else {
//            labelPercent.removeFromSuperview()
//        }
    }
}
