//
//  LTTestResultObject.swift
//  REPACE
//
//  Created by BM Johnny on 04/05/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift
import Realm

class LTTestResultObject: ResultExerciseObject {
    
    @Persisted var ltTestID: Int
    @Persisted var ltTestSettingModelMemberID: Int
    @Persisted var remoteID: Int
    @Persisted var testTypeID: String
    @Persisted var stageCnt: Int
    @Persisted var status: Int
    @Persisted var lastSpeed: Double
    @Persisted var protocolType: Int
    @Persisted var listAnalysis: List<RepaceAnalysisObject>
    @Persisted var listLactate: List<SmO2ChartObject>
    @Persisted var stage: List<RepaceStageObject>
    
    func convertToLTTestResultModel(isPostToServer: Bool) -> LTTestResultModel {
        var result = LTTestResultModel()
        result.ltTestID = self.ltTestID
        result.ltTestSettingModelMemberID = self.ltTestSettingModelMemberID
        result.remoteID = self.remoteID
        result.testTypeID = self.testTypeID
        result.stageCnt = self.stageCnt
        result.status = self.status
        result.lastSpeed = self.lastSpeed
        result.protocolType = self.protocolType
        result.listAnalysis = getAnalysisJson()
        result.listLactate = getArraySmO2(list: self.listLactate)
        result.stage = []
        self.stage.forEach { object in
            result.stage?.append(object.convertToRepaceStageModel())
        }
        if let targetModel = convertToModel(model: result, isPostToServer: isPostToServer) as? LTTestResultModel {
            return targetModel
        }
        return result
    }
    
    func convertToLTTestHistoryTempModel() -> LTTestHistoryTempModel {
        LTTestHistoryTempModel(id: self.id, stage: self.stageCnt, lactateOnset: self.onset, duration: self.totalDuration, distance: self.totalDistance, smO2Avg: self.smo2Avg, speedMax: self.speedMax, speedAvg: self.speedAvg, date: self.createdAt ?? "")
    }
    
    func getListAnalysisModel() -> [RepaceAnalysisModel] {
        var arr: [RepaceAnalysisModel] = []
        self.listAnalysis.forEach({ object in
            arr.append(RepaceAnalysisModel(isNext: object.isNext, lactate: object.lactate, speed: object.speed, onset: object.onset, threshold: object.threshold))
        })
        return arr
    }
    
    func getAnalysisJson() -> String {
        let arr = getListAnalysisModel()
        if arr.isEmpty == false {
            return Functions.structToJsonStr(arr)
        }
        return ""
    }
}

class RepaceStageObject: Object {
    @Persisted var stage: Int
    @Persisted var speed: Double
    @Persisted var distance: Double
    @Persisted var duration: Int
    @Persisted var avgSmO2: Double
    @Persisted var avgHeartRate: Double
    
    convenience init(model: RepaceStageModel) {
        self.init()
        self.stage = model.stage ?? 0
        self.speed = model.speed ?? 0
        self.distance = model.distance ?? 0
        self.duration = model.duration ?? 0
        self.avgSmO2 = model.avgSmO2 ?? 0
        self.avgHeartRate = model.avgHeartRate ?? 0
    }
    
    func convertToRepaceStageModel() -> RepaceStageModel {
        RepaceStageModel(stage: self.stage, speed: self.speed, distance: self.distance, duration: self.duration, avgSmO2: self.avgSmO2, avgHeartRate: self.avgHeartRate)
    }
}
