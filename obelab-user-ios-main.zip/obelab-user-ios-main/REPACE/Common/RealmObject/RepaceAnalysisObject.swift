//
//  RepaceAnalysisObject.swift
//  REPACE
//
//  Created by BM Johnny on 05/05/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift

class RepaceAnalysisObject: Object {
    @Persisted var isNext: Bool
    @Persisted var lactate: Double
    @Persisted var speed: Double
    @Persisted var onset: Double
    @Persisted var threshold: Double
    
    convenience init(model: RepaceAnalysisModel) {
        self.init()
        self.isNext = model.isNext
        self.lactate = model.lactate
        self.speed = model.speed
        self.onset = model.onset
        self.threshold = model.threshold
    }
}
