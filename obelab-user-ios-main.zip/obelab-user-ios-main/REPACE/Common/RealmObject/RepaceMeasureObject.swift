//
//  RepaceMeasureObject.swift
//  REPACE
//
//  Created by BM Johnny on 31/03/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift

class RepaceMeasureObject: Object {
    @Persisted var index: Int
    @Persisted var ch1_780: Int
    @Persisted var ch1_850: Int
    @Persisted var ch1_940: Int
    @Persisted var ch1_680: Int
    @Persisted var ch2_780: Int
    @Persisted var ch2_850: Int
    @Persisted var ch2_940: Int
    @Persisted var ch2_680: Int
    @Persisted var ch3_780: Int
    @Persisted var ch3_850: Int
    @Persisted var ch3_940: Int
    @Persisted var ch3_680: Int
    @Persisted var ch4_780: Int
    @Persisted var ch4_850: Int
    @Persisted var ch4_940: Int
    @Persisted var ch4_680: Int
    @Persisted var ch5_780: Int
    @Persisted var ch5_850: Int
    @Persisted var ch5_940: Int
    @Persisted var ch5_680: Int
    @Persisted var ch6_780: Int
    @Persisted var ch6_850: Int
    @Persisted var ch6_940: Int
    @Persisted var ch6_680: Int
    @Persisted var rSO2: Double
    @Persisted var ac_x: Int
    @Persisted var ac_y: Int
    @Persisted var ac_z: Int
    @Persisted var gyro_x: Int
    @Persisted var gyro_y: Int
    @Persisted var gyro_z: Int
    @Persisted var bleHex: String
    @Persisted var marker: Int
    
    convenience init(model: RepaceMeasureDetailModel) {
        self.init()
        self.index = model.index ?? 0
        self.ch1_780 = model.ch1_780 ?? 0
        self.ch1_850 = model.ch1_850 ?? 0
        self.ch1_940 = model.ch1_940 ?? 0
        self.ch1_680 = model.ch1_680 ?? 0
        self.ch2_780 = model.ch2_780 ?? 0
        self.ch2_850 = model.ch2_850 ?? 0
        self.ch2_940 = model.ch2_940 ?? 0
        self.ch2_680 = model.ch2_680 ?? 0
        self.ch3_780 = model.ch3_780 ?? 0
        self.ch3_850 = model.ch3_850 ?? 0
        self.ch3_940 = model.ch3_940 ?? 0
        self.ch3_680 = model.ch3_680 ?? 0
        self.ch4_780 = model.ch4_780 ?? 0
        self.ch4_850 = model.ch4_850 ?? 0
        self.ch4_940 = model.ch4_940 ?? 0
        self.ch4_680 = model.ch4_680 ?? 0
        self.ch5_780 = model.ch5_780 ?? 0
        self.ch5_850 = model.ch5_850 ?? 0
        self.ch5_940 = model.ch5_940 ?? 0
        self.ch5_680 = model.ch5_680 ?? 0
        self.ch6_780 = model.ch6_780 ?? 0
        self.ch6_850 = model.ch6_850 ?? 0
        self.ch6_940 = model.ch6_940 ?? 0
        self.ch6_680 = model.ch6_680 ?? 0
        self.rSO2 = model.rSO2 ?? 0
        self.ac_x = model.ac_x ?? 0
        self.ac_y = model.ac_y ?? 0
        self.ac_z = model.ac_z ?? 0
        self.gyro_x = model.gyro_x ?? 0
        self.gyro_y = model.gyro_y ?? 0
        self.gyro_z = model.gyro_z ?? 0
        self.bleHex = model.bleHex ?? ""
        self.marker = model.marker ?? 0
    }
    
    func convertToRepaceMeasureDetailModel() -> RepaceMeasureDetailModel {
        var model = RepaceMeasureDetailModel()
        model.index = index
        model.ch1_780 = ch1_780
        model.ch1_850 = ch1_850
        model.ch1_940 = ch1_940
        model.ch1_680 = ch1_680
        model.ch2_780 = ch2_780
        model.ch2_850 = ch2_850
        model.ch2_940 = ch2_940
        model.ch2_680 = ch2_680
        model.ch3_780 = ch3_780
        model.ch3_850 = ch3_850
        model.ch3_940 = ch3_940
        model.ch3_680 = ch3_680
        model.ch4_780 = ch4_780
        model.ch4_850 = ch4_850
        model.ch4_940 = ch4_940
        model.ch4_680 = ch4_680
        model.ch5_780 = ch5_780
        model.ch5_850 = ch5_850
        model.ch5_940 = ch5_940
        model.ch5_680 = ch5_680
        model.ch6_780 = ch6_780
        model.ch6_850 = ch6_850
        model.ch6_940 = ch6_940
        model.ch6_680 = ch6_680
        model.rSO2 = rSO2
        model.ac_x = ac_x
        model.ac_y = ac_y
        model.ac_z = ac_z
        model.gyro_x = gyro_x
        model.gyro_y = gyro_y
        model.gyro_z = gyro_z
        model.bleHex = bleHex
        model.marker = marker
        return model
    }
}
