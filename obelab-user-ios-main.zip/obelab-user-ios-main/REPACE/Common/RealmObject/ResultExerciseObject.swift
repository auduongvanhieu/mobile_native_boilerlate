//
//  ResultExerciseObject.swift
//  REPACE
//
//  Created by BM Johnny on 04/05/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift

class ResultExerciseObject: Object {
    @Persisted var id: Int
    @Persisted var memberID: Int
    @Persisted var totalDuration: Int
    @Persisted var totalDistance: Double
    @Persisted var onset: Double
    @Persisted var mol: Double
    @Persisted var bleData: String
    @Persisted var isUploadedS3File: Bool
    @Persisted var isUploadedExercise: Bool
    @Persisted var smo2Min: Double
    @Persisted var smo2Max: Double
    @Persisted var smo2Avg: Double
    @Persisted var speedMin: Double
    @Persisted var speedMax: Double
    @Persisted var speedAvg: Double
    @Persisted var heartRateMin: Double
    @Persisted var heartRateMax: Double
    @Persisted var heartRateAvg: Double
    @Persisted var listSmo2: List<SmO2ChartObject>
    @Persisted var listLocation: List<LocationObject>
    @Persisted var createdAt: String?
    @Persisted var isLock = false // if it is uploading isLock = true
    @Persisted var isAttachCreatedAt = false // True post createAt field, false not post createdAt
    
    func convertToModel(model: Any, isPostToServer: Bool) -> Any? {
        if let targetModel = model as? ExerciseResultModel {
            var resultModel = targetModel
            resultModel.id = self.id
            resultModel.memberID = self.memberID
            resultModel.totalDistance = self.totalDistance
            resultModel.totalDuration = self.totalDuration
            resultModel.onset = Int(self.onset)
            resultModel.mol = Int(self.mol)
            resultModel.bleData = self.bleData
            resultModel.smo2Min = self.smo2Min
            resultModel.smo2Max = self.smo2Max
            resultModel.smo2Avg = self.smo2Avg
            resultModel.speedMin = self.speedMin
            resultModel.speedMax = self.speedMax
            resultModel.speedAvg = self.speedAvg
            resultModel.heartRateMin = Int(self.heartRateMin)
            resultModel.heartRateMax = Int(self.heartRateMax)
            resultModel.heartRateAvg = self.heartRateAvg
            resultModel.listSmo2 = getArraySmO2(list: self.listSmo2)
            resultModel.listLocation = getArrayLocation(list: self.listLocation)
            if isPostToServer {
                if isAttachCreatedAt {
                    resultModel.createdAt = self.createdAt
                } else {
                    resultModel.createdAt = nil
                }
            } else {
                resultModel.createdAt = self.createdAt
            }
            return resultModel
        } else if let targetModel = model as? LTTestResultModel {
            var resultModel = targetModel
            resultModel.id = self.id
            resultModel.memberID = self.memberID
            resultModel.totalDistance = self.totalDistance
            resultModel.totalDuration = self.totalDuration
            resultModel.onset = self.onset
            resultModel.mol = self.mol
            resultModel.bleData = self.bleData
            resultModel.smo2Min = self.smo2Min
            resultModel.smo2Max = self.smo2Max
            resultModel.smo2Avg = self.smo2Avg
            resultModel.speedMin = self.speedMin
            resultModel.speedMax = self.speedMax
            resultModel.speedAvg = self.speedAvg
            resultModel.heartRateMin = self.heartRateMin
            resultModel.heartRateMax = self.heartRateMax
            resultModel.heartRateAvg = self.heartRateAvg
            resultModel.listSmo2 = getArraySmO2(list: self.listSmo2)
            resultModel.listLocation = getArrayLocation(list: self.listLocation)
            if isPostToServer {
                if isAttachCreatedAt {
                    resultModel.createdAt = self.createdAt
                } else {
                    resultModel.createdAt = nil
                }
            } else {
                resultModel.createdAt = self.createdAt
            }
            return resultModel
        }                               
        return nil
    }
    
    func getFromModel(model: Any) {
        if let resultModel = model as? ExerciseResultModel {
            self.id = resultModel.id ?? 0
            self.totalDistance = resultModel.totalDistance ?? 0
            self.totalDuration = resultModel.totalDuration ?? 0
            self.onset = Double(resultModel.onset ?? 0)
            self.mol = Double(resultModel.mol ?? 0)
            self.bleData = resultModel.bleData ?? ""
            self.smo2Min = resultModel.smo2Min ?? 0
            self.smo2Max = resultModel.smo2Max ?? 0
            self.smo2Avg = resultModel.smo2Avg ?? 0
            self.speedMin = resultModel.speedMin ?? 0
            self.speedMax = resultModel.speedMax ?? 0
            self.speedAvg = resultModel.speedAvg ?? 0
            self.heartRateMin = Double(resultModel.heartRateMin ?? 0)
            self.heartRateMax = Double(resultModel.heartRateMax ?? 0)
            self.heartRateAvg = Double(resultModel.heartRateAvg ?? 0)
            self.listSmo2 = getListSmO2(list: resultModel.listSmo2)
            self.listLocation = getListLocation(list: resultModel.listLocation)
            self.createdAt = resultModel.createdAt
        } else if let resultModel = model as? LTTestResultModel {
            self.id = resultModel.id ?? 0
            self.totalDistance = resultModel.totalDistance ?? 0
            self.totalDuration = resultModel.totalDuration ?? 0
            self.onset = Double(resultModel.onset ?? 0)
            self.mol = Double(resultModel.mol ?? 0)
            self.bleData = resultModel.bleData ?? ""
            self.smo2Min = resultModel.smo2Min ?? 0
            self.smo2Max = resultModel.smo2Max ?? 0
            self.smo2Avg = resultModel.smo2Avg ?? 0
            self.speedMin = resultModel.speedMin ?? 0
            self.speedMax = resultModel.speedMax ?? 0
            self.speedAvg = resultModel.speedAvg ?? 0
            self.heartRateMin = Double(resultModel.heartRateMin ?? 0)
            self.heartRateMax = Double(resultModel.heartRateMax ?? 0)
            self.heartRateAvg = Double(resultModel.heartRateAvg ?? 0)
            self.listSmo2 = getListSmO2(list: resultModel.listSmo2)
            self.listLocation = getListLocation(list: resultModel.listLocation)
            self.createdAt = resultModel.createdAt
        }
        self.memberID = LocalDataManager.profile?.id ?? 0
        self.isUploadedExercise = false
        self.isUploadedS3File = false
    }
    
    func getArraySmO2(list: List<SmO2ChartObject>) -> [SmO2ChartModel] {
        var result: [SmO2ChartModel] = []
        list.forEach { object in
            result.append(SmO2ChartModel(name: object.name, score: object.score))
        }
        return result
    }
    
    private func getArrayLocation(list: List<LocationObject>) -> [LocationModel] {
        var result: [LocationModel] = []
        list.forEach { object in
            result.append(LocationModel(latitude: object.latitude, longitude: object.longitude, time: object.time))
        }
        return result
    }
    
    private func getListSmO2(list: [SmO2ChartModel]?) -> List<SmO2ChartObject> {
        Functions.getListSmO2(list: list)
    }
    
    private func getListLocation(list: [LocationModel]?) -> List<LocationObject> {
        let result = List<LocationObject>()
        if let list = list {
            for (index, model) in list.enumerated() {
                result.append(LocationObject(index: index, model: model, period: nil, exerciseID: self.id))
            }
        }
        return result
    }
    
    func uploadData(isFailByConnection: ((Any) -> Void)?, finishSM3: ((String) -> Void)?, finishExercise: (() -> Void)?, isLock: ((Bool) -> Void)?, completion: ((Any) -> Void)? = nil, updatePercent: ((Double) -> Void)?) {
        if self.isUploadedS3File == false {
            // S3 file did Not uploaded
            FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload S3 data isUploadedS3File", content: "\(self.isUploadedS3File)")
            if self.bleData.isEmpty == false {
                let fileName = self.bleData
                let s3FileName = FileHelper.getS3MeasureFileName(fileName: fileName)
                if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    let fileURL = dir.appendingPathComponent(s3FileName)
                    if FileManager.default.fileExists(atPath: fileURL.path) == true {
                        uploadImageToS3With(fileURL: fileURL, fileName: fileName, finishSM3: { path in
                            do {
                                try FileManager.default.removeItem(atPath: fileURL.path)
                            } catch let err {
                                Functions.showLog(title: "Clean local file \(fileURL.absoluteString) error \(err.localizedDescription)", message: err)
                            }
                            finishSM3?(path)
                            self.uploadExercise(finishExercise: finishExercise, isFailByConnection: isFailByConnection, isLock: isLock, completion: completion)
                        }, isFailByConnection: isFailByConnection, isLock: isLock, completion: completion, updatePercent: updatePercent)
                    }
                }
            } else {
                FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload S3 data but bleData is empty, isUploadedS3File", content: "\(self.isUploadedS3File)")
                if self.isUploadedExercise == false {
                    FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload S3 data but bleData is empty, upload exercise data isUploadedExercise", content: "\(self.isUploadedExercise)")
                    self.uploadExercise(finishExercise: finishExercise, isFailByConnection: isFailByConnection, isLock: isLock, completion: completion)
                }
            }
        } else if self.isUploadedExercise == false {
            // Exercise did not uploaded
            FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload exercise data isUploadedExercise", content: "\(self.isUploadedExercise)")
            uploadExercise(finishExercise: finishExercise, isFailByConnection: isFailByConnection, isLock: isLock, completion: completion)
        } else {
            FileHelper.writeStringToLogFile(title: "ResultExerciseObject object is uploaded, isUploadedS3File -> \(self.isUploadedS3File), isUploadedExercise", content: "\(self.isUploadedExercise)")
            completion?("Object is uploaded")
        }
    }
    
    private func uploadImageToS3With(fileURL: URL, fileName: String, finishSM3: ((String) -> Void)?, isFailByConnection: ((Any) -> Void)?, isLock: ((Bool) -> Void)?, completion: ((Any) -> Void)? = nil, updatePercent: ((Double) -> Void)?) {
        if Connectivity.isConnectedToInternet == false {
            isFailByConnection?(true)
            isLock?(false)
            return
        }
        isLock?(true)
        FileHelper.writeStringToLogFile(title: "ResultExerciseObject start upload S3", content: "")
        DispatchQueue.global(qos: .background).async {
            AWSS3Manager.shared.uploadfile(fileUrl: fileURL, fileName: fileName, contenType: "txt", progress: { uploadProgress in
                updatePercent?(uploadProgress * 100)
                Functions.showLog(title: "Mytv S3UploadProgress", message: uploadProgress)
            }, completion: { (uploadedFileUrl, error) in
                if let error = error {
                    Functions.showLog(title: "AWSS3Manager fail", message: error)
                    if let urlError = error as? URLError,
                       (urlError.code == URLError.Code.notConnectedToInternet ||
                        urlError.code == URLError.Code.timedOut) {
                        isFailByConnection?(true)
                    } else if error.localizedDescription == "disconnect_network".localized {
                        isFailByConnection?(true)
                    } else {
                        isFailByConnection?(error.localizedDescription)
                    }
                    isLock?(false)
                    FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload S3 finish with error ", content: "\(error.localizedDescription)")
                } else {
                    // Success
                    if let finalPath = uploadedFileUrl as? String { // 3
                        finishSM3?(finalPath)
                        Functions.showLog(title: "S3FinalPath", message: finalPath)
                    } else {
                        Functions.showLog(title: "S3FinalPath", message: uploadedFileUrl ?? "uploadedFileUrl fail, it is not a String")
                    }
                    FileHelper.writeStringToLogFile(title: "ResultExerciseObject upload S3 finish success", content: "")
                }
            })
        }
    }
    
    func uploadExercise(finishExercise: (() -> Void)?, isFailByConnection: ((Any) -> Void)?, isLock: ((Bool) -> Void)?, completion: ((Any) -> Void)? = nil) {
        if Connectivity.isConnectedToInternet == false {
            isFailByConnection?(true)
            isLock?(false)
            return
        }
        FileHelper.writeStringToLogFile(title: "Begin Upload Exercise data", content: "")
        if let ltTest = self as? LTTestResultObject {
            let ltTestResult = ltTest.convertToLTTestResultModel(isPostToServer: true)
            isLock?(true)
            LTTestServices.postLTTestResult(ltTestResult: ltTestResult, listAnalysis: ltTest.getListAnalysisModel(),
                success: { res in
                    isLock?(false)
                    finishExercise?()
                    Functions.showLog(title: "postLTTestResult Success", message: ltTestResult)
                    FileHelper.writeStringToLogFile(title: "Upload LT Test Exercise success", content: "")
                    completion?(res)
                },
                failure: { error in
                    isLock?(false)
                    if error.localizedDescription == "disconnect_network".localized {
                        isFailByConnection?(true)
                    } else {
                        isFailByConnection?(error.localizedDescription)
                    }
                    Functions.showLog(title: "postLTTestResult Error", message: error.localizedDescription)
                    FileHelper.writeStringToLogFile(title: "Upload LT Test Exercise fail with error  \(error.localizedDescription)", content: "")
                }
            )
        } else if let exerciseResult = self as? RxExerciseResultObject {
            let exercise = exerciseResult.convertToExerciseResultModel(isPostToServer: true)
            isLock?(true)
            ExerciseServices.postExerciseResult(exercise: exercise,
                success: { res in
                    isLock?(false)
                    finishExercise?()
                    Functions.showLog(title: "postExerciseResult Success", message: exercise)
                    FileHelper.writeStringToLogFile(title: "Upload Rx Exercise success", content: "")
                    completion?(res)
                },
                failure: { error in
                    isLock?(false)
                    if error.localizedDescription == "disconnect_network".localized {
                        isFailByConnection?(true)
                    } else {
                        isFailByConnection?(error.localizedDescription)
                    }
                    Functions.showLog(title: "postExerciseResult Error", message: error.localizedDescription)
                    FileHelper.writeStringToLogFile(title: "Upload Rx Exercise fail with error  \(error.localizedDescription)", content: "")
                }
            )
        }
    }
    
    func addPostCreatedAt() {
        do {
            let realm = try Realm()
            try realm.write {
                self.isAttachCreatedAt = true
            }
        } catch let error {
            Functions.showLog(title: "updateCreatedAt error", message: error)
        }
    }
}

class SmO2ChartObject: Object {
    @Persisted var name: String
    @Persisted var score: Double
    
    convenience init(model: SmO2ChartModel) {
        self.init()
        self.name = model.name ?? ""
        self.score = model.score ?? 0
    }
}

class LocationObject: Object {
    @Persisted var index: Int
    @Persisted var time: Int
    @Persisted var latitude: Double
    @Persisted var longitude: Double
    @Persisted var period: String?
    @Persisted var memberID: Int
    @Persisted var exerciseID: Int
    
    convenience init(index: Int, model: LocationModel, period: String?, exerciseID: Int) {
        self.init()
        self.index = index
        self.time = model.time ?? 0
        self.latitude = model.latitude ?? 0
        self.longitude = model.longitude ?? 0
        self.period = period
        self.memberID = LocalDataManager.profile?.id ?? 0
        self.exerciseID = exerciseID
    }
}

class HeartrateObject: Object {
    @Persisted var index: Int
    @Persisted var heartrate: Double
    @Persisted var period: String?
    
    convenience init(index: Int, heartrate: Double, period: String?) {
        self.init()
        self.index = index
        self.heartrate = heartrate
        self.period = period
    }
}
