//
//  RxExerciseResultObject.swift
//  REPACE
//
//  Created by BM Johnny on 04/05/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift

class RxExerciseResultObject: ResultExerciseObject {
    @Persisted var exerciseID: Int
    @Persisted var typeID: String?
    @Persisted var intensityID: String?
    @Persisted var activityID: String?
    @Persisted var status: Int
    @Persisted var sessionCnt: Int
    @Persisted var time: Int
    @Persisted var startTime: String
    @Persisted var endTime: String
    @Persisted var updatedAt: String
    @Persisted var speed: Double
    @Persisted var heartRate: Int
    @Persisted var listHeartRate: List<SmO2ChartObject>
    
    func convertToExerciseResultModel(isPostToServer: Bool) -> ExerciseResultModel {
        var result = ExerciseResultModel()
        result.exerciseID = self.exerciseID
        result.typeID = self.typeID
        result.intensityID = self.intensityID
        result.activityID = self.activityID
        result.status = self.status
        result.sessionCnt = self.sessionCnt
        result.time = self.time
        result.startTime = self.startTime
        result.endTime = self.endTime
        result.updatedAt = self.updatedAt
        result.heartRate = self.heartRate
        result.speed = self.speed
        result.listHeartRate = getArraySmO2(list: self.listHeartRate)
        result.isFromLocal = true
        if let targetModel = convertToModel(model: result, isPostToServer: isPostToServer) as? ExerciseResultModel {
            return targetModel
        }
        return result
    }
}
