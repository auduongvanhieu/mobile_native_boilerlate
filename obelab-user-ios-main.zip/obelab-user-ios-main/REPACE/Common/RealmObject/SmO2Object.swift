//
//  SmO2Object.swift
//  REPACE
//
//  Created by BM Johnny on 31/03/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift

class SmO2Object: Object {
    @Persisted var index: Int
    @Persisted var rSO2: Double
}
