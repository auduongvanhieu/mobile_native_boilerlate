import UIKit

class RepaceProgress: UIView {

    let nibName = "RepaceProgress"
    let startAngle = -232
    let maxValue = 284.0
    let minValue = 0
    var xValue = 0.0
    var xSpeed = 0.0
    var xStage = "00"
    
    @IBOutlet weak var testProgress: KDCircularProgress!
    @IBOutlet weak var lbStage: UILabel!
    @IBOutlet weak var lbSpeed: UILabel!
    @IBOutlet weak var lbSpeedStandard: UILabel!
    @IBOutlet weak var btnWarn: UIButton!
    @IBOutlet weak var lblTop: UILabel!
    
    @IBOutlet weak var lblUnitSpeed: UILabel!
    override func draw(_ rect: CGRect) {
        layer.masksToBounds = true
        
        self.testProgress.angle = (maxValue * Double(xValue)) / 100.0
        self.lbStage.text = self.xStage
        self.lbSpeed.text = String(Functions.kmToMile(km: self.xSpeed).to1Decimal)
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
    }
    
    func setFakeSpeed(speed: Double) {
        let speed = Functions.kmToMile(km: speed).to1Decimal
        self.lbStage.text = "\(speed)"
    }
    
    func setValue(value: Double) {
        xValue = value < 100 ? value : 100
        self.testProgress.angle = (maxValue * Double(xValue)) / 100.0
    }
    
    func setSpeed(value: Double) {
        xSpeed = value
        let speed = Functions.kmToMile(km: value).to1Decimal
        self.lbSpeed.text = "\(speed)" // "\(value.to1Decimal)"
    }
    
    func setSpeedStandard(value: Double) {
        xSpeed = value
        self.lbSpeedStandard.text = "/\(Functions.kmToMile(km: value))" // "/\(value)"
    }
    
    func setStage(value: Int) {
        xStage = value > 9 ? "\(value)" : "0\(value)"
        self.lbSpeed.text = "\(value)"
    }
    
    func warningToSpeedUp() {
        btnWarn.isHidden = false
        btnWarn.setTitle("warning_to_speed_up".localized, for: .normal)
        lbSpeed.textColor = UI.Color.txtErrorColor
    }
    
    func warningToSpeedDown() {
        btnWarn.isHidden = false
        btnWarn.setTitle("warning_to_speed_down".localized, for: .normal)
        lbSpeed.textColor = UI.Color.txtErrorColor
    }
    
    func hideWarning() {
        btnWarn.isHidden = true
        lbSpeed.textColor = UIColor.white
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    @IBInspectable var value: Double = 0 {
        didSet {
            self.xValue = value
        }
    }
    @IBInspectable var stage: String = "00" {
        didSet {
            self.xStage = stage
        }
    }
    @IBInspectable var speed: Double = 0 {
        didSet {
            self.xSpeed = speed
        }
    }

}
