//
//  RepaceSegmentControl.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/1/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class RepaceSegmentControl : UISegmentedControl {
    
    override func layoutSubviews() {
            super.layoutSubviews()
        }
    
}
