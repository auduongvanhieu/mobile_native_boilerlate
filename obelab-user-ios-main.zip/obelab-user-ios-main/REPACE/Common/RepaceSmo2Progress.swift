import UIKit

class RepaceSmo2Progress: UIView {

    let nibName = "RepaceSmo2Progress"
    let startAngle = -232
    let maxValue = 284.0
    let minValue = 0
    var xValue = 0.0
    
    @IBOutlet weak var smo2Progress: KDCircularProgress!
    @IBOutlet weak var lbSmo2: UILabel!
    
    override func draw(_ rect: CGRect) {
        layer.masksToBounds = true
        
        self.smo2Progress.angle = (maxValue * Double(xValue)) / 100.0
        self.lbSmo2.text = String(self.xValue)
    }
    
    func setSmo2(value: Double){
        xValue = value
        self.lbSmo2.text = "\(value.to1Decimal)"
        self.smo2Progress.angle = (maxValue * Double(xValue < 100 ? xValue : 100)) / 100.0
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
}
