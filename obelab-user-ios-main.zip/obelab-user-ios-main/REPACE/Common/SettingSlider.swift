//
//  SettingSlider.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/8/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

protocol SettingSliderDelegate: NSObjectProtocol {
    func onSeek(type: String, value: Double)
}

class SettingSlider: UIView {
    
    var settingName: String = ""
    var unitName: String = ""
    var settingInfo: String = ""
    var xStep: Float = 0.1
    var showInfo: Bool = false
    var type = LTTestConstants.NUMBER
    
    weak var delegate: SettingSliderDelegate?

    @IBOutlet weak var tvValue: UILabel!
    @IBOutlet weak var tvInfo: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var tvSettingName: UILabel!
    @IBOutlet weak var tvUnitName: UILabel!
    @IBOutlet weak var viewContainerAverage: UIView!
    @IBOutlet weak var tvValueLeading: NSLayoutConstraint!
    @IBOutlet weak var tvWidth: NSLayoutConstraint!
    
    func setValue(value: Double) {
        let roundedValue = round(Float(value) / xStep) * xStep
        slider.setValue(roundedValue, animated: true)
        setUpValue(value: slider.value)
    }
    
    @IBAction func btnInfo_Click(_ sender: Any) {
        showInfo = !showInfo
        tvInfo.isHidden = !showInfo
        viewContainerAverage.isHidden = !showInfo
    }
    
    func setUpValue(value: Float) {
        let roundedValue = round(value / xStep) * xStep
        slider.value = roundedValue
        
        let trackRect = slider.trackRect(forBounds: slider.bounds)
        let thumbRect = slider.thumbRect(forBounds: slider.bounds, trackRect: trackRect, value: roundedValue)
        tvValue.text = String(Double(roundedValue).to1Decimal)
        tvWidth.constant = 30
        if xStep == 1 || slider.value - Float(Int(slider.value)) == 0 {
            tvValue.text = String(Int(round(roundedValue)))
        }
        if roundedValue == slider.maximumValue {
            tvValue.text = (tvValue.text ?? "") + "+"
        }
        let width = tvValue.intrinsicContentSize.width
        if width <= 30 {
            tvValueLeading.constant = thumbRect.minX
        } else {
            tvWidth.constant = width
            tvValueLeading.constant = thumbRect.midX - width / 2
        }
    }
    
    @IBAction func slider_ValueChanged(_ sender: Any) {
        setUpValue(value: slider.value)
        self.delegate?.onSeek(type: type, value: Double(slider.value))
    }
    
    @IBInspectable var value: Float = 0 {
        didSet {
            tvValue.text = String(slider.value)
            slider.value = value
        }
    }
    
    @IBInspectable var step: Float = 0 {
        didSet {
            self.xStep = step
            if xStep == 1 {
                tvValue.text = String(Int(round(slider.value)))
            }
        }
    }

    @IBInspectable var min: Float = 0 {
        didSet {
            slider.minimumValue = min
        }
    }
    
    @IBInspectable var max: Float = 0 {
        didSet {
            slider.maximumValue = max
        }
    }
    
    @IBInspectable var name: String = "noname" {
        didSet {
            tvSettingName.text = name
        }
    }
    
    @IBInspectable var unit: String = "unit/unit" {
        didSet {
            tvUnitName.text = unit
        }
    }
    
    @IBInspectable var info: String = "more info" {
        didSet {
            tvInfo.text = info
        }
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        self.viewContainerAverage.layer.masksToBounds = true
        self.viewContainerAverage.layer.cornerRadius = 8
        self.viewContainerAverage.backgroundColor = #colorLiteral(red: 0.1642299891, green: 0.1672272682, blue: 0.2963926792, alpha: 1)
        self.viewContainerAverage.isHidden = true
       }
    
    let nibName = "SettingSlider"
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
}
