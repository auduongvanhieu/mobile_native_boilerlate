//
//  SideBarViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 10/26/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

import UIKit

class SideBarViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var imvAvatar: UIImageView!
    @IBOutlet weak var usernameButton: UIButton!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        Functions.showLog(title: "SetUpProfileSideBar", message: animated)
        let profile = LocalDataManager.profile
        if let avatarUrl = URL(string: profile?.avatar ?? Constants.AVATAR_DEFAULT) {
            imvAvatar.load(url: avatarUrl)
        } else {
            imvAvatar.image = UIImage(named: "img_avartar_default")
        }
        usernameButton.setTitle(profile?.nickname, for: .normal)
    }
    
    @IBAction func didClickProfile(_ sender: Any) {
        HamburgerMenu().closeSideMenu()
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 3])
    }
    
    @IBAction func btnNotice_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.notices, with: .push)
    }
    @IBAction func btnLTTestHistory_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: LTTestRoutes.ltTestHistory, with: .push)
    }
    @IBAction func btnExcerciseHistory_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseHistory(type: nil), with: .push)
    }
    
    @IBAction func btnExcerciseStatistic_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseStatistic, with: .push)
    }
    @IBAction func btnGoals_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.goals, with: .push)
    }
    @IBAction func btnFriends_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: MainRoutes.friends, with: .push)
    }
}

class HamburgerMenu {
    // Class To Implement Easy Functions To Open Or Close RearView
    // Make object of this class and call functions
    func triggerSideMenu() {
        let notificationOpenOrCloseSideMenu = Notification.Name("notificationOpenOrCloseSideMenu")
        NotificationCenter.default.post(name: notificationOpenOrCloseSideMenu, object: nil)
    }
    
    func closeSideMenu() {
        let notificationCloseSideMenu = Notification.Name("notificationCloseSideMenu")
        NotificationCenter.default.post(name: notificationCloseSideMenu, object: nil)
    }
    
    func closeSideMenuWithoutAnimation() {
        let closeSideMenuWithoutAnimation = Notification.Name("notificationCloseSideMenuWithoutAnimation")
        NotificationCenter.default.post(name: closeSideMenuWithoutAnimation, object: nil)
    }
    
}
