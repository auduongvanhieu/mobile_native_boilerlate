import UIKit

class TopInfoShare: UIView {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var todayLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    let nibName = "TopInfoShare"
    
    @IBInspectable var title: String = "" {
        didSet {
            self.titleLabel.text = title
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        // Set now date
        todayLabel.text = Functions.getNowDateStr()
        // Set user name
        nameLabel.text = LocalDataManager.profile?.nickname
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
}

