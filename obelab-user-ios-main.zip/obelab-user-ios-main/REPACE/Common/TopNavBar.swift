import UIKit

class TopNavBar: UIView {
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var btnBluetooth: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    
    let nibName = "TopNavBar"
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    func commonInit() {
        guard let view = loadViewFromNib() else { return }
        view.frame = self.bounds
        self.addSubview(view)
        checkConnection()
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkConnection), name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        addLongPressGesture()
    }
    
    func loadViewFromNib() -> UIView? {
        let nib = UINib(nibName: nibName, bundle: nil)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    func setTitle(_ title: String) {
        lblTitle.text = title
    }
    
    func hideBluetoothButton(_ isHide: Bool) {
        btnBluetooth.isHidden = isHide
    }
    
    @IBAction func btnSideBar_Click(_ sender: Any) {
        HamburgerMenu().triggerSideMenu()
    }
    
    @IBAction func btnBluetooth_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: AuthRoutes.pairing(goToHome: true), with: .push)
    }
    
    @objc func btnBluetooth_LongClick( gesture: UILongPressGestureRecognizer) {
        if gesture.state == UIGestureRecognizer.State.began {
            if FileHelper.isExistLogFile == true {
                let text = FileHelper.getDataLogFromTxtFile()
                let activityViewController = UIActivityViewController(activityItems: [text], applicationActivities: nil)
                activityViewController.popoverPresentationController?.sourceView = UIApplication.shared.keyWindow?.rootViewController?.view
                activityViewController.completionWithItemsHandler = { (type, completed, temp, error) in
                    Functions.showLog(title: "", message: "type = \(String(describing: type)) completed = \(completed) temp = \(temp) error = \(error?.localizedDescription ?? "")")
                    if completed == true {
                        self.deleteLog()
                    }
                }
                UIApplication.shared.keyWindow?.rootViewController?.present(activityViewController, animated: true, completion: nil)
            }
        }
    }
    
    func deleteLog() {
        let alert = UIAlertController(
          title: "Do you want to delete log file?", message: "", preferredStyle: UIAlertController.Style.alert
        )
        alert.addAction(
            UIAlertAction(title: "ok".localized, style: UIAlertAction.Style.default, handler: {_ in
                FileHelper.cleanDataLogFromTxtFile()
            })
        )
        alert.addAction(
            UIAlertAction(title: "cancel".localized, style: UIAlertAction.Style.default, handler: nil)
        )
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func addLongPressGesture() {
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(btnBluetooth_LongClick(gesture:)))
        longPress.minimumPressDuration = 1.5
        self.btnBluetooth.addGestureRecognizer(longPress)
    }
    
    func setButtonIsConnected() {
        btnBluetooth.setImage(UI.Icon.ic_bluetooth_on, for: .normal)
    }
    
    func setButtonIsDisconnected() {
        btnBluetooth.setImage(UI.Icon.ic_bluetooth_off, for: .normal)
    }
    
    @objc func checkConnection() {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            setButtonIsConnected()
        } else {
            setButtonIsDisconnected()
        }
    }
    
    deinit {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
    }
}
