import UIKit
import Toaster
import LinkPresentation

class BaseViewController: UIViewController, ActivityIndicatorPresenter {
    
    var isShowTopNavBar: Bool = true
    let activityIndicator = UIActivityIndicatorView()
    let labelPercent = UILabel()
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        Functions.showLog(title: "BaseViewController didReceiveMemoryWarning", message: "")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        (self.tabBarController as? MainTabBarController)?.mainViewController?.topNavBar?.isHidden = !isShowTopNavBar
    }
    
    func copySelfForChangeLanguage() -> UIViewController {
        self
    }
    
    func showToast(message: String) {
        Toast(text: message).show()
    }
    
    func showDisconnectedDeviceAlert() {
        showMessage(title: "disconnected".localized, message: "disconnected_device_alert".localized) { _ in
            AppNavigator.shared.navigate(to: AuthRoutes.pairing(goToHome: true), with: .push)
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        .lightContent
    }
    
    @IBInspectable var showTopNavBar: Bool = true {
        didSet {
            self.isShowTopNavBar = showTopNavBar
        }
    }
}
