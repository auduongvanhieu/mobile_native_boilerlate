import Foundation
import UIKit

protocol ChooseGenderDialogDelegate: NSObjectProtocol {
    func onChooseGender(selectedIndex: Int, selectedValue: String)
}

class ChooseGenderDialogViewController: BaseViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // MARK: - outlets for the view controller
    @IBOutlet weak var dialogBoxView: UIView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var backgroundSelectedItem: DesignableView!
    
    weak var delegate: ChooseGenderDialogDelegate?
    var selectedIndex = 0
    let genderNameList = ["male".localized, "female".localized, "other".localized]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
    }
    
    func setUpView() {
        // Set background for dialog
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
        dialogBoxView.layer.cornerRadius = UI.Dialog.radius
        // Picker view
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.selectRow(selectedIndex, inComponent: 0, animated: true)
        pickerView.backgroundColor = UIColor.clear
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onClickOK(_ sender: Any) {
        let selectedIndex = pickerView.selectedRow(inComponent: 0)
        let selectedValue = genderNameList[selectedIndex]
        self.delegate?.onChooseGender(selectedIndex: selectedIndex, selectedValue: selectedValue)
        self.dismiss(animated: true, completion: nil)
    }
    
    // MARK: - functions for the viewController
    static func showPopup(parentVC: UIViewController, selectedIndex: Int?) {
        //        let storyboard : UIStoryboard = UIStoryboard(name: "CustomDialog", bundle: nil)
        //        let viewController = storyboard.instantiateViewController(withIdentifier: "ChooseGenderDialogViewController")
        if let popupViewController = UIStoryboard(name: "CustomDialog", bundle: nil).instantiateViewController(withIdentifier: "ChooseGenderDialogViewController") as? ChooseGenderDialogViewController {
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            popupViewController.delegate = parentVC as? ChooseGenderDialogDelegate
            popupViewController.selectedIndex = selectedIndex ?? 0
            parentVC.present(popupViewController, animated: true)
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        genderNameList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        30.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        if pickerView.subviews.count > 2 {
            pickerView.subviews[1].isHidden = true
            pickerView.subviews[2].isHidden = true
        } else {
            if pickerView.subviews.count > 1 {
                pickerView.subviews[1].backgroundColor = UIColor(named: "textMain")?.withAlphaComponent(0.1)
            }
            backgroundSelectedItem.isHidden = true
        }
        var label = UILabel()
        if let view = view as? UILabel {
            label = view
        }
        label.font = UIFont(name: AppFontName.regular, size: 18)
        label.text = genderNameList[row]
        label.textColor = UIColor.black
        label.textAlignment = .center
        return label
    }
}
