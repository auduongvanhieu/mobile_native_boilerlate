//
//  ChooseHeightWeightDialogViewController.swift
//  REPACE
//
//  Created by Macintosh on 10/19/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

protocol ChooseHeightWeightDialogDelegate: NSObjectProtocol {
    func onChooseHeightWeight(selectedIndex: Int, selectedValue: Double)
}

class ChooseHeightWeightDialogViewController: BaseViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // MARK: outlets for the view controller
    @IBOutlet weak var dialogBoxView: UIView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var backgroundSelectedItem: DesignableView!
    
    weak var delegate: ChooseHeightWeightDialogDelegate?
    
    var selectedIndex = 0
    var dataList = [50, 50.1, 50.2, 50.3, 50.4, 50.5, 50.6, 50.7, 50.8, 50.9, 60]
    var unitType = Constants.UNIT_TYPE_HEIGHT
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
    }
    
    func setUpView() {
        // Set background for dialog
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
        dialogBoxView.layer.cornerRadius = UI.Dialog.radius
        // Unit label
        if unitType == Constants.UNIT_TYPE_HEIGHT {
            unitLabel.text = Functions.getHeightUnitName()
        } else {
            unitLabel.text = Functions.getWeightUnitName()
        }
        // Picker view
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.selectRow(selectedIndex, inComponent: 0, animated: true)
        pickerView.backgroundColor = UIColor.clear
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onClickOK(_ sender: Any) {
        let selectedIndex = pickerView.selectedRow(inComponent: 0)
        var selectedValue = dataList[selectedIndex]
        if LocalDataManager.unit != Constants.UNIT_METRIC {
            selectedValue = unitType == Constants.UNIT_TYPE_HEIGHT ? Functions.inToCm(inch: selectedValue) : Functions.lbsToKg(lbs: selectedValue)
        }
        self.delegate?.onChooseHeightWeight(selectedIndex: selectedIndex, selectedValue: selectedValue)
        self.dismiss(animated: true, completion: nil)
    }
    
    // MARK: functions for the viewController
//    static func showPopup(parentVC: UIViewController, dataList: [Double], currentValue: Double?, unitType: String) {
////        let storyboard: UIStoryboard = UIStoryboard(name: "CustomDialog", bundle: nil)
////        let vc = storyboard.instantiateViewController(withIdentifier: "ChooseHeightWeightDialogViewController")
//        if let popupViewController = UIStoryboard(name: "CustomDialog", bundle: nil).instantiateViewController(withIdentifier: "ChooseHeightWeightDialogViewController") as? ChooseHeightWeightDialogViewController {
//            popupViewController.modalPresentationStyle = .custom
//            popupViewController.modalTransitionStyle = .crossDissolve
//            popupViewController.delegate = parentVC as? ChooseHeightWeightDialogDelegate
//            if dataList.isEmpty == false {
//                popupViewController.dataList = dataList // ?? popupViewController.dataList
//            }
//            let unit = LocalDataManager.unit
//            if unit == Constants.UNIT_METRIC {
//                for (index, item) in dataList.enumerated() {
//                    if item == currentValue {
//                        popupViewController.selectedIndex = index
//                        break
//                    }
//                }
//            } else {
//                if let currentValue = currentValue {
//                    for (index, item) in dataList.enumerated() {
//                        if item >= currentValue - 0.3 {
//                            popupViewController.selectedIndex = index
//                            break
//                        }
//                    }
//                }
//            }
//            popupViewController.unitType = unitType
//            parentVC.present(popupViewController, animated: true)
//        }
//    }
    
    // MARK: functions for the viewController
    // dataList && currentValue are always in METRIC unit (cm & kg)
    static func showPopupInUnit(parentVC: UIViewController, dataList: [Double], currentValue: Double?, unitType: String) {
        if let popupViewController = UIStoryboard(name: "CustomDialog", bundle: nil).instantiateViewController(withIdentifier: "ChooseHeightWeightDialogViewController") as? ChooseHeightWeightDialogViewController {
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            popupViewController.delegate = parentVC as? ChooseHeightWeightDialogDelegate
            let unit = LocalDataManager.unit
            if unit == Constants.UNIT_METRIC {
                popupViewController.dataList = dataList
                if let index = dataList.firstIndex(where: {$0 == currentValue}) {
                    popupViewController.selectedIndex = index
                }
            } else {
                var dataListResult: [Double] = []
                var oldValue = 0.0
                let listSort = dataList.sorted(by: {$0 < $1})
                listSort.forEach { value in
                    let addedValue = unitType == Constants.UNIT_TYPE_HEIGHT ? Functions.cmToIn(cm: value).to1Decimal : Functions.kgToLbs(kg: value).to1Decimal
                    if oldValue != addedValue {
                        oldValue = addedValue
                        dataListResult.append(addedValue)
                    }
                }
                popupViewController.dataList = dataListResult
                if let currentValue = currentValue {
                    let currentConvert = (unitType == Constants.UNIT_TYPE_HEIGHT ? Functions.cmToIn(cm: currentValue) : Functions.kgToLbs(kg: currentValue)).to1Decimal
                    if let index = dataListResult.firstIndex(where: {$0 == currentConvert}) {
                        popupViewController.selectedIndex = index
                    }
                }
            }
            popupViewController.unitType = unitType
            parentVC.present(popupViewController, animated: true)
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        dataList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        30.0
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        if pickerView.subviews.count > 2 {
            // iOS 13.x
            pickerView.subviews[1].isHidden = true
            pickerView.subviews[2].isHidden = true
        } else {
            if pickerView.subviews.count > 1 {
                pickerView.subviews[1].backgroundColor = UIColor(named: "textMain")?.withAlphaComponent(0.1)
            }
            backgroundSelectedItem.isHidden = true
        }
        var label = UILabel()
        if let view = view as? UILabel {
            label = view
        }
        label.font = UIFont(name: AppFontName.regular, size: 18)
        label.textColor = UIColor.black
        label.text = String(format: "%.1f", dataList[row])
//        label.text = String(format: "%.1f", unitType == Constants.UNIT_TYPE_HEIGHT ? Functions.getHeightUnitValue(height: dataList[row]) : Functions.getWeightUnitValue(weight: dataList[row]))
        label.textAlignment = .center
        return label
    }
}
