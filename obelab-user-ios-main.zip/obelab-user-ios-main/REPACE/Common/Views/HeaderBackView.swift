import Foundation
import UIKit

class HeaderBackView: UIView {
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    @objc func onClickBack(sender: UIButton!) {
        AppNavigator.shared.pop()
    }
    
    func setUp(width: Double, title: String, yPosition: Double = 26.0){
        let uiDevice = UIDevice()
        self.layer.frame =  CGRect( x: 0.0, y: uiDevice.hasNotch ? yPosition + 24.0 : yPosition, width: width, height: 40)
        
        // Icon back
        var imvBack = UIImageView(frame: CGRect( x: 18.0, y: 8.0, width: 24, height: 24))
        imvBack.image = UIImage(named:"ic_back.png")
        
        // Button back
        var btnBack = UIButton(frame: CGRect( x: 10.0, y: 0.0, width: 40, height: 40))
        btnBack.addTarget(self, action: #selector(onClickBack), for: .touchUpInside)
        
        // Title
        let titleUI = UILabel()
        titleUI.text = "   " + title + "   "
        titleUI.numberOfLines = 1
        titleUI.sizeToFit()
        titleUI.font = UIFont(name: "BebasNeueRepaceBold", size: UI.Text.title)
        titleUI.textColor = UIColor.white
        titleUI.frame.origin.x = CGFloat(width)/2 - titleUI.frame.width/2
        titleUI.frame.origin.y = 20 - titleUI.frame.height/2
        
        // Add to view
        self.addSubview(imvBack)
        self.addSubview(btnBack)
        self.addSubview(titleUI)
    }
}
