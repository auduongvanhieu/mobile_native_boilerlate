//
//  OutdoorViewController.swift
//  REPACE
//
//  Created by BM Johnny on 11/05/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit
import CoreLocation

class OutdoorViewController: BaseViewController {
    let locationManager = CLLocationManager()
    var distance: Double = 0
    var sumSpeed: Double = 0.0
    var countSpeed: Int = 0
    var period: Int = 1
    var previousLocation: CLLocation?
    var previousTime: Date?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if CLLocationManager.locationServicesEnabled() && LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR {
            locationManager.requestAlwaysAuthorization()
            locationManager.requestWhenInUseAuthorization()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 8.0
            locationManager.pausesLocationUpdatesAutomatically = true
            locationManager.activityType = .fitness
            locationManager.startUpdatingLocation()
        }
    }
    
    func updateLocationInfo(speed: Double) {
        
    }
}

extension OutdoorViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        let currentLocation: CLLocation = locations[0] as CLLocation
        guard let currentLocation = locations.last else { return }
        let currentTime = Date()
        Functions.showLog(title: "Location value listener", message: "(\(currentLocation.coordinate.latitude),\(currentLocation.coordinate.longitude))")
        if let previousLocation = previousLocation {
            let distanceDelta = Functions.getDistanceFrom2Coordinate(firstLocation: currentLocation, secondLocation: previousLocation)
            let speed = currentLocation.speed == -1 ? 0 : currentLocation.speed * 3.6
            if speed > Constants.HUMAN_MAX_SPEED {
                Functions.showLog(title: "Location speed \(speed) over human speed \(Constants.HUMAN_MAX_SPEED)", message: "")
                return
            }
            // Sum speed in this stage
            sumSpeed += speed
            countSpeed += 1
            // Save data
            let model = LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis())
            if BluetoothHelper.isExerciseProcessing {
                RealmHelper.share.saveLocationDB(index: countSpeed, model: model, period: "\(period * 5)")
            }
            distance += distanceDelta
            updateLocationInfo(speed: speed)
        }
        previousLocation = currentLocation
        previousTime = currentTime
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        Functions.showLog(title: "Location didFailWithError", message: error)
    }
}
