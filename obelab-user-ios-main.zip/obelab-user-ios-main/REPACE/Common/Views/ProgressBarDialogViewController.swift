import Foundation
import UIKit
import CollectionPickerView

class ProgressBarDialogViewController: UIViewController {
    
    @IBOutlet weak var dialogBoxView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var progressBarView: UIProgressView!
    var timer: Timer?
    static var instance: ProgressBarDialogViewController?
    var counter: Double = 0
    var descriptionStr: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate()
        timer = nil
    }
    
    func setUpView() {
        // Set background for dialog
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
        dialogBoxView.layer.cornerRadius = UI.Dialog.radius
        progressBarView.layer.cornerRadius = 3
        // Set Progress Bar View
        progressBarView.progress = 0
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        timer?.tolerance = 0.02
        lblTitle.text = descriptionStr
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) updateCounter = \(counter)", message: "")
        if counter == Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_2 * 10 {
            timer?.invalidate()
            timer = nil
        } else {
            counter += 1
            let progress = counter / (Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_2 * 10)
            progressBarView.setProgress(Float(progress), animated: true)
        }
    }
    
    static func showPopup(parentVC: UIViewController, title: String? = nil) {
//        let storyboard: UIStoryboard = UIStoryboard(name: "CustomDialog", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "ProgressBarDialogViewController")
        if let popupViewController = UIStoryboard(name: "CustomDialog", bundle: nil).instantiateViewController(withIdentifier: "ProgressBarDialogViewController") as? ProgressBarDialogViewController {
            popupViewController.descriptionStr = title ?? "The App is setting the personal time. Please wait."
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            parentVC.present(popupViewController, animated: true)
            ProgressBarDialogViewController.instance = popupViewController
        }
    }
    
    static func hidePopup() {
        ProgressBarDialogViewController.instance?.timer?.invalidate()
        ProgressBarDialogViewController.instance?.timer = nil
        ProgressBarDialogViewController.instance?.dismiss(animated: true)
    }
}
