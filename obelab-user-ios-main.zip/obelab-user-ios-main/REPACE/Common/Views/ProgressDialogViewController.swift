import Foundation
import UIKit
import CollectionPickerView

class ProgressDialogViewController: UIViewController {
    
    @IBOutlet weak var dialogBoxView: UIView!
    static var instance: ProgressDialogViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
    }
    
    func setUpView(){
        // Set background for dialog
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
        dialogBoxView.layer.cornerRadius = UI.Dialog.radius
    }
    
    static func showPopup(parentVC: UIViewController){
        let storyboard : UIStoryboard = UIStoryboard(name: "CustomDialog", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ProgressDialogViewController")
        if let popupViewController = UIStoryboard(name: "CustomDialog", bundle: nil).instantiateViewController(withIdentifier: "ProgressDialogViewController") as? ProgressDialogViewController {
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            parentVC.present(popupViewController, animated: true)
            ProgressDialogViewController.instance = popupViewController
        }
    }
    
    static func hidePopup(){
        ProgressDialogViewController.instance?.dismiss(animated: true)
    }
}
