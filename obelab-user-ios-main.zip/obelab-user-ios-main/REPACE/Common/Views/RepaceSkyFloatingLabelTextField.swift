import SkyFloatingLabelTextField

class RepaceSkyFloatingLabelTextField: SkyFloatingLabelTextField {
    
    private var placeholderBackup: String?
    private var _titleFormatter: (String) -> String = { (text: String) -> String in
        text
    }
    override var titleFormatter: ((String) -> String) {
        get {
            _titleFormatter
        }
        set {
            
        }
    }
    var didFocus: Bool = false {
        didSet {
            updatePlaceHolder()
        }
    }
    override func isTitleVisible() -> Bool {
        didFocus || super.isTitleVisible()
    }
    
    func updatePlaceHolder() {
        if placeholderBackup == nil {
            placeholderBackup = placeholder
        }
        title = didFocus ? placeholderBackup : nil
        placeholder = didFocus ? nil : placeholderBackup
    }
    
    override func becomeFirstResponder() -> Bool {
        didFocus = true
        return super.becomeFirstResponder()
    }
    
    override func resignFirstResponder() -> Bool {
        didFocus = false
        return super.resignFirstResponder()
    }
}
