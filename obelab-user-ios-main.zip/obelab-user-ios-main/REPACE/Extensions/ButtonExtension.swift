//
//  ButtonExtension.swift
//  REPACE
//
//  Created by Karen Stoletniy on 12/7/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
  
  static func primaryButton(
    color: UIColor = .buttonBackground,
    title: String = "",
    titleColor: UIColor = .white,
    cornerRadius: CGFloat = UI.Button.cornerRadius,
    height: CGFloat = UI.Button.height,
    font: UIFont = .h3Medium,
    target: Any? = nil,
    action: Selector? = nil
  ) -> UIButton {
    let button = UIButton()
    button.setup(
      color: color,
      title: title,
      titleColor: titleColor,
      cornerRadius: cornerRadius,
      height: height,
      font: font
    )
    if let action = action {
      button.addTarget(target, action: action, for: .touchUpInside)
    }
    return button
  }
  
  private func setup(
    color: UIColor = .buttonBackground,
    title: String = "",
    titleColor: UIColor = .white,
    cornerRadius: CGFloat = UI.Button.cornerRadius,
    height: CGFloat = UI.Button.height,
    font: UIFont = .h3Medium
  ) {
    translatesAutoresizingMaskIntoConstraints = false
    setTitle(title, for: .normal)
    setTitleColor(titleColor, for: .normal)
    backgroundColor = color
    titleLabel?.font = font
    setRoundBorders(cornerRadius)
    heightAnchor.constraint(equalToConstant: height).isActive = true
  }

    func centerVertically(padding: CGFloat = 6.0) {
        guard
            let imageViewSize = self.imageView?.frame.size,
            let titleLabelSize = self.titleLabel?.frame.size else {
            return
        }
        
        let totalHeight = imageViewSize.height + titleLabelSize.height + padding
        
        self.imageEdgeInsets = UIEdgeInsets(
            top: -(totalHeight - imageViewSize.height),
            left: 0.0,
            bottom: 0.0,
            right: -titleLabelSize.width
        )
        
        self.titleEdgeInsets = UIEdgeInsets(
            top: 0.0,
            left: -imageViewSize.width,
            bottom: -(totalHeight - titleLabelSize.height),
            right: 0.0
        )
        
        self.contentEdgeInsets = UIEdgeInsets(
            top: 0.0,
            left: 0.0,
            bottom: titleLabelSize.height,
            right: 0.0
        )
    }
      
    
}

class UISNSButton: UIButton {
    override var isHighlighted: Bool {
        didSet {
            setupBorderHighlightedButton()
        }
    }
    func setupBorderHighlightedButton() {
        layer.cornerRadius = UI.Button.cornerRadius
        if isHighlighted {
            self.layer.borderWidth = 1
            self.layer.borderColor = UIColor.white.withAlphaComponent(1).cgColor
        } else {
            self.layer.borderWidth = 0
            self.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        }
    }
}
