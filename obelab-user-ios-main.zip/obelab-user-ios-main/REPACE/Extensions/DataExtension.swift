import Foundation

extension Data {
    func asBase64Param(withType type: MimeType = .jpeg) -> String {
        return "data:\(type.rawValue);base64,\(self.base64EncodedString())"
    }
    
    func append(fileURL: URL) throws {
        if let fileHandle = FileHandle(forWritingAtPath: fileURL.path) {
            defer {
                fileHandle.closeFile()
            }
            fileHandle.seekToEndOfFile()
            fileHandle.write(self)
        }
        else {
            try write(to: fileURL, options: .atomic)
        }
    }
}
