import UIKit

extension Date {
   func getFormattedDate(format: String) -> String {
        let dateformat = DateFormatter()
        dateformat.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        dateformat.dateFormat = format
        return dateformat.string(from: self)
    }
    
    func currentTimeMillis() -> Int {
        return Int(self.timeIntervalSince1970 * 1000)
    }
}
