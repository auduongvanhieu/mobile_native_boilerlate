import Foundation

extension Double {
    var toInt: Int {
        return Int(self)
    }
    
    var to1Decimal: Double {
      return (self * 10).rounded() / 10
    }
    
    var to2Decimal: Double {
      return (self * 100).rounded() / 100
    }
}
