import Foundation

extension Int {
    var toInt32: Int32 {
        return Int32(self)
    }
}
