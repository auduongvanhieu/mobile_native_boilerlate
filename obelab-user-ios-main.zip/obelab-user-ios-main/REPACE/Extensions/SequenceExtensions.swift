//
//  SequenceExtensions.swift
//  REPACE
//
//  Created by Pham Van Huy on 21/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

public extension Sequence {
    func group<U: Hashable>(by key: (Iterator.Element) -> U) -> [U: [Iterator.Element]] {
        var categories: [U: [Iterator.Element]] = [:]
        for element in self {
            let key = key(element)
            if case nil = categories[key]?.append(element) {
                categories[key] = [element]
            }
        }
        return categories
    }
}
