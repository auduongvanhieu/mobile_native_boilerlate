import Foundation

extension String {
  var isAlphanumericWithNoSpaces: Bool {
    let alphaNumSet = CharacterSet(
      charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    )
    return rangeOfCharacter(from: alphaNumSet.inverted) == nil
  }
  
  var hasPunctuationCharacters: Bool {
    return rangeOfCharacter(from: CharacterSet.punctuationCharacters) != nil
  }
  
  var hasNumbers: Bool {
    return rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789")) != nil
  }
  
//  var localized: String {
//    return self.localize()
//  }
//
//  func localize(comment: String = "") -> String {
//    let path = Bundle.main.path(forResource: LocalDataManager.language, ofType: "lproj")
//    let bundle = Bundle(path: path!)
//    return NSLocalizedString(self, tableName: nil, bundle: bundle!, value: "", comment: "")
//  }
  
  var validFilename: String {
    guard !isEmpty else { return "emptyFilename" }
    return addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "emptyFilename"
  }
  
  // Regex fulfill RFC 5322 Internet Message format
  func isEmailFormatted() -> Bool {
    // swiftlint:disable line_length
    let emailRegex = "[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(\\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?"
    // swiftlint:enable line_length
    let predicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
    return predicate.evaluate(with: self)
  }
  
  // Regex fulfill RFC 5322 Internet Message format
  func isPasswordFormatted() -> Bool {
    // swiftlint:disable line_length
    let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z$@$#!%?&\\d]{8,15}$"
    
    // swiftlint:enable line_length
    let predicate = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
    return predicate.evaluate(with: self)
  }
  
  func isNicknameFormatted() -> Bool {
    // swiftlint:disable line_length
    let regex = "^(?<! )[-a-zA-Z0-9' ]{4,15}$"
    
    // swiftlint:enable line_length
    let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
    return predicate.evaluate(with: self)
  }
  
  func maxLength(length: Int) -> String {
    var str = self
    let nsString = str as NSString
    if nsString.length >= length {
      str = nsString.substring(with: NSRange( location: 0, length: nsString.length > length ? length : nsString.length)
      )
    }
    return  str
  }
  
  var htmlToAttributedString: NSAttributedString? {
    guard let data = data(using: .utf8) else { return nil }
    do {
      return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
    } catch {
      return nil
    }
  }
  
  var htmlToString: String {
    return htmlToAttributedString?.string ?? ""
  }
  
  func index(from: Int) -> Index {
    return self.index(startIndex, offsetBy: from)
  }
  
  func substring(range: Range<Int>) -> String {
    let startIndex = index(from: range.lowerBound)
    let endIndex = index(from: range.upperBound)
    return String(self[startIndex..<endIndex])
  }
  
  func toBytes() -> [UInt8] {
    let length = self.count
    if length & 1 != 0 {
      return []
    }
    var bytes = [UInt8]()
    bytes.reserveCapacity(length / 2)
    var index = string.startIndex
    for _ in 0..<length / 2 {
      let nextIndex = string.index(index, offsetBy: 2)
      if let oneByte = UInt8(string[index..<nextIndex], radix: 16) {
        bytes.append(oneByte)
      } else {
        return []
      }
      index = nextIndex
    }
    return bytes
  }
  
  func appendLineToURL(fileURL: URL) throws {
    try (self + "\n").appendToURL(fileURL: fileURL)
  }
  
  func appendToURL(fileURL: URL) throws {
    let data = self.data(using: String.Encoding.utf8)!
    try data.append(fileURL: fileURL)
  }
}
