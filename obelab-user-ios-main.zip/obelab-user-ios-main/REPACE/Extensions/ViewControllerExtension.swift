//
//  UIViewControllerExtension.swift
//  REPACE
//
//  Created by ignacio chiazzo Cardarello on 10/20/16.
//  Copyright © 2016 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
  // MARK: - Message Error
  func showMessage(
    title: String, message: String,
    handler: ((_ action: UIAlertAction) -> Void)? = nil,
    titleButton: String = "ok".localized
  ) {
    if let mainViewController = self.navigationController?.viewControllers.first as? MainViewController {
      if mainViewController.openFlag {
        mainViewController.openOrCloseSideMenu()
      }
    }
    let alert = UIAlertController(
      title: title, message: message, preferredStyle: UIAlertController.Style.alert
    )
    alert.addAction(
      UIAlertAction(title: titleButton, style: UIAlertAction.Style.default, handler: handler)
    )
    present(alert, animated: true, completion: nil)
  }
  
  func showMessage(
    title: String, message: String, buttonTitle: String,
    handle: ((_ action: UIAlertAction) -> Void)? = nil,
    handlerOK: ((_ action: UIAlertAction) -> Void)? = nil
  ) {
    if let mainViewController = self.navigationController?.viewControllers.first as? MainViewController {
      if mainViewController.openFlag {
        mainViewController.openOrCloseSideMenu()
      }
    }
    let alert = UIAlertController(
      title: title, message: message, preferredStyle: UIAlertController.Style.alert
    )
    alert.addAction(
      UIAlertAction(title: "ok".localized, style: UIAlertAction.Style.default, handler: handlerOK)
    )
    alert.addAction(
      UIAlertAction(title: buttonTitle, style: UIAlertAction.Style.default, handler: handle)
    )
    present(alert, animated: true, completion: nil)
  }
  
  func goToScreen(withIdentifier identifier: String,
                  storyboardId: String? = nil,
                  modally: Bool = false,
                  viewControllerConfigurationBlock: ((UIViewController) -> Void)? = nil) {
    var storyboard = self.storyboard
    
    if let storyboardId = storyboardId {
      storyboard = UIStoryboard(name: storyboardId, bundle: nil)
    }
    
    guard let viewController =
            storyboard?.instantiateViewController(withIdentifier: identifier) else {
              assert(false, "No view controller found with that identifier")
              return
            }
    
    viewControllerConfigurationBlock?(viewController)
    
    if modally {
      present(viewController, animated: true)
    } else {
      assert(navigationController != nil, "navigation controller is nil")
      navigationController?.pushViewController(viewController, animated: true)
    }
  }
  
  func applyDefaultUIConfigs() {
    view.backgroundColor = .screenBackground
  }
  
  func combine2Images(topImage: UIImage, bottomImage: UIImage) -> UIImage? {
    let size = CGSize(width: topImage.size.width, height: topImage.size.height + bottomImage.size.height)
    UIGraphicsBeginImageContext(size)
    let areaSize = CGRect(x: 0, y: 0, width: topImage.size.width, height: topImage.size.height)
    topImage.draw(in: areaSize)
    bottomImage.draw(at: CGPoint(x: 0, y: topImage.size.height), blendMode: .normal, alpha: 1.0)
    let resultImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return resultImage
  }
  
  func shareOtherApp(text: String?, shareImage: UIImage?, completion: (() -> Void)? = nil, isJustShareImage: Bool = false) {
    var share: [Any] = []
    if let text = text {
      share.append(text)
    } else {
      share.append("app_description".localized)
    }
    if let shareImage = shareImage {
      share.append(shareImage)
    }
    if #available(iOS 13.0, *) {
      let activityItemMetadata = ShareLinkMetadataManagerHelper()
      share.append(activityItemMetadata)
      let activityViewController = UIActivityViewController(activityItems: share, applicationActivities: nil)
      activityViewController.title = text
      activityViewController.popoverPresentationController?.sourceView = self.view
      activityViewController.completionWithItemsHandler = {(activity, success, items, error) in
          completion?()
      }
      self.present(activityViewController, animated: true, completion: nil)
    } else {
      // Fallback on earlier versions
      let appName = Bundle.main.infoDictionary?["CFBundleName"] as? String ?? "Repace"
      share.append(appName)
      let activityViewController = UIActivityViewController(activityItems: share, applicationActivities: nil)
      activityViewController.title = text
      activityViewController.popoverPresentationController?.sourceView = self.view
      activityViewController.completionWithItemsHandler = {(activity, success, items, error) in
          completion?()
      }
      self.present(activityViewController, animated: true, completion: nil)
    }
  }
  
  func topViewController() -> UIViewController? {
    var top = UIApplication.shared.keyWindow?.rootViewController
    while true {
      if let presented = top?.presentedViewController {
        top = presented
      } else if let nav = top as? UINavigationController {
        top = nav.visibleViewController
      } else if let tab = top as? UITabBarController {
        top = tab.selectedViewController
      } else {
        break
      }
    }
    return top
  }
}
