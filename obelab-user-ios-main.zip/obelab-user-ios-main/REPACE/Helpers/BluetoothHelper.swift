import Foundation
import CoreBluetooth
import UIKit
import RealmSwift

struct BluetoothHelper {
    static var isConnectedDevice = false
    static var isSaveBaseline = false
    static var isSaveCurrentSmo2 = false
    static var peripheral: CBPeripheral?
    static var characteristic: CBCharacteristic?
    static var isRunProgress: Bool = false
    // Save number elements in listSmo2 in 5 minutes, 10 minutes .... Exercise, each stage in LTTest
    static var arrSmo2: [Int] = []
    // Save number elements in listHeartrate in 5 minutes, 10 minutes .... Exercise, each stage in LTTest
    static var arrHeartrate: [Int] = []
    static var alertDisconnect: UIAlertController?
    static var isExerciseProcessing = false // User is doing exercise
    static let SERVICE_UUID = CBUUID(string: Constants.IS_TEST_EMULATOR ? "0000FFE0-0000-1000-8000-00805F9B34FB" : "6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    static let WRITE_UUID = CBUUID(string: Constants.IS_TEST_EMULATOR ? "0000FFE1-0000-1000-8000-00805F9B34FB" : "6e400002-b5a3-f393-e0a9-e50e24dcca9e")
    static let NOTIFY_UUID = CBUUID(string: Constants.IS_TEST_EMULATOR ? "0000FFE1-0000-1000-8000-00805F9B34FB" : "6e400003-b5a3-f393-e0a9-e50e24dcca9e")
    static var timer: Timer?
    static var remainData: [UInt8] = []
    static let HEADER_SIZE: Int = 5
    static let CHECKSUM_SIZE: Int = 1
    static let LENGHTH_INDEX: Int = 4
    static var isCurrentParingPage = false
    static var lastIndexSmO2 = 0
    static var ltTestResult: LTTestResultModel?
    static var exerciseResult: ExerciseResultModel?
    static var idExercise: Int?
    static var isDisableViewDidAppear = false
    
    static func startMeasure() {
        Functions.showLog(title: "BLE -> ", message: "write start measure data")
        let cmdBytes: [UInt8] = [0x0A, 0x0B, 0x0C, RepaceRequestData.TYPE_CMD, 0x01, RepaceCmd.CMD_MEASURE_START, 0x01]
        let cmd = Data(cmdBytes)
        if let characteristic = BluetoothHelper.characteristic {
            BluetoothHelper.peripheral?.writeValue(cmd, for: characteristic, type: .withoutResponse)
        }
        isExerciseProcessing = true
    }
    
    static func stopMeasure() {
        let cmdBytes: [UInt8] = [0x0A, 0x0B, 0x0C, RepaceRequestData.TYPE_CMD, 0x01, RepaceCmd.CMD_MEASURE_STOP, 0x01]
        let cmd = Data(cmdBytes)
        if let characteristic = BluetoothHelper.characteristic {
            BluetoothHelper.peripheral?.writeValue(cmd, for: characteristic, type: .withoutResponse)
        }
        isExerciseProcessing = false
    }
    
    static func parseDataToRepaceMeasure(_ measureData: [UInt8]) -> RepaceMeasureModel {
        if measureData.count > 71 {
            var data = measureData
            if Constants.IS_TEST_EMULATOR && Constants.IS_RUN_FAKE_DATA_LT_TEST == false {
                data = [0x0a, 0x0b, 0x0c, 0x01, 0x42, 0x01, 0x02, 0x0f, 0xb9, 0x04, 0x68, 0x04, 0x23, 0x05, 0x06, 0x07, 0x02, 0x08, 0x38, 0x09, 0x13, 0xff, 0xf0, 0xff, 0xfe, 0x01, 0x1d, 0x02, 0x0c, 0x03, 0x04, 0x05, 0x06, 0x07, 0x2c, 0x08, 0x16, 0xff, 0xfa, 0x09, 0x01, 0x02, 0xa9, 0x03, 0x5b, 0x04, 0x05, 0x06, 0x07, 0x08, 0x8a, 0x09, 0x37, 0xff, 0xfc, 0xff, 0xff, 0x04, 0x0e, 0xff, 0xd7, 0x01, 0x1d, 0xf8, 0xff, 0x01, 0x31, 0xfe, 0xdd, 0xff, 0xc8, 0x7e]
                data[57] = measureData[5]
                data[58] = measureData[6]
            }
            var rowData: [UInt8] = []
            rowData += data[9..<57]
            let length = data[4]
            var sequence: [UInt8] = []
            var rSO2: [UInt8] = []
            var accel: [UInt8] = []
            var gyro: [UInt8] = []
            var channel1: [UInt8] = []
            var channel2: [UInt8] = []
            var channel3: [UInt8] = []
            var channel4: [UInt8] = []
            var channel5: [UInt8] = []
            var channel6: [UInt8] = []
            sequence += data[5..<9]
            channel1 += data[9..<17]
            channel2 += data[17..<25]
            channel3 += data[25..<33]
            channel4 += data[33..<41]
            channel5 += data[41..<49]
            channel6 += data[49..<57]
            rSO2 += data[57..<59]
            accel += data[59..<65]
            gyro += data[65..<71]
            var marker: Int? = 0
            if LocalDataManager.actionType == Constants.ACTION_LT_TEST {
                marker = isRunProgress ? LocalDataManager.ltTestStage : 0
            } else {
                if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL || LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR {
                    marker = isRunProgress ? ExerciseHelper.getTodayExercise().todaySession?.session : 0
                } else {
                    marker = nil
                }
            }
            return RepaceMeasureModel(dataType: RepaceRequestType.TYPE_MEASURE_DATA, data: data, rowData: rowData, length: length, sequence: sequence, rSO2: rSO2, accel: accel, gyro: gyro, channel1: channel1, channel2: channel2, channel3: channel3, channel4: channel4, channel5: channel5, channel6: channel6, marker: marker)
        } else {
            return RepaceMeasureModel()
        }
    }
    
    static func parseDataToRepaceBattery(_ data: [UInt8]) -> RepaceBatteryModel {
        if data.count > 9 {
            let length = data[4]
            let status = data[5] == RepaceResData.BATTERY_CHARGING ? RepaceResValue.CHARGING : RepaceResValue.DISCHARGING
            var rawData: [UInt8] = []
            rawData += data[6..<8]
            let level = data[8]
            return RepaceBatteryModel(dataType: RepaceRequestType.TYPE_BATTERY_LEVEL, data: data, length: length, status: status, rawData: rawData, level: level)
        } else {
            return RepaceBatteryModel()
        }
    }
    
    static func parseDataToRepaceStatus(_ data: [UInt8]) -> RepaceStatusModel {
        if data.count > 14 {
            let length = data[4]
            let status = data[5] == RepaceResData.STATUS_AND_VERTION_NORMAL ? RepaceResValue.STATUS_AND_VERTION_NORMAL : RepaceResValue.STATUS_AND_VERTION_OTA_MODE
            var payload: [UInt8] = []
            payload += data[6..<14]
            return RepaceStatusModel(dataType: RepaceRequestType.TYPE_STATUS_VERSION, data: data, length: length, status: status, payload: payload)
        } else {
            return RepaceStatusModel()
        }
    }
    
    static func parseDataToRepaceGain(_ data: [UInt8]) -> RepaceGainDataModel {
        if data.count > 6 {
            let length = data[4]
            let status = data[5] == RepaceResData.GAIN_DATA_SUCCESS ? RepaceResValue.SUCCESS : RepaceResValue.FAIL
            return RepaceGainDataModel(dataType: RepaceRequestType.TYPE_GAIN_DATA, data: data, length: length, status: status)
        } else {
            return RepaceGainDataModel()
        }
    }
    
    static func parseDataToRepaceError(_ data: [UInt8]) -> RepaceErrorModel {
        let lastReceive = data[4]
        let errorCode = data[5]
        return RepaceErrorModel(dataType: RepaceRequestType.TYPE_ERROR, data: data, lastReceive: lastReceive, errorCode: errorCode)
    }
    
    static func getPayloadData(data: [UInt8]) -> String {
        var logStr = ""
        if data.count > 3 {
            switch data[3] {
            case RepaceRequestData.TYPE_MEASURE_DATA:
                let log = BluetoothHelper.parseDataToRepaceMeasure(data)
                logStr = "Type: \(log.dataType), Data: \(Functions.toHexArrayString(byteArray: log.data)), Sequence: \(log.sequence), Accel: \(log.accel), Gyro: \(log.gyro), channel1: \(log.channel1), channel2: \(log.channel2), channel3: \(log.channel3), channel4: \(log.channel4), channel5: \(log.channel5), channel6: \(log.channel6), length: \(log.length), rSO2: \(log.rSO2)) => Smo2: \(Functions.toSmO2(byteArray: log.rSO2)), index: \(Functions.fourBytesToInt(byteArray: log.sequence))"
            case RepaceRequestData.TYPE_BATTERY_LEVEL:
                let log = BluetoothHelper.parseDataToRepaceBattery(data)
                logStr = "Type: \(log.dataType), Data: \(Functions.toHexArrayString(byteArray: log.data)), length: \(log.length), Status: \(log.status), rawData: \(log.rawData), Level: \(log.level)"
                Functions.showLog(title: "", message: "int \(Int(log.level))")
                LocalDataManager.batteryLevel = Int(log.level)
            case RepaceRequestData.TYPE_STATUS_VERSION:
                let log = BluetoothHelper.parseDataToRepaceStatus(data)
                logStr = "Type: \(log.dataType), Data: \(Functions.toHexArrayString(byteArray: log.data)), length: \(log.length), status: \(log.status), version: \(Functions.toHexArrayString(byteArray: log.payload))"
            case RepaceRequestData.TYPE_GAIN_DATA:
                let log = BluetoothHelper.parseDataToRepaceGain(data)
                logStr = "Type: \(log.dataType), Data: \(Functions.toHexArrayString(byteArray: log.data)), length: \(log.length), status: \(log.status)"
            case RepaceRequestData.TYPE_ERROR:
                let log = BluetoothHelper.parseDataToRepaceError(data)
                logStr = "Type: \(log.dataType), Data: \(Functions.toHexArrayString(byteArray: log.data)), last receive: \(log.lastReceive), error code: \(log.errorCode)"
            case RepaceRequestData.TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE:
                logStr = "Type: TYPE_DATA, Data: TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE"
            default:
                logStr = "Parse data error \(Functions.toHexArrayString(byteArray: data))"
            }
        } else {
            logStr = "Parse data not found \(Functions.toHexArrayString(byteArray: data))"
        }
        return logStr
    }
    
    static func getLactate() -> Double {
        var lactate: Double = 0.0
        if LocalDataManager.ltTestStage > 1 {
            lactate = LocalDataManager.ltTestAnalysis.lactate
        }
        return lactate
    }
    
    static func getBaseLineSMO2() -> Double {
        let sum = LocalDataManager.ltTestSmo2BaseLineList.reduce(0, +)
        let count = LocalDataManager.ltTestSmo2BaseLineList.count
        if LocalDataManager.ltTestSmo2BaseLineList.isEmpty == false {
            return Double(sum) / Double(count)
        } else {
            return 0.0
        }
    }
    
    static func getCurrentSMO2() -> Double {
        let sum = LocalDataManager.ltTestSmo2CurrentList.reduce(0, +)
        let count = LocalDataManager.ltTestSmo2CurrentList.count
        if LocalDataManager.ltTestSmo2CurrentList.isEmpty == false {
            return (Double(sum) / Double(count)).to1Decimal
        } else {
            return 0.0
        }
    }
//    var rowData: [UInt8] = []
    static func updateAnalysis(isCalculate: Bool = false) -> RepaceAnalysisModel {
        let repaceLibrary = RepaceLibrary()
//        let rowData: UnsafeMutablePointer<UInt8> = UnsafeMutablePointer(mutating: LocalDataManager.rowData)
//        let result: UnsafeMutablePointer<UnsafeMutablePointer<UInt8>?> = UnsafeMutableRawPointer(rowData).bindMemory(to: UnsafeMutablePointer<UInt8>?.self, capacity: 1)
        let analysis = repaceLibrary.getAnalysis(Int32(LocalDataManager.ltTestStage), Int32(LocalDataManager.ltTestProtocol.protocolValue), BluetoothHelper.getLactate(), BluetoothHelper.getBaseLineSMO2(), BluetoothHelper.getCurrentSMO2(), nil)
        let analysisModel = RepaceAnalysisModel(isNext: analysis.isNext, lactate: analysis.lactate, speed: analysis.speed, onset: analysis.onset, threshold: analysis.threshold)
//        if isCalculate && analysis.isNext == false {
//            LocalDataManager.ltTestOnsetCurrentList.append(analysis.onset)
//            LocalDataManager.ltTestThresholdCurrentList.append(analysis.threshold)
//        }
        LocalDataManager.ltTestAnalysis = analysisModel
        return LocalDataManager.ltTestAnalysis
    }
    
    static func resetLtTestData() {
        LocalDataManager.ltTestStage = 0
        LocalDataManager.ltTestAnalysis = RepaceAnalysisModel()
        LocalDataManager.ltTestSmo2CurrentList = []
        LocalDataManager.ltTestStageModelList = []
        LocalDataManager.ltTestLocationList = []
        LocalDataManager.ltTestSmo2List = []
        LocalDataManager.ltTestHRList = []
        LocalDataManager.ltTestResult = LTTestResultModel()
        LocalDataManager.listTestAnalysis = []
        arrSmo2 = []
        arrHeartrate = []
        ltTestResult = nil
        idExercise = RealmHelper.share.getAutoIncrementExerciseID(isLTTest: true)
        RealmHelper.share.cleanDataBeforeStartNewExercise()
        self.lastIndexSmO2 = 0
    }
    
    static func resetExerciseData() {
        LocalDataManager.ltTestSmo2List = []
        LocalDataManager.ltTestHRList = []
        LocalDataManager.listTestAnalysis = []
        LocalDataManager.exerciseResult = ExerciseResultModel()
        arrSmo2 = []
        arrHeartrate = []
        exerciseResult = nil
        idExercise = RealmHelper.share.getAutoIncrementExerciseID(isLTTest: false)
        RealmHelper.share.cleanDataBeforeStartNewExercise()
        self.lastIndexSmO2 = 0
    }
    
    static func showDisconnectedDeviceAlert(fromViewController: UIViewController) {
        if fromViewController.isKind(of: MainViewController.self) == true {
            if let viewController = fromViewController.topViewController(),
               viewController.isKind(of: UIAlertController.self) == false {
                if alertDisconnect == nil {
                    alertDisconnect = UIAlertController(title: "disconnected".localized, message: "disconnected_device_alert".localized, preferredStyle: .alert)
                    alertDisconnect?.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
                        self.alertDisconnect = nil
                        AppNavigator.shared.navigate(to: AuthRoutes.pairing(goToHome: true), with: .push)
                    }))
                    if let alertDisconnect = alertDisconnect {
                        UIApplication.shared.keyWindow?.rootViewController?.present(alertDisconnect, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    static func restoreConnectDevice (fromViewController: UIViewController) {
        alertDisconnect?.dismiss(animated: true)
        self.alertDisconnect = nil
    }
    
    static func showStopProgressAlert(textStop: String, didStop: (() -> Void)? = nil) {
        let alert = UIAlertController(title: "", message: textStop, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
            BluetoothHelper.stopMeasure()
            Functions.stopFakeDataLTTest()
            didStop?()
            AppNavigator.shared.pop()
        }))
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    static func trimRepaceData(byteArrayData: [UInt8]) -> [UInt8] {
        var correctArrayData: [UInt8] = []
        if byteArrayData.count > 6 {
            for index in 0 ..< byteArrayData.count - 2 {
                if byteArrayData[index] == RepaceResData.CORRECT_START_DATA_ARRAY[0] && byteArrayData[index + 1] == RepaceResData.CORRECT_START_DATA_ARRAY[1] && byteArrayData[index + 2] == RepaceResData.CORRECT_START_DATA_ARRAY[2] {
                    correctArrayData = Array(byteArrayData[index ..< byteArrayData.count])
                    return correctArrayData
                }
            }
        }
        return correctArrayData
    }
    
    static func getPacketSize(byteArrayData: [UInt8]) -> Int {
        Int(byteArrayData[LENGHTH_INDEX]) + HEADER_SIZE + CHECKSUM_SIZE
    }
    
    static func pauseMeasure(isPause: Bool) {
        isExerciseProcessing = !isPause
        if isExerciseProcessing == true && isConnectedDevice == false {
            // Connect Device again when disconnect device
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil)
        }
    }
    
    static func getCheckSum(byteArrayData: [UInt8], packetSize: Int) -> UInt8 {
        var sum: Int = 0
        for index in (HEADER_SIZE...packetSize - 2) {
            sum += Int(byteArrayData[index])
        }
        sum = sum & 0xff
        return UInt8(sum)
    }
    
    static func checkRepaceData(byteArrayData: [UInt8]) {
        var checkArrayData = byteArrayData
        if remainData.isEmpty == false {
            checkArrayData = remainData + byteArrayData
            remainData = []
        }
        var isCheckData = true
        while isCheckData == true {
            isCheckData = false
            let correctByteArrayData = trimRepaceData(byteArrayData: checkArrayData) // Trim array to 0x0a, 0x0b, 0x0c,
            if correctByteArrayData.count > LENGHTH_INDEX {
                let packetSize: Int = getPacketSize(byteArrayData: correctByteArrayData) // packetSize by calculator
                if correctByteArrayData.count >= packetSize { // Check size of packet count == packetSize by calculator
                    let checkSum = getCheckSum(byteArrayData: correctByteArrayData, packetSize: packetSize)
                    let packetCS = Int(correctByteArrayData[packetSize - 1])
                    if checkSum == packetCS { // Check checkSum == packetCS
                        pairRepaceData(byteArrayData: correctByteArrayData)
                    }
                    if correctByteArrayData.count > packetSize { // Check is packet has sub data
                        let subByteArrayData: [UInt8] = Array(correctByteArrayData[packetSize ..< correctByteArrayData.count])
                        checkArrayData = subByteArrayData
                        isCheckData = true
                    }
                }
            }
        }
    }
    
    static func pairRepaceData(byteArrayData: [UInt8]) {
        if byteArrayData.count > 3 {
            switch byteArrayData[3] {
            case RepaceRequestData.TYPE_MEASURE_DATA:
                if byteArrayData.count > 71 {
                    let measureData = BluetoothHelper.parseDataToRepaceMeasure(byteArrayData)
                    LocalDataManager.rowData = measureData.rowData
                    let s3MeasureModel = Functions.convertMeasureToS3Measure(measure: measureData)
                    let rSO2 = Functions.toSmO2(byteArray: measureData.rSO2)
                    lastIndexSmO2 = s3MeasureModel.index ?? 0
                    RealmHelper.share.addDataRealm(s3MeasureModel: s3MeasureModel, rSO2: rSO2)
                    if BluetoothHelper.isSaveBaseline {
                        LocalDataManager.ltTestSmo2BaseLineList.append(rSO2)
                    }
                    if BluetoothHelper.isSaveCurrentSmo2 {
                        LocalDataManager.ltTestSmo2CurrentList.append(rSO2)
                    }
                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA: measureData])
                } else {
                    remainData = byteArrayData
                }
            case RepaceRequestData.TYPE_GAIN_DATA:
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION, object: nil)
            case RepaceRequestData.TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE:
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE, object: nil)
            default:
                Functions.showLog(title: "BLE -> ", message: "payloadDataDefaut")
            }
        }
        let payloadData = BluetoothHelper.getPayloadData(data: byteArrayData)
        // Functions.showLog(title: "BLE -> ", message: payloadData)
//        FileHelper.writeStringToLogFile(title: Constants.CHARACTERISTIC_DATA, content: payloadData)
    }
    
    static func saveSmo2AndHeartrateData() {
        arrSmo2.append(lastIndexSmO2)
        if let max = RealmHelper.share.getMaxIndexHeartrate() {
            self.arrHeartrate.append(max)
        }
        Functions.showLog(title: "saveSmo2AndHeartrateData arrSmo2 = \(arrSmo2.count) arrHeartrate = \(arrHeartrate)", message: "")
    }
    
    static func getNewestLTTestResultModel(completion: ((LTTestResultModel) -> Void)?) {
        RealmHelper.share.loadAllDataInExercise(isLTTest: true, arrSmo2: arrSmo2, arrHeartrate: arrHeartrate) { model in
            guard let model = model else { return }
            var ltTestResult = LocalDataManager.ltTestResult
            ltTestResult.testTypeID = LocalDataManager.ltTestType
            if LocalDataManager.ltTestStage == arrSmo2.count {
                ltTestResult.stageCnt = LocalDataManager.ltTestStage
            } else {
                ltTestResult.stageCnt = arrSmo2.count
            }
            ltTestResult.stage = LocalDataManager.ltTestStageModelList
            // totalDuration
            var totalDuration = ltTestResult.totalDuration ?? 0
            var totalDistance = LocalDataManager.ltTestStage != arrSmo2.count ? 0 : (LocalDataManager.ltTestResult.totalDistance ?? 0)
            LocalDataManager.ltTestStageModelList.forEach { (element) in
                totalDuration += (element.duration ?? 0)
                if LocalDataManager.ltTestStage != arrSmo2.count {
                    totalDistance += element.distance ?? 0
                }
            }
            ltTestResult.totalDuration = totalDuration
            ltTestResult.totalDistance = totalDistance
            // Prepare Sm02 Data
            ltTestResult.listLocation = model.listLocation
            ltTestResult.smo2Min = model.smo2Min
            ltTestResult.smo2Max = model.smo2Max
            ltTestResult.smo2Avg = model.smo2Avg
            ltTestResult.listSmo2 = model.listSmo2
            // Prepare Heartrate Data
            ltTestResult.heartRateMin = Double(model.heartRateMin ?? 0).to1Decimal
            ltTestResult.heartRateMax = Double(model.heartRateMax ?? 0).to1Decimal
            ltTestResult.heartRateAvg = model.heartRateAvg
            // Onset and mol
            ltTestResult.onset = LocalDataManager.ltTestAnalysis.onset.to1Decimal
            ltTestResult.mol = LocalDataManager.ltTestAnalysis.threshold.to1Decimal
            ltTestResult.protocolType = LocalDataManager.ltTestProtocol.protocolValue
            ltTestResult.lastSpeed = LocalDataManager.ltTestAnalysis.onset.to1Decimal
            ltTestResult.id = RealmHelper.share.getAutoIncrementExerciseID(isLTTest: true)
            ltTestResult.createdAt = Functions.convertDateISO8601ToString(date: Date())
            self.ltTestResult = ltTestResult
            completion?(ltTestResult)
        }
    }
    
    static func getNewestExerciseResultModelBy5Minutes(completion: ((ExerciseResultModel) -> Void)?) {
        RealmHelper.share.loadAllDataInExercise(isLTTest: false, arrSmo2: arrSmo2, arrHeartrate: arrHeartrate) { model in
            guard let model = model else { return }
            let todayExercise = ExerciseHelper.getTodayExercise()
            var exerciseResult = LocalDataManager.exerciseResult
            exerciseResult.intensityID = todayExercise.type == LTTestConstants.PRESCRIPTION_TYPE_LOW ? ExerciseConstants.LOW_INTENSITY : ExerciseConstants.HIGH_INTENSITY
            exerciseResult.sessionCnt = todayExercise.todaySession?.session
            exerciseResult.time = todayExercise.todaySession?.time
            exerciseResult.speed = todayExercise.todaySession?.speed?.to1Decimal
            exerciseResult.heartRate = todayExercise.todaySession?.heartRate
            // Prepare Sm02 Data
            exerciseResult.smo2Min = model.smo2Min
            exerciseResult.smo2Max = model.smo2Max
            exerciseResult.smo2Avg = model.smo2Avg
            exerciseResult.listSmo2 = model.listSmo2
            // Prepare Heartrate Data
            exerciseResult.heartRateMin = model.heartRateMin
            exerciseResult.heartRateMax = model.heartRateMax
            exerciseResult.heartRateAvg = model.heartRateAvg
            exerciseResult.listHeartRate = model.listHeartRate
            exerciseResult.listLocation = model.listLocation
            exerciseResult.id = RealmHelper.share.getAutoIncrementExerciseID(isLTTest: false)
            let now = Date()
            let createdAt = Functions.convertDateISO8601ToString(date: now)
            exerciseResult.createdAt = createdAt
            exerciseResult.updatedAt = createdAt
            exerciseResult.endTime = Functions.getExerciseTimeNow(fromDate: now)
            let totalInSeconds = exerciseResult.totalDuration ?? 0
            let startAt = Calendar.current.date(byAdding: .second, value: -totalInSeconds, to: now) ?? now
            exerciseResult.startTime = Functions.getExerciseTimeNow(fromDate: startAt)
            if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL &&
                LocalDataManager.exerciseResult.typeID == ExerciseConstants.FREE_EXERCISE {
                exerciseResult.totalDistance = LocalDataManager.freeExercisTotalDistanceInput.to1Decimal
                let hour = Double(exerciseResult.time ?? 0) / Constants.H_TO_S_COEFFICIENT
                if hour > 0 {
                    exerciseResult.speed = (LocalDataManager.freeExercisTotalDistanceInput / hour).to1Decimal
                }
            }
            self.exerciseResult = exerciseResult
            completion?(exerciseResult)
        }
    }
    
    static func getDeviceInfoStr(peripheral: CBPeripheral) -> String {
        "(Name: \(peripheral.name ?? ""), id: \(Functions.getBluetoothDeviceId(identifier: peripheral.identifier.uuidString)))"
    }
}

struct SmO2AndHeartrateModel: Codable {
    var min: Double
    var max: Double
    var avg: Double
    var list: [SmO2ChartModel]
    
    init(min: Double, max: Double, avg: Double, list: [SmO2ChartModel]) {
        self.min = min
        self.max = max
        self.avg = avg
        self.list = list
    }
}
