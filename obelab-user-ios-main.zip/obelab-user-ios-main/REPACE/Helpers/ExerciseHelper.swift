import Foundation

class ExerciseHelper {
    static func getTodayExercise() -> ExercisePresciptionModel {
        var prescription = LocalDataManager.ltTestPrescription
        if LocalDataManager.intensityId == Constants.HIGH_INTENSITY {
            prescription.todaySession = ExerciseSessionModel()
            prescription.todaySession?.session = prescription.sessionCnt
            prescription.todaySession?.speed = prescription.ptSpeed
            prescription.todaySession?.time = prescription.ptMin
        } else {
            prescription.todaySession = ExerciseSessionModel()
            prescription.todaySession?.session = prescription.sessionCnt
            prescription.todaySession?.speed = prescription.leSpeed
            prescription.todaySession?.time = prescription.leMin
        }
        prescription.session = []
        return prescription
    }
}
