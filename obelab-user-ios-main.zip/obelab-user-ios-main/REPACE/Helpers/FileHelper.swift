import UIKit

class FileHelper {
    static func getImageFileName() -> String {
        let profile = LocalDataManager.profile
        let date = Date()
        let sub = date.getFormattedDate(format: "yyyy_MM_dd_hh_mm_ss")
        return "user_\(profile?.id ?? 0)_\(sub).png"
    }
    
    static func getS3ImageFileName(imageFileName: String) -> String {
        let profile = LocalDataManager.profile
        return "app/user_\(profile?.id ?? 0)/\(imageFileName)"
    }
    
    static func getMeasureFileName() -> String {
        let profile = LocalDataManager.profile
        let date = Date()
        let sub = date.getFormattedDate(format: "yyyy_MM_dd_hh_mm_ss")
        return "user_\(profile?.id ?? 0)_\(sub).txt"
    }
    
    static func getS3MeasureFileName(fileName: String) -> String {
        let profile = LocalDataManager.profile
        return "repace_data/user_\(profile?.id ?? 0)/\(fileName)"
    }
    
    static func getS3MeasureFileDirectory() -> String {
        let profile = LocalDataManager.profile
        return "repace_data/user_\(profile?.id ?? 0)/"
    }
    
    static func getFileLogUrl() -> URL {
        let fileName = "repace_\(Functions.getNowDateLogName()).txt"
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .allDomainsMask).first {
            let fileURL = dir.appendingPathComponent(fileName)
            return fileURL
        }
        return URL(fileURLWithPath: "")
    }
    
    static func writeStringToLogFile(title: String, content: String) {
        let connectInternet = content.isEmpty ? " with connect internet: \(Connectivity.isConnectedToInternet)" : "\(content) with connect internet: \(Connectivity.isConnectedToInternet)"
        let text = "😊 \(Functions.getNowDateTimeLogStr()): \(title) -> \(content)\(connectInternet)"
        do {
            if FileManager.default.fileExists(atPath: FileHelper.getFileLogUrl().path) {
                try text.appendLineToURL(fileURL: FileHelper.getFileLogUrl())
            } else {
                try "\(text)\n".write(to: FileHelper.getFileLogUrl(), atomically: false, encoding: .utf8)
            }
            Functions.showLog(title: "writeStringToLogFileSuccess", message: title)
        } catch let error {
            Functions.showLog(title: "writeStringToLogFileError", message: error)
        }
    }
    
    static func getDataLogFromTxtFile() -> String {
        do {
            let dataLogStr = try String(contentsOf: FileHelper.getFileLogUrl(), encoding: .utf8)
            return dataLogStr
        } catch let error {
            Functions.showLog(title: "getFileDataLogError", message: error)
        }
        return "File not found"
    }
    
    static func cleanDataLogFromTxtFile() {
        do {
            let fileURL = FileHelper.getFileLogUrl()
            try FileManager.default.removeItem(at: fileURL)
        } catch let error {
            Functions.showLog(title: "cleanDataLogFromTxtFile File not found", message: error)
        }
    }
    
    static var isExistLogFile: Bool = {
        return FileManager.default.fileExists(atPath: FileHelper.getFileLogUrl().path)
    }()
}
