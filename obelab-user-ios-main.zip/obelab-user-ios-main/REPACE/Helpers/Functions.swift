import Foundation
import CoreLocation
import RealmSwift
import Realm

struct Functions {
    
    static var timer: Timer?
    
    static func showLog(title: String = "", message: Any = "" ) {
        if Constants.IS_SHOW_LOG {
            print("mytv", title, message)
        }
    }
    
    static func getShortDateFromDateStr(dateStr: String = "") -> String {
        if dateStr.isEmpty == false {
            return dateStr.count == 10 ? dateStr : dateStr.substring(range: 0..<10)
        } else {
            return Constants.DATE_DEFAULT
        }
    }
    
    static func convertOptionalDateStrToDateStr(optionalDateStr: String = "") -> String {
        if optionalDateStr.count >= 20 {
            return optionalDateStr.substring(range: 9..<19)
        } else {
            return Constants.DATE_DEFAULT
        }
    }
    
    static func convertDateStrToProfileDateStr(dateStr: String = "") -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd"
        dateFormatterGet.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "MMM dd, yyyy"
//        let localIdentifier = LocalDataManager.language == Constants.LANGUAGE_EN ? "en-au" : "ko"
        dateFormatterPrint.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        
        if let date = dateFormatterGet.date(from: getShortDateFromDateStr(dateStr: dateStr)) {
            return dateFormatterPrint.string(from: date).uppercased()
        } else {
            return "JAN 01, 2000"
        }
    }
    
    static func convertDateStrToDateStr(dateStr: String = "", inputFormat: String = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", formatStr: String) -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.timeZone = TimeZone.current
        dateFormatterGet.dateFormat = inputFormat
//        dateFormatterGet.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.timeZone = TimeZone.current
        dateFormatterPrint.dateFormat = formatStr
//        dateFormatterPrint.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        
        if let date = dateFormatterGet.date(from: dateStr) {
            return dateFormatterPrint.string(from: date).uppercased()
        } else {
            return "WRONG DATE FORMAT!"
        }
    }
    
    static func convertDateStrUTCToDateStr(dateStr: String, formatStr: String = "MMM dd, yyyy HH:mm:ss") -> String {
        if let date = self.convertDateStrToDateISO8601(dateStr: dateStr) {
            let dateFormatterPrint = DateFormatter()
            dateFormatterPrint.timeZone = TimeZone.current
            dateFormatterPrint.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
            dateFormatterPrint.dateFormat = formatStr
            return dateFormatterPrint.string(from: date).uppercased()
        }
        return "WRONG DATE FORMAT!"
    }
    
    static func convertDateStrToDate(dateStr: String = Constants.DATE_DEFAULT, inputFormat: String) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputFormat
        dateFormatter.timeZone = TimeZone.current
//        dateFormatter.locale = Locale.current
        dateFormatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        return dateFormatter.date(from: getShortDateFromDateStr(dateStr: dateStr)) ?? Date()
    }
    
    static func dateToString(date: Date, outFormat: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = outFormat
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        return formatter.string(from: date)
    }
    
    static func convertDateStrToDate(dateStr: String = Constants.DATE_DEFAULT) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        return dateFormatter.date(from: getShortDateFromDateStr(dateStr: dateStr)) ?? Date()
    }
    
    static func convertDateStrToDateISO8601(dateStr: String? = Constants.DATE_DEFAULT) -> Date? {
        let date = dateStr ?? Constants.DATE_DEFAULT
        let formatter = ISO8601DateFormatter()
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds,
            .withColonSeparatorInTime,
            .withDashSeparatorInDate,
            .withTimeZone]
        if let date = formatter.date(from: date) {
            return date
        } else {
            return convertDateStrToDate(dateStr: date)
        }
    }
    
    static func convertDateISO8601ToString(date: Date) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.formatOptions = [
            .withInternetDateTime,
            .withFractionalSeconds,
            .withColonSeparatorInTime,
            .withDashSeparatorInDate,
            .withTimeZone]
        return formatter.string(from: date)
    }
    
    static func convertSqlDateToNoticeDateStr(sqlDate: String = Constants.DATE_DEFAULT) -> String {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        dateFormatterGet.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatterPrint.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        if let date = dateFormatterGet.date(from: sqlDate) {
            return dateFormatterPrint.string(from: date).uppercased()
        } else {
            return Constants.DATE_DEFAULT
        }
    }
    
    static func convertSqlDateToDate(sqlDate: String = Constants.SQL_DATE_DEFAULT) -> Date {
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        dateFormatterGet.timeZone = TimeZone.current
        dateFormatterGet.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        return dateFormatterGet.date(from: sqlDate) ?? Date()
    }
    
    static func getNowDateStr() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter.string(from: date)
    }
    
    static func getNowDateTimeLogStr() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter.string(from: date)
    }
    
    static func getNowDateLogName() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        formatter.dateFormat = "yyyy_MM_dd"
        return formatter.string(from: date)
    }
    
    static func getNowSQLDateTime() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        return formatter.string(from: date)
    }
    
    static func getHeightUnitName() -> String {
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            return UnitConstants.CM
        } else {
            return UnitConstants.IN
        }
    }
    
    static func getWeightUnitName() -> String {
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            return UnitConstants.KG
        } else {
            return UnitConstants.LBS
        }
    }
    
    static func cmToIn(cm: Double) -> Double {
        (cm * 0.393701).to1Decimal
    }
    
    static func inToCm(inch: Double) -> Double {
        (inch / 0.393701).to1Decimal
    }
    
    static func kgToLbs(kg: Double) -> Double {
        (kg * 2.205).to1Decimal
    }
    
    static func lbsToKg(lbs: Double) -> Double {
        (lbs / 2.205).to1Decimal
    }
    
    static func showUnitLabel(isSpeed: Bool) -> String {
        if LocalDataManager.unit == Constants.UNIT_METRIC {
            return isSpeed ? "km/h" : "km"
        }
        return isSpeed ? "mph" : "mi"
    }
    
    static func kmToMile(km: Double?) -> Double {
        if LocalDataManager.unit == Constants.UNIT_METRIC {
            return (km ?? 0).to1Decimal
        }
        return ((km ?? 0.0) * 0.621371).to1Decimal
    }
    
    static func mileToKm(mile: Double?) -> Double {
        return ((mile ?? 0.0) / 0.621371).to1Decimal
    }
    
    static func getHeightUnitValue(height: Double) -> Double {
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            return height
        } else {
            return cmToIn(cm: height)
        }
    }
    static func getImperialHeightValue(cm: Double?) -> String {
        guard let cm = cm, cm != 0.0, let feetValue = convertCmToFeet(cm: cm) else {
            return ""
        }
        let feetInt = Int(feetValue)
        if convertFeetToInch(feet: feetValue - Double(feetInt)) == 12 {
            return "\(feetInt + 1) ft 0 in"
        } else {
            let deltaFeet = ((feetValue - Double(feetInt)) * 12).to1Decimal
            return "\(feetInt) ft \(String(format: "%.1f", deltaFeet)) in"
//            return "\(Int(feetValue)) ft \(convertFeetToInch(feet: feetValue - Double(Int(feetValue))) ?? 0) in"
        }
    }

    static func convertCmToFeet(cm: Double?) -> Double? {
        guard let cm = cm else {
            return 0.0
        }
        return (cm) * 0.032808
    }
    
    static func convertFeetToInch(feet: Double?) -> Int? {
        guard let feet = feet else {
            return 0
        }
        return Int(feet * 12)
    }
    
    static func getWeightUnitValue(weight: Double) -> Double {
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            return weight
        } else {
            return (weight * 2.205).to1Decimal
        }
    }
    
    static func getBluetoothDeviceId(identifier: String) -> String {
        "\(identifier.substring(range: 0..<2)):\(identifier.substring(range: 2..<4)):\(identifier.substring(range: 4..<6)):\(identifier.substring(range: 6..<8))"
    }
    
    static func getLTTestUserType() -> Int {
        switch LocalDataManager.ltTestSetting.userType {
        case LTTestConstants.ORDINARY_USER:
            return 1
        case LTTestConstants.RUNNING_USER:
            return 2
        case LTTestConstants.ETC_USER:
            return 3
        case .none:
            return 1
        case .some:
            return 1
        }
    }
    
    static func toHexString(byteArray: [UInt8]) -> String {
        byteArray.map { .init(format: "%02x", $0) }.joined()
    }
    
    static func toHexArrayString(byteArray: [UInt8]) -> String {
        "[\(byteArray.map { .init(format: "0x%02x, ", $0) }.joined())]"
    }
    
    static func toString(byteArray: [UInt8]) -> String {
        String(decoding: byteArray, as: UTF8.self)
    }
    
    static func toSmO2(byteArray: [UInt8]) -> Double {
        var result: Double = Double(twoBytesToInt(byteArray: byteArray))
        result /= 10.0
        if(result > 100) {
            result = 100
        }
        return result.to1Decimal
    }
    
    static func twoBytesToInt(byteArray: [UInt8]) -> Int {
        var result: Int = 0
        for idx in 0..<(byteArray.count) {
            let shiftAmount = UInt((byteArray.count) - idx - 1) * 8
            result += Int(byteArray[idx]) << shiftAmount
        }
        return result
    }
    
    static func fourBytesToInt(byteArray: [UInt8]) -> Int {
        var result: UInt32 = 0
        let data = NSData(bytes: byteArray, length: byteArray.count)
        data.getBytes(&result, length: byteArray.count)
        result = UInt32(bigEndian: result)
        return Int(result)
    }
    
    static func structToJsonStr<T: Encodable>(_ data: T) -> String {
        do {
            let jsonData = try JSONEncoder().encode(data)
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                return jsonString
            } else {
                Functions.showLog(title: "Error", message: "Parse data to json error")
            }
        } catch {
            // Nothing
            Functions.showLog(title: "Error", message: "Parse data to json error")
        }
        return ""
    }
    
    static func getDistanceFrom2Coordinate(firstLocation: CLLocation, secondLocation: CLLocation) -> Double {
        firstLocation.distance(from: secondLocation) / 1000.0 // return km
    }
    
    static func getCurrenYear() -> Int {
        Calendar.current.component(.year, from: Date())
    }
    
    static func getCurrenMonth() -> Int {
        Calendar.current.component(.month, from: Date())
    }
    
    static func getCurrenSecond() -> Int {
        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        dateFormatterPrint.dateFormat = "ss"
        return Int(dateFormatterPrint.string(from: Date()).uppercased()) ?? 0
    }
    
    static func getTodayExerciseId() -> String {
        let day = Calendar.current.component(.day, from: Date())
        let month = Calendar.current.component(.month, from: Date())
        let year = Calendar.current.component(.year, from: Date())
        return "\(year)_\(month)_\(day)"
    }
    
    static func getExerciseTimeNow(fromDate: Date = Date()) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        formatter.timeZone = TimeZone.current
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: fromDate)
    }
    
    static func getTimeDisplayStrFromSeconds(_ seconds: Int?) -> String {
        let display = "--:--:--"
        if seconds != nil {
            let seconds = seconds ?? 0
            let hh = seconds / 3600
            let mm = (seconds % 3600) / 60
            let ss = (seconds % 3600) % 60
            return "\(getStringFrom(seconds: hh)):\(getStringFrom(seconds: mm)):\(getStringFrom(seconds: ss))"
        }
        return display
    }
    static func getStringFrom(seconds: Int) -> String {
        return seconds < 10 ? "0\(seconds)" : "\(seconds)"
    }
    static func convertMeasureToS3Measure(measure: RepaceMeasureModel) -> RepaceMeasureDetailModel {
        var s3Measure = RepaceMeasureDetailModel()
        do {
            s3Measure.index = fourBytesToInt(byteArray: measure.sequence)
            s3Measure.ch1_780 = twoBytesToInt(byteArray: [measure.channel1[0], measure.channel1[1]])
            s3Measure.ch1_850 = twoBytesToInt(byteArray: [measure.channel1[2], measure.channel1[3]])
            s3Measure.ch1_940 = twoBytesToInt(byteArray: [measure.channel1[4], measure.channel1[5]])
            s3Measure.ch1_680 = twoBytesToInt(byteArray: [measure.channel1[6], measure.channel1[7]])
            s3Measure.ch2_780 = twoBytesToInt(byteArray: [measure.channel2[0], measure.channel2[1]])
            s3Measure.ch2_850 = twoBytesToInt(byteArray: [measure.channel2[2], measure.channel2[3]])
            s3Measure.ch2_940 = twoBytesToInt(byteArray: [measure.channel2[4], measure.channel2[5]])
            s3Measure.ch2_680 = twoBytesToInt(byteArray: [measure.channel2[6], measure.channel2[7]])
            s3Measure.ch3_780 = twoBytesToInt(byteArray: [measure.channel3[0], measure.channel3[1]])
            s3Measure.ch3_850 = twoBytesToInt(byteArray: [measure.channel3[2], measure.channel3[3]])
            s3Measure.ch3_940 = twoBytesToInt(byteArray: [measure.channel3[4], measure.channel3[5]])
            s3Measure.ch3_680 = twoBytesToInt(byteArray: [measure.channel3[6], measure.channel3[7]])
            s3Measure.ch4_780 = twoBytesToInt(byteArray: [measure.channel4[0], measure.channel4[1]])
            s3Measure.ch4_850 = twoBytesToInt(byteArray: [measure.channel4[2], measure.channel4[3]])
            s3Measure.ch4_940 = twoBytesToInt(byteArray: [measure.channel4[4], measure.channel4[5]])
            s3Measure.ch4_680 = twoBytesToInt(byteArray: [measure.channel4[6], measure.channel4[7]])
            s3Measure.ch5_780 = twoBytesToInt(byteArray: [measure.channel5[0], measure.channel5[1]])
            s3Measure.ch5_850 = twoBytesToInt(byteArray: [measure.channel5[2], measure.channel5[3]])
            s3Measure.ch5_940 = twoBytesToInt(byteArray: [measure.channel5[4], measure.channel5[5]])
            s3Measure.ch6_680 = twoBytesToInt(byteArray: [measure.channel5[6], measure.channel5[7]])
            s3Measure.ch6_780 = twoBytesToInt(byteArray: [measure.channel6[0], measure.channel6[1]])
            s3Measure.ch6_850 = twoBytesToInt(byteArray: [measure.channel6[2], measure.channel6[3]])
            s3Measure.ch6_940 = twoBytesToInt(byteArray: [measure.channel6[4], measure.channel6[5]])
            s3Measure.ch6_680 = twoBytesToInt(byteArray: [measure.channel6[6], measure.channel6[7]])
            s3Measure.rSO2 = toSmO2(byteArray: measure.rSO2)
            s3Measure.ac_x = twoBytesToInt(byteArray: [measure.accel[0], measure.accel[1]])
            s3Measure.ac_y = twoBytesToInt(byteArray: [measure.accel[2], measure.accel[3]])
            s3Measure.ac_z = twoBytesToInt(byteArray: [measure.accel[4], measure.accel[5]])
            s3Measure.gyro_x = twoBytesToInt(byteArray: [measure.gyro[0], measure.accel[1]])
            s3Measure.gyro_y = twoBytesToInt(byteArray: [measure.gyro[2], measure.accel[3]])
            s3Measure.gyro_z = twoBytesToInt(byteArray: [measure.gyro[4], measure.accel[5]])
            s3Measure.bleHex = toHexArrayString(byteArray: measure.data)
            s3Measure.marker = measure.marker
        } catch {
            Functions.showLog(title: "convertMeasureToS3MeasureError", message: error)
        }
        return s3Measure
    }
    
    static func getListSmO2(list: [SmO2ChartModel]?) -> List<SmO2ChartObject> {
        let result = List<SmO2ChartObject>()
        if let list = list {
            list.forEach { model in
                result.append(SmO2ChartObject(model: model))
            }
        }
        return result
    }
    
    static func startFakeGainData() {
        if Constants.IS_RUN_FAKE_DATA_LT_TEST {
            Timer.scheduledTimer(withTimeInterval: 5, repeats: false) { _ in
                let data: [UInt8] = [0x0a, 0x0b, 0x0c, 0x0b, 0x16, 0x1f, 0x00, 0x1f, 0x00, 0x1f, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x5f, 0x0a, 0x0b, 0x0c, 0xee, 0x01, 0x01, 0x01]
                BluetoothHelper.checkRepaceData(byteArrayData: data)
            }
        }
    }
    
    static func startFakeMeasureData() {
        if Constants.IS_RUN_FAKE_DATA_LT_TEST {
            var index = 0
            timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { _ in
                let dataList = Constants.FAKE_MEASURE_DATA
                let data: [UInt8] = dataList[index]
                BluetoothHelper.checkRepaceData(byteArrayData: data)
                // Fake heartrate
                let heartrate = Double.random(in: 50...100)
                // Functions.showLog(title: "HR -> Heart Rate Value", message: heartrate)
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil, userInfo: [NotificationCenterHelper.HR_HEART_RATE_DATA: heartrate])
                if LocalDataManager.isSaveSmo2List == true {
                    LocalDataManager.ltTestHRList.append(heartrate)
                }
                // Update index fake data
                index += 1
                if index > 10 {
                    index = 0
                }
            }
        }
    }
    
    static func stopFakeDataLTTest() {
        timer?.invalidate()
        timer = nil
    }
}
