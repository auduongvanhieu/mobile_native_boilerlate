struct NotificationCenterHelper {
    // Instance
    static let nc = NotificationCenter.default
    
    static let CHANGE_LANGUAGE_ACTION = NSNotification.Name(rawValue: "CHANGE_LANGUAGE_ACTION")
    // Action
    static let BLUETOOTH_CONNECTION_STATUS_ACTION = NSNotification.Name(rawValue: "BLUETOOTH_CONNECTION_STATUS_ACTION")
    static let CHANGE_MAIN_TAB_ACTION = NSNotification.Name(rawValue: "CHANGE_MAIN_TAB_ACTION")
    static let MAIN_TAB_CHANGE_LANGUAGE = NSNotification.Name(rawValue: "MAIN_TAB_CHANGE_LANGUAGE")
    static let BLE_START_SCAN_ACTION = NSNotification.Name(rawValue: "BLE_START_SCAN_ACTION")
    static let BLE_STOP_SCAN_ACTION = NSNotification.Name(rawValue: "BLE_STOP_SCAN_ACTION")
    static let BLE_SCANNED_ACTION = NSNotification.Name(rawValue: "BLE_SCANNED_ACTION")
    static let BLE_CONNECT_DEVICE_ACTION = NSNotification.Name(rawValue: "BLE_CONNECT_DEVICE_ACTION")
    static let BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION = NSNotification.Name(rawValue: "BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION")
    static let BLE_TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE = NSNotification.Name(rawValue: "BLE_TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE")
    static let BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION = NSNotification.Name(rawValue: "BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION")
    static let HR_RECEIVE_HEART_RATE_ACTION = NSNotification.Name(rawValue: "HR_RECEIVE_HEART_RATE_ACTION")
    
    // Data
    static let TAB_DATA = NSNotification.Name(rawValue: "TAB_DATA")
    static let BLE_SCANNED_DATA = NSNotification.Name(rawValue: "BLE_SCANNED_DATA")
    static let BLE_CONNECT_DEVICE_DATA = NSNotification.Name(rawValue: "BLE_CONNECT_DEVICE_DATA")
    static let BLE_DISCONNECT_DEVICE_DATA = NSNotification.Name(rawValue: "BLE_DISCONNECT_DEVICE_DATA")
    static let BLE_RECEIVE_MEASURE_DATA = NSNotification.Name(rawValue: "BLE_RECEIVE_MEASURE_DATA")
    static let HR_HEART_RATE_DATA = NSNotification.Name(rawValue: "HR_HEART_RATE_DATA")
    
    // Reset
    static let RESET_MAINVIEWCONTROLLER = NSNotification.Name(rawValue: "RESET_MAINVIEWCONTROLLER")
}
