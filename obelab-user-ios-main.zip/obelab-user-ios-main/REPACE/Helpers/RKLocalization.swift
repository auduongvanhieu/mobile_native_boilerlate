//
//  LanguageLocalized.swift
//  HoloEditing
//
//  Created by Timmy on 5/7/20.
//  Copyright © 2020 HoloEditing. All rights reserved.
//

import UIKit

class RKLocalization: NSObject {
    static let sharedInstance = RKLocalization()
    var bundle: Bundle?

    // get localizedString from bundle of selected language
    func localizedString(forKey key: String, value comment: String) -> String {
        if let bundle = bundle {
            let localized = bundle.localizedString(forKey: key, value: comment, table: nil)
            return localized
        }
        else {
            bundle = Bundle.main
            let localized = bundle!.localizedString(forKey: key, value: comment, table: nil)
            return localized
        }
    }

    // set language for localization
    func setLanguage(language: String) {
        var selectedLanguage = language
        if language.isEmpty {
            selectedLanguage = "en"
        }
        UserDefaults.standard.set(selectedLanguage, forKey: "kLanguage")
        UserDefaults.standard.synchronize()
        let path: String? = Bundle.main.path(forResource: selectedLanguage, ofType: "lproj")
        if path == nil {
            //in case the language does not exists
            resetLocalization()
        } else {
            bundle = Bundle(path: path!)
        }
    }

    // reset bundle
    func resetLocalization() {
        bundle = Bundle.main
    }

    // get selected language from UserDefaults
    func getLanguage() -> String? {
        if let language = UserDefaults.standard.string(forKey: "kLanguage") {
            return language
        }
        return nil
    }

}

// LocalizedString to get string in selected language
func RKLocalizedString(key: String, _ comment: String = "") -> String {
    return RKLocalization.sharedInstance.localizedString(forKey: key, value: comment)
}
