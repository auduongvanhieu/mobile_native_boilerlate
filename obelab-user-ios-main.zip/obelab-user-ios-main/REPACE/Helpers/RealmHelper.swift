//
//  RealmHelper.swift
//  REPACE
//
//  Created by BM Johnny on 4/4/22.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import RealmSwift
import Realm
import CoreLocation

class RealmHelper: NSObject {
    
    static var share = RealmHelper()
    
    func loadS3File(completion: @escaping (String) -> Void) {
        DispatchQueue(label: "background").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    let list = realm.objects(RepaceMeasureObject.self).sorted(byKeyPath: "index", ascending: true)
                    var result: [RepaceMeasureDetailModel] = []
                    list.forEach { object in
                        let element = object.convertToRepaceMeasureDetailModel()
                        result.append(element)
                    }
                    let text = Functions.structToJsonStr(result)
                    DispatchQueue.main.async {
                        completion(text)
                    }
                } catch let err {
                    Functions.showLog(title: "Error function loadS3File", message: err.localizedDescription)
                }
            }
        }
    }
    
    func cleanS3File() {
        DispatchQueue(label: "cleanS3File").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    try realm.safeWrite {
                        realm.delete(realm.objects(RepaceMeasureObject.self))
                    }
                } catch let err {
                    Functions.showLog(title: "Error function cleanS3File", message: err.localizedDescription)
                }
            }
        }
    }
    
    func loadSmo2Object(completion: @escaping ([Double]) -> Void) {
        DispatchQueue(label: "loadSmo2Object").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    let list = realm.objects(SmO2Object.self).sorted(byKeyPath: "index", ascending: true)
                    var arr: [Double] = []
                    list.forEach { smO2 in
                        arr.append(smO2.rSO2)
                    }
                    DispatchQueue.main.async {
                        completion(arr)
                    }
                } catch let err {
                    Functions.showLog(title: "Error function loadSmo2Object", message: err.localizedDescription)
                }
            }
        }
    }
    
    func loadAllDataInExercise(isLTTest: Bool, arrSmo2: [Int], arrHeartrate: [Int], completion: ((ExerciseResultModel?) -> Void)?) {
        DispatchQueue(label: "loadAllDataInExercise").async {
            autoreleasepool {
                do {
                    var exerciseResult = ExerciseResultModel()
                    let realm = try Realm()
                    let smo2 = self.loadSmO2Value(isLTTest: isLTTest, realm: realm, arrSmo2: arrSmo2)
                    exerciseResult.smo2Min = smo2.min
                    exerciseResult.smo2Max = smo2.max
                    exerciseResult.smo2Avg = smo2.avg
                    exerciseResult.listSmo2 = smo2.list
                    let heartrate = self.loadHeartRateValue(isLTTest: isLTTest, realm: realm, arrHeartrate: arrHeartrate)
                    exerciseResult.heartRateMin = Int(heartrate.min)
                    exerciseResult.heartRateMax = Int(heartrate.max)
                    exerciseResult.heartRateAvg = heartrate.avg
                    exerciseResult.listHeartRate = heartrate.list
                    exerciseResult.listLocation = self.loadLocationValue(realm: realm)
                    DispatchQueue.main.async {
                        completion?(exerciseResult)
                    }
                } catch let err {
                    Functions.showLog(title: "Error function loadSmo2Object", message: err.localizedDescription)
                    DispatchQueue.main.async {
                        completion?(nil)
                    }
                }
            }
        }
    }
    
    private func loadSmO2Value(isLTTest: Bool, realm: Realm, arrSmo2: [Int]) -> SmO2AndHeartrateModel {
        let list = realm.objects(SmO2Object.self).sorted(byKeyPath: "index", ascending: true)
        var arrValue: [Double] = []
        list.forEach { smO2 in
            arrValue.append(smO2.rSO2)
        }
        return self.getParamForModel(arr: arrSmo2, arrValue: arrValue, isLTTest: isLTTest)
    }
    
    private func loadHeartRateValue(isLTTest: Bool, realm: Realm, arrHeartrate: [Int]) -> SmO2AndHeartrateModel {
        let list = realm.objects(HeartrateObject.self).sorted(byKeyPath: "index", ascending: true)
        var arrValue: [Double] = []
        list.forEach { object in
            arrValue.append(object.heartrate)
        }
        return self.getParamForModel(arr: arrHeartrate, arrValue: arrValue, isLTTest: isLTTest)
    }
    
    private func loadLocationValue(realm: Realm) -> [LocationModel] {
        let memberID = LocalDataManager.profile?.id ?? 0
        var arrValue: [LocationModel] = []
        if let exerciseID = BluetoothHelper.idExercise {
            let list = realm.objects(LocationObject.self).filter("memberID == \(memberID) and exerciseID == \(exerciseID)").sorted(byKeyPath: "index", ascending: true)
            list.forEach { object in
                arrValue.append(LocationModel(latitude: object.latitude, longitude: object.longitude, time: object.time))
            }
        }
        return arrValue
    }
    
    // Return min, max, average all, array SmO2ChartModel period
    private func getParamForModel(arr: [Int], arrValue: [Double], isLTTest: Bool) -> SmO2AndHeartrateModel {
        var min: Double = 0
        var max: Double = 0
        var arrResult: [SmO2ChartModel] = []
        var averageAll: Double = 0
        var sumSmO2All: Double = 0
        var arrSmo2 = arr
        var durationTime = 5
        if isLTTest || LocalDataManager.exerciseResult.typeID == ExerciseConstants.FREE_EXERCISE {
            durationTime = 1
        }
        if arrSmo2.isEmpty == false {
            var smo2Sum: Double = 0
            var indexSmO2 = 1
            var numberElement: Double = 0
            var totalElement: Double = 0
            for (index, smO2) in arrValue.enumerated() {
                if smO2 > 0 {
                    min = min == 0 ? smO2 : Double.minimum(smO2, min)
                    max = Double.maximum(smO2, max)
                    sumSmO2All += smO2
                    totalElement += 1
                }
                if let first = arrSmo2.first {
                    // last Element
                    if smO2 > 0 {
                        smo2Sum += smO2
                        numberElement += 1
                    }
                    if index == first || index == arrValue.count - 1 {
                        let score = numberElement == 0 ? smO2 : smo2Sum / numberElement
                        arrResult.append(SmO2ChartModel(name: "\(indexSmO2 * durationTime)", score: score.to1Decimal))
                        if index == first {
                            indexSmO2 += 1
                            smo2Sum = 0
                            numberElement = 0
                            arrSmo2.remove(at: 0)
                        }
                    }
                }
            }
            if totalElement > 0 {
                averageAll = sumSmO2All / totalElement
            }
        }
        return SmO2AndHeartrateModel(min: min.to1Decimal, max: max.to1Decimal, avg: averageAll.to1Decimal, list: arrResult)
    }
    
    func cleanSmO2Object() {
        DispatchQueue(label: "cleanSmO2Object").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    try realm.safeWrite {
                        realm.delete(realm.objects(SmO2Object.self))
                    }
                } catch let err {
                    Functions.showLog(title: "Error cleanSmO2Object", message: err.localizedDescription)
                }
            }
        }
    }
    
    func cleanLocationObject(idExercise: Int) {
        Functions.showLog(title: "Uploading Local Progress success: delete Location local DB", message: "")
        DispatchQueue(label: "cleanLocationObject").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    let memberID = LocalDataManager.profile?.id ?? 0
                    try realm.safeWrite {
                        realm.delete(realm.objects(LocationObject.self).filter({$0.memberID == memberID && $0.exerciseID == idExercise}))
                    }
                } catch let err {
                    Functions.showLog(title: "Error cleanLocationObject", message: err.localizedDescription)
                }
            }
        }
    }
    
    func cleanExerciseObject(isLTest: Bool, idExercise: Int) {
        Functions.showLog(title: "Uploading Local Progress success: delete Location local DB", message: "")
        DispatchQueue(label: "cleanLocationObject").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    let memberID = LocalDataManager.profile?.id ?? 0
                    try realm.safeWrite {
                        if isLTest {
                            if let object = realm.objects(LTTestResultObject.self).first(where: {$0.memberID == memberID && $0.id == idExercise}) {
                                realm.delete(object)
                            }
                            
                        } else {
                            if let object = realm.objects(RxExerciseResultObject.self).first(where: {$0.memberID == memberID && $0.id == idExercise}) {
                                realm.delete(object)
                            }
                        }
                    }
                } catch let err {
                    Functions.showLog(title: "Error cleanLocationObject", message: err.localizedDescription)
                }
            }
        }
    }
    
    func cleanHeartrateObject() {
        DispatchQueue(label: "cleanHeartrateObject").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    try realm.safeWrite {
                        realm.delete(realm.objects(HeartrateObject.self))
                    }
                } catch let err {
                    Functions.showLog(title: "Error cleanHeartrateObject", message: err.localizedDescription)
                }
            }
        }
    }
    
    func cleanDataBeforeStartNewExercise() {
        cleanS3File()
        cleanSmO2Object()
        cleanHeartrateObject()
    }
    
    func addDataRealm(s3MeasureModel: RepaceMeasureDetailModel, rSO2: Double) {
        let s3MeasureObject = RepaceMeasureObject(model: s3MeasureModel)
        let smO2Object = SmO2Object()
        smO2Object.index = s3MeasureObject.index
        smO2Object.rSO2 = rSO2
        do {
            let realm = try Realm()
            try realm.safeWrite({
                realm.add(smO2Object)
                realm.add(s3MeasureObject)
                Functions.showLog(title: "addDataRealm index = \(smO2Object.index) rSO2 = \(rSO2) marker = \(s3MeasureObject.marker)", message: "")
            })
        } catch let err {
            Functions.showLog(title: "Error addDataRealm Realm Write", message: err.localizedDescription)
        }
    }
    
    func saveLocationDB(index: Int, model: LocationModel, period: String?) {
        guard let id = BluetoothHelper.idExercise else { return }
        let locationObject = LocationObject(index: index, model: model, period: period, exerciseID: id)
        do {
            let realm = try Realm()
            try realm.safeWrite({
                realm.add(locationObject)
                let periodStr = period == nil ? "" : " period = \(period ?? "")"
                Functions.showLog(title: "saveLocationDB index = \(index)\(periodStr)", message: "")
            })
        } catch let err {
            Functions.showLog(title: "Error saveLocationDB Realm Write", message: err.localizedDescription)
        }
    }
    
    func saveHeartrate(heartrate: Double, period: String?) {
        do {
            let realm = try Realm()
            try realm.safeWrite({
                let max = realm.objects(HeartrateObject.self).map({$0.index}).max() ?? 0
                let object = HeartrateObject(index: max + 1, heartrate: heartrate, period: period)
                realm.add(object)
                let periodStr = period == nil ? "" : " period = \(period ?? "")"
                Functions.showLog(title: "saveHeartrate index =\(max + 1) heartrate = \(heartrate)\(periodStr)", message: object)
            })
        } catch let err {
            Functions.showLog(title: "Error saveHeartrate Realm Write", message: err.localizedDescription)
        }
    }
    
    func getMaxIndexHeartrate() -> Int? {
        do {
            let realm = try Realm()
            let maxIndex = realm.objects(HeartrateObject.self).map({$0.index}).max()
            return maxIndex
        } catch let err {
            Functions.showLog(title: "Error getMaxIndexHeartrate Realm Write", message: err.localizedDescription)
            return nil
        }
    }
    
    func loadLTTest() {
        do {
            let realm = try Realm()
            let id = LocalDataManager.profile?.id ?? 0
            let list = realm.objects(RxExerciseResultObject.self).filter("memberID == \(id)")
            Functions.showLog(title: "loadLTTest", message: list)
        } catch let err {
            Functions.showLog(title: "loadLTTest error", message: err.localizedDescription)
        }
    }
    
    func saveExercise(isLTTest: Bool, idExercise: Int, isFailByConnection: ((Any) -> Void)?, completion: ((Any) -> Void)?, updatePercent: ((Double) -> Void)?) {
        do {
            let realm = try Realm()
            let memberID = LocalDataManager.profile?.id ?? 0
            var object: ResultExerciseObject?
            if isLTTest {
                object = realm.objects(LTTestResultObject.self).first(where: {$0.id == idExercise && $0.memberID == memberID})
            } else {
                object = realm.objects(RxExerciseResultObject.self).first(where: {$0.id == idExercise && $0.memberID == memberID})
            }
            if let object = object {
                uploadDataByObject(realm: realm, object: object, isFailByConnection: isFailByConnection, completion: completion, updatePercent: updatePercent)
            } else {
                let exer = isLTTest ? "LTTestExercise" : "RxExercise"
                FileHelper.writeStringToLogFile(title: "RealmHelper load \(exer) fail because exercise id = \(idExercise) is not existed", content: "")
                completion?(true)
            }
        } catch let err {
            Functions.showLog(title: "Save Local Progress Error: saveExercise update DB", message: err)
            let exer = isLTTest ? "LTTestExercise" : "RxExercise"
            FileHelper.writeStringToLogFile(title: "RealmHelper load \(exer) fail exercise id = \(idExercise) with error \(err.localizedDescription)", content: "")
            completion?(true)
        }
    }
    
    private func uploadDataByObject(realm: Realm, object: ResultExerciseObject, isFailByConnection: ((Any) -> Void)?, completion: ((Any) -> Void)?, updatePercent: ((Double) -> Void)?) {
        BluetoothHelper.isCurrentParingPage = true // Don't show pop up disconnect BLE
        object.uploadData(isFailByConnection: isFailByConnection,
                          finishSM3: { urlStr in
                                    if object.isInvalidated == false {
                                    do {
                                        try realm.safeWrite {
                                            object.bleData = urlStr
                                            object.isUploadedS3File = true
                                            Functions.showLog(title: "Uploading Local Progress success: BLE = \(urlStr)", message: object)
                                            FileHelper.writeStringToLogFile(title: "RealmHelper upload S3 success exercise local id = \(object.id) BLE = \(urlStr)", content: "")
                                        }
                                    } catch let err {
                                        Functions.showLog(title: "Update Local Progress Error: BLE = \(urlStr)", message: err)
                                        FileHelper.writeStringToLogFile(title: "RealmHelper update BLE & isUploadedS3File properties fail exercise local id = \(object.id)", content: err.localizedDescription)
                                    }
                                } else {
                                    BluetoothHelper.isCurrentParingPage = false
                                    FileHelper.writeStringToLogFile(title: "RealmHelper update BLE & isUploadedS3File property fail object is invalidated", content: "")
                                }
                            }, finishExercise: {
                                if object.isInvalidated == false {
                                    do {
                                        try realm.safeWrite {
                                            object.isUploadedExercise = true
                                            Functions.showLog(title: "Uploading Local Progress success: isUploadedExercise = true", message: object)
                                            FileHelper.writeStringToLogFile(title: "RealmHelper upload exercise data success exercise local id = \(object.id)", content: "")
                                        }
                                    } catch let err {
                                        Functions.showLog(title: "Update Local Progress Error: isUploadedExercise", message: err)
                                        FileHelper.writeStringToLogFile(title: "RealmHelper update isUploadedExercise property fail exercise local id = \(object.id)", content: err.localizedDescription)
                                    }
                                } else {
                                    BluetoothHelper.isCurrentParingPage = false
                                    FileHelper.writeStringToLogFile(title: "RealmHelper update isUploadedExercise property fail object is invalidated", content: "")
                                }
                            }, isLock: { isLock in
//                                if object.isInvalidated == false {
//                                    do {
//                                        try realm.safeWrite {
//                                            object.isLock = isLock
//                                            Functions.showLog(title: "Uploading Local Progress success: isLock = \(isLock)", message: object)
//                                            FileHelper.writeStringToLogFile(title: "RealmHelper upload exercise isLock = \(isLock) exercise local id = \(object.id)", content: "")
//                                        }
//                                    } catch let err {
//                                        Functions.showLog(title: "Update Local Progress Error: isLock = \(isLock)", message: err)
//                                        FileHelper.writeStringToLogFile(title: "RealmHelper update property isLock = \(isLock) fail exercise local id = \(object.id)", content: err.localizedDescription)
//                                    }
//                                } else {
//                                    BluetoothHelper.isCurrentParingPage = false
//                                }
                            }, completion: { data in
                                if object.isInvalidated == false {
                                    let idExercise = object.id
                                    RealmHelper.share.cleanLocationObject(idExercise: idExercise)
                                    BluetoothHelper.idExercise = nil
                                    RealmHelper.share.cleanExerciseObject(isLTest: object.isKind(of: LTTestResultObject.self), idExercise: idExercise)
                                    Functions.showLog(title: "Uploading Local Progress success: delete local DB", message: object)
                                    FileHelper.writeStringToLogFile(title: "RealmHelper upload exercise success, clean local DB, exercise local id = \(object.id)", content: "")
                                }
                                completion?(data)
                                BluetoothHelper.isCurrentParingPage = false
                            }, updatePercent: updatePercent)
    }
    
    func saveExerciseResult(object: Object, isAdded: ((Realm?) -> Void)?) {
        do {
            let realm = try Realm()
            try realm.safeWrite({
                realm.add(object)
                Functions.showLog(title: "Save Local Progress success: saveExerciseResult", message: object)
                isAdded?(realm)
            })
        } catch let err {
            Functions.showLog(title: "Save Local Progress Error: Realm Write", message: err.localizedDescription)
            isAdded?(nil)
        }
    }
    
    func cleanAnObject(object: Object) {
        Functions.showLog(title: "Uploading Local Progress success: delete exercise local DB", message: object)
        DispatchQueue(label: "cleanAnObject").async {
            autoreleasepool {
                if object.isInvalidated == false {
                    do {
                        let realm = try Realm()
                        try realm.safeWrite {
                            realm.delete(object)
                        }
                    } catch let err {
                        Functions.showLog(title: "Error function cleanAnObject", message: err.localizedDescription)
                    }
                }
            }
        }
    }
    
    func getAllLTTestInLocalDB() -> Results<LTTestResultObject>? {
        do {
            let realm = try Realm()
            let memberID = LocalDataManager.profile?.id ?? 0
            let result = realm.objects(LTTestResultObject.self).filter("memberID == \(memberID)").sorted(byKeyPath: "id", ascending: false)
            return result
        } catch let err {
            Functions.showLog(title: "Error function getExerciseID", message: err.localizedDescription)
        }
        return nil
    }
    
    func getAllLTTestInLocalDB(memberID: Int?) -> Results<LTTestResultObject>? {
        do {
            let realm = try Realm()
            if let memberID = memberID {
                let result = realm.objects(LTTestResultObject.self).filter("memberID = \(memberID)").sorted(byKeyPath: "id", ascending: false)
                return result
            } else {
                let result = realm.objects(LTTestResultObject.self).sorted(byKeyPath: "id", ascending: false)
                return result
            }
        } catch let err {
            Functions.showLog(title: "Error function getExerciseID", message: err.localizedDescription)
        }
        return nil
    }
    
    func getAllExerciseInLocalDB(month: Int, year: Int, type: String?) -> Results<RxExerciseResultObject>? {
        do {
            let realm = try Realm()
            let memberID = LocalDataManager.profile?.id ?? 0
            let monthStr = month < 10 ? "0\(month)" : "\(month)"
            let monthDateFilter = "\(year)-\(monthStr)"
            var typeStr = " "
            if let type = type {
                typeStr = " AND typeID = '\(type)' "
            }
            let predicate = "memberID = \(memberID)\(typeStr)AND createdAt BEGINSWITH '\(monthDateFilter)'"
            return realm.objects(RxExerciseResultObject.self).filter(predicate).sorted(byKeyPath: "createdAt", ascending: false)
        } catch let err {
            Functions.showLog(title: "Error function getExerciseID", message: err.localizedDescription)
        }
        return nil
    }
    
    func getAutoIncrementExerciseID(isLTTest: Bool) -> Int {
        do {
            let realm = try Realm()
            let memberID = LocalDataManager.profile?.id ?? 0
            if isLTTest {
                let max = realm.objects(LTTestResultObject.self).filter("memberID == \(memberID)").map({$0.id}).max()
                let result = max ?? 0
                return result + 1
            } else {
                let max = realm.objects(RxExerciseResultObject.self).filter("memberID == \(memberID)").map({$0.id}).max()
                let result = max ?? 0
                return result + 1
            }
        } catch let err {
            Functions.showLog(title: "Error function getExerciseID", message: err.localizedDescription)
        }
        return 1
    }
    
    func getExerciseByID(isLTTest: Bool, idExercise: Int) -> ResultExerciseObject? {
        do {
            let realm = try Realm()
            let memberID = LocalDataManager.profile?.id ?? 0
            if isLTTest {
                return realm.objects(LTTestResultObject.self).first(where: {$0.memberID == memberID && $0.id == idExercise})
            } else {
                return realm.objects(RxExerciseResultObject.self).first(where: {$0.memberID == memberID && $0.id == idExercise})
            }
        } catch let err {
            Functions.showLog(title: "Error function getExerciseID", message: err.localizedDescription)
        }
        return nil
    }
}

extension Object {
    func save(isAdded: ((Realm?) -> Void)?) {
        RealmHelper.share.saveExerciseResult(object: self, isAdded: isAdded)
    }
    
    func delete() {
        RealmHelper.share.cleanAnObject(object: self)
    }
    
    func toDictionary() -> [String: Any] {
        let properties = self.objectSchema.properties.map { $0.name }
        var mutabledic = self.dictionaryWithValues(forKeys: properties)
        for prop in self.objectSchema.properties as [Property] {
            // find lists
            if let nestedObject = self[prop.name] as? Object {
                mutabledic[prop.name] = nestedObject.toDictionary()
            } else if let nestedListObject = self[prop.name] as? RLMSwiftCollectionBase {
                var objects = [[String: Any]]()
                for index in 0..<nestedListObject._rlmCollection.count {
                    if let object = nestedListObject._rlmCollection[index] as? Object {
                        objects.append(object.toDictionary())
                    }
                }
                mutabledic[prop.name] = objects
            }
        }
        return mutabledic
    }
    
//    func showValue(atIndex: Int) -> [[String]] {
//        let properties = self.objectSchema.properties.map { $0.name }
//        var line: String = "\n"
//        var objectProperty: [String] = []
//        var listObjectProperty: [String] = []
//        for prop in properties {
//            let value = self[prop]
//            if let nestedObject = value as? Object {
//                let type = type(of: nestedObject)
//                line += String(describing: type) + "_\(atIndex)\t"
//                objectProperty.append(prop)
//            } else if let nestedListObject = value as? List<Object> {
//                let type = type(of: nestedListObject)
//                line += "List_" + "\(String(describing: type))" + "_\(atIndex) (\(nestedListObject.count)\t"
//                listObjectProperty.append(prop)
//            } else if let valueDouble = value as? Double {
//                line += "\(valueDouble.to1Decimal)\t"
//            } else {
//                line += String(describing: value) + "\t"
//            }
//        }
//        print(line)
//        return [objectProperty, listObjectProperty]
//    }
}

extension Realm {
    public func safeWrite(_ block: (() throws -> Void)) throws {
        if isInWriteTransaction {
            try block()
        } else {
            try write(block)
        }
    }
}

extension Results {
    func toArray<T>(ofType: T.Type) -> [T] {
        var array = [T]()
        for index in 0 ..< count {
            if let result = self[index] as? T {
                array.append(result)
            }
        }
        return array
    }
    
    func toList<T>(ofType: T.Type) -> List<T> {
        let list = List<T>()
        for index in 0 ..< count {
            if let result = self[index] as? T {
                list.append(result)
            }
        }
        return list
    }
    
//    func showData() {
//        if self.isEmpty == true {
//            let type = type(of: self)
//            print("List_" + "\(String(describing: type))" + " empty")
//        } else {
//            let type = type(of: self)
//            print("List_" + "\(String(describing: type))" + " \(self.count)")
//        }
//        var arrObjectAndListObject: [[String]] = []
//        for (indObject, object) in self.enumerated() {
//            if let object = object as? Object {
//                if indObject == 0 {
//                    // Print properties
//                    var line: String = ""
//                    let properties = object.objectSchema.properties.map { $0.name }
//                    for prop in properties {
//                        line += "\(prop)\t"
//                    }
//                    print(line)
//                }
//                arrObjectAndListObject = object.showValue(atIndex: indObject)
//            }
//        }
//        if arrObjectAndListObject.count == 2 {
//            if let listObject = arrObjectAndListObject.first {
//                // Key contain object
//                var list = [String: List<Object>]()
//                for objectTemp in self {
//                    guard let object = objectTemp as? Object else { return }
//                    for key in listObject {
//                        if let object = object[key] as? Object {
//                            if list[key] != nil {
//                                list[key]?.append(object)
//                            } else {
//                                let listTemp = List<Object>()
//                                listTemp.append(object)
//                                list[key] = listTemp
//                            }
//                        }
//                    }
//                }
//                for param in list {
//                    param.value.showData()
//                }
//            }
//            if let listObject = arrObjectAndListObject.last {
//                // Key contain list object
//                var list = [String: List<Object>]()
//                for objectTemp in self {
//                    guard let object = objectTemp as? Object else { return }
//                    for key in listObject {
//                        if let object = object[key] as? List<Object> {
//                            if list[key] != nil {
//                                list[key]?.append(objectsIn: object)
//                            } else {
//                                list[key] = object
//                            }
//                        }
//                    }
//                }
//                for param in list {
//                    param.value.showData()
//                }
//            }
//        }
//    }
}

extension List where Iterator.Element: Object {
    
    /** Retrieves the list of a given object which does not contain any instance in the Realm database.
     
        - returns: A list of object that has no instance of the given primary key.
    */
    
    func excludedObjects() -> LazyFilterCollection<List> {
        let realm = try! Realm()
        let filteredList = filter { object in
            let objectType = type(of: object)
            let primaryKey = object.value(forKey: objectType.primaryKey() ?? String())
            return realm.object(ofType: objectType, forPrimaryKey: primaryKey) == nil
        }
        return filteredList
    }
    
//    func showData() {
//        if self.isEmpty == true {
//            let type = type(of: self)
//            print("List_" + "\(String(describing: type))" + " empty")
//        } else {
//            let type = type(of: self)
//            print("List_" + "\(String(describing: type))" + " \(self.count)")
//        }
//        var arrObjectAndListObject: [[String]] = []
//        for (indObject, object) in self.enumerated() {
//            if indObject == 0 {
//                // Print properties
//                var line: String = ""
//                let properties = object.objectSchema.properties.map { $0.name }
//                for prop in properties {
//                    line += "\(prop)\t"
//                }
//                print(line)
//            }
//            arrObjectAndListObject = object.showValue(atIndex: indObject)
//        }
//        if arrObjectAndListObject.count == 2 {
//            if let listObject = arrObjectAndListObject.first {
//                // Key contain object
//                var list = [String: List<Object>]()
//                for object in self {
//                    for key in listObject {
//                        if let object = object[key] as? Object {
//                            if list[key] != nil {
//                                list[key]?.append(object)
//                            } else {
//                                let listTemp = List<Object>()
//                                listTemp.append(object)
//                                list[key] = listTemp
//                            }
//                        }
//                    }
//                }
//                for param in list {
//                    param.value.showData()
//                }
//            }
//            if let listObject = arrObjectAndListObject.last {
//                // Key contain list object
//                var list = [String: List<Object>]()
//                for object in self {
//                    for key in listObject {
//                        if let object = object[key] as? List<Object> {
//                            if list[key] != nil {
//                                list[key]?.append(objectsIn: object)
//                            } else {
//                                list[key] = object
//                            }
//                        }
//                    }
//                }
//                for param in list {
//                    param.value.showData()
//                }
//            }
//        }
//    }
}
