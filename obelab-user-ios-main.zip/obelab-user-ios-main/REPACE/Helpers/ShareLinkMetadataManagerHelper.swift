//
//  ShareLinkMetadataManagerHelper.swift
//  REPACE
//
//  Created by BM Johnny on 21/03/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import LinkPresentation

/// Transform url to metadata to populate to user.
@available(iOS 13.0, *)
final class ShareLinkMetadataManagerHelper: NSObject {
    
    var linkMetadata: LPLinkMetadata
    
    let appTitle = Bundle.main.infoDictionary?["CFBundleName"] as? String ?? "Repace"
    let appleStoreProductURL = "https://apps.apple.com/us/app/repace/id1585726892" // The url of your app in Apple Store
    let iconImage = "appIcon" // The name of the image file in your directory
    let png = "png" // The extension of the image
    
    init(linkMetadata: LPLinkMetadata = LPLinkMetadata()) {
        self.linkMetadata = linkMetadata
    }
}

// MARK: - LinkMetadataManager Setup
@available(iOS 13.0, *)
extension ShareLinkMetadataManagerHelper: UIActivityItemSource {
    /// Creating metadata to be populated in the share sheet.
    func activityViewControllerLinkMetadata(_ activityViewController: UIActivityViewController) -> LPLinkMetadata? {
        
        guard let url = URL(string: appleStoreProductURL) else { return linkMetadata }
        
        linkMetadata.originalURL = url
        linkMetadata.url = linkMetadata.originalURL
        linkMetadata.title = appTitle
        linkMetadata.iconProvider = NSItemProvider(
            contentsOf: Bundle.main.url(forResource: iconImage, withExtension: png))
        
        return linkMetadata
    }
    
    /// Showing an empty string returns a share sheet with the minimum requirement.
    func activityViewControllerPlaceholderItem(_ activityViewController: UIActivityViewController) -> Any {
        String()
    }
    
    /// Sharing the application url.
    func activityViewController(_ activityViewController: UIActivityViewController,
                                itemForActivityType activityType: UIActivity.ActivityType?) -> Any? {
        linkMetadata.url
    }
}
