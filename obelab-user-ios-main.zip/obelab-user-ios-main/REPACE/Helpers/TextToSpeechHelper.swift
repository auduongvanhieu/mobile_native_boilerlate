import Foundation
import AVFoundation

class TextToSpeechHelper {
    static let synthesizer = AVSpeechSynthesizer()
    static func speak(text: String, countDown: Int?, timeUp: Int, page: String) {
        let down = countDown == nil ? "" : " countDown = \(countDown ?? 0) seconds"
        Functions.showLog(title: "TextToSpeechHelper \(page): countUp = \(timeUp) seconds \(down)\nTextToSpeechHelper speak: \(text)", message: "")
        if LocalDataManager.volumeTurnOn && synthesizer.isSpeaking == false {
            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
            utterance.rate = 0.5
            synthesizer.speak(utterance)
        }
    }
}
