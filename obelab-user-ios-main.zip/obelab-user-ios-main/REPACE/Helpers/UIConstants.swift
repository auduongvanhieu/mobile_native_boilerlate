import Foundation
import UIKit

struct UI {
    enum Defaults {
        static let margin: CGFloat = 32
    }
    
    enum ViewController {
        static let topMargin: CGFloat = 72
    }
    
    enum Button {
        static let cornerRadius: CGFloat = 12.0
        static let height: CGFloat = 48.0
        static let width: CGFloat = 200.0
        static let spacing: CGFloat = 10.0
    }
    
    enum Color {
        static let transparentColor = UIColor(white: 0, alpha: 0)
        static let btnBgColor = #colorLiteral(red: 0.2230088115, green: 0.363083899, blue: 1, alpha: 1)
        static let btnBgDisableColor = #colorLiteral(red: 0.37782377, green: 0.390155077, blue: 0.5477172136, alpha: 1)
        static let btnTitleDisableColor = #colorLiteral(red: 0.5490196078, green: 0.5725490196, blue: 0.6745098039, alpha: 1)
        static let txtFloatTitleColor = #colorLiteral(red: 0.7685534358, green: 0.7686808705, blue: 0.7685263157, alpha: 1)
        static let txtPlaceholderColor = #colorLiteral(red: 0.5483424664, green: 0.5728343129, blue: 0.6752532125, alpha: 1)
        static let txtErrorColor = #colorLiteral(red: 1, green: 0.3222170472, blue: 0.6638055444, alpha: 1)
        static let inputBgColor = #colorLiteral(red: 0.1573603749, green: 0.1673573852, blue: 0.2910459936, alpha: 1)
        static let dropdownSelectedBgColor = UIColor(red: 58 / 255, green: 91 / 255, blue: 246 / 255, alpha: 1.00)
        static let screenBackgroundColor = #colorLiteral(red: 0.1152264401, green: 0.1283853352, blue: 0.2120530903, alpha: 1)
        static let orangeColor  = #colorLiteral(red: 0.9830996394, green: 0.411678344, blue: 0.4789012671, alpha: 1)
        static let cyanColor = #colorLiteral(red: 0.1827787459, green: 0.7981325984, blue: 0.801317513, alpha: 1)
        static let pinkColor = #colorLiteral(red: 0.9845753312, green: 0.1979151666, blue: 0.6009585261, alpha: 1)
        static let lightPinkColor = #colorLiteral(red: 0.9886305928, green: 0.5020442605, blue: 0.7478299141, alpha: 1)
        static let violetColor = #colorLiteral(red: 0.6843592525, green: 0.1331642866, blue: 0.8905373216, alpha: 1)
        static let blueColor = #colorLiteral(red: 0.2109684646, green: 0.3683449626, blue: 0.9974866509, alpha: 1)
        static let lightBlueColor = #colorLiteral(red: 0.3010914326, green: 0.5565325022, blue: 1, alpha: 1)
        static let highBlueColor = #colorLiteral(red: 0.2082209885, green: 0.05240706354, blue: 1, alpha: 1)
        static let exercisePurposeGeneralBg = #colorLiteral(red: 0, green: 0.8, blue: 0.8, alpha: 1)
        static let exercisePurposeWeightLossBg = #colorLiteral(red: 1, green: 0.7882352941, blue: 0.2509803922, alpha: 1)
        static let exercisePurposeMaximalBg = #colorLiteral(red: 0.1803921569, green: 0.3607843137, blue: 1, alpha: 1)
        static let exercisePurposeDisableBg = #colorLiteral(red: 0.3764705882, green: 0.3882352941, blue: 0.5490196078, alpha: 1)
        static let exerciseLowIntensityBg = #colorLiteral(red: 0.007843137255, green: 0.1882352941, blue: 0.8156862745, alpha: 1)
        static let exerciseHighIntensityBg = #colorLiteral(red: 0.937254902, green: 0.2823529412, blue: 0.5215686275, alpha: 1)
    }
    
    enum Text {
        static let title: CGFloat = 28.0
    }
    
    enum Dialog {
        static let radius: CGFloat = 14.0
    }
    
    enum Header {
        static let yPositionInScroll: Double = 10.0
    }
    
    enum View {
        static let radius: CGFloat = 8.0
        static let padding: CGFloat = 16.0
        static let paddingText: CGFloat = 11.0
        static let topInfoHeight: CGFloat = 90
    }
    
    enum Image {
        static let img_general_performance = #imageLiteral(resourceName: "img_general_performance")
        static let img_general_performance_disable = #imageLiteral(resourceName: "img_general_performance_disable")
        static let img_weight_loss = #imageLiteral(resourceName: "img_weight_loss")
        static let img_weight_loss_disable = #imageLiteral(resourceName: "img_weight_loss_disable")
        static let img_max_earobic_performance = #imageLiteral(resourceName: "img_max_earobic_performance")
        static let img_max_earobic_performance_disable = #imageLiteral(resourceName: "img_max_earobic_performance_disable")
        static let img_high_intensity = UIImage(named: "img_high_intensity")
        static let img_high_intensity_disable = UIImage(named: "img_high_intensity_disable")
        static let img_low_insensity = UIImage(named: "img_low_insensity")
        static let img_low_insensity_disable = UIImage(named: "img_low_insensity_disable")
    }
    
    enum Icon {
        static let ic_history = UIImage(named: "ic_history")
        static let ic_history_disable = UIImage(named: "ic_history_disable")
        static let ic_bluetooth_on = UIImage(named: "ic_bluetooth_on")
        static let ic_bluetooth_off = UIImage(named: "ic_bluetooth_off")
        static let ic_play = UIImage(named: "ic_play")
        static let ic_pause = UIImage(named: "ic_pause")
        static let ic_check_empty_dark = UIImage(named: "ic_check_empty_dark")
        static let ic_check_checked_dark = UIImage(named: "ic_check_checked_dark")
        static let ic_map_start = UIImage(named: "ic_map_start")
        static let ic_map_stop = UIImage(named: "ic_map_stop")
    }
}
