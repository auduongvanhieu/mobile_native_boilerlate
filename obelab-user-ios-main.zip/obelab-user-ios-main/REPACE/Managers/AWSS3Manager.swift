import Foundation
import UIKit
import AWSS3 // 1

typealias progressBlock = (_ progress: Double) -> Void // 2
typealias completionBlock = (_ response: Any?, _ error: Error?) -> Void // 3

class AWSS3Manager {
    static let shared = AWSS3Manager() // 4
    private init () { }
    let bucketName = "ol-repace" //5
    
    static func initializeS3() {
        let poolId = "ap-northeast-2:0c479b9e-21c0-43fa-8fbd-b97f34b98447"
        let credentialsProvider = AWSCognitoCredentialsProvider(regionType: .APNortheast2, identityPoolId: poolId)
        let configuration = AWSServiceConfiguration(region: .APNortheast2, credentialsProvider: credentialsProvider)
        configuration?.timeoutIntervalForRequest = 120
        AWSServiceManager.default().defaultServiceConfiguration = configuration
    }
    
    // Upload image using UIImage object
    func uploadImage(image: UIImage, progress: progressBlock?, completion: completionBlock?) {
        
        guard let imageData = image.jpegData(compressionQuality: 1.0) else {
            let error = NSError(domain: "", code: 402, userInfo: [NSLocalizedDescriptionKey: "invalid image"])
            completion?(nil, error)
            return
        }
        
        let tmpPath = NSTemporaryDirectory() as String
        let fileName: String = FileHelper.getImageFileName()
        let filePath = tmpPath + "/" + fileName
        let fileUrl = URL(fileURLWithPath: filePath)
        let fileNameS3 = FileHelper.getS3ImageFileName(imageFileName: fileName)
        
        Functions.showLog(title: "fileNameS3", message: fileNameS3)
        do {
            try imageData.write(to: fileUrl)
            self.uploadfile(fileUrl: fileUrl, fileName: fileNameS3, contenType: "image", progress: progress, completion: completion)
        } catch {
            let error = NSError(domain: "", code: 402, userInfo: [NSLocalizedDescriptionKey: "invalid image"])
            completion?(nil, error)
        }
    }
    
    // Upload video from local path url
    func uploadVideo(videoUrl: URL, progress: progressBlock?, completion: completionBlock?) {
        let fileName = self.getUniqueFileName(fileUrl: videoUrl)
        self.uploadfile(fileUrl: videoUrl, fileName: fileName, contenType: "video", progress: progress, completion: completion)
    }
    
    // Upload auido from local path url
    func uploadAudio(audioUrl: URL, progress: progressBlock?, completion: completionBlock?) {
        let fileName = self.getUniqueFileName(fileUrl: audioUrl)
        self.uploadfile(fileUrl: audioUrl, fileName: fileName, contenType: "audio", progress: progress, completion: completion)
    }
    
    // Upload files like Text, Zip, etc from local path url
    func uploadOtherFile(fileUrl: URL, conentType: String, progress: progressBlock?, completion: completionBlock?) {
        let fileName = self.getUniqueFileName(fileUrl: fileUrl)
        self.uploadfile(fileUrl: fileUrl, fileName: fileName, contenType: conentType, progress: progress, completion: completion)
    }
    
    // Get unique file name
    func getUniqueFileName(fileUrl: URL) -> String {
        let strExt: String = "." + (URL(fileURLWithPath: fileUrl.absoluteString).pathExtension)
        return (ProcessInfo.processInfo.globallyUniqueString + (strExt))
    }
    
    // MARK: - AWS file upload
    // fileUrl :  file local path url
    // fileName : name of file, like "myimage.jpeg" "video.mov"
    // contenType: file MIME type
    // progress: file upload progress, value from 0 to 1, 1 for 100% complete
    // completion: completion block when uplaoding is finish, you will get S3 url of upload file here
    func uploadfile(fileUrl: URL, fileName: String, contenType: String, progress: progressBlock?, completion: completionBlock?, timeoutInSeconds: TimeInterval = 120) {
        Functions.showLog(title: "Begin upload s3 at \(Functions.getExerciseTimeNow())", message: "")
        FileHelper.writeStringToLogFile(title: "Begin upload s3 file", content: "")
        var isFinished = false
        var isTimeOut = false
        var originalTask: AWSS3TransferUtilityTask?
        // Upload progress block
        let expression = AWSS3TransferUtilityUploadExpression()
        expression.progressBlock = {(task, awsProgress) in
            if isTimeOut == true {
                task.cancel()
                Functions.showLog(title: "Cancel upload s3 with task \(task.transferID) at \(Functions.getExerciseTimeNow())", message: "")
                return
            }
            if originalTask != task {
                originalTask?.cancel()
                originalTask = task
            }
            guard let uploadProgress = progress else { return }
            DispatchQueue.main.async {
                uploadProgress(awsProgress.fractionCompleted)
                FileHelper.writeStringToLogFile(title: "Upload s3 file progress \(awsProgress.fractionCompleted * 100.to1Decimal) %", content: "")
            }
        }
        // Completion block
        var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
        completionHandler = { (_, error) -> Void in
            DispatchQueue.main.async(execute: {
                if isFinished == false && isTimeOut == false {
                    isFinished = true
                    if error == nil {
                        let url = AWSS3.default().configuration.endpoint.url
                        let publicURL = url?.appendingPathComponent(self.bucketName).appendingPathComponent(fileName)
                        Functions.showLog(title: "Mytv Upload s3 file success Uploaded to:\(String(describing: publicURL)) at \(Functions.getExerciseTimeNow())", message: "")
                        FileHelper.writeStringToLogFile(title: "Upload s3 file success", content: "")
                        if let completionBlock = completion {
                            completionBlock(publicURL?.absoluteString, nil)
                        }
                    } else {
                        Functions.showLog(title: "Mytv Upload s3 file fail at \(Functions.getExerciseTimeNow())", message: "")
                        FileHelper.writeStringToLogFile(title: "Upload s3 file fail", content: "")
                        if let completionBlock = completion {
                            completionBlock(nil, error)
                        }
                    }
                }
            })
        }
        // Start uploading using AWSS3TransferUtility
        let awsTransferUtility = AWSS3TransferUtility.default()
        awsTransferUtility.uploadFile(fileUrl, bucket: bucketName, key: fileName, contentType: contenType, expression: expression, completionHandler: completionHandler)
            .continueWith { (task) -> Any? in
                DispatchQueue.main.async {
                    if let error = task.error {
                        completion?(nil, error)
                    }
//                    if let _ = task.result {
//                         your uploadTask
//                    }
                }
                return nil
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + timeoutInSeconds, execute: {
            if isFinished == false {
                Functions.showLog(title: "Mytv Fail upload s3 Timeout at \(Functions.getExerciseTimeNow())", message: "")
                FileHelper.writeStringToLogFile(title: "Fail upload s3 file because of Timeout", content: "")
                isTimeOut = true
                // Time out
                if let originalTask = originalTask {
                    originalTask.cancel()
                }
                let disconnectError = App.error(
                  domain: .generic,
                  localizedDescription: "disconnect_network".localized
                )
                completion?(nil, disconnectError)
            }
        })
    }
}
