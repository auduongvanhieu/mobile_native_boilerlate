import UIKit

class LocalDataManager: NSObject {
    
    static func resetData() {
        ltTestSetting = LTTestSettingModel()
        lastLTTestResult = LTTestResultModel()
        ltTestPrescription = ExercisePresciptionModel()
        todayHistoryExercise = DayExerciseModel()
    }
    
    static var token: String? {
        get { return UserDefaults.standard.string(forKey: "TOKEN") }
        set { UserDefaults.standard.set(newValue, forKey: "TOKEN") }
    }
    
    static var profile: UserInfo? {
        get {
            if let data = UserDefaults.standard.data(forKey: "PROFILE"), let session = try? JSONDecoder().decode(UserInfo.self, from: data) {
                return session
            }
            return nil
        }
        
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "PROFILE")
        }
    }
    
    static var unit: String? {
        get {
            var value = UserDefaults.standard.string(forKey: "UNIT")
            if value == nil || value?.isEmpty == true {
                value = Constants.UNIT_METRIC
            }
            return value
        }
        
        set { UserDefaults.standard.set(newValue, forKey: "UNIT") }
    }
    
    static var intensityId: Int? {
        get { return UserDefaults.standard.integer(forKey: "intensityId") }
        set { UserDefaults.standard.set(newValue, forKey: "intensityId") }
    }
    static var batteryLevel: Int? {
        get { return UserDefaults.standard.integer(forKey: "batteryLevel") }
        set { UserDefaults.standard.set(newValue, forKey: "batteryLevel") }
    }
    static var language: String? {
        get {
            var value = UserDefaults.standard.string(forKey: "LANGUAGE")
            if value == nil || value?.isEmpty == true {
                value = Constants.LANGUAGE_EN
            }
            return value
        }
        
        set {
            UserDefaults.standard.set(newValue, forKey: "LANGUAGE")
            if let newLanguage = newValue {
                RKLocalization.sharedInstance.setLanguage(language: newLanguage)
            }
        }
    }
    
    static var ltTestSetting: LTTestSettingModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_SETTING"), let session = try? JSONDecoder().decode(LTTestSettingModel.self, from: data) {
                return session
            }
            return LTTestSettingModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_SETTING")
        }
    }
    
    static var isShowLTTestGuide: Bool {
        get { return UserDefaults.standard.bool(forKey: "IS_SHOW_LT_TEST_GUIDE") }
        set { UserDefaults.standard.set(newValue, forKey: "IS_SHOW_LT_TEST_GUIDE") }
    }
    
    static var ltTestType: String {
        get {
            let value = UserDefaults.standard.string(forKey: "LT_TEST_TYPE")
            return value ?? LTTestConstants.TREADMILL_TEST
        }
        set { UserDefaults.standard.set(newValue, forKey: "LT_TEST_TYPE") }
    }
    
    static var isNotFirstOpenApp: Bool {
        get { return UserDefaults.standard.bool(forKey: "IS_NOT_FIRST_OPEN_APP") }
        set { UserDefaults.standard.set(newValue, forKey: "IS_NOT_FIRST_OPEN_APP") }
    }
    
    static var volumeTurnOn: Bool {
        get { return UserDefaults.standard.bool(forKey: "VOLUME_TURN_ON") }
        set { UserDefaults.standard.set(newValue, forKey: "VOLUME_TURN_ON") }
    }
    
    static var ltTestProtocol: RepaceProtocolModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_PROTOCOL"), let session = try? JSONDecoder().decode(RepaceProtocolModel.self, from: data) {
                return session
            }
            return RepaceProtocolModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_PROTOCOL")
        }
    }
    
    static var ltTestStage: Int {
        get { return UserDefaults.standard.integer(forKey: "LT_TEST_STAGE") }
        set { UserDefaults.standard.set(newValue, forKey: "LT_TEST_STAGE") }
    }
    
    static var isSaveSmo2List: Bool {
        get { return UserDefaults.standard.bool(forKey: "IS_SAVE_SMO2_LIST") }
        set { UserDefaults.standard.set(newValue, forKey: "IS_SAVE_SMO2_LIST") }
    }
    
    static var ltTestSmo2List: [Double] = []
    
    static var ltTestHRList: [Double] {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_HR_LIST"), let result = try? JSONDecoder().decode([Double].self, from: data) {
                return result
            }
            return []
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_HR_LIST")
        }
    }
    static var rowData: [UInt8] = []
    
    static var ltTestSmo2BaseLineList: [Double] {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_SMO2_BASE_LINE_LIST"), let session = try? JSONDecoder().decode([Double].self, from: data) {
                return session
            }
            return []
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_SMO2_BASE_LINE_LIST")
        }
    }
    
    static var ltTestSmo2CurrentList: [Double] {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_SMO2_CURRENT_LIST"), let session = try? JSONDecoder().decode([Double].self, from: data) {
                return session
            }
            return []
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_SMO2_CURRENT_LIST")
        }
    }
    
//    static var ltTestOnsetCurrentList: [Double] {
//        get {
//            if let data = UserDefaults.standard.data(forKey: "LT_TEST_Onset_CURRENT_LIST"), let session = try? JSONDecoder().decode([Double].self, from: data) {
//                return session
//            }
//            return []
//        }
//        set {
//            let data = try? JSONEncoder().encode(newValue)
//            UserDefaults.standard.set(data, forKey: "LT_TEST_Onset_CURRENT_LIST")
//        }
//    }
    
//    static var ltTestThresholdCurrentList: [Double] {
//        get {
//            if let data = UserDefaults.standard.data(forKey: "LT_TEST_Threshold_CURRENT_LIST"), let session = try? JSONDecoder().decode([Double].self, from: data) {
//                return session
//            }
//            return []
//        }
//        set {
//            let data = try? JSONEncoder().encode(newValue)
//            UserDefaults.standard.set(data, forKey: "LT_TEST_Threshold_CURRENT_LIST")
//        }
//    }
    
    static var listTestAnalysis: [RepaceAnalysisModel] = []
    
    static var ltTestAnalysis: RepaceAnalysisModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_ANALYSIS"), let session = try? JSONDecoder().decode(RepaceAnalysisModel.self, from: data) {
                return session
            }
            return RepaceAnalysisModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_ANALYSIS")
        }
    }
    
    static var ltTestStageModelList: [RepaceStageModel] {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_STAGE_MODEL_LIST"), let session = try? JSONDecoder().decode([RepaceStageModel].self, from: data) {
                return session
            }
            return []
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_STAGE_MODEL_LIST")
        }
    }
    
    static var ltTestResult: LTTestResultModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_RESULT"), let result = try? JSONDecoder().decode(LTTestResultModel.self, from: data) {
                return result
            }
            return LTTestResultModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_RESULT")
        }
    }
    
    static var ltTestPrescription: ExercisePresciptionModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_PRESCRIPTION"), let session = try? JSONDecoder().decode(ExercisePresciptionModel.self, from: data) {
                return session
            }
            return ExercisePresciptionModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_PRESCRIPTION")
        }
    }

    static var ltTestPurpose: Int32 {
        get { return Int32(UserDefaults.standard.integer(forKey: "LT_TEST_PURPOSE")) }
        set { UserDefaults.standard.set(newValue, forKey: "LT_TEST_PURPOSE") }
    }
    
    static var ltTestLocationList: [LocationModel] {
        get {
            if let data = UserDefaults.standard.data(forKey: "LT_TEST_LOCATION_LIST"), let session = try? JSONDecoder().decode([LocationModel].self, from: data) {
                return session
            }
            return []
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LT_TEST_LOCATION_LIST")
        }
    }
    
    static var lastLTTestResult: LTTestResultModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "LAST_LT_TEST_RESULT"), let session = try? JSONDecoder().decode(LTTestResultModel.self, from: data) {
                return session
            }
            return LTTestResultModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "LAST_LT_TEST_RESULT")
        }
    }
    
    static var lastConnectedBleDeviceId: String {
        get { return UserDefaults.standard.string(forKey: "LAST_CONNECTED_BLE_DEVICE_ID") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "LAST_CONNECTED_BLE_DEVICE_ID") }
    }
    
    static var todayHistoryExercise: DayExerciseModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "TODAY_HISTORY_EXERCISE"), let exercise = try? JSONDecoder().decode(DayExerciseModel.self, from: data) {
                return exercise
            }
            return DayExerciseModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "TODAY_HISTORY_EXERCISE")
        }
    }
    
    static var exerciseType: String {
        get { return UserDefaults.standard.string(forKey: "EXERCISE_TYPE") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "EXERCISE_TYPE") }
    }
    
    static var exerciseResult: ExerciseResultModel {
        get {
            if let data = UserDefaults.standard.data(forKey: "EXERCISE_RESULT"), let exercise = try? JSONDecoder().decode(ExerciseResultModel.self, from: data) {
                return exercise
            }
            return ExerciseResultModel()
        }
        set {
            let data = try? JSONEncoder().encode(newValue)
            UserDefaults.standard.set(data, forKey: "EXERCISE_RESULT")
        }
    }
    
    static var freeExercisTotalDistanceInput: Double {
        get { return UserDefaults.standard.double(forKey: "FREE_EXERCISE_TOTAL_DISTANCE_INPUT") }
        set { UserDefaults.standard.set(newValue, forKey: "FREE_EXERCISE_TOTAL_DISTANCE_INPUT") }
    }
    
    static var actionType: String {
        get { return UserDefaults.standard.string(forKey: "ACTION_TYPE") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "ACTION_TYPE") }
    }
}
