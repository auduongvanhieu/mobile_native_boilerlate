//
//  AnnouncementModel.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/2/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

struct AnnouncementModel: Codable {
    
    var id: Int?
    var parentId: Int?
    
    var code: String?
    var name: String?
    var value: String?
    var creator: String?
    var isActive: String?
    var order: Int?
    var ext1, ext2: String?
    var deleteAt, updatedAt: String?
    
    init (){
        
    }
    
}
