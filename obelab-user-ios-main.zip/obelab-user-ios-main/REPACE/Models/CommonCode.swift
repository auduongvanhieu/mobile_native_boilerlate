import Foundation

struct CommonCode: Codable {
    let id, parentID: Int?
    let code, name, value: String?
    let ext1, ext2: JSONAny?

    enum CodingKeys: String, CodingKey {
        case id
        case parentID = "parentId"
        case code, name, value, ext1, ext2
    }
    
    init(id: Int = 0) {
        self.id = 0
        self.parentID = 0
        self.code = ""
        self.name = ""
        self.value = ""
        self.ext1 = JSONAny()
        self.ext2 = JSONAny()
    }
}
