import Foundation

struct DayExerciseModel: Codable {
    var id: String?
    var date: Date?
    var exercise: [ExerciseResultModel]?
    
    init(id: String? = "", date: Date? = Date(), exercise: [ExerciseResultModel]? = []) {
        self.id = id
        self.date = date
        self.exercise = exercise
    }
}

struct DayExerciseHistoryModel: Codable {
    var id: String?
    var date: Int?
    var month: Int?
    var year: Int?
    var exercise: [ExerciseResultModel]?
    
    func convertToDayExerciseModel() -> DayExerciseModel? {
        guard let day = date, let month = month, let year = year else {
            return nil
        }
        var dateComponents = DateComponents()
        dateComponents.day = day
        dateComponents.month = month
        dateComponents.year = year
        let date = Calendar.current.date(from: dateComponents)
        return DayExerciseModel(id: id, date: date, exercise: exercise)
    }
}
