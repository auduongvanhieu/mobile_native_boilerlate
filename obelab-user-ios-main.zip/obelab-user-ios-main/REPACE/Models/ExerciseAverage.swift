import Foundation

// MARK: - ExerciseAverage
struct ExerciseAverage: Codable {
    let heartRateAvg: Double?
    let smo2Avg: Double?
    let rxExercise: Int?
    
    init(heartRateAvg: Double? = 0, smo2Avg: Double? = 0, rxExercise: Int? = 0) {
        self.heartRateAvg = heartRateAvg
        self.smo2Avg = smo2Avg
        self.rxExercise = rxExercise
    }
    
}
