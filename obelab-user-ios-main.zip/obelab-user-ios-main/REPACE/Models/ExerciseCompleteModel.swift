import Foundation

// MARK: - ExerciseCompleteModel
struct ExerciseCompleteModel: Codable {
    var medal, badge: Bool?
}
