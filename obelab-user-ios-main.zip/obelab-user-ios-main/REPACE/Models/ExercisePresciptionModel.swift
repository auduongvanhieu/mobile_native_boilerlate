import Foundation

struct ExercisePresciptionModel: Codable {
    var id, memberID, type: Int?
    var leSpeed: Double?
    var leWeek, leTime, leMin: Int?
    var ptSpeed: Double?
    var ptWeek, ptTime, ptMin: Int?
    var ptIndex: Double?
    var createdAt: String?
    var session: [ExerciseSessionModel]?
    var todaySession: ExerciseSessionModel?
    var isPracticedToday: Bool? = false
    var sessionCnt: Int?
    
    enum CodingKeys: String, CodingKey {
        case id
        case memberID = "memberId"
        case type, leSpeed, leWeek, leTime, leMin, ptSpeed, ptWeek, ptTime, ptMin, ptIndex, createdAt, session, todaySession, isPracticedToday, sessionCnt
    }
    
    init (type: Int = 0, leSpeed: Double = 0, leWeek: Int = 0, leTime: Int = 0, leMin: Int = 0, ptSpeed: Double = 0, ptWeek: Int = 0, ptTime: Int = 0, ptMin: Int = 0, ptIndex: Double = 0, sessionCnt: Int = 1){
        self.id = 0
        self.memberID = 0
        self.type = type
        self.leSpeed = leSpeed
        self.leWeek = leWeek
        self.leTime = leTime
        self.leMin = leMin
        self.ptSpeed = ptSpeed
        self.ptWeek = ptWeek
        self.ptTime = ptTime
        self.ptMin = ptMin
        self.ptIndex = ptIndex
        self.createdAt = Functions.getNowSQLDateTime()
        self.session = []
        self.todaySession = ExerciseSessionModel()
        self.isPracticedToday = false
        self.sessionCnt = sessionCnt
    }
    
    func sessionToParameters() -> [[String: Any]] {
        var sessionParams: [[String: Any]] = []
        if let session = session {
            for item in session {
                sessionParams.append(item.toParameters())
            }
        }
        return sessionParams
    }
    
    func toParameters() -> [String: Any] {
        return [
            "type": self.type ?? 0,
            "leSpeed": self.leSpeed ?? 0,
            "leWeek": self.leWeek ?? 0,
            "leTime": self.leTime ?? 0,
            "leMin": self.leMin ?? 0,
            "ptSpeed": self.ptSpeed ?? 0,
            "ptWeek": self.ptWeek ?? 0,
            "ptTime": self.ptTime ?? 0,
            "ptMin": self.ptMin ?? 0,
            "ptIndex": self.ptIndex ?? 0,
            "session": self.sessionToParameters(),
        ]
    }
}
