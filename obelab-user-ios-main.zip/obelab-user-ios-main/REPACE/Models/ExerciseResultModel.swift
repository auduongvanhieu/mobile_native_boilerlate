import Foundation
import RealmSwift
import Realm

struct ExerciseResultModel: Codable {
    var id, memberID, exerciseID: Int?
    var typeID, intensityID, activityID: String?
    var totalDuration: Int?
    var totalDistance: Double?
    var onset, mol: Int?
    var smo2Min, smo2Max: Double?
    var heartRateMin, heartRateMax: Int?
    var smo2Avg, heartRateAvg, speedMin, speedMax, speedAvg: Double?
    var status, sessionCnt, time: Int?
    var speed: Double?
    var heartRate: Int?
    var startTime, endTime, createdAt, updatedAt: String?
    var listSmo2: [SmO2ChartModel]?
    var listHeartRate: [SmO2ChartModel]?
    var listLocation: [LocationModel]?
    var bleData: String?
    var isFromLocal = false
    
    enum CodingKeys: String, CodingKey {
        case id
        case memberID = "memberId"
        case exerciseID = "exerciseId"
        case typeID = "typeId"
        case intensityID = "intensityId"
        case activityID = "activityId"
        case totalDuration, totalDistance, onset, mol, smo2Min, smo2Max, smo2Avg, heartRateMin, heartRateMax, heartRateAvg, speedMin, speedMax, speedAvg, status, sessionCnt, time, speed, heartRate, startTime, endTime, createdAt, updatedAt, listSmo2, listHeartRate, listLocation, bleData
    }
    
    func listSmo2ToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listSmo2 ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func listHeartRateToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listHeartRate ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func listLocationToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listLocation ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func toParameters() -> [String: Any] {
        var result: [String: Any] = [
            "typeId": self.typeID ?? "",
            "intensityId": self.intensityID ?? "",
            "activityId": self.activityID ?? "",
            "totalDuration": self.totalDuration ?? 0,
            "totalDistance": self.totalDistance ?? 0,
            "smo2Min": self.smo2Min ?? 0,
            "smo2Max": self.smo2Max ?? 0,
            "smo2Avg": self.smo2Avg ?? 0,
            "heartRateMin": self.heartRateMin ?? 0,
            "heartRateMax": self.heartRateMax ?? 0,
            "heartRateAvg": self.heartRateAvg ?? 0,
            "speedMin": self.speedMin ?? 0,
            "speedMax": self.speedMax ?? 0,
            "speedAvg": self.speedAvg ?? 0,
            "sessionCnt": self.sessionCnt ?? 0,
            "time": self.time ?? 0,
            "speed": self.speed ?? 0,
            "heartRate": self.heartRate ?? 0,
            "startTime": self.startTime ?? 0,
            "endTime": self.endTime ?? 0,
            "listSmo2": self.listSmo2ToParameters(),
            "listHeartRate": self.listHeartRateToParameters(),
            "listLocation": self.listLocationToParameters(),
            "bleData": self.bleData ?? ""
        ]
        if let createdAt = self.createdAt,
           createdAt.isEmpty == false {
            result["createdAt"] = createdAt
        }
        return result
    }
    
    init() {
        typeID = ""
        intensityID = ""
        activityID = ""
        totalDuration = 0
        totalDistance = 0
        smo2Min = 0
        smo2Max = 0
        smo2Avg = 0
        heartRateMin = 0
        heartRateMax = 0
        heartRateAvg = 0
        speedMin = 0
        speedMax = 0
        speedAvg = 0
        sessionCnt = 0
        time = 0
        speed = 0
        heartRate = 0
        startTime = ""
        endTime = ""
        listSmo2 = []
        listHeartRate = []
        listLocation = []
        bleData = ""
    }
    
    func convertToSaveObject() -> RxExerciseResultObject {
        let result = RxExerciseResultObject()
        result.getFromModel(model: self)
        result.memberID = LocalDataManager.profile?.id ?? 0
        result.exerciseID = self.exerciseID ?? 0
        result.typeID = self.typeID
        result.intensityID = self.intensityID
        result.activityID = self.activityID
        result.totalDuration = self.totalDuration ?? 0
        result.totalDistance = self.totalDistance ?? 0
        result.status = self.status ?? 0
        result.sessionCnt = self.sessionCnt ?? 0
        result.time = self.time ?? 0
        result.startTime = self.startTime ?? ""
        result.endTime = self.endTime ?? ""
        result.createdAt = self.createdAt
        result.updatedAt = self.updatedAt ?? ""
        result.heartRate = self.heartRate ?? 0
        result.speed = self.speed ?? 0
        result.isUploadedS3File = false
        result.isUploadedExercise = false
        result.isAttachCreatedAt = false
        result.listHeartRate = Functions.getListSmO2(list: self.listHeartRate)
        return result
    }
}

struct ExerciseResultListModel: Codable {
    var totalItems: Int?
    var data: [ExerciseResultModel]
    var totalPages: Int?
    var currentPage: Int?
    
    init() {
       totalItems = 0
        data = []
        totalPages = 0
        currentPage = 0
    }
}
