import Foundation

struct ExerciseSessionModel: Codable {
    var session, time, heartRate: Int?
    var speed: Double?
    
    init (session: Int? = 0, time: Int? = 0, speed: Double? = 0, heartRate: Int? = 0){
        self.session = session
        self.time = time
        self.speed = speed
        self.heartRate = heartRate
    }
    
    func toParameters() -> [String: Any] {
        return [
            "session": self.session ?? 0,
            "time": self.time ?? 0,
            "speed": self.speed ?? 0,
            "heartRate": self.heartRate ?? 0
        ]
    }
}
