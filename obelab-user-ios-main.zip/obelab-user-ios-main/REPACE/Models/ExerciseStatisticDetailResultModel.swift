//
//  ExerciseStatisticDetailResultModel.swift
//  REPACE
//
//  Created by Pham Van Huy on 26/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

struct ExerciseStatisticDetailResultModel: Codable {
    let statistic: [ExerciseStatisticDetailModel]
    let average: ExerciseStatisticDetailModel
    let start: String
    let end: String
    
    init() {
        self.statistic = []
        self.average = ExerciseStatisticDetailModel()
        start = ""
        end = ""
    }
}

struct ExerciseStatisticDetailModel: Codable {
    let speedMin: Int?
    let speedMax: Int?
    let speedAvg: Double?
    let smO2Min: Double?
    let smO2Max: Double?
    let smO2Avg: Double?
    let heartRateMin: Int?
    let heartRateMax: Int?
    let heartRateAvg: Double?
    let duration: Double?
    let distance: Double?
    let date: String?
    let dateEnd: String?
    
    init() {
        speedMin = 0
        speedMax = 0
        speedAvg = 0
        smO2Avg = 0
        smO2Min = 0
        smO2Max = 0
        heartRateAvg = 0
        heartRateMin = 0
        heartRateMax = 0
        duration = 0
        distance = 0
        date = ""
        dateEnd = ""
    }
}
