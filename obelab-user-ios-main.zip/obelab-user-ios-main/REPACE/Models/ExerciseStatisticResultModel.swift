//
//  ExerciseStatisticResultModel.swift
//  REPACE
//
//  Created by Pham Van Huy on 22/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

struct ExerciseStatisticResultModel: Codable {
    let statistic: [ExerciseStatisticModel]
    let average: ExerciseStatisticModel
    
    init() {
        self.statistic = []
        self.average = ExerciseStatisticModel()
    }
}

struct ExerciseStatisticModel: Codable {
    let speed: Double?
    let time: Double?
    let distance: Double?
    let smO2: Double?
//    let distance: Float?
//    let smO2: Float?
    let date: String?
    
    init() {
        self.speed = 0
        self.time = 0
        self.distance = 0
        self.smO2 = 0
        self.date = ""
    }
    
    func isDataEmpty() -> Bool {
        return (self.speed ?? 0 == 0)
                && (self.time ?? 0 == 0)
                && self.smO2 ?? 0 == 0
                && self.distance ?? 0 == 0
    }
}
