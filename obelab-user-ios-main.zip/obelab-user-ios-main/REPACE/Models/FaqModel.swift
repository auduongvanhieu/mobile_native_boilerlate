import Foundation

struct FaqModel: Codable {
    var id: Int?
    var question, answer: String?
    var status: Int?
    var createdAt, updatedAt: String?
    
    init (id: Int? = 0, question: String = "", answer: String = "", status: Int = 0, createdAt: String = "", updatedAt: String = ""){
        self.id = id
        self.question = question
        self.answer = answer
        self.status = status
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}
