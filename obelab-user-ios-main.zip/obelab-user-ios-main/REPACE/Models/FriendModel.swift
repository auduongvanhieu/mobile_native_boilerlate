//
//  FriendModel.swift
//  REPACE
//
//  Created by ThienBanh on 20/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit

struct FriendModel: Codable {
    
    let data: [UserInfo]?
    init() {
        data = nil
    }
}
struct AllFriendModel: Codable {
    let totalItems, totalPages, currentPage: Int?
    let data: [UserInfo]?
    
    init(totalItems: Int = 0) {
        self.totalItems = 0
        self.totalPages = 0
        self.currentPage = 0
        self.data = []
    }
}
