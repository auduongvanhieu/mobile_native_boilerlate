//
//  GoalModel.swift
//  REPACE
//
//  Created by ThienBanh on 19/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit

struct GoalModel: Codable {
    var medal_cnt, trophy_cnt, badge_cnt: Int?
    enum CodingKeys: String, CodingKey {
        case medal_cnt, trophy_cnt, badge_cnt
    }
    init() {
        self.medal_cnt = 0
        self.trophy_cnt = 0
        self.badge_cnt = 0
    }
}
