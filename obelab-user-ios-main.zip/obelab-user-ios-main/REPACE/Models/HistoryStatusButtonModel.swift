//
//  HistoryStatusButtonModel.swift
//  REPACE
//
//  Created by BM Johnny on 05/04/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

struct HistoryStatusButtonModel: Codable {
    var rxEnable: Bool
    var freeEnable: Bool
    
    init(rxEnable: Bool = false, freeEnable: Bool = false) {
        self.rxEnable = rxEnable
        self.freeEnable = freeEnable
    }
}
