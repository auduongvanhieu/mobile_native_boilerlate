import Foundation

struct LTTestHistoryModel: Codable {
    var totalItems: Int?
    var data: [LTTestResultModel]?
    var totalPages, currentPage: Int?
}
