import Foundation

struct LTTestHistoryTempModel: Codable {
    let id: Int?
    let stage: Int?
    let lactateOnset: Double?
    let duration: Double?
    let distance: Double?
    let smO2Avg: Double?
    let speedMax: Double?
    let speedAvg: Double?
    let date: String?
    let isFromLocal: Bool?

    enum CodingKeys: String, CodingKey {
        case id
        case stage
        case lactateOnset
        case duration
        case distance
        case speedMax
        case speedAvg
        case smO2Avg
        case date
        case isFromLocal
    }
    
    init (_ id: Int? = 0, _ stage: Int? = 0, _ lactateOnSet: Float? = 0, _  smo2AtLactate4mmol: Float = 0,_ updateDt: String? = "", isFromLocal: Bool = false) {
        self.id = id
        self.stage = 0
        self.duration = 0
        self.distance = 0
        self.speedMax = 0
        self.speedAvg = 0
        self.lactateOnset = 0
        self.smO2Avg = 0
        self.date = ""
        self.isFromLocal = isFromLocal
    }
    
    init(id: Int?, stage: Int?, lactateOnset: Double, duration: Int, distance: Double, smO2Avg: Double, speedMax: Double, speedAvg: Double, date: String) {
        self.id = id
        self.stage = stage
        self.lactateOnset = lactateOnset
        self.duration = Double(duration)
        self.distance = distance
        self.smO2Avg = smO2Avg
        self.speedMax = speedMax
        self.speedAvg = speedAvg
        self.date = date
        self.isFromLocal = true
    }
}
//
//struct LTTestHistoryResult: Codable {
//    let result: LTTestHistoryTempModel?
//    let date: String?
//
//    init() {
//        result = LTTestHistoryTempModel()
//        date = ""
//    }
//}
