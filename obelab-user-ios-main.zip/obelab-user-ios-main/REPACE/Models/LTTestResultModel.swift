import Foundation
import RealmSwift
import Realm

struct LTTestResultModel: Codable {
    var id, ltTestID, ltTestSettingModelMemberID, remoteID: Int?
    var testTypeID: String?
    var stageCnt, totalDuration: Int?
    var totalDistance, onset, mol, smo2Min, smo2Max, smo2Avg: Double?
    var heartRateMin, heartRateMax, heartRateAvg, speedMin: Double?
    var speedMax, speedAvg: Double?
    var status: Int?
    var memberID: Int?
    var createdAt: String?
    var member: UserInfo?
    var listSmo2: [SmO2ChartModel]?
    var listLactate: [SmO2ChartModel]?
    var listLocation: [LocationModel]?
    var listAnalysis: String?
    var stage: [RepaceStageModel]?
    var bleData: String?
    var lastSpeed: Double?
    var protocolType: Int?
    
    enum CodingKeys: String, CodingKey {
        case id
        case ltTestID = "ltTestId"
        case ltTestSettingModelMemberID = "memberId"
        case remoteID = "remoteId"
        case testTypeID = "testTypeId"
        case stageCnt, totalDuration, totalDistance, onset, mol, smo2Min, smo2Max, smo2Avg, heartRateMin, heartRateMax, heartRateAvg, speedMin, speedMax, speedAvg, status
        case memberID = "MemberId"
        case createdAt
        case member = "Member"
        case listSmo2, listLactate, listLocation, stage, bleData, listAnalysis
        case protocolType = "protocolType"
    }
    
    init(id: Int = 0, ltTestID: Int = 0, ltTestSettingModelMemberID: Int = 0, remoteID: Int = 0, testTypeID: String = "", stageCnt: Int = 0, totalDuration: Int = 0, totalDistance: Double = 0, onset: Double = 0, mol: Double = 0, smo2Min: Double = 0, smo2Max: Double = 0, smo2Avg: Double = 0, heartRateMin: Double = 0, heartRateMax: Double = 0, heartRateAvg: Double = 0, speedMin: Double = 0, speedMax: Double = 0, speedAvg: Double = 0, status: Int = 0, memberID: Int = 0, createdAt: String = Functions.getNowSQLDateTime(), lastSpeed: Double = 0.0, protocolType: Int = 0) {
        self.id = id
        self.ltTestID = ltTestID
        self.ltTestSettingModelMemberID = ltTestSettingModelMemberID
        self.remoteID = remoteID
        self.testTypeID = testTypeID
        self.stageCnt = stageCnt
        self.totalDuration = totalDuration
        self.totalDistance = totalDistance
        self.onset = onset
        self.mol = mol
        self.smo2Min = smo2Min
        self.smo2Max = smo2Max
        self.smo2Avg = smo2Avg
        self.heartRateMin = heartRateMin
        self.heartRateMax = heartRateMax
        self.heartRateAvg = heartRateAvg
        self.speedMin = speedMin
        self.speedMax = speedMax
        self.speedAvg = speedAvg
        self.status = status
        self.memberID = memberID
        self.createdAt = createdAt
        self.listSmo2 = []
        self.listLactate = []
        self.listLocation = []
        self.listAnalysis = ""
        self.stage = []
        self.bleData = ""
        self.lastSpeed = lastSpeed
        self.protocolType = protocolType
    }
    
    func listSmo2ToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listSmo2 ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func listLactateToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listLactate ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func listLocationToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.listLocation ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func stageToParameters() -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in self.stage ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func listAnalysisToParameters(listAnalysis: [RepaceAnalysisModel]?) -> [[String: Any]] {
        var params: [[String: Any]] = []
        for item in listAnalysis ?? [] {
            params.append(item.toParameters())
        }
        return params
    }
    
    func toParameters(listAnalysis: [RepaceAnalysisModel]) -> [String: Any] {
        var param: [String: Any] = [
            "testTypeId": self.testTypeID ?? "",
            "stageCnt": self.stageCnt ?? 0,
            "totalDuration": self.totalDuration ?? 0,
            "totalDistance": self.totalDistance?.to1Decimal ?? 0,
            "onset": self.onset?.to1Decimal ?? 0,
            "mol": self.mol?.to1Decimal ?? 0,
            "heartRateMin": self.heartRateMin?.to1Decimal ?? 0,
            "heartRateMax": self.heartRateMax?.to1Decimal ?? 0,
            "heartRateAvg": self.heartRateAvg?.to1Decimal ?? 0,
            "speedMin": self.speedMin?.to1Decimal ?? 0,
            "speedMax": self.speedMax?.to1Decimal ?? 0.0,
            "speedAvg": self.speedAvg?.to1Decimal ?? 0.0,
            "status": 1,
            "listSmo2": self.listSmo2ToParameters(),
            "listLactate": self.listLactateToParameters(),
            "listLocation": self.listLocationToParameters(),
            "stage": self.stageToParameters(),
            "smo2Min": self.smo2Min?.to1Decimal ?? 0,
            "smo2Max": self.smo2Max?.to1Decimal ?? 0,
            "smo2Avg": self.smo2Avg?.to1Decimal ?? 0,
            "bleData": self.bleData ?? "",
            "lastSpeed": self.lastSpeed?.to1Decimal ?? 0,
            "protocolType": self.protocolType ?? 0,
            "listAnalysis": self.listAnalysisToParameters(listAnalysis: listAnalysis)]
        if let createdAt = self.createdAt,
           createdAt.isEmpty == false {
            param["createdAt"] = createdAt
        } 
        return param
    }
    
    func convertToSaveObject(list: [RepaceAnalysisModel]) -> LTTestResultObject {
        let result = LTTestResultObject()
        result.getFromModel(model: self)
        result.memberID = LocalDataManager.profile?.id ?? 0
        result.ltTestID = self.ltTestID ?? 0
        result.ltTestSettingModelMemberID = self.ltTestSettingModelMemberID ?? 0
        result.remoteID = self.remoteID ?? 0
        result.testTypeID = self.testTypeID ?? ""
        result.stageCnt = self.stageCnt ?? 0
        result.status = self.status ?? 0
        result.createdAt = self.createdAt
        result.lastSpeed = self.lastSpeed ?? 0
        result.protocolType = self.protocolType ?? 0
        result.isUploadedS3File = false
        result.isUploadedExercise = false
        result.isAttachCreatedAt = false
        result.listAnalysis = List<RepaceAnalysisObject>()
        for model in list {
            result.listAnalysis.append(RepaceAnalysisObject(model: model))
        }
        result.listLactate = Functions.getListSmO2(list: self.listLactate)
        result.stage = List<RepaceStageObject>()
        if let stages = self.stage {
            stages.forEach { model in
                result.stage.append(RepaceStageObject(model: model))
            }
        }
        return result
    }
    
    private func jsonStringToArray(_ json: String) -> [RepaceAnalysisModel] {
        if let jsonData = json.data(using: .utf8) {
            do {
              let decoder = JSONDecoder()
              let result = try decoder.decode([RepaceAnalysisModel].self, from: jsonData)
              return result
            } catch {
                Functions.showLog(title: "jsonStringToArray error decode", message: json)
            }
        }
        return []
    }
}
