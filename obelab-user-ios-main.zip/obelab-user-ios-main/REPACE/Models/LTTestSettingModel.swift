import Foundation

// MARK: - LTTestSettingModel
struct LTTestSettingModel: Codable {
    var id: Int?
    var testType: String?
    var memberID: Int?
    var userType: String?
    var time: Double?
    var distance, number: Int?

    enum CodingKeys: String, CodingKey {
        case id, testType
        case memberID = "memberId"
        case userType, time, distance, number
    }
    
    init(){
        self.id = 0
        self.testType = ""
        self.memberID = 0
        self.userType = ""
        self.time = 0
        self.distance = 0
        self.number = 0
    }
    
    func toParameters() -> [String: Any] {
        return [
            "testType": self.testType ?? "",
            "userType": self.userType ?? "",
            "time": self.time ?? 0,
            "distance": self.distance ?? 0,
            "number": self.number ?? 0
        ]
    }
}
