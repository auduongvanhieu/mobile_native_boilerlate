import Foundation

struct LocationModel: Codable {
    var latitude, longitude: Double?
    var time: Int?
    
    init(latitude: Double, longitude: Double, time: Int) {
        self.latitude = latitude
        self.longitude = longitude
        self.time = time
    }
    
    func toParameters() -> [String: Any] {
        return [
            "latitude": self.latitude ?? 0,
            "longitude": self.longitude ?? 0,
            "time": self.time ?? 0
        ]
    }
}
