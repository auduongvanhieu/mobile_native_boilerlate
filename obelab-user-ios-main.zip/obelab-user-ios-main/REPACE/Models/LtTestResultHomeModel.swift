import Foundation

struct LtTestResultHomeModel: Codable {
    var totalStages: Int?
    var lactateOnset: Double?
    var smO2AtLactate4Mmol: Int?

    enum CodingKeys: String, CodingKey {
        case totalStages, lactateOnset
        case smO2AtLactate4Mmol = "smO2AtLactate4mmol"
    }
    
}
