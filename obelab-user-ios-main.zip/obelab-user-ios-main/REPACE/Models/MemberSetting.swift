import Foundation

// MARK: - MemberSetting
struct MemberSetting: Codable {
    var id, memberID, pushNotice, mailNotice: Int?
    var guide: Int?
    var language, unit, profileDisclosure: String?

    enum CodingKeys: String, CodingKey {
        case id
        case memberID = "memberId"
        case pushNotice, mailNotice, guide, language, unit, profileDisclosure
    }
    
    init(id: Int = 0) {
        self.id = 0
        self.memberID = 0
        self.pushNotice = 0
        self.mailNotice = 0
        self.guide = 0
        self.language = ""
        self.unit = ""
        self.profileDisclosure = ""
    }
    
    func toParameters() -> [String: Any] {
        return [
            "pushNotice": self.pushNotice ?? 0,
            "mailNotice": self.mailNotice ?? 0,
            "guide": self.guide ?? 0,
            "language": self.language ?? "",
            "unit": self.unit ?? "",
            "profileDisclosure": self.profileDisclosure ?? ""
        ]
    }
}
