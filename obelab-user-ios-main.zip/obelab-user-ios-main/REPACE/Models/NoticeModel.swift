//
//  NoticeModel.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/2/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

struct NoticeModel: Codable {
    let id: Int?
    let title, announcementID, content, htmlContent: String?
    let typeID: String?
    let status: Int?
    let createdAt, updatedAt: String?

    enum CodingKeys: String, CodingKey {
        case id, title
        case announcementID = "announcementId"
        case content, htmlContent
        case typeID = "typeId"
        case status, createdAt, updatedAt
    }
    
    init (_ id: Int? = 0, _ title: String? = "", _ content: String = "",_ updateDt: String? = ""){
        self.id = id
        self.title = ""
        self.announcementID = ""
        self.content = ""
        self.htmlContent = ""
        self.typeID = ""
        self.status = 0
        self.createdAt = ""
        self.updatedAt = ""
    }
}
