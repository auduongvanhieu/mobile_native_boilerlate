import Foundation

// MARK: - NoticeParentModel
struct NoticeParentModel: Codable {
    let totalItems, totalPages, currentPage: Int?
    let data: [NoticeModel]?
    
    init(totalItems: Int = 0) {
        self.totalItems = 0
        self.totalPages = 0
        self.currentPage = 0
        self.data = []
    }
}
