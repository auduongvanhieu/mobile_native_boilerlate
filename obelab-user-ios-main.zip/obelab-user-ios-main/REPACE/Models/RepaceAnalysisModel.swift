import Foundation

struct RepaceAnalysisModel: Codable {
    var isNext: Bool = false
    var lactate: Double = 0.0
    var speed: Double = 0.0
    var onset: Double = 0.0
    var threshold: Double = 0.0
    
    init (isNext: Bool = false, lactate: Double = 0.0, speed: Double = 0.0, onset: Double = 0.0, threshold: Double = 0.0) {
        self.isNext = isNext
        self.lactate = lactate
        self.speed = speed
        self.onset = onset
        self.threshold = threshold
    }
     
    func toParameters() -> [String: Any] {
        return [
            "isNext": self.isNext,
            "lactate": self.lactate.to1Decimal,
            "speed": self.speed.to1Decimal,
            "onset": self.onset.to1Decimal,
            "threshold": self.threshold.to1Decimal
            ]
    }
}
