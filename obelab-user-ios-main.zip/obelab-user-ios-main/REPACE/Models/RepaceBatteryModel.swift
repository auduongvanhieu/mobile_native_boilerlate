import Foundation

struct RepaceBatteryModel: Codable {
    var dataType: String = ""
    var data: [UInt8] = []
    
    var length: UInt8 = 0
    var status: String = ""
    var rawData: [UInt8] = []
    var level: UInt8 = 0
    
    init (dataType: String = "", data: [UInt8] = [], length: UInt8 = 0, status: String = "", rawData: [UInt8] = [], level: UInt8 = 0){
        self.dataType = dataType
        self.data = data
        self.length = length
        self.status = status
        self.rawData = rawData
        self.level = level
    }
}
