import Foundation

struct RepaceErrorModel: Codable {
    var dataType: String = ""
    var data: [UInt8] = []
    
    var lastReceive: UInt8 = 0
    var errorCode: UInt8 = 0
    
    init (dataType: String = "", data: [UInt8] = [], lastReceive: UInt8 = 0, errorCode: UInt8 = 0){
        self.dataType = dataType
        self.data = data
        self.lastReceive = lastReceive
        self.errorCode = errorCode
    }
}
