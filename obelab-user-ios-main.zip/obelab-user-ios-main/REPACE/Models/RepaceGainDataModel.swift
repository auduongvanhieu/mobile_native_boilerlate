import Foundation

struct RepaceGainDataModel: Codable {
    var dataType: String = ""
    var data: [UInt8] = []
    
    var length: UInt8 = 0
    var status: String = ""
    
    init (dataType: String = "", data: [UInt8] = [], length: UInt8 = 0, status: String = ""){
        self.dataType = dataType
        self.data = data
        self.length = length
        self.status = status
    }
}
