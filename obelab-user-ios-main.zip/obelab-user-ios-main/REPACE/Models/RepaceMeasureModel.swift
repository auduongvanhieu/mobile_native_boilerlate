import Foundation

struct RepaceMeasureModel: Codable {
    var dataType: String = ""
    var data: [UInt8] = []
    var rowData: [UInt8] = []
    
    var length: UInt8 = 0
    var sequence: [UInt8] = []
    var rSO2: [UInt8] = []
    var accel: [UInt8] = []
    var gyro: [UInt8] = []
    var channel1: [UInt8] = []
    var channel2: [UInt8] = []
    var channel3: [UInt8] = []
    var channel4: [UInt8] = []
    var channel5: [UInt8] = []
    var channel6: [UInt8] = []
    var marker: Int?
    init (dataType: String = "", data: [UInt8] = [], rowData: [UInt8] = [], length: UInt8 = 0, sequence: [UInt8] = [], rSO2: [UInt8] = [], accel: [UInt8] = [], gyro: [UInt8] = [], channel1: [UInt8] = [], channel2: [UInt8] = [], channel3: [UInt8] = [], channel4: [UInt8] = [], channel5: [UInt8] = [], channel6: [UInt8] = [], marker: Int? = nil){
        self.dataType = dataType
        self.data = data
        self.rowData = rowData
        self.length = length
        self.sequence = sequence
        self.rSO2 = rSO2
        self.accel = accel
        self.gyro = gyro
        self.channel1 = channel1
        self.channel2 = channel2
        self.channel3 = channel3
        self.channel4 = channel4
        self.channel5 = channel5
        self.channel6 = channel6
        self.marker = marker
    }
}
