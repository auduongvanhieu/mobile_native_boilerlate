import Foundation

struct RepaceProtocolModel: Codable {
    var protocolValue: Int = 0
    var startSpeed: Double = 0.0
    var heartRate: Int = 0
    
    init (protocolValue: Int = 0, startSpeed: Double = 0.0, heartRate: Int = 0){
        self.protocolValue = protocolValue
        self.startSpeed = startSpeed
        self.heartRate = heartRate
    }
}
