import Foundation

struct RepaceStageModel: Codable {
    var stage: Int? = 0
    var speed: Double? = 0.0
    var distance: Double? = 0.0
    var duration: Int? = 0
    var avgSmO2: Double? = 0.0
    var avgHeartRate: Double? = 0.0
    
    init (stage: Int = 0, speed: Double = 0.0, distance: Double = 0.0, duration: Int = 0, avgSmO2: Double = 0.0, avgHeartRate: Double = 0.0) {
        self.stage = stage
        self.speed = speed
        self.distance = distance
        self.duration = duration
        self.avgSmO2 = avgSmO2
        self.avgHeartRate = avgHeartRate
    }
    
    func toParameters() -> [String: Any] {
        return [
            "stage": self.stage ?? 0,
            "speed": self.speed ?? 0,
            "distance": self.distance ?? 0
        ]
    }
}
