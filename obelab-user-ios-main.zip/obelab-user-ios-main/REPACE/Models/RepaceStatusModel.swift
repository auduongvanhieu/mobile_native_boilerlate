import Foundation

struct RepaceStatusModel: Codable {
    var dataType: String = ""
    var data: [UInt8] = []
    
    var length: UInt8 = 0
    var status: String = ""
    var payload: [UInt8] = []
    
    init (dataType: String = "", data: [UInt8] = [], length: UInt8 = 0, status: String = "", payload: [UInt8] = []){
        self.dataType = dataType
        self.data = data
        self.length = length
        self.status = status
        self.payload = payload
    }
}
