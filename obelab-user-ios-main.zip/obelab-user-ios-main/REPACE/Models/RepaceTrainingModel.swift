import Foundation

struct RepaceTrainingModel: Codable {
    var section: Int = 0
    var time: Int = 0
    var speed: Double = 0.0
    var heartRate: Int = 0
    
    init (section: Int = 0, time: Int = 0, speed: Double = 0.0, heartRate: Int = 0) {
        self.section = section
        self.time = time
        self.speed = speed
        self.heartRate = heartRate
    }
}
