// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let resModel = try? newJSONDecoder().decode(ResModel.self, from: jsonData)

import Foundation

// MARK: - ResModel
struct ResModel: Codable {
    let success: Bool?
    let msg: String?
    let data: JSONAny?
    
    init(success: Bool = false) {
        self.success = false
        self.msg = ""
        self.data = JSONAny()
    }
}

struct BaseArrayResModel<T: Codable>: Codable {
    let success: Bool?
    let msg: String?
    let data: [T]
    
    init(success: Bool = false) {
        self.success = success
        self.msg = ""
        self.data = []
    }
}

struct BaseObjResModel<T: Codable>: Codable {
    let success: Bool?
    let msg: String?
    let data: T?
}
