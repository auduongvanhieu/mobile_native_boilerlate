import Foundation

struct SmO2ChartModel: Codable {
    var name: String?
    var score: Double?
    
    init(name: String = "", score: Double = 0){
        self.name = name
        self.score = score
    }
    
    func toParameters() -> [String : Any] {
        return [
            "name": self.name ?? "",
            "score": self.score ?? 0
        ]
    }
}
