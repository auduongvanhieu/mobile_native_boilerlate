import Foundation

// MARK: - UserInfo
struct UserInfo: Codable {
    var id: Int?
    var email, nickname: String?
    var avatar, level: String?
    var socialID, socialType, socialToken: String?
    var key: Int?
    var height, weight: Double?
    var os, birthday, gender, memberType: String?
    var trophyCnt, medalCnt, badgeCnt: Int?
    var status, deleteAt: JSONAny?
    var lastLogin: String?
    var requested: Bool?
    
    enum CodingKeys: String, CodingKey {
        case id, email, nickname, avatar, level, requested
        case socialID = "socialId"
        case socialType, socialToken, key, height, weight, os, birthday, gender, memberType, trophyCnt, medalCnt, badgeCnt, status, deleteAt, lastLogin
    }
    
    init(id: Int = 0) {
        self.id = 0
        self.email = ""
        self.nickname = ""
        self.avatar = ""
        self.level = ""
        self.socialID = ""
        self.socialType = ""
        self.key = 0
        self.height = 0
        self.weight = 0
        self.os = ""
        self.birthday = ""
        self.gender = ""
        self.memberType = ""
        self.trophyCnt = 0
        self.medalCnt = 0
        self.badgeCnt = 0
        self.status = JSONAny()
        self.deleteAt = JSONAny()
        self.lastLogin = ""
        self.requested = false
    }
    
    func getAge() -> Int{
        let now = Date()
        let birthday: Date = Functions.convertDateStrToDate(dateStr: self.birthday ?? Constants.DATE_DEFAULT)
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: birthday, to: now)
        let age = ageComponents.year!
        return age
    }
    
    func toParameters() -> [String : Any] {
        return [
            "avatar": self.avatar ?? Constants.AVATAR_DEFAULT,
            "nickname": self.nickname ?? "nickname",
            "birthday": self.birthday ?? Constants.DATE_DEFAULT,
            "gender": self.gender ?? Constants.GENDER_MALE,
            "height": self.height ?? Constants.HEIGHT_DEFAULT,
            "weight": self.weight ?? Constants.WEIGHT_DEFAULT,
        ]
    }
}
