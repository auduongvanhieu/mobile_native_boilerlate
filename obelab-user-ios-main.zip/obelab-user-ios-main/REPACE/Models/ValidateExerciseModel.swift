//
//  ValidateExerciseModel.swift
//  REPACE
//
//  Created by BM Johnny on 28/03/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
struct ValidateExerciseModel: Codable {
    let type: Int?
    let success: Bool?
    let msg: String?
    
    init(type: Int? = 0, success: Bool? = false, msg: String? = "") {
        self.type = type
        self.success = success
        self.msg = msg
    }
}
