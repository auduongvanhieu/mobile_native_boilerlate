//
//  AuthenticationServices.swift
//  REPACE
//
//  Created by Germán Stábile on 6/8/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class AuthenticationServices {
    
    class func login(
        email: String,
        password: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/login"
        let parameters = [
            "email": email,
            "password": password
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["token": "", "user": "{}"]
                let token = data["token"] as? String ?? ""
                let user = data["user"] as? [String: Any] ?? ["id": "0"]
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let resLogin = try? JSONDecoder().decode(ResModel.self, from: response)

                Functions.showLog(title: "login_token", message: token)
                Functions.showLog(title: "login_user", message: profile ?? "")
                Functions.showLog(title: "res_login", message: resLogin ?? "")
                
                LocalDataManager.token = token
                LocalDataManager.profile = profile
                LocalDataManager.resetData()
                
                success(resLogin ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func signUp(
        email: String,
        password: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/register"
        let parameters = [
            "email": email,
            "password": password,
            "os": Constants.iOS
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["token": "", "user": "{}"]
                let token = data["token"] as? String ?? ""
                let user = data["user"] as? [String: Any] ?? ["id": "0"]
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let resLogin = try? JSONDecoder().decode(ResModel.self, from: response)

                Functions.showLog(title: "sign_up_token", message: token)
                Functions.showLog(title: "sign_up_user", message: profile ?? "")
                Functions.showLog(title: "res_sign_up", message: resLogin ?? "")
                
                LocalDataManager.token = token
                LocalDataManager.profile = profile
                LocalDataManager.resetData()
                
                success(resLogin ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func checkEmail(
        email: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/check-mail"
        let parameters = [
            "email": email,
            "os": Constants.iOS
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let resLogin = try? JSONDecoder().decode(ResModel.self, from: response)
                success(resLogin ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func forgetPassword(
        email: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/forget-password"
        let parameters = [
            "mail": email
        ]
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "forgetPasswordRes", message: res ?? "")
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func loginSocial(
        id: String,
        socialType: String,
        success: @escaping (_ isExist: Bool) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/login-social"
        let parameters = [
            "id": id,
            "social_type": socialType,
            "os": Constants.OS,
        ]
        Functions.showLog(title: "loginSocialParams", message: parameters)
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["token": "", "user": "{}"]
                let token = data["token"] as? String ?? ""
                let user = data["user"] as? [String: Any] ?? ["id": "0"]
                let isExist = data["isExist"] as? Bool ?? false
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let resLogin = try? JSONDecoder().decode(ResModel.self, from: response)

                Functions.showLog(title: "login_token", message: token)
                Functions.showLog(title: "login_user", message: profile ?? "")
                Functions.showLog(title: "login_isExist", message: isExist)
                Functions.showLog(title: "res_login", message: resLogin ?? "")
                
                LocalDataManager.token = token
                LocalDataManager.profile = profile
                
                success(isExist)
            },
            failure: failure
        )
    }
    
    class func registerSocial(
        id: String,
        socialType: String,
        email: String,
        success: @escaping (_ res: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/register-social"
        let parameters = [
            "id": id,
            "social_type": socialType,
            "email": email,
            "os": Constants.OS,
        ]
        Functions.showLog(title: "loginSocialParams", message: parameters)
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["token": "", "user": "{}"]
                let token = data["token"] as? String ?? ""
                let user = data["user"] as? [String: Any] ?? ["id": "0"]
                let isRegister = data["isRegister"] as? Bool ?? false
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let resModel = try? JSONDecoder().decode(ResModel.self, from: response)

                Functions.showLog(title: "login_token", message: token)
                Functions.showLog(title: "login_user", message: profile ?? "")
                Functions.showLog(title: "login_isRegister", message: isRegister)
                Functions.showLog(title: "res_register", message: resModel ?? "")
                
                LocalDataManager.token = token
                LocalDataManager.profile = profile
                
                success(resModel ?? ResModel())
            },
            failure: failure
        )
    }
    class func postFCMToken(
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/member-token/post"
        let parameters = [
            "token": Constants.FCM_TOKEN
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "postFCMToken", message: res ?? "")
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
}
