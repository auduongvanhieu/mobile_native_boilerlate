//
//  BaseURLConvertible.swift
//  REPACE
//
//  Created by Germán Stábile on 6/8/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import Foundation
import Alamofire

class BaseURLConvertible: URLConvertible {
  
  let path: String
  let baseUrl: String
  
  init(path: String, baseUrl: String = APIClient.getBaseUrl()) {
    self.path = path
    self.baseUrl = baseUrl
  }
  
  func asURL() throws -> URL {
    return URL(string: "\(baseUrl)\(path)")!
  }
}

class BaseURLRequestConvertible: URLRequestConvertible {
  let url: URLConvertible
  let method: HTTPMethod
  let headers: HTTPHeaders
  let params: [String: Any]?
  let encoding: ParameterEncoding?
  
  func asURLRequest() throws -> URLRequest {
    let request = try URLRequest(
      url: url,
      method: method,
      headers: headers
    )
    if let params = params, let encoding = encoding {
        let newParams = removeNanParam(params: params, url: url)
//        if let theJSONData = try? JSONSerialization.data(
//            withJSONObject: newParams,
//            options: []) {
//            let theJSONText = String(data: theJSONData,
//                                     encoding: .utf8)
//            Functions.showLog(title: "Mytv API URL \(request.url?.absoluteString)", message: theJSONText ?? "")
//        }
      return try encoding.encode(request, with: newParams)
    }
    
    return request
  }
    
    private func removeNanParam(params: [String: Any], url: URLConvertible) -> [String: Any] {
        var newParams: [String: Any] = [:]
        params.forEach { (key, value) in
            if let doubleValue = value as? Double {
                if doubleValue.isNaN == false {
                    newParams[key] = doubleValue
                } else {
                    Functions.showLog(title: "Function removeNanParam Param is Nan: \(key) = \(doubleValue)", message: url)
                    newParams[key] = 0.0
                }
            } else if let dictionaryValue = value as? [String: Any] {
                newParams[key] = removeNanParam(params: dictionaryValue, url: url)
            } else if let arrDictionaryValue = value as? [[String: Any]] {
                var newArray: [[String: Any]] = []
                arrDictionaryValue.forEach { (param) in
                    let newParam = removeNanParam(params: param, url: url)
                    newArray.append(newParam)
                }
                newParams[key] = newArray
            } else {
                newParams[key] = value
            }
        }
        return newParams
    }
  
  init(
    path: String,
    baseUrl: String = APIClient.getBaseUrl(),
    method: HTTPMethod,
    encoding: ParameterEncoding? = nil,
    params: [String: Any]? = nil,
    headers: [String: String] = [:]
  ) {
    url = BaseURLConvertible(path: path, baseUrl: baseUrl)
    self.method = method
    self.headers = HTTPHeaders(headers)
    self.params = params
    self.encoding = encoding
  }
}
