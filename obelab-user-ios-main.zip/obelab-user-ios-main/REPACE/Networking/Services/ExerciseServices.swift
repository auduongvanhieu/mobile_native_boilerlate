import Foundation

class ExerciseServices {
    class func getExerciseHistoryInMonth(
        year: Int, month: Int,
        success: @escaping (_ res: [DayExerciseModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "getExerciseHistoryInMonthParams", message: "{'month': \(month), 'year': \(year)}")
        APIClient.request(
            .get, url: "/api/private/user/exercise-result/by-month?month=\(month)&year=\(year)",
            success: { response, _ in
                let data = response["data"] as? [[String: Any]] ?? [["id": 0]]
                var res: [DayExerciseModel] = []
                data.map {
                    let item = try? JSONDecoder().decode(DayExerciseModel.self, from: $0)
                    res.append(item ?? DayExerciseModel())
                    if(item?.id == Functions.getTodayExerciseId()){
                        LocalDataManager.todayHistoryExercise = item!
                    }
                }
                Functions.showLog(title: "getExerciseHistoryInMonthRes", message: Functions.structToJsonStr(res))
                success(res)
            },
            failure: failure
        )
    }
    
    class func getRxExerciseHistoryInMonth(
        year: Int, month: Int,
        success: @escaping (_ res: [DayExerciseModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "getRxExerciseHistoryInMonth", message: "{'month': \(month), 'year': \(year)}")
        APIClient.request(
            .get, url: "/api/private/user/exercise-result/by-month?month=\(month)&year=\(year)",
            success: { response, _ in
                let data = response["data"] as? [[String: Any]] ?? [["id": 0]]
                var res: [DayExerciseModel] = []
                data.map {
                    let item = try? JSONDecoder().decode(DayExerciseHistoryModel.self, from: $0)
                    let dayExerciseModel = item?.convertToDayExerciseModel()
                    res.append(dayExerciseModel ?? DayExerciseModel())
                    if let dayExerciseModel = dayExerciseModel, dayExerciseModel.id == Functions.getTodayExerciseId() {
                        LocalDataManager.todayHistoryExercise = dayExerciseModel
                    }
                }
                Functions.showLog(title: "getExerciseHistoryInMonthRes", message: Functions.structToJsonStr(res))
                success(res)
            },
            failure: failure
        )
    }
    
    class func getExerciseHistoryToday(
        success: @escaping (_ res: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "getExerciseHistoryToday", message: "")
        APIClient.request(
            .get, url: "/api/private/exercise/validate",
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "getExerciseHistoryToday", message: Functions.structToJsonStr(res))
                success(res ?? ResModel(success: false))
            },
            failure: failure
        )
    }
    
    class func postExerciseResult(
        exercise: ExerciseResultModel,
        success: @escaping (_ res: ExerciseCompleteModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "postExerciseResultParams", message: exercise.toParameters())
        APIClient.request(
            .post, url: "/api/private/exercise-result/create", params: exercise.toParameters(),
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                var res: ExerciseCompleteModel = try! JSONDecoder().decode(ExerciseCompleteModel.self, from: data)
                let resFinal = res ?? ExerciseCompleteModel()
                Functions.showLog(title: "postExerciseResultRes", message: Functions.structToJsonStr(res))
                success(resFinal)
                },
            failure: failure
        )
    }
    
    static func getResultExercise(
        id: Int,
        success: @escaping (_ res: ExerciseResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/exercise-detail/\(id)",
            params: nil,
            success: { response, _ in
                let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseResultModel>.self, from: response)
                success(item?.data ?? ExerciseResultModel())
            },
            failure: failure
        )
    }
    
    static func getStatusHistoryButton(
        success: @escaping (_ res: HistoryStatusButtonModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/exercise-result/check-record",
            success: { response, _ in
                let item = try? JSONDecoder().decode(BaseObjResModel<HistoryStatusButtonModel>.self, from: response)
                success(item?.data ?? HistoryStatusButtonModel())
            },
            failure: failure
        )
    }
    
    static func getExerciseHistory(
        page: Int = 0,
        success: @escaping (_ res: ExerciseResultListModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = [ "page": page, "limit": Constants.PAGE_LIMIT ]
        APIClient.request(
            .get, url: "/api/private/user/exercise-result/history",
            params: parameters,
            success: { response, _ in
                let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseResultListModel>.self, from: response)
                
                success(item?.data ?? ExerciseResultListModel())
            },
            failure: failure
        )
    }
    
    static func getHistoryExerciseInMonth(
        year: Int, month: Int, type: String?,
        success: @escaping (_ res: [DayExerciseModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let logType = type == nil ? "" : ", 'type' = " + (type ?? "")
        Functions.showLog(title: "getHistoryExerciseInMonthParams", message: "{'month': \(month), 'year': \(year)\(logType)}")
        var urlString = "/api/private/user/exercise-result/by-month?month=\(month)&year=\(year)"
        if let type = type {
            urlString += "&type=\(type)"
        }
        APIClient.request(
            .get, url: urlString,
            success: { response, _ in
                let data = response["data"] as? [[String: Any]] ?? [["id": 0]]
                var res: [DayExerciseModel] = []
                _ = data.map {
                    let item = try? JSONDecoder().decode(DayExerciseHistoryModel.self, from: $0)
                    if let itemConvert = item?.convertToDayExerciseModel() {
                        res.append(itemConvert)
                        if itemConvert.id == Functions.getTodayExerciseId() {
                            LocalDataManager.todayHistoryExercise = itemConvert
                        }
                    }
                }
                Functions.showLog(title: "getExerciseHistoryInMonthRes", message: Functions.structToJsonStr(res))
                success(res)
            },
            failure: failure
        )
    }
    
   static func getLast7DaysStatistic(
        type: String,
        activity: String = "",
        fromDate: String = "",
        success: @escaping (_ res: ExerciseStatisticResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = [ "activity": activity, "date": fromDate, "type": type ]
        APIClient.request(
            .get, url: "/api/private/user/exercise-result/7-day",
            params: parameters,
            success: { response, _ in
                let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseStatisticResultModel>.self, from: response)
                
                success(item?.data ?? ExerciseStatisticResultModel())
            },
            failure: failure
        )
    }
    
    static func getLast4WeeksStatistic(
        type: String,
        activity: String = "",
        fromDate: String = "",
        success: @escaping (_ res: ExerciseStatisticResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
     ) {
         let parameters = [ "activity": activity, "date": fromDate, "type": type ]
         APIClient.request(
             .get, url: "/api/private/user/exercise-result/4-week",
             params: parameters,
             success: { response, _ in
                 let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseStatisticResultModel>.self, from: response)
                 
                 success(item?.data ?? ExerciseStatisticResultModel())
             },
             failure: failure
         )
     }
    
    static func getLast1YearStatistic(
        type: String,
        activity: String = "",
        fromDate: String = "",
        success: @escaping (_ res: ExerciseStatisticResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
     ) {
         let parameters = [ "activity": activity, "date": fromDate, "type": type ]
         APIClient.request(
             .get, url: "/api/private/user/exercise-result/1-year",
             params: parameters,
             success: { response, _ in
                 let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseStatisticResultModel>.self, from: response)
                 
                 success(item?.data ?? ExerciseStatisticResultModel())
             },
             failure: failure
         )
     }
    
    static func getStatisticDetails(
         type: String = "0",
         typeExercise: String = "",
         activity: String = "",
         fromDate: String = "",
         success: @escaping (_ res: ExerciseStatisticDetailResultModel) -> Void,
         failure: @escaping (_ error: Error) -> Void
     ) {
         let parameters = ["type": type, "typeexercise": typeExercise, "activity": activity, "date": fromDate ]
         APIClient.request(
             .get, url: "/api/private/user/exercise-statistic/detail",
             params: parameters,
             success: { response, _ in
                 let item = try? JSONDecoder().decode(BaseObjResModel<ExerciseStatisticDetailResultModel>.self, from: response)
                 
                 success(item?.data ?? ExerciseStatisticDetailResultModel())
             },
             failure: failure
         )
     }
}
