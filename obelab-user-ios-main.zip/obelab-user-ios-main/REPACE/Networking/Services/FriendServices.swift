//
//  FriendServices.swift
//  REPACE
//
//  Created by ThienBanh on 19/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit

class FriendServices {
    
    class func checkProfilePrivate(
        id: Int = 0,
        success: @escaping (_ canAccess: Bool) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend/get-other-info/\(id)"

        APIClient.request(
            .get, url: url,
            success: { response, _ in
                let resModel = try? JSONDecoder().decode(ResModel.self, from: response)
                success(resModel?.success ?? false)
            },
            failure: failure
        )
    }
    
    class func getListFriends(
        name: String = "",
        success: @escaping (_ goal: FriendModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend/all"

        APIClient.request(
            .get, url: url,
            success: { response, _ in
                let friend = try? JSONDecoder().decode(FriendModel.self, from: response) 
                let friendEmpty = FriendModel()
                Functions.showLog(title: "getListFriends", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    
    class func getFriendRequest(
        success: @escaping (_ goal: FriendModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend-request/all-invite"

        APIClient.request(
            .get, url: url,
            success: { response, _ in
                let friend = try? JSONDecoder().decode(FriendModel.self, from: response)
                let friendEmpty = FriendModel()
                Functions.showLog(title: "getFriendRequest", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func getListNotFriends(
        page: Int,
        name: String = "",
        success: @escaping (_ goal: AllFriendModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend/get-other"
        let parameters = ["page": page, "limit": Constants.PAGE_LIMIT, "nickname": name ] as [String : Any]
        APIClient.request(
            .get, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(AllFriendModel.self, from: data)
                let friendEmpty = AllFriendModel()
                Functions.showLog(title: "getListNotFriends", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func unfriend(
        id: Int,
        success: @escaping (_ goal: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend/unfriend/\(id)"

        APIClient.request(
            .delete, url: url,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(ResModel.self, from: data)
                let friendEmpty = ResModel()
                Functions.showLog(title: "unfriend", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func rejectRequest(
        id: Int,
        success: @escaping (_ goal: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend-request/reject/\(id)"

        APIClient.request(
            .delete, url: url,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(ResModel.self, from: data)
                let friendEmpty = ResModel()
                Functions.showLog(title: "rejectRequest", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func acceptRequest(
        id: Int,
        success: @escaping (_ goal: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend-request/accept/\(id)"

        APIClient.request(
            .put, url: url,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(ResModel.self, from: data)
                let friendEmpty = ResModel()
                Functions.showLog(title: "acceptRequest", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func requestAddFriend(
        id: Int,
        success: @escaping (_ goal: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend-request/create"
        let parameters = [
            "friendId": id,
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(ResModel.self, from: data)
                let friendEmpty = ResModel()
                Functions.showLog(title: "acceptRequest", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func cancelRequest(
        id: Int,
        success: @escaping (_ goal: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/friend-request/cancel/\(id)"
        
        APIClient.request(
            .delete, url: url,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(ResModel.self, from: data)
                let friendEmpty = ResModel()
                Functions.showLog(title: "rejectRequest", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
    class func linkFacebook(
        socialID: String,
        token: String,
        success: @escaping (_ goal: FriendModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user-connect/social-connect"
        let parameters = [
            "socialId": socialID,
            "socialToken" : token
        ] as [String : Any]
        APIClient.request(
            .put,
            url: url,
            params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let friend = try? JSONDecoder().decode(FriendModel.self, from: response)
                let friendEmpty = FriendModel()
                Functions.showLog(title: "linkFacebook", message: friend ?? friendEmpty)
                success(friend ?? friendEmpty)
            },
            failure: failure
        )
    }
}
