import Foundation

class GeneralServices {
    
    class func getTermOfUse(
        success: @escaping (_ commonCode: CommonCode) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/public/commoncode/get-by-code/term_use",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let commonCode = try? JSONDecoder().decode(CommonCode.self, from: data)
                let commonCodeEmpty = CommonCode()
                Functions.showLog(title: "getTermOfUseRes", message: commonCode ?? commonCodeEmpty)
                success(commonCode ?? commonCodeEmpty)
            },
            failure: failure
        )
    }
    
    class func getPrivacyPolicy(
        success: @escaping (_ commonCode: CommonCode) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/public/commoncode/get-by-code/privacy",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let commonCode = try? JSONDecoder().decode(CommonCode.self, from: data)
                let commonCodeEmpty = CommonCode()
                Functions.showLog(title: "getTermOfUseRes", message: commonCode ?? commonCodeEmpty)
                success(commonCode ?? commonCodeEmpty)
            },
            failure: failure
        )
    }
    
    class func getHeightWeight(
        success: @escaping (_ heightList: Array<Double>, _ weightList: Array<Double>) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/public/commoncode/get-list-height",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["heightList": [], "weightList": []]
                let heightList = data["heightList"] as? [Double] ?? []
                let weightList = data["weightList"] as? [Double] ?? []
                Functions.showLog(title: "heightList", message: heightList)
                Functions.showLog(title: "weightList", message: weightList)
                success(heightList, weightList)
            },
            failure: failure
        )
    }
    
    class func getPairingVideo(
        success: @escaping (_ commonCode: CommonCode) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/public/commoncode/get-by-code/pairing_video",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let commonCode = try? JSONDecoder().decode(CommonCode.self, from: data)
                let commonCodeEmpty = CommonCode()
                Functions.showLog(title: "pairingVideoRes", message: commonCode ?? commonCodeEmpty)
                success(commonCode ?? commonCodeEmpty)
            },
            failure: failure
        )
    }
    
    class func getFaqList(
        success: @escaping (_ faqList: [FaqModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/faq/get-list"
        APIClient.request(
            .get, url: url,
            success: { response, _ in
                let data = response["data"] as? [[String: Any]] ?? [["id": 0]]
                let faqList: [FaqModel] = data.map {
                   let faqModel = try? JSONDecoder().decode(FaqModel.self, from: $0)
                    return faqModel ?? FaqModel()
                }
                Functions.showLog(title: "getFaqListRes", message: faqList )
                success(faqList)
            },
            failure: failure
        )
    }
}
