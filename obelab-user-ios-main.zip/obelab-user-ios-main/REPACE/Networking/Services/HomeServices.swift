import Foundation

class HomeServices {
    class func getMyExerciseAverage(
        cumulative: Bool,
        success: @escaping (_ res: ExerciseAverage) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = [
            "cumulative": cumulative
        ]
        Functions.showLog(title: "getMyExerciseAverageParams", message: parameters)
        APIClient.request(
            .get, url: "/api/private/exercise-result/get-avg?cumulative=\(cumulative)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(ExerciseAverage.self, from: data)
                let resEmpty = ExerciseAverage()
                Functions.showLog(title: "getMyExerciseAverageRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getLtTestResultHome(
        cumulative: Bool,
        success: @escaping (_ res: LtTestResultHomeModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = ["cumulative": cumulative]
        Functions.showLog(title: "getLtTestResultHomeParams", message: parameters)
        APIClient.request(
            .get, url: "/api/private/admin/lt-test/get-by-user?cumulative=\(cumulative)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LtTestResultHomeModel.self, from: data)
                let resEmpty = LtTestResultHomeModel()
                Functions.showLog(title: "getLtTestResultHomeRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getLastestLtTestResultHome(
        success: @escaping (_ res: LTTestResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "getLastestLtTestResultHome", message: "")
        APIClient.request(
            .get, url: "/api/private/user/lt-test/last-result",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LTTestResultModel.self, from: data)
                let resEmpty = LTTestResultModel()
                Functions.showLog(title: "getLtTestResultHomeRes", message: res ?? resEmpty)
                let resFinal = res ?? resEmpty
                LocalDataManager.lastLTTestResult = resFinal
                success(resFinal)
            },
            failure: failure
        )
    }
    
    class func getLastestLtTestOtherUser(
        id: Int,
        success: @escaping (_ res: LTTestResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "getLastestLtTestOtherUser", message: "")
        APIClient.request(
            .get, url: "/api/private/other/lt-test/last-result/\(id)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LTTestResultModel.self, from: data)
                let resEmpty = LTTestResultModel()
                Functions.showLog(title: "getLtTestResultHomeRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getExercisePrescription(
        success: @escaping (_ res: ExercisePresciptionModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/exercise-prescription/me",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(ExercisePresciptionModel.self, from: data)
                let resEmpty = ExercisePresciptionModel()
                Functions.showLog(title: "getExercisePrescriptionRes", message: res ?? resEmpty)
                if res != nil {
                    if (LocalDataManager.ltTestPrescription.type ?? 0) == 0 {
                        if (LocalDataManager.ltTestPrescription.id ?? 0) == 0{
                            LocalDataManager.ltTestPrescription = res ?? ExercisePresciptionModel()
                        }
                        else if(LocalDataManager.ltTestPrescription.createdAt?.compare(res?.createdAt ?? "") == ComparisonResult.orderedAscending){
                            LocalDataManager.ltTestPrescription = res ?? ExercisePresciptionModel()
                        }
                    }
                }
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getOtherExerciseAverage(
        id: Int,
        cumulative: Bool,
        success: @escaping (_ res: ExerciseAverage) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = [
            "cumulative": cumulative
        ]
        Functions.showLog(title: "getMyExerciseAverageParams", message: parameters)
        APIClient.request(
            .get, url: "/api/private/exercise-result/get-other-avg/\(id)?cumulative=\(cumulative)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(ExerciseAverage.self, from: data)
                let resEmpty = ExerciseAverage()
                Functions.showLog(title: "getMyExerciseAverageRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    class func getOtherLtTestResultHome(
        id: Int,
        cumulative: Bool,
        success: @escaping (_ res: LtTestResultHomeModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = ["cumulative": cumulative]
        Functions.showLog(title: "getLtTestResultHomeParams", message: parameters)
        APIClient.request(
            .get, url: "/api/private/admin/lt-test/get-by-member/\(id)?cumulative=\(cumulative)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LtTestResultHomeModel.self, from: data)
                let resEmpty = LtTestResultHomeModel()
                Functions.showLog(title: "getLtTestResultHomeRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    class func getOtherExercisePrescription(
        id: Int,
        success: @escaping (_ res: ExercisePresciptionModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/exercise-prescription/other/\(id)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(ExercisePresciptionModel.self, from: data)
                let resEmpty = ExercisePresciptionModel()
                Functions.showLog(title: "getExercisePrescriptionRes", message: res ?? resEmpty)
//                if(res != nil && ((LocalDataManager.ltTestPrescription.type ?? 0) == 0 || LocalDataManager.ltTestPrescription.createdAt?.compare((res?.createdAt)!) == ComparisonResult.orderedAscending)){
//                    LocalDataManager.ltTestPrescription = res!
//                }
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
}
