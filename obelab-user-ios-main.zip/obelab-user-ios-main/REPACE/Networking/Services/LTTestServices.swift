import Foundation

class LTTestServices {
    
    class func getLtTestSetting(
        success: @escaping (_ res: LTTestSettingModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/lt-test/protocol",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LTTestSettingModel.self, from: data)
                let resEmpty = LTTestSettingModel()
                LocalDataManager.ltTestSetting = res ?? resEmpty
                Functions.showLog(title: "getLtTestSettingRes", message: res ?? resEmpty)
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func updateLtTestSetting(
        ltTestSetting: LTTestSettingModel,
        success: @escaping (_ res: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .put, url: "/api/private/user/lt-test/protocol/update", params: ltTestSetting.toParameters(),
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                let resEmpty = ResModel()
                Functions.showLog(title: "updateLtTestSettingRes", message: res ?? resEmpty)
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let resData = try? JSONDecoder().decode(LTTestSettingModel.self, from: data)
                LocalDataManager.ltTestSetting = resData ?? LTTestSettingModel()
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func postLTTestResult(
        ltTestResult: LTTestResultModel,
        listAnalysis: [RepaceAnalysisModel],
        success: @escaping (_ res: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "postLTTestResultParams", message: Functions.structToJsonStr(ltTestResult))
        LocalDataManager.lastLTTestResult = ltTestResult
        APIClient.request(
            .post, url: "/api/private/admin/lt-test/upload-result", params: ltTestResult.toParameters(listAnalysis: listAnalysis),
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                let resEmpty = ResModel()
                let finalRes = res ?? resEmpty
                Functions.showLog(title: "postLTTestResultRes", message: Functions.structToJsonStr(finalRes))
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getLtTestHistoryByUser(
        page: Int = 0,
        success: @escaping (_ res: LTTestHistoryModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/lt-test/history?limit=\(Constants.PAGE_LIMIT)$page=\(page)",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LTTestHistoryModel.self, from: data)
                let resEmpty = LTTestHistoryModel()
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
    
    class func getLtTestHistory(
        page: Int = 0,
        success: @escaping (_ res: [LTTestHistoryTempModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = [ "page": page, "limit": Constants.PAGE_LIMIT ]
        APIClient.request(
            .get,
            url: "/api/private/user/lt-test/get-per-month",
            params: parameters,
            success: { response, _ in
                let result = response
                let res = try? JSONDecoder().decode(BaseArrayResModel<LTTestHistoryTempModel>.self, from: result)

                success(res?.data ?? [])
            },
            failure: failure
        )
    }
    
    class func getLtTestHistory(
        page: Int = 0,
        limit: Int = 4,
        success: @escaping (_ res: [LTTestHistoryTempModel]) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let parameters = ["page": page, "limit": limit]
        APIClient.request(
            .get,
            url: "/api/private/user/lt-test/get-per-month",
            params: parameters,
            success: { response, _ in
                let result = response
                let res = try? JSONDecoder().decode(BaseArrayResModel<LTTestHistoryTempModel>.self, from: result)

                success(res?.data ?? [])
            },
            failure: failure
        )
    }
    
    class func getLTTestResult(
        id: Int = 0,
        success: @escaping (_ res: LTTestResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/private/admin/lt-test/get-by-id/\(id)",
            success: { response, _ in
                let result = response
                let res = try? JSONDecoder().decode(BaseObjResModel<LTTestResultModel>.self, from: result)
                success(res?.data ?? LTTestResultModel())
            },
            failure: failure
        )
    }
    
    class func getLastLtTest(
        success: @escaping (_ res: LTTestResultModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/user/lt-test/last-result",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let res = try? JSONDecoder().decode(LTTestResultModel.self, from: data)
                let resEmpty = LTTestResultModel()
                let resFinal = res ?? resEmpty
                LocalDataManager.lastLTTestResult = resFinal
//                if(LocalDataManager.lastLTTestResult.testTypeID == nil || LocalDataManager.lastLTTestResult.testTypeID == "") {
//                    LocalDataManager.lastLTTestResult = resFinal
//                } else {
//                    if(LocalDataManager.lastLTTestResult.createdAt?.compare((resFinal.createdAt ?? "")) == ComparisonResult.orderedAscending) {
//                        LocalDataManager.lastLTTestResult = resFinal
//                    }
//                }
                success(resFinal)
            },
            failure: failure
        )
    }
    
    class func getValidateLtTest(
        success: @escaping (_ res: ValidateExerciseModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get, url: "/api/private/exercise/validate",
            success: { response, _ in
                let res = try? JSONDecoder().decode(ValidateExerciseModel.self, from: response)
                let resEmpty = ValidateExerciseModel()
                let resFinal = res ?? resEmpty
                success(resFinal)
            },
            failure: failure
        )
    }
    
    class func postExercisePrescription(
        exercisePresciption: ExercisePresciptionModel,
        success: @escaping (_ res: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        Functions.showLog(title: "postExercisePrescriptionParams", message: Functions.structToJsonStr(exercisePresciption))
        LocalDataManager.ltTestPrescription = exercisePresciption
        APIClient.request(
            .post, url: "/api/private/user/exercise-prescription/low-intensity", params: exercisePresciption.toParameters(),
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                let resEmpty = ResModel()
                Functions.showLog(title: "postExercisePrescription", message: Functions.structToJsonStr(res ?? resEmpty))
                success(res ?? resEmpty)
            },
            failure: failure
        )
    }
}
