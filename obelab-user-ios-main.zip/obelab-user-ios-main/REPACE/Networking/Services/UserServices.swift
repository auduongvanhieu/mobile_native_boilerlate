//
//  UserServices.swift
//  REPACE
//
//  Created by Germán Stábile on 6/8/20.
//  Copyright © 2020 Rootstrap Inc. All rights reserved.
//

import Foundation

class UserServices {
    
    class func getMyProfile(
        success: @escaping (_ user: UserInfo) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/private/user-profile",
            success: { response, _ in
                let user = response["data"] as? [String: Any] ?? ["user": "{}"]
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let profileEmpty = UserInfo()
                Functions.showLog(title: "getMyProfileRes", message: Functions.structToJsonStr(profile ?? profileEmpty))
                LocalDataManager.profile = profile
                if LocalDataManager.profile?.id == nil {
                    LocalDataManager.token = ""
                    LocalDataManager.profile = UserInfo()
                    LocalDataManager.unit = Constants.UNIT_METRIC
                    AppNavigator.shared.navigate(to: AuthRoutes.welcome, with: .reset)
                }
                success(profile ?? profileEmpty)
            },
            failure: failure
        )
    }
    
    class func updateNickname(
        nickname: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user-profile/update"
        let parameters = [
            "nickname": nickname
        ]
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "res_update_profile", message: res ?? "")
                if res?.success == true {
                    let user = response["data"] as? [String: Any] ?? ["id": "0"]
                    let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                    Functions.showLog(title: "res_update_profile_data", message: profile ?? "")
                    LocalDataManager.profile = profile
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func checkNickname(
        nickname: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/admin/member/check"
        let parameters = [
            "nickname": nickname
        ]
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func registerUser(
        parameters: [String: Any],
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/public/user/register"
        APIClient.request(
            .post, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["token": "", "user": "{}"]
                let token = data["token"] as? String ?? ""
                let user = data["user"] as? [String: Any] ?? ["id": "0"]
                let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                let resLogin = try? JSONDecoder().decode(ResModel.self, from: response)

                Functions.showLog(title: "sign_up_token", message: token)
                Functions.showLog(title: "sign_up_user", message: profile ?? "")
                Functions.showLog(title: "res_sign_up", message: resLogin ?? "")
                
                LocalDataManager.token = token
                LocalDataManager.profile = profile
                LocalDataManager.resetData()
                
                success(resLogin ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func updateAdditionalInfo(
        parameters: [String: Any],
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user-profile/update"
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "res_update_profile", message: res ?? "")
                if res?.success == true {
                    let user = response["data"] as? [String: Any] ?? ["id": "0"]
                    let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                    Functions.showLog(title: "res_update_profile_data", message: profile ?? "")
                    LocalDataManager.profile = profile
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func updateAdditionalInfo(
        birthday: String,
        gender: String,
        height: Double,
        weight: Double,
        nickname: String,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user-profile/update"
        let parameters = [
            "birthday": birthday,
            "gender": gender,
            "height": height,
            "weight": weight,
            "nickname": nickname
        ] as [String: Any]
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "res_update_profile", message: res ?? "")
                if res?.success == true {
                    let user = response["data"] as? [String: Any] ?? ["id": "0"]
                    let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                    Functions.showLog(title: "res_update_profile_data", message: profile ?? "")
                    LocalDataManager.profile = profile
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func getMemberSetting(
        success: @escaping (_ memberSetting: MemberSetting) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        APIClient.request(
            .get,
            url: "/api/private/member-setting",
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["id": 0]
                let memberSetting = try? JSONDecoder().decode(MemberSetting.self, from: data)
                if memberSetting != nil {
                    LocalDataManager.unit = memberSetting?.unit
                    LocalDataManager.language = memberSetting?.language
                }
                let memberSettingEmpty = MemberSetting()
                Functions.showLog(title: "getMemberSettingRes", message: memberSetting ?? memberSettingEmpty)
                success(memberSetting ?? memberSettingEmpty)
            },
            failure: failure
        )
    }
    
    class func updateMemberSetting(
        memberSetting: MemberSetting,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/member-setting/update"
        let parameters = memberSetting.toParameters()
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "updateMemberSettingRes", message: res ?? "")
                if res?.success == true {
                    let data = response["data"] as? [String: Any] ?? ["id": 0]
                    let memberSetting = try? JSONDecoder().decode(MemberSetting.self, from: data)
                    if memberSetting != nil {
                        LocalDataManager.unit = memberSetting?.unit
                    }
                    let memberSettingEmpty = MemberSetting()
                    Functions.showLog(title: "memberSettingRes", message: memberSetting ?? memberSettingEmpty)
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func updateNotificationSetting(
        pushNotice: Int,
        mailNotice: Int,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/member-setting/update"
        let parameters = [
            "pushNotice": pushNotice,
            "mailNotice": mailNotice
        ]
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "updateNotificationSettingRes", message: res ?? "")
                if res?.success == true {
                    let data = response["data"] as? [String: Any] ?? ["id": 0]
                    let memberSetting = try? JSONDecoder().decode(MemberSetting.self, from: data)
                    if memberSetting != nil {
                        LocalDataManager.unit = memberSetting?.unit
                        LocalDataManager.language = memberSetting?.language
                    }
                    let memberSettingEmpty = MemberSetting()
                    Functions.showLog(title: "memberSettingRes", message: memberSetting ?? memberSettingEmpty)
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func updateProfile(
        profile: UserInfo,
        success: @escaping (_ resLogin: ResModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user-profile/update"
        let parameters = profile.toParameters()
        Functions.showLog(title: "updateProfileParams", message: parameters)
        APIClient.request(
            .put, url: url, params: parameters,
            success: { response, _ in
                let res = try? JSONDecoder().decode(ResModel.self, from: response)
                Functions.showLog(title: "res_update_profile", message: res ?? "")
                if res?.success == true {
                    let user = response["data"] as? [String: Any] ?? ["id": "0"]
                    let profile = try? JSONDecoder().decode(UserInfo.self, from: user)
                    Functions.showLog(title: "res_update_profile_data", message: profile ?? "")
                    LocalDataManager.profile = profile
                }
                success(res ?? ResModel())
            },
            failure: failure
        )
    }
    
    class func getNoticeList(
        page: Int,
        success: @escaping (_ user: NoticeParentModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/admin/notice/get-all"
        let parameters = [ "page": page, "limit": Constants.PAGE_LIMIT ]
        APIClient.request(
            .get, url: url, params: parameters,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let noticeParent = try? JSONDecoder().decode(NoticeParentModel.self, from: data)
                let noticeParentEmpty = NoticeParentModel()
                Functions.showLog(title: "getNoticeListRes", message: noticeParent ?? noticeParentEmpty)
                success(noticeParent ?? noticeParentEmpty)
            },
            failure: failure
        )
    }
    
    class func getAchievements(
        success: @escaping (_ goal: GoalModel) -> Void,
        failure: @escaping (_ error: Error) -> Void
    ) {
        let url = "/api/private/user/achievement/get-all"

        APIClient.request(
            .get, url: url,
            success: { response, _ in
                let data = response["data"] as? [String: Any] ?? ["data": "[]"]
                let goal = try? JSONDecoder().decode(GoalModel.self, from: data)
                let goalEmpty = GoalModel()
                Functions.showLog(title: "getAchievements", message: goal ?? goalEmpty)
                success(goal ?? goalEmpty)
            },
            failure: failure
        )
    }
}
