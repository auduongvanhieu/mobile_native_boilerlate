//
//  OnboardingRoutes.swift
//  REPACE
//
//  Created by Mauricio Cousillas on 6/13/19.
//  Copyright © 2019 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

enum AuthRoutes: Route {
    case splash
    case welcome
    case signIn
    case signUp
    case signUpCheck(id: String, socialType: String, email: String)
    case enterNickname(email: String, password: String)
    case additionalInfo(email: String, password: String, nickname: String)
    case tutorial
    case pairing(goToHome: Bool = false)
    case notificationAccess
    case forgetPassword
    
    var screen: UIViewController {
        switch self {
        case .splash:
            return builSplashViewController()
        case .welcome:
            return builWelcomeViewController()
        case .signIn:
            return buildSignInViewController()
        case .signUp:
            return buildSignUpViewController()
        case .signUpCheck(let id, let socialType, let email):
            return buildSignUpCheckViewController(id: id, socialType: socialType, email: email)
        case .enterNickname(let email, let password):
            return buildEnterNicknameViewController(email: email, password: password)
        case .additionalInfo(let email, let password, let nickname):
            return buildAdditionalInfoViewController(email: email, password: password, nickname: nickname)
        case .tutorial:
            return buildTutorialInfoViewController()
        case .pairing(let goToHome):
            return buildPairingViewController(goToHome)
        case .notificationAccess:
            return buildNoticayionAccessViewController()
        case .forgetPassword:
            return buildForgetPasswordViewController()
        }
    }
    
    private func builWelcomeViewController() -> UIViewController {
        guard let welcome = R.storyboard.auth.welcomeViewController() else {
            return UIViewController()
        }
        return welcome
    }
    
    private func builSplashViewController() -> UIViewController {
        guard let splash = R.storyboard.auth.splashViewController() else {
            return UIViewController()
        }
        return splash
    }
    
    private func buildSignInViewController() -> UIViewController {
        guard let signIn = R.storyboard.auth.signInViewController() else {
            return UIViewController()
        }
        signIn.viewModel = SignInViewModel()
        return signIn
    }
    
    private func buildSignUpViewController() -> UIViewController {
        guard let signUp = R.storyboard.auth.signUpViewController() else {
            return UIViewController()
        }
        signUp.viewModel = SignUpViewModel()
        return signUp
    }
    
    private func buildSignUpCheckViewController(id: String, socialType: String, email: String) -> UIViewController {
        guard let page = R.storyboard.auth.signUpCheckViewController() else {
            return UIViewController()
        }
        page.viewModel = SignUpCheckViewModel()
        page.id = id
        page.socialType = socialType
        page.email = email
        return page
    }
    
    private func buildEnterNicknameViewController(email: String, password: String) -> UIViewController {
        guard let enterNickname = R.storyboard.auth.enterNicknameViewController() else {
            return UIViewController()
        }
        enterNickname.viewModel = EnterNicknameViewModel()
        enterNickname.viewModel.email = email
        enterNickname.viewModel.password = password
        return enterNickname
    }
    
    private func buildAdditionalInfoViewController(email: String, password: String, nickname: String) -> UIViewController {
        guard let page = R.storyboard.auth.additionalInfoViewController() else {
            return UIViewController()
        }
        let viewModel = AdditionalInfoViewModel()
        viewModel.email = email
        viewModel.password = password
        viewModel.nickname = nickname
        page.viewModel = viewModel
        return page
    }
    
    private func buildTutorialInfoViewController() -> UIViewController {
        guard let page = R.storyboard.auth.tutorialViewController() else {
            return UIViewController()
        }
        return page
    }
    
    private func buildPairingViewController(_ goToHome: Bool) -> UIViewController {
        guard let page = R.storyboard.auth.pairingViewController() else {
            return UIViewController()
        }
        page.viewModel = PairingViewModel()
        page.goToHome = goToHome
        return page
    }
    
    private func buildNoticayionAccessViewController() -> UIViewController {
        guard let page = R.storyboard.auth.noticationAccessViewController() else {
            return UIViewController()
        }
        page.viewModel = NotificationAccessViewModel()
        return page
    }
    
    private func buildForgetPasswordViewController() -> UIViewController {
        guard let page = R.storyboard.auth.forgetPasswordViewController() else {
            return UIViewController()
        }
        page.viewModel = ForgetPasswordViewModel()
        return page
    }
}
