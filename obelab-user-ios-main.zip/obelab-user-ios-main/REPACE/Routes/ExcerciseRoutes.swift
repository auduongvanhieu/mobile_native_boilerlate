import Foundation
import UIKit

enum ExcerciseRoutes: Route {
    case rxExcerciseCalendar
    case rxExcerciseSelectType
    case rxExcercisePre(isLowIntensity: Bool)
    case rxExcerciseRest
    case rxExcercisePrepare(isLowIntensity: Bool)
    case rxExcerciseProgress(isLowIntensity: Bool)
    case excerciseLowMore
    case excerciseHighMore
    case exerciseCompleted(title: String)
    case exerciseResult(model: ExerciseResultModel, fromHistory: Bool)
    case freeExcercisePrepare
    case freeExcerciseInputDistance
    case freeExcerciseProgress
    case excerciseHistory(type: String?)
    case excerciseStatistic
    case rxExcerciseStatistic
    case freeExcerciseStatistic
    case exerciseStatisticCompleteDetail
    case goals
    case details
    
    var screen: UIViewController {
        switch self {
        case .rxExcerciseCalendar:
            guard let page = R.storyboard.excercise.rxExcerciseCalendarViewController() else {
                return UIViewController()
            }
            return page
        case .rxExcerciseSelectType:
            guard let page = R.storyboard.excercise.rxExcerciseSelectTypeViewController() else {
                return UIViewController()
            }
            return page
        case .rxExcercisePre(let isLowIntensity):
            guard let page = R.storyboard.excercise.rxExercisePreViewController() else {
                return UIViewController()
            }
            page.isLowIntensity = isLowIntensity
            return page
        case .rxExcerciseRest:
            guard let page = R.storyboard.excercise.rxExerciseRestViewController() else {
                return UIViewController()
            }
            return page
        case .freeExcercisePrepare:
            guard let page = R.storyboard.excercise.freeExercisePrepareViewController() else {
                return UIViewController()
            }
            return page
        case .freeExcerciseProgress:
            guard let page = R.storyboard.excercise.freeExcerciseProgressViewController() else {
                return UIViewController()
            }
            return page
        case .freeExcerciseInputDistance:
            guard let page = R.storyboard.excercise.freeExcerciseInputDistanceViewController() else {
                return UIViewController()
            }
            return page
        case .excerciseHistory(let type):
            guard let page = R.storyboard.excercise.excerciseHistoryViewController() else {
                return UIViewController()
            }
            page.viewModel = ExcerciseHistoryViewModel(type: type)
            return page
        case .excerciseStatistic:
            guard let page = R.storyboard.excercise.excerciseStatisticViewController() else {
                return UIViewController()
            }
            return page
        case .rxExcerciseStatistic:
            guard let page = R.storyboard.excercise.rxExcerciseStatisticViewController() else {
                return UIViewController()
            }
            return page
        case .freeExcerciseStatistic:
            guard let page = R.storyboard.excercise.freeExcerciseStatisticViewController() else {
                return UIViewController()
            }
            return page
        case .exerciseStatisticCompleteDetail:
            guard let page = R.storyboard.excercise.statisticCompleteDetailViewController() else {
                return UIViewController()
            }
            return page
        case .goals:
            guard let page = R.storyboard.excercise.goalViewController() else {
                return UIViewController()
            }
            return page
        case .details:
            guard let page = R.storyboard.excercise.statisticDetailViewController() else {
                return UIViewController()
            }
            return page
        case .excerciseLowMore:
            guard let page = R.storyboard.excercise.rxExerciseLowMoreViewController() else {
                return UIViewController()
            }
            return page
        case .excerciseHighMore:
            guard let page = R.storyboard.excercise.rxExerciseHighMoreViewController() else {
                return UIViewController()
            }
            return page
        case .rxExcercisePrepare(let isLowIntensity):
            guard let page = R.storyboard.excercise.rxExercisePrepareViewController() else {
                return UIViewController()
            }
            page.isLowIntensity = isLowIntensity
            return page
        case .rxExcerciseProgress(let isLowIntensity):
            guard let page = R.storyboard.excercise.rxExerciseProgressViewController() else {
                return UIViewController()
            }
            page.isLowIntensity = isLowIntensity
            return page
        case .exerciseCompleted(let title):
            guard let page = R.storyboard.excercise.exerciseCompletedViewController() else {
                return UIViewController()
            }
            page.textTitle = title
            return page
        case .exerciseResult(let model, let fromHistory):
            guard let page = R.storyboard.excercise.rxExcerciseResultViewController() else {
                return UIViewController()
            }
            
            let viewModel = RxExcerciseResultModel()
            viewModel.exerciseResultModel = model
            page.viewModel = viewModel
            page.fromHistory = fromHistory
            return page
        }
        
    }
    
}
