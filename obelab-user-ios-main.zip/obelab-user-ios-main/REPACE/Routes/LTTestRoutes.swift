//
//  LTTestRoutes.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/10/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//
import Foundation
import UIKit

enum LTTestRoutes: Route {
    case test
    case testSum
    case ltTestProgress
    case ltTestHistory
    case ltTestComplete
    case ltTestResult
    case ltTestRXEExercise(isJustFinishLTTest: Bool, protocolValue: Int)
    case ltTestRXEExerciseFromLTTestResult(onset: Double, protocolValue: Int)
    case ltTestRXEExerciseLow(prescription: ExercisePresciptionModel, purpose: Int32)
    case ltTestRXEExercisePolarized(prescription: ExercisePresciptionModel, purpose: Int32, onset: Double?, protocolValue: Int)
    
    var screen: UIViewController {
        switch self {
        case .test:
            guard let page = R.storyboard.ltTest.ltTestViewController() else {
                return UIViewController()
            }
            return page
        case .testSum:
            guard let page = R.storyboard.main.testSummaryOffViewController() else {
                return UIViewController()
            }
            return page
        case .ltTestProgress:
            guard let page = R.storyboard.ltTest.ltTestProgressViewController() else {
                return UIViewController()
            }
            return page
        case .ltTestHistory:
            guard let page = R.storyboard.ltTest.ltTestHistoryViewController() else {
                return UIViewController()
            }
            return page
        case .ltTestComplete:
            guard let page = R.storyboard.ltTest.ltTestCompleteViewController() else {
                return UIViewController()
            }
            return page
        case .ltTestResult:
            guard let page = R.storyboard.ltTest.ltTestResultViewController() else {
                return UIViewController()
            }
            return page
        case .ltTestRXEExercise(let isJustFinishLTTest, let protocolValue):
            guard let page = R.storyboard.ltTest.ltTestRXExerciseViewController() else {
                return UIViewController()
            }
            page.onset = isJustFinishLTTest ? LocalDataManager.ltTestAnalysis.onset : (LocalDataManager.lastLTTestResult.onset?.to1Decimal ?? 0.0)
            page.protocolValue = protocolValue
            return page
        case .ltTestRXEExerciseFromLTTestResult(let onset, let protocolValue):
            guard let page = R.storyboard.ltTest.ltTestRXExerciseViewController() else {
                return UIViewController()
            }
            page.onset = onset
            page.protocolValue = protocolValue
            return page
        case .ltTestRXEExerciseLow(let prescription, let purpose):
            guard let page = R.storyboard.ltTest.ltTestRXExerciseLowViewController() else {
                return UIViewController()
            }
            page.prescription = prescription
            page.purpose = purpose
            return page
        case .ltTestRXEExercisePolarized(let prescription, let purpose, let onset, let protocolValue):
            guard let page = R.storyboard.ltTest.ltTestRXExercisePolarizedViewController() else {
                return UIViewController()
            }
            page.prescription = prescription
            page.purpose = purpose
            page.onset = onset
            page.protocolValue = protocolValue
            return page
        }
    }
}
