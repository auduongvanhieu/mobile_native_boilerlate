import Foundation
import UIKit

enum MainRoutes: Route {
    case main(requestNotificationRight: Bool)
    case home
    case excerciseAmountSetting
    case friends
    case addFriends
    
    var screen: UIViewController {
        switch self {
        case .main(let requestNotificationRight):
            guard let main = R.storyboard.main.mainViewController() else {
                return UIViewController()
            }
            main.isRequestNotificationRight = requestNotificationRight
            main.viewModel = MainViewModel()
            return main
        case .home:
            guard let home = R.storyboard.main.homeViewController() else {
                return UIViewController()
            }
            return home
        case .excerciseAmountSetting:
            guard let page = R.storyboard.main.exerciseAmountSettingViewController() else {
                return UIViewController()
            }
            return page
        case .friends:
            guard let page = R.storyboard.main.friendViewController() else {
                return UIViewController()
            }
            return page
        case .addFriends:
            guard let page = R.storyboard.main.addFriendViewController() else {
                return UIViewController()
            }
            return page
        }
    }
}
