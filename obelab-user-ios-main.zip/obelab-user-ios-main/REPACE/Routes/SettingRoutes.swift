import Foundation
import UIKit

enum SettingRoutes: Route {
    case termOfUse(type: String)
    case preference(memberSetting: MemberSetting?, isDidSignup: Bool, target: UIViewController?)
    case notificationSetting
    case profileSetting
    case narrationGuide
    case notices
    case noticeDetail(noticeModel: NoticeModel)
    case help
    case helpDetail(faq: FaqModel)
    
    var screen: UIViewController {
        switch self {
        case .termOfUse(let type):
            guard let page = R.storyboard.setting.termOfUseViewController() else {
                return UIViewController()
            }
            page.viewModel = TermOfUseViewModel()
            page.type = type
            return page
        case .preference(let memberSetting, let isDidSignup, let target):
            guard let page = R.storyboard.setting.preferenceViewController() else {
                return UIViewController()
            }
            let viewModel = PreferenceViewModel()
            viewModel.memberSetting = memberSetting ?? MemberSetting()
            viewModel.isDidSignup = isDidSignup
            page.viewModel = viewModel
            if let target = target {
                page.delegate = target as? PreferenceViewControllerDelegate
            }
            return page
        case .notificationSetting:
            guard let page = R.storyboard.setting.notificationSettingViewController() else {
                return UIViewController()
            }
            page.viewModel = NotificationSettingViewModel()
            return page
        case .profileSetting:
            guard let page = R.storyboard.setting.profileSettingViewController() else {
                return UIViewController()
            }
            page.viewModel = ProfileSettingViewModel()
            return page
        case .narrationGuide:
            guard let page = R.storyboard.setting.narrationGuideViewController() else {
                return UIViewController()
            }
            page.viewModel = NarrationGuideViewModel()
            return page
        case .notices:
            guard let page = R.storyboard.setting.noticesViewController() else {
                return UIViewController()
            }
            page.viewModel = NoticesViewModel()
            return page
        case .noticeDetail(let noticeModel):
            guard let page = R.storyboard.setting.noticeDetailViewController() else {
                return UIViewController()
            }
            page.noticeModel = noticeModel
            return page
        case .help:
            guard let page = R.storyboard.setting.helpViewController() else {
                return UIViewController()
            }
            page.viewModel = HelpViewModel()
            return page
        case .helpDetail(let faq):
            guard let page = R.storyboard.setting.helpDetailViewController() else {
                return UIViewController()
            }
            page.faqModel = faq
            return page
        }
    }
}
