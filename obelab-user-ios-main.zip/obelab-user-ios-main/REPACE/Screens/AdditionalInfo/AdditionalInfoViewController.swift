import Foundation
import UIKit
import SkyFloatingLabelTextField
import ActionSheetPicker_3_0

class AdditionalInfoViewController: BaseViewController, ChooseHeightWeightDialogDelegate, ChooseGenderDialogDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var setPreferceView: UIView!
    @IBOutlet weak var birthdateView: UIView!
    @IBOutlet weak var birthdateField: SkyFloatingLabelTextField!
    @IBOutlet weak var genderView: UIView!
    @IBOutlet weak var genderField: SkyFloatingLabelTextField!
    @IBOutlet weak var heightView: UIView!
    @IBOutlet weak var heightField: SkyFloatingLabelTextField!
    @IBOutlet weak var weightView: UIView!
    @IBOutlet weak var weightField: SkyFloatingLabelTextField!
    
    @IBOutlet weak var topWeight: NSLayoutConstraint!
    @IBOutlet weak var topHeight: NSLayoutConstraint!
    @IBOutlet weak var topGender: NSLayoutConstraint!
    @IBOutlet weak var topBirthday: NSLayoutConstraint!
    
    @IBOutlet weak var bottomWeight: NSLayoutConstraint!
    @IBOutlet weak var bottomHeight: NSLayoutConstraint!
    @IBOutlet weak var bottomGender: NSLayoutConstraint!
    @IBOutlet weak var bottomBirthday: NSLayoutConstraint!
    
    let constraintBottomSelected: CGFloat = 6
    let constraintBottom: CGFloat = 13
    let constantsTop: CGFloat = 7
    var viewModel: AdditionalInfoViewModel!
    var datePicker: UIDatePicker!
    var dialogType = Constants.UNIT_TYPE_HEIGHT
    let genderNameList = ["male".localized, "female".localized, "other".localized]
    let genderList = [Constants.GENDER_MALE, Constants.GENDER_FEMALE, Constants.GENDER_OTHER]
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        viewModel.getHeightWeight()
    }
    
    func setUpView() {
        // Button Next
        btnNext.setRoundBorders(UI.Button.cornerRadius)
        setNextButton(enabled: false)
        // Button Preferce
        setPreferceView.layer.cornerRadius = UI.Button.cornerRadius
        // Birthdate Field
        birthdateView.layer.cornerRadius = UI.Button.cornerRadius
        birthdateField.lineColor = UIColor.white.withAlphaComponent(0.0)
        birthdateField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        birthdateField.selectedTitleColor = UI.Color.btnBgColor
        birthdateField.titleColor = UI.Color.txtFloatTitleColor
        birthdateField.textColor = UIColor.white
        birthdateField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        // Gender Field
        genderView.layer.cornerRadius = UI.Button.cornerRadius
        genderField.lineColor = UIColor.white.withAlphaComponent(0.0)
        genderField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        genderField.selectedTitleColor = UI.Color.btnBgColor
        genderField.titleColor = UI.Color.txtFloatTitleColor
        genderField.textColor = UIColor.white
        genderField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        // Height Field
        heightView.layer.cornerRadius = UI.Button.cornerRadius
        heightField.lineColor = UIColor.white.withAlphaComponent(0.0)
        heightField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        heightField.selectedTitleColor = UI.Color.btnBgColor
        heightField.titleColor = UI.Color.txtFloatTitleColor
        heightField.textColor = UIColor.white
        heightField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        // Weight Field
        weightView.layer.cornerRadius = UI.Button.cornerRadius
        weightField.lineColor = UIColor.white.withAlphaComponent(0.0)
        weightField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        weightField.selectedTitleColor = UI.Color.btnBgColor
        weightField.titleColor = UI.Color.txtFloatTitleColor
        weightField.textColor = UIColor.white
        weightField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        
        bottomWeight.constant = self.constraintBottom
        bottomHeight.constant = self.constraintBottom
        bottomGender.constant = self.constraintBottom
        bottomBirthday.constant = self.constraintBottom
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let page = R.storyboard.auth.additionalInfoViewController() else {
            return UIViewController()
        }
        page.viewModel = self.viewModel
        return page
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let viewModel = viewModel {
            if viewModel.birthdate.isEmpty == false {
                self.birthdateField.text = Functions.convertDateStrToProfileDateStr(dateStr: viewModel.birthdate)
            }
            if viewModel.height > 0 {
                var height = Functions.getImperialHeightValue(cm: viewModel.height)
                let unit = LocalDataManager.unit
                if unit == Constants.UNIT_METRIC {
                    height = "\(Functions.getHeightUnitValue(height: viewModel.height)) \(Functions.getHeightUnitName())"
                }
                heightField.text = "\(height)"
            }
            if viewModel.weight > 0 {
                weightField.text = "\(Functions.getWeightUnitValue(weight: viewModel.weight)) \(Functions.getWeightUnitName())"
            }
            self.topBirthday.constant = viewModel.birthdate.isEmpty ? 0 : constantsTop
            self.topHeight.constant = viewModel.height == 0 ? 0 : constantsTop
            self.topWeight.constant = viewModel.weight == 0 ? 0 : constantsTop
            if let ind = genderList.firstIndex(where: {$0 == viewModel.gender}) {
                self.topGender.constant = constantsTop
                genderField.text = genderNameList[ind]
            } else {
                self.topGender.constant = 0
                genderField.text = nil
            }
            checkValid()
        }
    }
    
    // MARK: - Actions
    func checkValid() {
        if viewModel.hasValidForm {
            setNextButton(enabled: true)
        } else {
            setNextButton(enabled: false)
        }
    }
    
    func setNextButton(enabled: Bool) {
        btnNext.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnNext.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnNext.setTitleColor(titleColor, for: .normal)
    }
    
    @IBAction func onClickBỉthdate(_ sender: Any) {
        showDatePicker()
    }
    
    @IBAction func onClickGender(_ sender: Any) {
        showGenderPicker()
    }
    
    @IBAction func onClickHeight(_ sender: Any) {
        showHeightPicker()
    }
    
    @IBAction func onClickWeight(_ sender: Any) {
        showWeightPicker()
    }
    
    @IBAction func onClickSetPreference(_ sender: Any) {
        let memberSetting = viewModel.memberSetting ?? MemberSetting()
        let preferenceRoute = SettingRoutes.preference(memberSetting: memberSetting, isDidSignup: false, target: self)
        AppNavigator.shared.navigate(to: preferenceRoute, with: .push)
    }
    
    @IBAction func onClickNext(_ sender: Any) {
        viewModel.registerUserInfo(isSkip: false)
//        viewModel.updateAdditionalInfo()
    }
    
    @IBAction func onClickSkip(_ sender: Any) {
        viewModel.registerUserInfo(isSkip: true)
//        AppNavigator.shared.navigate(to: AuthRoutes.tutorial, with: .push)
    }
    
    func showDatePicker() {
        let selectedDate = self.viewModel.birthdate.isEmpty == false ? Functions.convertDateStrToDate(dateStr: self.viewModel.birthdate) : Functions.convertDateStrToDate(dateStr: Constants.DATE_DEFAULT)
        let datePicker = ActionSheetDatePicker(title: "",
                                               datePickerMode: UIDatePicker.Mode.date,
                                               selectedDate: selectedDate,
                                               doneBlock: { _, date, _ in
                                                if let date = date as? Date {
                                                    var components = DateComponents()
                                                    components.day = 1
                                                    let dateSelected = Calendar.current.date(byAdding: components, to: date)
                                                    self.viewModel.birthdate = Functions.convertOptionalDateStrToDateStr(optionalDateStr: dateSelected.debugDescription)
                                                    self.birthdateField.text = Functions.convertDateStrToProfileDateStr(dateStr: self.viewModel.birthdate)
                                                    self.topBirthday.constant = self.constantsTop
                                                    self.bottomBirthday.constant = self.constraintBottomSelected
                                                }
                                               },
                                               cancel: { _ in
                                                Functions.showLog(title: "", message: "Press cancel date picker")
                                               },
                                               origin: self.view.superview)
        var components = DateComponents()
        components.day = 0
        let maxDate = Calendar.current.date(byAdding: components, to: Date())
        datePicker?.maximumDate = maxDate ?? Date()
//        let localIdentifier = LocalDataManager.language == Constants.LANGUAGE_EN ? "en-au" : "ko"
        datePicker?.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        datePicker?.show()
    }
    
    func showGenderPicker() {
        var selectedIndex = 0
        if let selected = genderList.firstIndex(where: {$0 == viewModel.gender}) {
            selectedIndex = selected
        }
        ChooseGenderDialogViewController.showPopup(parentVC: self, selectedIndex: selectedIndex)
    }
    
    func showHeightPicker() {
        dialogType = Constants.UNIT_TYPE_HEIGHT
        let dataList = viewModel.heightList
//        let dataList = Functions.getHeightUnitName() == UnitConstants.CM ? viewModel.heightList : viewModel.heightInList
        var height = viewModel.height
        if height == 0.0 {
            height = Constants.HEIGHT_DEFAULT
        }
        ChooseHeightWeightDialogViewController.showPopupInUnit(parentVC: self, dataList: dataList, currentValue: height, unitType: Constants.UNIT_TYPE_HEIGHT)
    }
    
    func showWeightPicker() {
        dialogType = Constants.UNIT_TYPE_WEIGHT
        var weight = viewModel.weight
        if weight == 0.0 {
            weight = Constants.WEIGHT_DEFAULT
        }
        ChooseHeightWeightDialogViewController.showPopupInUnit(parentVC: self, dataList: viewModel.weightList, currentValue: weight, unitType: Constants.UNIT_TYPE_WEIGHT)
    }
    
    func onChooseHeightWeight(selectedIndex: Int, selectedValue: Double) {
        Functions.showLog(title: "onChooseHeightWeight", message: selectedIndex)
        if dialogType == Constants.UNIT_TYPE_HEIGHT {
            topHeight.constant = constantsTop
            self.bottomHeight.constant = self.constraintBottomSelected
            viewModel.height = selectedValue
            var height = Functions.getImperialHeightValue(cm: viewModel.height)
            let unit = LocalDataManager.unit
            if unit == Constants.UNIT_METRIC {
                height = "\(Functions.getHeightUnitValue(height: viewModel.height)) \(Functions.getHeightUnitName())"
            }
            let text = "\(height)"
            setAttributedTextWeightAndHeight(text: text, isWeight: false)
        } else {
            topWeight.constant = constantsTop
            self.bottomWeight.constant = self.constraintBottomSelected
            viewModel.weight = selectedValue
            let text = "\(Functions.getWeightUnitValue(weight: viewModel.weight)) \(Functions.getWeightUnitName())"
            setAttributedTextWeightAndHeight(text: text, isWeight: true)
        }
        checkValid()
    }
    
    func onChooseGender(selectedIndex: Int, selectedValue: String) {
        Functions.showLog(title: "onChooseGender", message: selectedIndex)
        viewModel.gender = genderList[selectedIndex]
        genderField.text = selectedValue
        topGender.constant = constantsTop
        self.bottomGender.constant = self.constraintBottomSelected
    }
    
    private func setAttributedTextWeightAndHeight(text: String, isWeight: Bool) {
        let mutableAttrString = NSMutableAttributedString(string: text)
        let font14 = UIFont(name: AppFontName.medium, size: 14.0) ?? UIFont.systemFont(ofSize: 14)
        let myAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: font14]
        let allRange = NSRange(location: 0, length: text.count)
        mutableAttrString.addAttributes(myAttributes, range: allRange)
        let font11 = UIFont(name: AppFontName.medium, size: 11.0) ?? UIFont.systemFont(ofSize: 11)
        let unitRange = NSRange(location: text.count - 3, length: 3)
        mutableAttrString.addAttribute(NSAttributedString.Key.font, value: font11, range: unitRange)
        if isWeight {
            self.weightField.text = " "
            self.weightField.attributedText = mutableAttrString
        } else {
            self.heightField.text = " "
            self.heightField.attributedText = mutableAttrString
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Functions.showLog(title: "LocalDataManager.unit", message: LocalDataManager.unit as Any)
        if viewModel.height != 0.0 {
            self.heightField.text = "\(Functions.getHeightUnitValue(height: viewModel.height)) \(Functions.getHeightUnitName())"
        }
        if viewModel.weight != 0.0 {
            self.weightField.text = "\(Functions.getWeightUnitValue(weight: viewModel.weight)) \(Functions.getWeightUnitName())"
        }
    }
}

extension AdditionalInfoViewController: AdditionalInfoViewModelDelegate {
    func didUpdateState(to state: AdditionalInfoViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .updateNicknameSuccess:
            AppNavigator.shared.navigate(to: AuthRoutes.notificationAccess, with: .push)
//            AppNavigator.shared.navigate(to: AuthRoutes.tutorial, with: .push)
        case .updateNicknameFail(let msg):
            showToast(message: msg)
        }
    }
}

extension AdditionalInfoViewController: PreferenceViewControllerDelegate {
    func didChangeSetting(preferenceViewModel: PreferenceViewModel) {
        viewModel.memberSetting = preferenceViewModel.memberSetting
    }
}
