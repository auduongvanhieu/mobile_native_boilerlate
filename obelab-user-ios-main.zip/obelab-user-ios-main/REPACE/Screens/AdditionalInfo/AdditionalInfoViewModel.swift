import Foundation

protocol AdditionalInfoViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: AdditionalInfoViewModelState)
}

enum AdditionalInfoViewModelState {
    case updateNicknameSuccess
    case updateNicknameFail(message: String)
    case network(state: NetworkState)
}

class AdditionalInfoViewModel {
    
    private var state: AdditionalInfoViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: AdditionalInfoViewModelDelegate?
    
    var birthdate = ""
    var gender = ""
    var height = 0.0
    var weight = 0.0
    var email = ""
    var password = ""
    var nickname = ""
    var heightList: [Double] = []
    var heightInList: [Double] = []
    var weightList: [Double] = []
    var memberSetting: MemberSetting?
    
    var hasValidForm: Bool {
        birthdate.isEmpty == false && gender.isEmpty == false && height != 0.0 && weight != 0.0
    }
    
    func registerUserInfo(isSkip: Bool = false) {
        if password.isEmpty {
            // Update
            updateAdditionalInfo(isSkip: isSkip)
        } else {
            // Sign up
            registerUserInfoEmail(isSkip: isSkip)
        }
    }
    
    func registerUserInfoEmail(isSkip: Bool = false) {
        var param: [String: Any] = [:]
        if isSkip == false {
            param = ["birthday": birthdate, "gender": gender, "height": height, "weight": weight]
        }
        param["nickname"] = nickname
        param["os"] = Constants.iOS
        param["fcmToken"] = Constants.FCM_TOKEN
        if email.isEmpty == false {
            param["email"] = email
        }
        if password.isEmpty == false {
            param["password"] = password
        }
        state = .network(state: .loading)
        UserServices.registerUser(parameters: param, success: { [weak self] res in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            if res.success == true {
                if let memberSetting = self.memberSetting {
                    self.updateMemberSetting(memberSetting: memberSetting)
                } else {
                    self.state = .updateNicknameSuccess
                }
            } else {
                self.state = .updateNicknameFail(message: res.msg ?? "")
            }
        },
        failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
    
    func updateAdditionalInfo(isSkip: Bool) {
        var param: [String: Any] = [:]
        if isSkip == false {
            param = ["birthday": birthdate, "gender": gender, "height": height, "weight": weight]
        }
        param["nickname"] = nickname
        param["os"] = Constants.iOS
        param["fcmToken"] = Constants.FCM_TOKEN
        state = .network(state: .loading)
        UserServices.updateAdditionalInfo(parameters: param, success: { [weak self] res in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            if res.success == true {
                if let memberSetting = self.memberSetting {
                    self.updateMemberSetting(memberSetting: memberSetting)
                } else {
                    self.state = .updateNicknameSuccess
                }
            } else {
                self.state = .updateNicknameFail(message: res.msg ?? "")
            }
        },
        failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
    
    func getHeightWeight() {
        state = .network(state: .loading)
        GeneralServices.getHeightWeight( success: { [weak self] (heightList, weightList) in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            self.heightList = heightList
            self.weightList = weightList
//            var heightOld = 0.0
//            self.heightList.forEach { (item) in
//                if Functions.cmToIn(cm: item) != heightOld {
//                    self.heightInList.append(item)
//                    heightOld = Functions.cmToIn(cm: item)
//                }
//            }
//            for (_, item) in self.heightList.enumerated() {
//                if Functions.cmToIn(cm: item) != heightOld {
//                    self.heightInList.append(item)
//                    heightOld = Functions.cmToIn(cm: item)
//                }
//            }
        },
        failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
    
    func updateMemberSetting(memberSetting: MemberSetting) {
        state = .network(state: .loading)
        UserServices.updateMemberSetting(memberSetting: memberSetting,
                                         success: { [weak self] res in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            if res.success == true {
                self.state = .updateNicknameSuccess
            } else {
                self.state = .updateNicknameFail(message: res.msg ?? "")
            }
        },
                                         failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
}
