import UIKit
import SkyFloatingLabelTextField

class EnterNicknameViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var btnCheck: UIButton!
    @IBOutlet weak var nicknameView: UIView!
    @IBOutlet weak var nicknameField: SkyFloatingLabelTextField!
    
    @IBOutlet weak var topNicknameField: NSLayoutConstraint!
    @IBOutlet weak var bottomNicknameField: NSLayoutConstraint!
    
    var viewModel: EnterNicknameViewModel!
    var isNicknameAvailable = false
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        nicknameField.delegate = self
        setUpView()
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let enterNickname = R.storyboard.auth.enterNicknameViewController() else {
            return UIViewController()
        }
        enterNickname.viewModel = self.viewModel
        return enterNickname
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        nicknameField.text = self.viewModel.nickname
        adjustContraintsOfTextField(self.viewModel.nickname, top: topNicknameField, bottom: bottomNicknameField)
    }
    
    func setUpView() {
        // Button
        btnCheck.setRoundBorders(UI.Button.cornerRadius)
        setCheckButton(enabled: false)
        // Input Field
        nicknameView.layer.cornerRadius = UI.Button.cornerRadius
        nicknameField.lineColor = UIColor.white.withAlphaComponent(0.0)
        nicknameField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        nicknameField.selectedTitleColor = UI.Color.btnBgColor
        nicknameField.titleColor = UI.Color.txtFloatTitleColor
        nicknameField.textColor = UIColor.white
        nicknameField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
    }
    
    private func nicknameExisted(isError: Bool) {
        nicknameView.layer.borderWidth = isError ? 1 : 0
        nicknameView.layer.borderColor = isError ? UI.Color.txtErrorColor.cgColor : UIColor.clear.cgColor
        nicknameField.selectedTitleColor = isError ? UI.Color.txtErrorColor : UI.Color.btnBgColor
        nicknameField.titleColor = isError ? UI.Color.txtErrorColor : UI.Color.txtFloatTitleColor
    }
    
    // MARK: - Actions
    @IBAction func formEditingChange(_ sender: UITextField) {
        let newValue = sender.text ?? ""
        isNicknameAvailable = false
        switch sender {
        case nicknameField:
            viewModel.nickname = newValue
        default: break
        }
        setCheckButton(enabled: viewModel.hasValidNickname)
        btnCheck.setTitle("check".localized, for: .normal)
    }
    
    func setCheckButton(enabled: Bool) {
        btnCheck.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnCheck.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnCheck.setTitleColor(titleColor, for: .normal)
    }
    
    private func adjustContraintsOfTextField(_ updatedText: String, top: NSLayoutConstraint, bottom: NSLayoutConstraint) {
        top.constant = updatedText.isEmpty ? -2 : 2
        bottom.constant = updatedText.isEmpty ? 12 : 0
    }
    
    @IBAction func onClickCheck(_ sender: Any) {
        if isNicknameAvailable {
            AppNavigator.shared.navigate(to: AuthRoutes.additionalInfo(email: viewModel.email, password: viewModel.password, nickname: viewModel.nickname), with: .push)
        } else {
            viewModel.checkNickName()
//            viewModel.updateNickname()
        }
    }
}

extension EnterNicknameViewController: EnterNicknameViewModelDelegate {
    func didUpdateState(to state: EnterNicknameViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .updateNicknameSuccess:
            nicknameExisted(isError: false)
            isNicknameAvailable = true
            showToast(message: "available_nickname".localized)
            btnCheck.setTitle("next".localized, for: .normal)
        case .updateNicknameFail(let msg):
            showToast(message: msg)
            setCheckButton(enabled: false)
            nicknameExisted(isError: true)
        }
    }
}

extension EnterNicknameViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: false)
    }
    
    private func textFieldEditing(_ textField: UITextField, isBegin: Bool) {
        var isEmpty = false
        if isBegin == false {
            isEmpty = (textField.text ?? "").isEmpty
        }
        let text = isEmpty ? "" : " "
        adjustContraintsOfTextField(text, top: topNicknameField, bottom: bottomNicknameField)
    }
}
