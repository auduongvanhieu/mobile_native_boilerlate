import Foundation

protocol EnterNicknameViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: EnterNicknameViewModelState)
}

enum EnterNicknameViewModelState {
    case updateNicknameSuccess
    case updateNicknameFail(message: String)
    case network(state: NetworkState)
}

class EnterNicknameViewModel {
    
    private var state: EnterNicknameViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: EnterNicknameViewModelDelegate?
    
    var nickname = ""
    var email = ""
    var password = ""
    
    var hasValidNickname: Bool {
        nickname.isNicknameFormatted()
    }
    
    func checkNickName() {
        state = .network(state: .loading)
        UserServices.checkNickname(nickname: nickname,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .updateNicknameSuccess
                } else {
                    self.state = .updateNicknameFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func updateNickname() {
        state = .network(state: .loading)
        UserServices.updateNickname(nickname: nickname,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .updateNicknameSuccess
                } else {
                    self.state = .updateNicknameFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
