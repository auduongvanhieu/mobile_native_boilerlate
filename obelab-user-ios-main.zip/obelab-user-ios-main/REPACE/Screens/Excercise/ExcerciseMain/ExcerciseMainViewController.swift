import Foundation
import UIKit

class ExcerciseMainViewController: BaseViewController {
    @IBOutlet weak var rxTreadmillButton: UIButton!
    @IBOutlet weak var rxOutdoorButton: UIButton!
    @IBOutlet weak var freeTreadmillButton: UIButton!
    @IBOutlet weak var freeOutdoorButton: UIButton!
    @IBOutlet weak var freeCyclingButton: UIButton!
    @IBOutlet weak var freeClimbingButton: UIButton!
    @IBOutlet weak var rxHistoryButton: UIButton!
    @IBOutlet weak var freeHistoryButton: UIButton!
    @IBOutlet weak var rxHaveDataView: UIView!
    @IBOutlet weak var rxEmptyView: UIView!
    
    @IBOutlet weak var navigationMyItem: UINavigationItem!
    var viewModel = ExcerciseMainViewModel()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self

        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.navigationBar.barTintColor = .white
        setUpView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if BluetoothHelper.isDisableViewDidAppear == false {
            viewModel.loadAllData()
        }
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        if let controller = R.storyboard.excercise.excerciseMainViewController() {
            return controller
        }
        return UIViewController()
    }
    
    func setUpView() {
//        navigationMyItem.title = nil
        setRxNoData()
        bindDataHistoryStateButton()
        // Setup button
        rxHistoryButton.addTarget(self, action: #selector(onClickHistory), for: .touchUpInside)
        freeHistoryButton.addTarget(self, action: #selector(onClickHistoryFreeExcercise), for: .touchUpInside)
    }
    
    func setRxHaveData() {
        rxHaveDataView.isHidden = false
        rxEmptyView.isHidden = true
    }
    
    func setRxNoData() {
        rxHaveDataView.isHidden = true
        rxEmptyView.isHidden = false
    }
    
    func bindDataHistoryStateButton() {
        let isActiveRxExercise = viewModel.historyStatus?.rxEnable ?? false
        setActiveHistoryFreeExercise(isActive: isActiveRxExercise, isRxExercise: true)
        let isActiveFreeExercise = viewModel.historyStatus?.freeEnable ?? false
        setActiveHistoryFreeExercise(isActive: isActiveFreeExercise, isRxExercise: false)
    }
    
    func setActiveHistoryFreeExercise(isActive: Bool, isRxExercise: Bool) {
        let icon = isActive ? UI.Icon.ic_history : UI.Icon.ic_history_disable
        if isRxExercise {
            rxHistoryButton.setImage(icon, for: .normal)
            rxHistoryButton.isEnabled = isActive
        } else {
            freeHistoryButton.setImage(icon, for: .normal)
            freeHistoryButton.isEnabled = isActive
        }
    }
    
    @objc func onClickHistory(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseHistory(type: "rx_exercise"), with: .push)
    }
    
    @objc func onClickHistoryFreeExcercise(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseHistory(type: "free_exercise"), with: .push)
    }
    
    @IBAction func onClickRxTreadmill(_ sender: Any) {
        BluetoothHelper.resetExerciseData()
        LocalDataManager.exerciseType = ExerciseConstants.RX_EXERCISE_TREADMILL
        LocalDataManager.exerciseResult.typeID = ExerciseConstants.RX_EXERCISE
        LocalDataManager.exerciseResult.activityID = ExerciseConstants.EX_TREADMILL
        if BluetoothHelper.isConnectedDevice == true || Constants.IS_DEV == true {
            if viewModel.validateModel?.success == false && viewModel.validateModel?.type == 2 {
                let protocolValue = LocalDataManager.ltTestProtocol.protocolValue
                AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExercise(isJustFinishLTTest: false, protocolValue: protocolValue), with: .push)
            } else {
                AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseCalendar, with: .push)
            }
        } else {
            showDisconnectedDeviceAlert()
        }
    }
    
    @IBAction func onClickRxOutdoor(_ sender: Any) {
       BluetoothHelper.resetExerciseData()
        LocalDataManager.exerciseType = ExerciseConstants.RX_EXERCISE_OUTDOOR
        LocalDataManager.exerciseResult.typeID = ExerciseConstants.RX_EXERCISE
        LocalDataManager.exerciseResult.activityID = ExerciseConstants.EX_OUTDOOR
        if BluetoothHelper.isConnectedDevice == true || Constants.IS_DEV == true {
            if LocalDataManager.ltTestPrescription.type != 0 {
                AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseCalendar, with: .push)
            } else {
                let protocolValue = LocalDataManager.ltTestProtocol.protocolValue
                AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExercise(isJustFinishLTTest: false, protocolValue: protocolValue), with: .push)
            }
        } else {
            showDisconnectedDeviceAlert()
        }
    }
    
    @IBAction func onClickFreeTreadmillRunning(_ sender: Any) {
        if BluetoothHelper.isConnectedDevice == true || Constants.IS_DEV == true {
            if LocalDataManager.batteryLevel ?? 0 < Constants.BATTERY_LEVEL_WARNING {
                showMessage(title: "", message: "Not enough battery.\nPlease recharge to start.".localized)
//                let alert = UIAlertController(title: "", message: "Not enough battery.\nPlease recharge to start.".localized, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//                }))
//                self.present(alert, animated: true, completion: nil)
            } else {
                BluetoothHelper.resetExerciseData()
                //        LocalDataManager.freeExercisTotalDistanceInput = 0
                LocalDataManager.exerciseType = ExerciseConstants.FREE_EXERCISE_TREADMILL
                LocalDataManager.exerciseResult.typeID = ExerciseConstants.FREE_EXERCISE
                LocalDataManager.exerciseResult.activityID = ExerciseConstants.EX_TREADMILL
                AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcercisePrepare, with: .push)
            }
        } else {
            showDisconnectedDeviceAlert()
        }
        
    }
    
    @IBAction func onClickFreeTreadmillOutdoor(_ sender: Any) {
        if Constants.IS_DISABLE_OUTDOOR_EXERCISE == true {
            showMessage(title: "", message: "Outdoor update coming soon!".localized, handler: nil)
        } else {
            BluetoothHelper.resetExerciseData()
            LocalDataManager.exerciseType = ExerciseConstants.FREE_EXERCISE_OUTDOOR
            LocalDataManager.exerciseResult.typeID = ExerciseConstants.FREE_EXERCISE
            LocalDataManager.exerciseResult.activityID = ExerciseConstants.EX_OUTDOOR
            if BluetoothHelper.isConnectedDevice == true || Constants.IS_DEV == true {
                AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcercisePrepare, with: .push)
            } else {
                showDisconnectedDeviceAlert()
            }
        }
    }
    
    @IBAction func onClickFreeTreadmillCycling(_ sender: Any) {
        if Constants.IS_DEV {
            LocalDataManager.exerciseType = ExerciseConstants.FREE_EXERCISE_TREADMILL
            // TO DO: Change id
            AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseResult(model: ExerciseResultModel(), fromHistory: true), with: .push)
        }
    }
    
    @IBAction func onClickFreeTreadmillClimbing(_ sender: Any) {
        if Constants.IS_DEV {
            LocalDataManager.exerciseType = ExerciseConstants.FREE_EXERCISE_OUTDOOR
            // TO DO: Change id
            AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseResult(model: ExerciseResultModel(), fromHistory: true), with: .push)
        }
    }
    
    @IBAction func onClickGoToLTTest(_ sender: Any) {
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 1])
    }
}

extension ExcerciseMainViewController: ExcerciseMainViewModelDelegate {
    func didUpdateState(to state: ExcerciseMainViewModelState) {
        switch state {
        case .network(let networkStatus): networkStatusChanged(to: networkStatus)
        case .getLastLtTestSuccess:
            let lastLTTest = LocalDataManager.lastLTTestResult
            Functions.showLog(title: "LocalDataManager.lastLTTestResult", message: LocalDataManager.lastLTTestResult)
            if lastLTTest.testTypeID == nil || lastLTTest.testTypeID == "" {
                setRxNoData()
            } else {
                setRxHaveData()
            }
            bindDataHistoryStateButton()
        }
    }
}
