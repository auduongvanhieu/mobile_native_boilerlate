import Foundation

protocol ExcerciseMainViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: ExcerciseMainViewModelState)
}

enum ExcerciseMainViewModelState {
    case network(state: NetworkState)
    case getLastLtTestSuccess
}

class ExcerciseMainViewModel {
    
    weak var delegate: ExcerciseMainViewModelDelegate?
    var validateModel: ValidateExerciseModel?
    var historyStatus: HistoryStatusButtonModel?
    
    private var state: ExcerciseMainViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    func loadAllData() {
        getValidateRxExercise()
    }
    
    private func getValidateRxExercise() {
        state = .network(state: .loading)
        LTTestServices.getValidateLtTest(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                Functions.showLog(title: "getValidateRxExercise", message: res.type as Any)
                self.validateModel = res
                self.getActiveHistoryButton()
            },
            failure: { [weak self] error in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getValidateRxExercise", message: error)
                self.getActiveHistoryButton()
            }
        )
    }
    
    private func getActiveHistoryButton() {
        state = .network(state: .loading)
        ExerciseServices.getStatusHistoryButton(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                Functions.showLog(title: "getActiveHistoryButton", message: res.freeEnable as Any)
                self.historyStatus = res
                self.getLastLtTest()
            },
            failure: { [weak self] error in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getActiveHistoryButton", message: error)
                self.getLastLtTest()
            }
        )
    }
    
    private func getLastLtTest() {
        state = .network(state: .loading)
        LTTestServices.getLastLtTest(
            success: { [weak self] res in
                self?.state = .network(state: .hideLoading)
                Functions.showLog(title: "getLastLtTestSuccessSuccess", message: res.testTypeID as Any)
                self?.state = .getLastLtTestSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getLastLtTestSuccessError", message: error)
                self?.state = .getLastLtTestSuccess
            }
        )
    }
}
