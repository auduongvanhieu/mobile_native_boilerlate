import Foundation
import UIKit

class ExerciseCompletedViewController: BaseViewController {
    
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var medalImageView: UIImageView!
    @IBOutlet weak var badgeImageView: UIImageView!
    @IBOutlet weak var paddingView: UIView!
    @IBOutlet weak var headerBack: HeaderBack!
    var textTitle = ""
    var viewModel = ExerciseCompletedViewModel()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        headerBack.title = textTitle
        headerBack.hideLeftButton = true
        BluetoothHelper.restoreConnectDevice(fromViewController: self)
        viewModel.delegate = self
        setUpView()
        viewModel.uploadExercise()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        APIClient.isAutoShowDisconnectAlertMessage = true
        BluetoothHelper.isDisableViewDidAppear = false
    }
    
    func setUpView() {
        nextButton.layer.cornerRadius = UI.Button.cornerRadius
        nextButton.addTarget(self, action: #selector(onClickNext), for: .touchUpInside)
        nextButton.isEnabled = false
        nextButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
        nextButton.layer.backgroundColor = UI.Color.btnBgDisableColor.cgColor
        nextButton.setTitle("EXERCISE RESULT", for: .normal)
    }
    
    @objc func onClickNext(_ sender: UIButton) {
        // TO DO: Change id
        if viewModel.model != nil {
            AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseResult(model: viewModel.model, fromHistory: false), with: .push)
            self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
        }
    }
    
    func setUpData() {
        nextButton.isEnabled = true
        nextButton.setTitleColor(UIColor.white, for: .normal)
        nextButton.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        
        if viewModel.completeModel.medal == true {
            medalImageView.isHidden = false
        }
        if viewModel.completeModel.badge == true {
            badgeImageView.isHidden = false
        }
    }
}

extension ExerciseCompletedViewController: ExerciseCompletedViewModelDelegate {
    func didUpdateState(to state: ExerciseCompletedViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .failUploadData(let alertString):
            showMessage(title: "Data upload fail", message: alertString, buttonTitle: "Retry", handle: { _ in
                // Retry
                self.viewModel.didTouchRetry()
            }, handlerOK: { _ in
                self.viewModel.didTouchOK()
                self.setUpData()
            })
        case .failAPI(let errString):
            showToast(message: errString)
        case .postExerciseResultSuccess:
            setUpData()
        }
    }
}
