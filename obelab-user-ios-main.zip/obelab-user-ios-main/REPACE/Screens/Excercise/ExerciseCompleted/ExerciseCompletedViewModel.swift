import Foundation
import RealmSwift

protocol ExerciseCompletedViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: ExerciseCompletedViewModelState)
}

enum ExerciseCompletedViewModelState {
    case postExerciseResultSuccess
    case failUploadData(alertString: String)
    case failAPI(errStr: String)
    case network(state: NetworkState)
}

class ExerciseCompletedViewModel: ExerciseModelService {
    
    weak var delegate: ExerciseCompletedViewModelDelegate?
    var model: ExerciseResultModel!
    
    var state: ExerciseCompletedViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    var completeModel: ExerciseCompleteModel = ExerciseCompleteModel()
    
    func uploadExercise() {
        self.state = .network(state: .loading)
        BluetoothHelper.getNewestExerciseResultModelBy5Minutes { [weak self] exerciseResult in
            guard let self = self else { return }
            self.model = exerciseResult
            self.model.isFromLocal = true
            self.object = exerciseResult.convertToSaveObject()
            self.uploadFile(object: self.object, updatePercent: { percent in
                self.state = .network(state: .loadingPercent(percent: percent))
            }, failAPI: { errStr in
                self.state = .network(state: .hideLoading)
                self.state = .failAPI(errStr: errStr)
            })
        }
    }
    
    func didTouchRetry() {
        Functions.showLog(title: "Mytv didTouchRetry", message: "")
        self.state = .network(state: .loading)
        uploadExerciseData(failAPI: { errStr in
            self.state = .network(state: .hideLoading)
            self.state = .failAPI(errStr: errStr)
        }, updatePercent: { percent in
            self.state = .network(state: .loadingPercent(percent: percent))
        })
    }
    
    override func didFailUploadingData(isFailByConnection: Bool) {
        let alertString = "noInternetPostExercise".localized
        self.state = .network(state: .hideLoading)
        self.state = .failUploadData(alertString: alertString)
    }
    
    override func didFinishUploadingData(res: Any) {
        RealmHelper.share.cleanDataBeforeStartNewExercise()
        if let model = res as? ExerciseCompleteModel {
            self.completeModel = model
        }
        self.state = .network(state: .hideLoading)
        self.state = .postExerciseResultSuccess
    }
    
    func didTouchOK() {
        Functions.showLog(title: "Mytv didTouchOK", message: "")
        self.state = .network(state: .hideLoading)
        updateCreatedAt()
    }
}
