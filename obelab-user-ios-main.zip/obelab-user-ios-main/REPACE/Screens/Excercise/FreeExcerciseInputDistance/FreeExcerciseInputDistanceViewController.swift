import Foundation
import UIKit

class FreeExcerciseInputDistanceViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var lblUnitDistance: UILabel!
    @IBOutlet weak var pvDistance: UIPickerView!
    
    var pickerData: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Connect data:
        self.pvDistance.delegate = self
        self.pvDistance.dataSource = self
        
        for item in 1...999 {
            pickerData.append(String(Double(item) / 10.0))
        }
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
    }
    
    @IBAction func onClickFinish(_ sender: Any) {
        var selectedValue: Double = Double(pickerData[pvDistance.selectedRow(inComponent: 0)]) ?? 0
        if LocalDataManager.unit != Constants.UNIT_METRIC {
            selectedValue = Functions.mileToKm(mile: selectedValue).to1Decimal
        }
        LocalDataManager.freeExercisTotalDistanceInput = selectedValue
        Functions.showLog(title: "selectedValue", message: selectedValue)
        self.navigationController?.viewControllers.removeLast(1)
        APIClient.isAutoShowDisconnectAlertMessage = false
        BluetoothHelper.isDisableViewDidAppear = true
        AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseCompleted(title: "FREE EXERCISE"), with: .push)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Number of columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        pickerData.count
    }
    
    // The data to return fopr the row and component (column) that's being passed in
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        70
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let parentView = UIView()
        let label = UILabel(frame: CGRect(x: 0, y: 15, width: 80, height: 50))
        label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        label.font = UIFont(name: AppFontName.boldButton, size: 48)
        label.textAlignment = .center
        label.text = pickerData[row]
        parentView.addSubview(label)
        return parentView
    }
}
