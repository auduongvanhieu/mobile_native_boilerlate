import Foundation
import UIKit
import CoreLocation

class FreeExcerciseProgressViewController: BaseViewController {
    
    @IBOutlet weak var smo2Progress: RepaceSmo2Progress!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var heartRateLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var lblUnitDistance: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    var counter: Int = 0
    var timer: Timer?
    var distance: Double = 0
    let locationManager = CLLocationManager()
    var oldDate = Date()
    var oldLocation: CLLocation?
    var sumSpeed: Double = 0.0
    var countSpeed: Int = 0
    var isPause = false
    var page = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let index = self.navigationController?.viewControllers.firstIndex(where: {$0.isKind(of: FreeExercisePrepareViewController.self) == true}) {
            self.navigationController?.viewControllers.remove(at: index)
        }
        LocalDataManager.isSaveSmo2List = true
        // Set receive measure data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveMeasureData(_:)), name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        // Set receive heartrate data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveHeartrateData(_:)), name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
        setUpView()
        TextToSpeechHelper.speak(text: "Start running.", countDown: nil, timeUp: self.counter, page: page)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Setup timer
        if timer == nil {
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            timer?.tolerance = Constants.TIME_INTERVAL * 0.1
        }
        // Set total distance
//        if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL && LocalDataManager.freeExercisTotalDistanceInput > 0 {
//            distanceLabel.text = "\(LocalDataManager.freeExercisTotalDistanceInput)"
//            Functions.showLog(title: "Set total distance", message: LocalDataManager.freeExercisTotalDistanceInput)
//        }
        distanceLabel.text = "-"
//        Functions.showLog(title: "Set total distance", message: LocalDataManager.freeExercisTotalDistanceInput)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if timer != nil {
            timer?.invalidate()
            timer = nil
        }
        removeObserveNotification()
    }
    
    func removeObserveNotification() {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        // Set receive heartrate data
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
    }
    
    func setUpView() {
        if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
            page = "Free Exercise progress Treadmil (page 15)"
            speedLabel.text = "-"
        } else {
            page = "Free Exercise progress Outdoor (page 15)"
            // Setup location
            if CLLocationManager.locationServicesEnabled() {
                locationManager.requestAlwaysAuthorization()
                locationManager.requestWhenInUseAuthorization()
                locationManager.delegate = self
                locationManager.desiredAccuracy = kCLLocationAccuracyBest
                locationManager.distanceFilter = 8.0
                locationManager.pausesLocationUpdatesAutomatically = true
                locationManager.activityType = .fitness
                locationManager.startUpdatingLocation()
            }
        }
        pauseButton.setImage(UI.Icon.ic_pause, for: .normal)
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
    }
    
    @objc func onReceiveMeasureData(_ notification: NSNotification) {
        if let measureData = notification.userInfo?[NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA] as? RepaceMeasureModel {
            smo2Progress.setSmo2(value: Double(Functions.toSmO2(byteArray: measureData.rSO2)))
        }
    }
    
    @objc func onReceiveHeartrateData(_ notification: NSNotification) {
        if let heartrate = notification.userInfo?[NotificationCenterHelper.HR_HEART_RATE_DATA] as? Double {
            DispatchQueue.main.async {
                self.heartRateLabel.text = "\(Int(heartrate))"
            }
        }
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) updateCounter = \(counter)", message: "")
        counter += 1
        let minStr = counter / 60 > 9 ? "\(counter / 60)" : "0\(counter / 60)"
        let secondStr = counter % 60 > 9 ? "\(counter % 60)" : "0\(counter % 60)"
        timeLabel.text = "\(minStr) : \(secondStr)"
        var speech: String?
        let distanceUnit = Functions.kmToMile(km: distance)
        let unit = Functions.showUnitLabel(isSpeed: false)
        if counter == 60 * 60 {
            // 60 minutes
            if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
                speech = "Workout completed!\nTime 60 minutes, average SmO2 \(BluetoothHelper.getCurrentSMO2().to1Decimal) mmol"
            } else {
                speech = "Workout completed!\nTime 60 minutes, distance \(distanceUnit) \(unit), average pace \(distanceUnit) \(unit) per hour, average SmO2 2 mmol"
            }
        } else if counter % (5 * 60) == 0 {
            // after 5 minute
            let minute = counter / 60
            if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
                speech = "Time \(minute) minutes, average SmO2 \(BluetoothHelper.getCurrentSMO2().to1Decimal) mmol"
            } else {
                let speed = (distanceUnit / Double(minute) * 60).to1Decimal
                speech = "Time \(minute) minutes, distance \(distanceUnit) \(unit), average pace \(speed) \(unit) per hour, average SmO2 2 mmol"
            }
        }
        if let speech = speech {
            TextToSpeechHelper.speak(text: speech, countDown: nil, timeUp: self.counter, page: page)
        }
        // 1 minutes/time
        if counter % 60 == 0 {
            BluetoothHelper.saveSmo2AndHeartrateData()
        }
    }
    
    func stopAll() {
        Functions.stopFakeDataLTTest()
        LocalDataManager.isSaveSmo2List = false
        timer?.invalidate()
        timer = nil
        if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
            LocalDataManager.exerciseResult.speedMin = 0
            LocalDataManager.exerciseResult.speedMax = 0
            LocalDataManager.exerciseResult.speedAvg = 0
        } else {
            LocalDataManager.exerciseResult.speedAvg = countSpeed > 0 ? sumSpeed / Double(countSpeed) : sumSpeed
            locationManager.stopUpdatingLocation()
        }
        LocalDataManager.exerciseResult.totalDistance = distance
        LocalDataManager.exerciseResult.totalDuration = counter
    }
    
    @IBAction func onClickTotalDistance(_ sender: Any) {
//        if LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
//            AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcerciseInputDistance, with: .push)
//            timer?.invalidate()
//            timer = nil
//        }
    }
    
    @IBAction func onClickStop(_ sender: Any) {
        showMessage(title: "", message: "Are you sure you want to exit?\nWhen stopped, data will be saved", buttonTitle: "cancel".localized, handle: nil) { _ in
            BluetoothHelper.stopMeasure()
            BluetoothHelper.saveSmo2AndHeartrateData()
            AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcerciseInputDistance, with: .push)
            self.stopAll()
            self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
        }
//        let alert = UIAlertController(title: "", message: "Are you sure you want to exit?\nWhen stopped, data will be saved", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
//        alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//            BluetoothHelper.stopMeasure()
//            BluetoothHelper.saveSmo2AndHeartrateData()
//            AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcerciseInputDistance, with: .push)
//            self.stopAll()
//            self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
//        }))
//        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func onClickPause(_ sender: Any) {
        if isPause == false {
            isPause = true
            timer?.invalidate()
            pauseButton.setImage(UI.Icon.ic_play, for: .normal)
            TextToSpeechHelper.speak(text: "Workout paused.", countDown: nil, timeUp: self.counter, page: page)
        } else {
            isPause = false
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            timer?.tolerance = Constants.TIME_INTERVAL * 0.1
            pauseButton.setImage(UI.Icon.ic_pause, for: .normal)
            TextToSpeechHelper.speak(text: "Workout resumed.", countDown: nil, timeUp: self.counter, page: page)
        }
    }
}

extension FreeExcerciseProgressViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation: CLLocation = locations[0] as CLLocation
        Functions.showLog(title: "Location value listener", message: "(\(currentLocation.coordinate.latitude),\(currentLocation.coordinate.longitude))")
        let newDate = Date()
        if let oldLocation = oldLocation {
            let distanceDelta = Functions.getDistanceFrom2Coordinate(firstLocation: currentLocation, secondLocation: oldLocation)
            let speed = currentLocation.speed == -1 ? 0 : currentLocation.speed * 3.6
//            if speed < Constants.HUMAN_MAX_SPEED {
//                Functions.showLog(title: "Location speed", message: speed)
//                // Sum speed in this stage
//                sumSpeed += speed
//                countSpeed += 1
//                // Check max speed, min speed
//                if LocalDataManager.exerciseResult.speedMax == 0 || (LocalDataManager.exerciseResult.speedMax ?? 0 < speed) {
//                    LocalDataManager.exerciseResult.speedMax = speed
//                }
//                if LocalDataManager.exerciseResult.speedMin == 0 || (LocalDataManager.exerciseResult.speedMin ?? 0 > speed && speed != 0) {
//                    LocalDataManager.exerciseResult.speedMin = speed
//                }
//                // Save data
//                LocalDataManager.exerciseResult.listLocation?.append(LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis()))
//                distance += distanceDelta
//                // Show data
//                distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
//                speedLabel.text = "\(Functions.kmToMile(km: speed).to1Decimal)"
////                distanceLabel.text = "\(distance.to1Decimal)"
////                speedLabel.text = "\(speed.to1Decimal)"
//            }
            if speed > Constants.HUMAN_MAX_SPEED {
                Functions.showLog(title: "Location speed \(speed) over human speed \(Constants.HUMAN_MAX_SPEED)", message: "")
            }
            // Sum speed in this stage
            sumSpeed += speed
            countSpeed += 1
            // Check max speed, min speed
            if LocalDataManager.exerciseResult.speedMax == 0 || (LocalDataManager.exerciseResult.speedMax ?? 0 < speed) {
                LocalDataManager.exerciseResult.speedMax = speed
            }
            if LocalDataManager.exerciseResult.speedMin == 0 || (LocalDataManager.exerciseResult.speedMin ?? 0 > speed && speed != 0) {
                LocalDataManager.exerciseResult.speedMin = speed
            }
            // Save data
            LocalDataManager.exerciseResult.listLocation?.append(LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis()))
            distance += distanceDelta
            // Show data
            distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
            speedLabel.text = "\(Functions.kmToMile(km: speed).to1Decimal)"
        }
        oldLocation = currentLocation
        oldDate = newDate
    }
}
