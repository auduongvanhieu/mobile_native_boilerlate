import JTAppleCalendar
import UIKit

class CalendarCell: JTAppleCell, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var calendarHistoryTable: UITableView!
    
    var cellModel: DayExerciseModel = DayExerciseModel()
    var isActiveDistingush: Bool = false
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cellModel.exercise?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "CalendarExcerciseHistoryCell", for: indexPath) as? CalendarExcerciseHistoryCell,
           let exercise = cellModel.exercise {
            // set color here
            cell.bindData(exercise[indexPath.row], isActiveDistingush: isActiveDistingush)
            cell.selectionStyle = .none
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        8.0
    }
    
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet weak var vwCellContainer: UIView!
    @IBOutlet weak var excerciseTable: UITableView!
    
    func bindData(_ data: DayExerciseModel, isActiveDistingush: Bool) {
        calendarHistoryTable.delegate = self
        calendarHistoryTable.dataSource = self
        cellModel = data
        self.isActiveDistingush = isActiveDistingush
        calendarHistoryTable.reloadData()
    }
    
    func clean() {
        cellModel.exercise = []
        calendarHistoryTable.reloadData()
    }
}
