import Foundation
import UIKit

class CalendarExcerciseHistoryCell: UITableViewCell {
    
    @IBOutlet weak var vwItem: UIView!
    
    func bindData(_ data: ExerciseResultModel, isActiveDistingush: Bool) {
        vwItem.layer.borderColor = UI.Color.screenBackgroundColor.cgColor
        vwItem.layer.borderWidth = 0.5
        if data.typeID == ExerciseConstants.RX_EXERCISE {
//            if data.intensityID == ExerciseConstants.HIGH_INTENSITY && isActiveDistingush == true {
//                vwItem.backgroundColor = UI.Color.pinkColor
//            } else {
                vwItem.backgroundColor = UI.Color.btnBgColor
//            }
        } else {
            vwItem.backgroundColor = UI.Color.lightBlueColor
        }
    }
}
