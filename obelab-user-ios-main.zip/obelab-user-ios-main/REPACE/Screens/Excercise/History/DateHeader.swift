//
//  DateHeader.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/8/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//
import UIKit
import JTAppleCalendar

class DateHeader: JTAppleCollectionReusableView  {
    @IBOutlet var monthTitle: UILabel!
    
    
}
