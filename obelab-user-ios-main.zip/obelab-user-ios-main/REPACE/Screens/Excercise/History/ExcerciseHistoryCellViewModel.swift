//
//  ExcerciseHistoryCellViewModel.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/10/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

class ExcerciseHistoryCellViewModel {
    init(_ isRXExcercise: Bool) {
        self.isRXExcercise = isRXExcercise
    }
    init(_ isRXExcercise: Bool, _ isHighIntensity: Bool) {
        self.isRXExcercise = isRXExcercise
        self.isHighIntensity = isHighIntensity
    }
    
    var isRXExcercise: Bool = false
    var isHighIntensity: Bool = false
}
