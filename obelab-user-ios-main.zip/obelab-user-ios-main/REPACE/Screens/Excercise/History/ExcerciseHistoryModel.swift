//
//  ExcerciseHistoryModel.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/10/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

class ExcerciseHistoryModel {
    
    init(date: Date, excercises: [ExcerciseHistoryCellViewModel]) {
        self.excercises = excercises
        self.date = date
    }
    
    var date: Date = Date()
    var excercises: [ExcerciseHistoryCellViewModel] = []
   
}
