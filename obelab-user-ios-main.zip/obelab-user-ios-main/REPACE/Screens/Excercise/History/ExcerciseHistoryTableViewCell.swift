import Foundation
import UIKit

class ExcerciseHistoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var vwType: DesignableView!
    @IBOutlet weak var ivExcerciseType: UIImageView!
    @IBOutlet weak var ivRxBg: DesignableImageView!
    @IBOutlet weak var lbType: UILabel!
    @IBOutlet weak var lbActivityName: UILabel!
    @IBOutlet weak var lbDuration: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    func bindData(_ data: ExerciseResultModel) {
      
        if data.typeID == ExerciseConstants.RX_EXERCISE {
            vwType.backgroundColor = UI.Color.btnBgColor
            lbType.text = "Rx"
            lbType.textColor = UI.Color.btnBgColor
            ivRxBg.isHidden = false
        } else {
            vwType.backgroundColor = #colorLiteral(red: 0.1803921569, green: 0.6431372549, blue: 1, alpha: 1)
            lbType.text = "Free"
            lbType.textColor = UIColor.white
            ivRxBg.isHidden = true
        }
        
        let seconds = data.totalDuration ?? 0
        let hh = seconds / 3600
        let hhStr = hh < 10 ? "0\(hh)" : "\(hh)"
        let mm = (seconds % 3600) / 60
        let mmStr = mm < 10 ? "0\(mm)" : "\(mm)"
        let ss = (seconds % 3600) % 60
        let ssStr = ss < 10 ? "0\(ss)" : "\(ss)"
        lbDuration.text = "\(hhStr):\(mmStr):\(ssStr)"
        if let endTime = Functions.convertDateStrToDateISO8601(dateStr: data.updatedAt ?? ""),
           let startTime = Calendar.current.date(byAdding: .second, value: -seconds, to: endTime) {
            let startText = Functions.dateToString(date: startTime, outFormat: "MMM dd, yyyy HH:mm:ss")
            lbDate.text = startText
        } else {
            lbDate.text = "\(Functions.convertDateStrUTCToDateStr(dateStr: data.updatedAt ?? ""))"
        }
        if data.activityID == ExerciseConstants.EX_TREADMILL {
            lbActivityName.text = "Treadmill Running"
            ivExcerciseType.image = UIImage(#imageLiteral(resourceName: "ic_treadmill"))
        } else if data.activityID == ExerciseConstants.EX_OUTDOOR {
            lbActivityName.text = "Outdoor Running"
            ivExcerciseType.image = UIImage(#imageLiteral(resourceName: "ic_outdoor"))
        } else if data.activityID == ExerciseConstants.EX_CYCLING {
            lbActivityName.text = "Cycling Running"
            ivExcerciseType.image = UIImage(#imageLiteral(resourceName: "ic_cycling"))
        } else if data.activityID == ExerciseConstants.EX_CLIMBING {
            lbActivityName.text = "Climbing Running"
            ivExcerciseType.image = UIImage(#imageLiteral(resourceName: "ic_climbing"))
        }
      
    }
}
