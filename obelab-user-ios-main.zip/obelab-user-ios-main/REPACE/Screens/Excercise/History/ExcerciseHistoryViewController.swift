import UIKit
import JTAppleCalendar
class ExcerciseHistoryViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    let formatter = DateFormatter()  // Declare this outside, to avoid instancing this heavy class multiple times.
    
    var cellModel: DayExerciseModel = DayExerciseModel()
    var viewModel: ExcerciseHistoryViewModel = ExcerciseHistoryViewModel(type: nil)
    
    @IBOutlet weak var calendar: JTAppleCalendarView!
    
    @IBOutlet weak var vwDetails: DesignableView!
    @IBOutlet weak var tbExcercises: UITableView!
    @IBOutlet weak var lbSelectedDate: UILabel!
    @IBOutlet weak var ctViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var ctScrollViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var lbNoData: UILabel!
    
    @IBAction func btnNextMonth_Click(_ sender: Any) {
        calendar.scrollToSegment(.next)
        clearViewShowSelectedDate()
    }
    
    @IBAction func btnPrevMonth_Click(_ sender: Any) {
        calendar.scrollToSegment(.previous)
        clearViewShowSelectedDate()
    }
    
    private func clearViewShowSelectedDate() {
        lbSelectedDate.text = nil
        vwDetails.isHidden = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        calendar.ibCalendarDataSource = self
        calendar.ibCalendarDelegate = self
        
        calendar.scrollDirection = .horizontal
        calendar.scrollingMode = .stopAtEachCalendarFrame
        calendar.showsHorizontalScrollIndicator = false
        
        calendar.minimumInteritemSpacing = 0
        calendar.minimumLineSpacing = 0
        
        calendar.allowsSelection = true
        calendar.allowsMultipleSelection = false
        
        calendar.reloadData()
        calendar.scrollToDate(Date())
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        
        tbExcercises.dataSource = self
        tbExcercises.delegate = self
        tbExcercises.separatorStyle = .none
        viewModel.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.getExerciseHistoryInMonth()
    }
    
    func configureCell(view: JTAppleCell?, cellState: CellState) {
        guard let cell = view as? CalendarCell  else { return }
        cell.dateLabel.text = cellState.text
        handleCellTextColor(cell: cell, cellState: cellState)
        handleCellSelected(cell: cell, cellState: cellState)
    }
    
    func handleCellTextColor(cell: CalendarCell, cellState: CellState) {
        if cellState.day == .saturday || cellState.day == .sunday || cellState.dateBelongsTo != .thisMonth {
            cell.dateLabel.textColor = UI.Color.txtPlaceholderColor
        } else {
            cell.dateLabel.textColor = UIColor.white
        }
    }
    
    func handleCellSelected(cell: CalendarCell, cellState: CellState) {
        cell.vwCellContainer.layer.borderWidth = 1
        cell.vwCellContainer.layer.borderColor = cellState.isSelected ? #colorLiteral(red: 0.9575472474, green: 0.1922258139, blue: 0.5849661231, alpha: 1) : UIColor.clear.cgColor
        cell.vwCellContainer.layer.backgroundColor = cellState.isSelected ? UI.Color.btnBgDisableColor.cgColor : UIColor.clear.cgColor
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cellModel.exercise?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ExcerciseHistoryTableViewCell", for: indexPath) as? ExcerciseHistoryTableViewCell,
           let exercise = cellModel.exercise {
            // set color here
            cell.bindData(exercise[indexPath.row])
            cell.selectionStyle = .none
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        90.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let exercise = cellModel.exercise else {
            return
        }
        let model = exercise[indexPath.row]
        AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseResult(model: model, fromHistory: true), with: .push)
    }
}

extension ExcerciseHistoryViewController: JTAppleCalendarViewDataSource {
    func configureCalendar(_ calendar: JTAppleCalendarView) -> ConfigurationParameters {
        let endDate = Date()
        let startDate = endDate.addingTimeInterval(-365 * 24 * 60 * 60)
        let firstDayOfWeek: DaysOfWeek = .sunday
        return ConfigurationParameters(startDate: startDate, endDate: endDate, firstDayOfWeek: firstDayOfWeek)
    }
}

extension ExcerciseHistoryViewController: JTAppleCalendarViewDelegate {
    func calendar(_ calendar: JTAppleCalendarView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTAppleCell {
        guard let cell = calendar.dequeueReusableJTAppleCell(withReuseIdentifier: "dateCell", for: indexPath) as? CalendarCell else {
            return JTAppleCell()
        }
        cell.dateLabel.text = cellState.text
        if !viewModel.excerciseHistories.isEmpty {
            if let data = viewModel.excerciseHistories.first(where: {$0.date == cellState.date}) {
                cell.bindData(data, isActiveDistingush: viewModel.type != "rx_exercise")
            } else {
                cell.clean()
            }
        }
        configureCell(view: cell, cellState: cellState)
        return cell
    }
    func calendar(_ calendar: JTAppleCalendarView, willDisplay cell: JTAppleCell, forItemAt date: Date, cellState: CellState, indexPath: IndexPath) {
        let cell = cell as? CalendarCell
        configureCell(view: cell, cellState: cellState)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, headerViewForDateRange range: (start: Date, end: Date), at indexPath: IndexPath) -> JTAppleCollectionReusableView {
        guard let header = calendar.dequeueReusableJTAppleSupplementaryView(withReuseIdentifier: "dateHeader", for: indexPath) as? DateHeader else {
            return JTAppleCollectionReusableView()
        }
        formatter.dateFormat = "MMMM yyyy"
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        header.monthTitle.text = formatter.string(from: range.start)
        return header
    }
    
    func calendarSizeForMonths(_ calendar: JTAppleCalendarView?) -> MonthSize? {
        MonthSize(defaultSize: 72)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didSelectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        configureCell(view: cell, cellState: cellState)
        formatter.dateFormat = "MMM dd, yyyy"
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        lbSelectedDate.text = formatter.string(from: date)
        
        if let data = viewModel.excerciseHistories.first(where: {$0.date == cellState.date}) {
            cellModel = data
        } else {
            cellModel.exercise = []
        }
        tbExcercises.reloadData()
        vwDetails.isHidden = false
        ctViewHeightConstraint.constant = CGFloat((cellModel.exercise?.count ?? 0 == 0 ? 1 : cellModel.exercise?.count ?? 1) * 90) + 16
        ctScrollViewHeightConstraint.constant = 600 + ctViewHeightConstraint.constant
        lbSelectedDate.isHidden = false
        if let exercise = cellModel.exercise {
            lbNoData.isHidden = !exercise.isEmpty
        } else {
            lbNoData.isHidden = false
        }
        tbExcercises.isHidden = !lbNoData.isHidden
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didDeselectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        configureCell(view: cell, cellState: cellState)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
        if let lastDateOfMonth = visibleDates.monthDates.last?.date {
            let month = Calendar.current.component(.month, from: lastDateOfMonth)
            let year = Calendar.current.component(.year, from: lastDateOfMonth)
            viewModel.didScrollCalendarView(toMonth: month, year: year)
        }
    }
}

extension ExcerciseHistoryViewController: ExcerciseHistoryViewModelDelegate {
    func didUpdateState(to state: ExcerciseHistoryViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .finishLoadData:
            calendar.reloadData()
        case .scrollToToday:
            self.calendar.reloadData()
            self.calendar.scrollToDate(Date())
            // Selected Today
//            self.calendar.selectDates([Date()])
        }
    }
}
