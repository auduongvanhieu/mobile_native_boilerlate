//
//  ExcerciseHistoryViewModel.swift
//  REPACE
//
//  Created by Pham Van Huy on 20/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation
import MapboxMaps

protocol ExcerciseHistoryViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: ExcerciseHistoryViewModelState)
}

enum ExcerciseHistoryViewModelState {
    case scrollToToday
    case finishLoadData
    case network(state: NetworkState)
}

class ExcerciseHistoryViewModel: NSObject {
    
    private var state: ExcerciseHistoryViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: ExcerciseHistoryViewModelDelegate?
    
    var page = 0
    var totalPages = 0
    var exerciseHistoryList: [ExerciseResultModel] = []
    var excerciseHistories: [DayExerciseModel] = []
    var listHistoryInLocal: [ExerciseResultModel] = []
    var month: Int = Functions.getCurrenMonth()
    var year: Int = Functions.getCurrenYear()
    var dictionaryYearMonthLoaded: [Int: Set<Int>] = [:]
    var type: String?
    
    init(type: String?) {
        self.type = type
        super.init()
    }
    
    func checkMonthInFuture(month: Int, year: Int) -> Bool {
        if year == Functions.getCurrenYear() {
            return month > Functions.getCurrenMonth()
        } else {
            return year > Functions.getCurrenYear()
        }
    }
    
    func didScrollCalendarView(toMonth: Int, year: Int) {
        let isFuture = checkMonthInFuture(month: toMonth, year: year)
        if isFuture == false {
            if year < self.year {
                didChangeMonth(isNext: false)
            } else if year > self.year {
                didChangeMonth(isNext: true)
            } else {
                if toMonth > self.month {
                    didChangeMonth(isNext: true)
                } else if toMonth < self.month {
                    didChangeMonth(isNext: false)
                }
            }
        }
    }
    
    private func didChangeMonth(isNext: Bool) {
        month += isNext ? 1 : -1
        if month == 0 {
            month = 12
            year -= 1
        } else if month == 13 {
            month = 1
            year += 1
        }
        getExerciseHistoryInMonth(isNext: isNext)
    }
    
    func getExerciseHistoryInMonth(isNext: Bool? = nil) {
        if isNext == nil {
            dictionaryYearMonthLoaded = [:]
            listHistoryInLocal.removeAll()
            excerciseHistories.removeAll()
        }
        var needLoadNewData = true
        let isCurrentMonth = self.month == Functions.getCurrenMonth() && self.year == Functions.getCurrenYear()
        if let arrMonth = dictionaryYearMonthLoaded[year] {
            if arrMonth.contains(month) {
                needLoadNewData = isCurrentMonth
            } else {
                dictionaryYearMonthLoaded[year]?.insert(month)
            }
        } else {
            dictionaryYearMonthLoaded[year] = [month]
        }
        if needLoadNewData {
            state = .network(state: .loading)
            ExerciseServices.getHistoryExerciseInMonth(year: year, month: month, type: type,
                success: { [weak self] res in
                    guard let self = self else { return }
                    DispatchQueue.main.async {
                        self.state = .network(state: .hideLoading)
                        if isCurrentMonth {
                            self.excerciseHistories = self.excerciseHistories.filter { (viewModel) -> Bool in
                                if let date = viewModel.date {
                                    let monthData = Calendar.current.component(.month, from: date)
                                    let yearData = Calendar.current.component(.year, from: date)
                                    return monthData != self.month || yearData != self.year
                                }
                                return true
                            }
                        }
                        self.excerciseHistories += res.filter({ (viewModel) -> Bool in
                            guard let exDate = viewModel.date else {
                                return true
                            }
                            return exDate <= Date()
                        })
                        self.state = isNext == nil ? .scrollToToday : .finishLoadData
                        self.getLocalDB()
                    }
                },
                failure: { [weak self] error in
                    guard let self = self else { return }
                    self.getLocalDB()
                    self.state = .network(state: .hideLoading)
                    self.state = .network(state: .error(error.localizedDescription))
                }
            )
        } else {
            self.getLocalDB()
        }
    }
    
    private func getLocalDB() {
        if let list = RealmHelper.share.getAllExerciseInLocalDB(month: month, year: year, type: self.type),
           list.isEmpty == false {
            for element in list {
                if element.createdAt != nil && listHistoryInLocal.first(where: {$0.id == element.id}) == nil {
                    let newElement = element.convertToExerciseResultModel(isPostToServer: false)
                    listHistoryInLocal.append(newElement)
                }
            }
        }
        merge2List()
    }
    
    private func merge2List() {
        for element in listHistoryInLocal {
            if let createdAt = element.createdAt {
                let date = Functions.convertDateStrToDate(dateStr: createdAt)
                if let index = self.excerciseHistories.firstIndex(where: { model in
                    if let modelDate = model.date {
                        return Calendar.current.component(.year, from: modelDate) == Calendar.current.component(.year, from: date) &&
                        Calendar.current.component(.day, from: modelDate) == Calendar.current.component(.day, from: date) &&
                        Calendar.current.component(.month, from: modelDate) == Calendar.current.component(.month, from: date)
                    }
                    return false
                }) {
                    if self.excerciseHistories[index].exercise == nil {
                        self.excerciseHistories[index].exercise = [element]
                    } else {
                        if var list = self.excerciseHistories[index].exercise {
                            list.append(element)
                            list = list.sorted(by: { oldElement, newElement in
                                guard let oldDate = Functions.convertDateStrToDateISO8601(dateStr: oldElement.createdAt ?? ""),
                                      let newDate = Functions.convertDateStrToDateISO8601(dateStr: newElement.createdAt ?? "") else {
                                          return true
                                      }
                                return oldDate >= newDate
                            })
                            self.excerciseHistories[index].exercise = list
                        }
                    }
                } else {
                    let newDateList = DayExerciseModel(id: createdAt, date: date, exercise: [element])
                    excerciseHistories.append(newDateList)
                }
            }
        }
        for (index, exerciseInDate) in self.excerciseHistories.enumerated() {
            if var list = exerciseInDate.exercise {
                list = list.sorted(by: { oldElement, newElement in
                    guard let oldDate = Functions.convertDateStrToDateISO8601(dateStr: oldElement.createdAt ?? ""),
                          let newDate = Functions.convertDateStrToDateISO8601(dateStr: newElement.createdAt ?? "") else {
                              return false
                          }
                    return oldDate >= newDate
                })
                self.excerciseHistories[index].exercise = list
            }
        }
        self.state = .finishLoadData
    }
}
