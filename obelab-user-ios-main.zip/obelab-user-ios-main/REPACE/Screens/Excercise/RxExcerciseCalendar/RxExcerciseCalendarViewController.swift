import Foundation
import UIKit
import JTAppleCalendar

class RxExcerciseCalendarViewController: BaseViewController {
    
    var viewModel = RxExcerciseCalendarViewModel()
    let formatter = DateFormatter()
    var month: Int = Functions.getCurrenMonth()
    var year: Int = Functions.getCurrenYear()
    let todayExercise = ExerciseHelper.getTodayExercise()
    @IBOutlet weak var headerBack: HeaderBack!
    
    @IBOutlet weak var calendar: JTAppleCalendarView!
    
    @IBAction func btnNextMonth_Click(_ sender: Any) {
        month += 1
        if(month == 13) {
            month = 1
            year += 1
        }
//        viewModel.getExerciseHistoryInMonth(year: self.year, month: self.month)
        viewModel.getRxExerciseHistoryInMonth(year: self.year, month: self.month)
        calendar.scrollToSegment(.next)
        calendar.reloadData()
    }
    
    @IBAction func btnPrevMonth_Click(_ sender: Any) {
        month -= 1
        if month == 0 {
            month = 12
            year -= 1
        }
//        viewModel.getExerciseHistoryInMonth(year: self.year, month: self.month)
        viewModel.getRxExerciseHistoryInMonth(year: self.year, month: self.month)
        calendar.scrollToSegment(.previous)
        calendar.reloadData()
    }
    
    @IBAction func onClickNext(_ sender: Any) {
        Functions.showLog(title: "todayExercise", message: Functions.structToJsonStr(todayExercise))
//        if todayExercise.todaySession?.time == 0 {
//            AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseRest, with: .push)
//        } else {
            AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseSelectType, with: .push)
//        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        headerBack.setTitle(title: "title_rx_excercise_calendar".localized)
        calendar.ibCalendarDataSource = self
        calendar.ibCalendarDelegate = self
        
        calendar.scrollDirection = .horizontal
        calendar.scrollingMode   = .stopAtEachCalendarFrame
        calendar.showsHorizontalScrollIndicator = false
        
        calendar.minimumInteritemSpacing = 0
        calendar.minimumLineSpacing = 0
        
        calendar.allowsSelection = false
        calendar.allowsMultipleSelection = false
        
        formatter.dateFormat = "MMMM yyyy"
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        calendar.scrollToDate(Date())
        calendar.isScrollEnabled = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        viewModel.getExerciseHistoryInMonth(year: self.year, month: self.month)
        viewModel.getRxExerciseHistoryInMonth(year: self.year, month: self.month)
    }
    
    func getNextMonth() -> Int {
        var nextMonth = month + 1
        if nextMonth == 13 {
            nextMonth = 1
        }
        return nextMonth
    }
    
    func getNextYear() -> Int {
        var nextYear = year
        if month + 1 == 13 {
            nextYear += 1
        }
        return nextYear
    }
    
    func configureCell(view: JTAppleCell?, cellState: CellState) {
        guard let cell = view as? CalendarCell  else { return }
        cell.dateLabel.text = cellState.text
        handleCellTextColor(cell: cell, cellState: cellState)
        handleCellSelected(cell: cell, cellState: cellState)
    }
    
    func handleCellTextColor(cell: CalendarCell, cellState: CellState) {
        if cellState.day == .saturday || cellState.day == .sunday || cellState.dateBelongsTo != .thisMonth {
            cell.dateLabel.textColor = UI.Color.txtPlaceholderColor
        } else {
            cell.dateLabel.textColor = UIColor.white
        }
    }
    
    func handleCellSelected(cell: CalendarCell, cellState: CellState) {
        cell.vwCellContainer.layer.borderWidth = 1
        cell.vwCellContainer.layer.borderColor = cellState.isSelected ? #colorLiteral(red: 0.9575472474, green: 0.1922258139, blue: 0.5849661231, alpha: 1) : UIColor.clear.cgColor
        cell.vwCellContainer.layer.backgroundColor = cellState.isSelected ? UI.Color.btnBgDisableColor.cgColor : UIColor.clear.cgColor
    }
    
}

extension RxExcerciseCalendarViewController: JTAppleCalendarViewDataSource {
    func configureCalendar(_ calendar: JTAppleCalendarView) -> ConfigurationParameters {
        formatter.dateFormat = "yyyy MM dd"
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        let startDate = formatter.date(from: "\(year) \(month) 1")!
        let endDate = formatter.date(from: "\(getNextYear()) \(getNextMonth()) 1")!
        let firstDayOfWeek: DaysOfWeek = .sunday
        return ConfigurationParameters(startDate: startDate, endDate: endDate, firstDayOfWeek: firstDayOfWeek)
    }
}

extension RxExcerciseCalendarViewController: JTAppleCalendarViewDelegate {
    func calendar(_ calendar: JTAppleCalendarView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTAppleCell {
        guard let cell = calendar.dequeueReusableJTAppleCell(withReuseIdentifier: "dateCell", for: indexPath) as? CalendarCell else {
            return JTAppleCell()
        }
        cell.dateLabel.text = cellState.text
        if let model = viewModel.historyList.first(where: {$0.date == date}) {
            cell.bindData(model, isActiveDistingush: true)
        } else {
            cell.clean()
        }
//        let currentMonth = Int(date.getFormattedDate(format: "MM"))
//        let currentDay: Int = Int(date.getFormattedDate(format: "dd")) ?? 1
//        if currentMonth == month && viewModel.historyList.count > currentDay {
//            cell.bindData(viewModel.historyList[currentDay - 1], isActiveDistingush: true)
//        }
        configureCell(view: cell, cellState: cellState)
        return cell
    }
    
    func calendar(_ calendar: JTAppleCalendarView, willDisplay cell: JTAppleCell, forItemAt date: Date, cellState: CellState, indexPath: IndexPath) {
        let cell = cell as? CalendarCell
        configureCell(view: cell, cellState: cellState)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, headerViewForDateRange range: (start: Date, end: Date), at indexPath: IndexPath) -> JTAppleCollectionReusableView {
        guard let header = calendar.dequeueReusableJTAppleSupplementaryView(withReuseIdentifier: "dateHeader", for: indexPath) as? DateHeader else {
            return JTAppleCollectionReusableView()
        }
        formatter.dateFormat = "MMMM yyyy"
        formatter.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
        header.monthTitle.text = formatter.string(from: range.start)
        return header
    }
    
    func calendarSizeForMonths(_ calendar: JTAppleCalendarView?) -> MonthSize? {
        MonthSize(defaultSize: 72)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didSelectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        configureCell(view: cell, cellState: cellState)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didDeselectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        configureCell(view: cell, cellState: cellState)
    }
}

extension RxExcerciseCalendarViewController: RxExcerciseCalendarViewModelDelegate {
    func didUpdateState(to state: RxExcerciseCalendarViewModelState) {
        switch state {
        case .network(let networkStatus): networkStatusChanged(to: networkStatus)
        case .getMyExerciseAverageSuccess:
            Functions.showLog(title: "getMyExerciseAverageSuccess", message: "")
            calendar.reloadData()
        }
    }
}
