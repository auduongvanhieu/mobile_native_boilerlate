import Foundation

protocol RxExcerciseCalendarViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: RxExcerciseCalendarViewModelState)
}

enum RxExcerciseCalendarViewModelState {
    case getMyExerciseAverageSuccess
    case network(state: NetworkState)
}

class RxExcerciseCalendarViewModel {
    
    weak var delegate: RxExcerciseCalendarViewModelDelegate?
    
    private var state: RxExcerciseCalendarViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    var historyList: [DayExerciseModel] = []
    
    func getExerciseHistoryInMonth(year: Int, month: Int) {
        ExerciseServices.getExerciseHistoryInMonth(year: year, month: month,
            success: { [weak self] res in
                let filter = res.filter({($0.date ?? Date()) <= Date()})
                self?.historyList = filter
                self?.state = .getMyExerciseAverageSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    func getRxExerciseHistoryInMonth(year: Int, month: Int) {
        state = .network(state: .loading)
        ExerciseServices.getRxExerciseHistoryInMonth(year: year, month: month,
            success: { [weak self] res in
                self?.state = .network(state: .hideLoading)
                let filter = res.filter({($0.date ?? Date()) <= Date()})
                self?.historyList = filter
                self?.state = .getMyExerciseAverageSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
}
