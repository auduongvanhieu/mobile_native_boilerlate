//
//  RxExcerciseResultModel.swift
//  REPACE
//
//  Created by BM Johnny on 2/14/22.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

protocol RxExcerciseResultModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: RxExcerciseResultModelState)
}

enum RxExcerciseResultModelState {
    case didGetRxExcerciseResult
    case network(state: NetworkState)
    case hideSync(isHidden: Bool)
    case failWithMessage(message: String)
    case failAPI(errSTr: String)
    case exerciseUploading
}

class RxExcerciseResultModel {
    
    private var state: RxExcerciseResultModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
//    var id: Int = 0
    var exerciseResultModel: ExerciseResultModel!
    var data: ExerciseResultModel!
    weak var delegate: RxExcerciseResultModelDelegate?
    var object: ResultExerciseObject?
    
    func getExerciseTypeLabel() -> String? {
        if data != nil {
            if data.typeID == ExerciseConstants.FREE_EXERCISE {
                return data.activityID == ExerciseConstants.EX_TREADMILL ? ExerciseConstants.FREE_EXERCISE_TREADMILL : ExerciseConstants.FREE_EXERCISE_OUTDOOR
            } else {
                return data.activityID == ExerciseConstants.EX_TREADMILL ? ExerciseConstants.RX_EXERCISE_TREADMILL : ExerciseConstants.RX_EXERCISE_OUTDOOR
            }
        }
        return nil
    }
    
    func getRxExcerciseResult() {
        if exerciseResultModel != nil, let idExerise = exerciseResultModel.id {
            if exerciseResultModel.isFromLocal == true {
                loadLocalDB(idExercise: idExerise, isFirstTime: true)
            } else {
                state = .network(state: .loading)
                ExerciseServices.getResultExercise(id: idExerise,
                                                   success: { [weak self] res in
                    guard let self = self else { return }
                    self.state = .network(state: .hideLoading)
                    self.data = res
                    self.changeMinSmO2()
                    self.state = .didGetRxExcerciseResult
                },
                                                   failure: { [weak self] error in
                    self?.state = .network(state: .hideLoading)
                    self?.state = .network(state: .error(error.localizedDescription))
                })
            }
        }
    }
    
    private func loadLocalDB(idExercise: Int, isFirstTime: Bool) {
        if let object = RealmHelper.share.getExerciseByID(isLTTest: false, idExercise: idExercise) as? RxExerciseResultObject {
            if isFirstTime {
                self.data = object.convertToExerciseResultModel(isPostToServer: false)
                changeMinSmO2()
                self.state = .didGetRxExcerciseResult
            }
            self.object = object
            self.state = .hideSync(isHidden: false)
            if object.isLock == true {
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                    self.loadLocalDB(idExercise: idExercise, isFirstTime: false)
                }
            }
        } else {
            self.data = exerciseResultModel
            self.state = .hideSync(isHidden: true)
            changeMinSmO2()
            self.state = .didGetRxExcerciseResult
            self.object = nil
        }
    }
    
    func didTouchSync() {
        FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel didTouchSync", content: "")
        Functions.showLog(title: "Mytv didTouchSync", message: "")
        uploadData()
    }
    
    func didTouchRetry() {
        FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel didTouchRetry", content: "")
        Functions.showLog(title: "Mytv didTouchRetry", message: "")
        uploadData()
    }
    
    private func uploadData() {
        if let object = object {
            if object.isInvalidated == false {
                if object.isAttachCreatedAt == false {
                    object.addPostCreatedAt()
                }
                if object.isLock == false {
                    upload()
                } else {
                    self.state = .exerciseUploading
                }
            } else {
                self.state = .hideSync(isHidden: true)
            }
        }
    }
    
    private func upload() {
        guard let object = object else {
            return
        }
        self.state = .network(state: .loading)
        RealmHelper.share.saveExercise(isLTTest: false, idExercise: object.id, isFailByConnection: { isFailByConnection in
            Functions.showLog(title: "RxExcerciseResultModel Fail isFailByConnection ", message: isFailByConnection)
            if let isFailByConnection = isFailByConnection as? Bool {
                self.state = .failWithMessage(message: "noInternetPostLTTest".localized)
                FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel upload local data fail exercise id \(object.id) with isFailByConnection = \(isFailByConnection)", content: "")
            } else if let errStr = isFailByConnection as? String {
                self.state = .failAPI(errSTr: errStr)
                FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel upload local data fail exercise id \(object.id) with isFailByConnection = \(errStr)", content: "")
            } else if let err = isFailByConnection as? Error {
                self.state = .failAPI(errSTr: err.localizedDescription)
                FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel upload local data fail exercise id \(object.id) with isFailByConnection = \(err.localizedDescription)", content: "")
            } else {
                self.state = .failAPI(errSTr: "Unknown error")
                FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel upload local data fail exercise id \(object.id) with isFailByConnection Unknown error", content: "")
            }
            self.state = .network(state: .hideLoading)
        }, completion: { _ in
            self.state = .network(state: .hideLoading)
            self.state = .hideSync(isHidden: true)
        }, updatePercent: {percent in
            self.state = .network(state: .loadingPercent(percent: percent))
        })
    }
    
    func changeMinSmO2() {
        let min = data.smo2Min ?? 0.0
        data.smo2Min = min != 0 ? min : data.smo2Max
    }
    
    func didTouchOK() {
        FileHelper.writeStringToLogFile(title: "RxExcerciseResultModel didTouchOK", content: "")
        Functions.showLog(title: "Mytv didTouchOK", message: "")
        if let object = object,
           object.isInvalidated == false {
            object.addPostCreatedAt()
        }
    }
}
