import UIKit
import Charts
import MapboxMaps
import CoreLocation
import LinkPresentation

class RxExcerciseResultViewController: BaseViewController {
    
    @IBOutlet weak var contentViewHeight: NSLayoutConstraint!
    @IBOutlet weak var mapViewMarginTop: NSLayoutConstraint!
    @IBOutlet weak var mapViewHeight: NSLayoutConstraint!
    @IBOutlet weak var presciptionViewMarginTop: NSLayoutConstraint!
    @IBOutlet weak var presciptionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var presciptionLabelMarginTop: NSLayoutConstraint!
    @IBOutlet weak var presciptionLabelHeight: NSLayoutConstraint!
    @IBOutlet weak var freeSummaryViewTop: NSLayoutConstraint!
    @IBOutlet weak var freeSummaryViewHeight: NSLayoutConstraint!
    @IBOutlet weak var headerBack: HeaderBack!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var todayLabel: UILabel!
    @IBOutlet weak var userNicknameLabel: UILabel!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var sessionLabel: UILabel!
    @IBOutlet weak var exerciseTypeLabel: UILabel!
    @IBOutlet weak var presciptionView: UIView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var heartrateLabel: UILabel!
    @IBOutlet weak var smo2Button: UIButton!
    @IBOutlet weak var heartrateButton: UIButton!
    @IBOutlet weak var minSmo2Label: UILabel!
    @IBOutlet weak var maxSmo2Label: UILabel!
    @IBOutlet weak var avgSmo2Label: UILabel!
    @IBOutlet weak var minHeartrateLabel: UILabel!
    @IBOutlet weak var maxHeartrateLabel: UILabel!
    @IBOutlet weak var avgHeartrateLabel: UILabel!
    @IBOutlet weak var mapUIView: UIView!
    @IBOutlet weak var vwChartContainer: UIStackView!
    @IBOutlet weak var okButton: UIButton!
    @IBOutlet weak var topLeftImageView: UIImageView!
    @IBOutlet weak var topRightImageView: UIImageView!
    @IBOutlet weak var bottomLeftImageView: UIImageView!
    @IBOutlet weak var bottomRightImageView: UIImageView!
    @IBOutlet weak var freeSummaryView: UIView!
    @IBOutlet weak var duractionLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var calorieLabel: UILabel!
    @IBOutlet weak var maxSpeedLabel: UILabel!
    @IBOutlet weak var avgSpeedLabel: UILabel!
    @IBOutlet weak var paceLabel: UILabel!
    @IBOutlet weak var lblSession: UILabel!
    internal var mapView: MapView!
    
    @IBOutlet weak var lblUnitAvgSpeed: UILabel!
    @IBOutlet weak var lblUnitMaxSpeed: UILabel!
    @IBOutlet weak var lblUnitDistance: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var topLabelDate: NSLayoutConstraint!
    @IBOutlet weak var btnSync: UIView!
    
    var lineChartView = LineChartView()
    var exerciseResult: ExerciseResultModel!
    var isSmo2Enable = true
    var isHeartrateEnable = true
    
    var viewModel = RxExcerciseResultModel()
    
    var fromHistory = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Functions.showLog(title: "exerciseResult", message: Functions.structToJsonStr(exerciseResult))
        setUpView()
        viewModel.delegate = self
        viewModel.getRxExcerciseResult()
        if !fromHistory {
            self.headerBack.hideLeftButton = true
        }
//        self.setUpData()
    }
    
    func setUpView() {
        btnSync.layer.cornerRadius = 12.0
        btnSync.clipsToBounds = true
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitMaxSpeed.text = lblUnitSpeed.text
        lblUnitAvgSpeed.text = lblUnitSpeed.text
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
        headerBack.delegate = self
        // Set button
        smo2Button.layer.cornerRadius = UI.Button.cornerRadius
        heartrateLabel.layer.cornerRadius = UI.Button.cornerRadius
        okButton.addTarget(self, action: #selector(onClickOK), for: .touchUpInside)
        smo2Button.addTarget(self, action: #selector(onClickSmo2ChartButton), for: .touchUpInside)
        heartrateButton.addTarget(self, action: #selector(onClickHeartrateChartButton), for: .touchUpInside)
    }
    
    func setUpData() {
        var dateStr = Functions.getNowDateStr()
        if let date = exerciseResult.updatedAt {
            dateStr = Functions.convertDateStrToProfileDateStr(dateStr: date)
        }
        todayLabel.text = dateStr // Functions.getNowDateStr()
        userNicknameLabel.text = LocalDataManager.profile?.nickname
        var start = exerciseResult.startTime ?? ""
        if start.count > 5 {
            start = String(start.prefix(5))
        }
        var end = exerciseResult.endTime ?? ""
        if end.count > 5 {
            end = String(end.prefix(5))
        }
        startTimeLabel.text = "\(start) ~ \(end)"
        sessionLabel.text = "0\(exerciseResult.sessionCnt ?? 0)"
        if let type = viewModel.getExerciseTypeLabel() {
            if type == ExerciseConstants.RX_EXERCISE_TREADMILL || type == ExerciseConstants.RX_EXERCISE_OUTDOOR {
                exerciseTypeLabel.text = "\(type.localized) - \(exerciseResult.intensityID?.localized ?? "")"
            } else {
                exerciseTypeLabel.text = "\(type.localized)"
            }
        } else {
            exerciseTypeLabel.text = "\(LocalDataManager.exerciseType.localized)"
        }
        self.sessionLabel.isHidden = exerciseResult.typeID == ExerciseConstants.FREE_EXERCISE
        self.lblSession.isHidden = exerciseResult.typeID == ExerciseConstants.FREE_EXERCISE
        self.userNicknameLabel.isHidden = true // exerciseResult.typeID == ExerciseConstants.FREE_EXERCISE
//        if(LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL || LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR){
//            exerciseTypeLabel.text = "\(LocalDataManager.exerciseType.localized) - \(exerciseResult.intensityID?.localized ?? "")"
//        } else {
//            exerciseTypeLabel.text = "\(LocalDataManager.exerciseType.localized)"
//        }
        timeLabel.text = "\(exerciseResult.time ?? 0)"
        speedLabel.text = "\(Functions.kmToMile(km: exerciseResult.speed).to1Decimal)"
//        speedLabel.text = "\(exerciseResult.speed?.to1Decimal ?? 0)"
        let heartrate = exerciseResult.heartRate ?? 0
        heartrateLabel.text = heartrate == 0 ? "< -" : "< \(heartrate)"
        minSmo2Label.text = "\(exerciseResult.smo2Min?.to1Decimal ?? 0)"
        maxSmo2Label.text = "\(exerciseResult.smo2Max?.to1Decimal ?? 0)"
        avgSmo2Label.text = "\(exerciseResult.smo2Avg?.to1Decimal ?? 0)"
        
        minHeartrateLabel.text = (exerciseResult.heartRateMin ?? 0) != 0 ? "\(exerciseResult.heartRateMin ?? 0)" : "-"
        maxHeartrateLabel.text = (exerciseResult.heartRateMax ?? 0) != 0 ? "\(exerciseResult.heartRateMax ?? 0)" : "-"
        let avgHeartrate = Int((exerciseResult.heartRateAvg ?? 0).rounded(.toNearestOrAwayFromZero))
        avgHeartrateLabel.text = avgHeartrate != 0 ? "\(avgHeartrate)" : "-"
        // Set up Chart
        self.initChart()
        // Other view
        if let type = viewModel.getExerciseTypeLabel() {
            if type == ExerciseConstants.RX_EXERCISE_TREADMILL || type == ExerciseConstants.FREE_EXERCISE_TREADMILL {
                mapViewHeight.constant = 0
                mapViewMarginTop.constant = 0
                if type == ExerciseConstants.RX_EXERCISE_TREADMILL {
                    headerBack.setTitle(title: "title_rx_exercise_result".localized)
                    contentViewHeight.constant = 900
                    freeSummaryView.isHidden = true
                    freeSummaryViewTop.constant = 0
                    freeSummaryViewHeight.constant = 0
                } else { // FREE_EXERCISE_TREADMILL
                    headerBack.setTitle(title: "title_free_exercise_result".localized)
                    contentViewHeight.constant = 960
                    presciptionLabelMarginTop.constant = 0
                    presciptionLabelHeight.constant = 0
                    presciptionViewMarginTop.constant = 0
                    presciptionViewHeight.constant = 0
                    presciptionView.isHidden = true
                    freeSummaryViewHeight.constant = 125
                    setUpFreeSummary()
                }
            } else {
                if type == ExerciseConstants.RX_EXERCISE_OUTDOOR {
                    headerBack.setTitle(title: "title_rx_exercise_result".localized)
                    contentViewHeight.constant = 1160
                    freeSummaryView.isHidden = true
                    freeSummaryViewTop.constant = 0
                    freeSummaryViewHeight.constant = 0
                } else { // FREE_EXERCISE_OUTDOOR
                    headerBack.setTitle(title: "title_free_exercise_result".localized)
                    contentViewHeight.constant = 1300
                    presciptionLabelMarginTop.constant = 0
                    presciptionLabelHeight.constant = 0
                    presciptionViewMarginTop.constant = 0
                    presciptionViewHeight.constant = 0
                    presciptionView.isHidden = true
                    setUpFreeSummary()
                }
                // Map
                self.setUpMapView()
            }
        }
//        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL || LocalDataManager.exerciseType == ExerciseConstants.FREE_EXERCISE_TREADMILL {
//            mapViewHeight.constant = 0
//            mapViewMarginTop.constant = 0
//            if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
//                headerBack.setTitle(title: "title_rx_exercise_result".localized)
//                contentViewHeight.constant = 900
//                freeSummaryView.isHidden = true
//                freeSummaryViewTop.constant = 0
//                freeSummaryViewHeight.constant = 0
//            } else { // FREE_EXERCISE_TREADMILL
//                headerBack.setTitle(title: "title_free_exercise_result".localized)
//                contentViewHeight.constant = 960
//                presciptionLabelMarginTop.constant = 0
//                presciptionLabelHeight.constant = 0
//                presciptionViewMarginTop.constant = 0
//                presciptionViewHeight.constant = 0
//                presciptionView.isHidden = true
//                freeSummaryViewHeight.constant = 125
//                setUpFreeSummary()
//            }
//        } else {
//            if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR {
//                headerBack.setTitle(title: "title_rx_exercise_result".localized)
//                contentViewHeight.constant = 1160
//                freeSummaryView.isHidden = true
//                freeSummaryViewTop.constant = 0
//                freeSummaryViewHeight.constant = 0
//            } else { // FREE_EXERCISE_OUTDOOR
//                headerBack.setTitle(title: "title_free_exercise_result".localized)
//                contentViewHeight.constant = 1300
//                presciptionLabelMarginTop.constant = 0
//                presciptionLabelHeight.constant = 0
//                presciptionViewMarginTop.constant = 0
//                presciptionViewHeight.constant = 0
//                presciptionView.isHidden = true
//                setUpFreeSummary()
//            }
//            // Map
//            self.setUpMapView()
//        }
    }
    
    func initChart() {
        lineChartView.legend.enabled = false
        lineChartView.leftAxis.labelTextColor = .white
        lineChartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.valueFormatter = self
        lineChartView.xAxis.labelTextColor = .white
        lineChartView.xAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.rightAxis.labelTextColor = .white
        lineChartView.xAxis.spaceMin = 0.3
        lineChartView.xAxis.spaceMax = 0.3
        lineChartView.rightAxis.axisMinimum = 0
        lineChartView.rightAxis.axisMaximum = 200
        lineChartView.leftAxis.axisMinimum = 0
        lineChartView.leftAxis.axisMaximum = 100
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.granularityEnabled = true
        lineChartView.xAxis.granularity = 1
        lineChartView.doubleTapToZoomEnabled = false
        lineChartView.scaleXEnabled = false
        lineChartView.scaleYEnabled = false
        lineChartView.dragEnabled = false
        vwChartContainer.addArrangedSubview(lineChartView)
        self.setChartData()
    }
    
    func setChartData() {
        var ySmo2Values: [BarChartDataEntry] = []
        var yHeartrateValues: [BarChartDataEntry] = []
        for (index, element) in (exerciseResult.listSmo2 ?? []).enumerated() {
            ySmo2Values.append(BarChartDataEntry(x: Double(index + 1), y: Double(element.score ?? 0)))
        }
        for (index, element) in (exerciseResult.listHeartRate ?? []).enumerated() {
            yHeartrateValues.append(BarChartDataEntry(x: Double(index + 1), y: Double(element.score ?? 0)))
        }
        
        let setSmo2 = LineChartDataSet(entries: ySmo2Values, label: "SmO2")
        setSmo2.setColor(isSmo2Enable ? UI.Color.lightBlueColor : UI.Color.transparentColor)
        setSmo2.drawValuesEnabled = false
        setSmo2.lineWidth = 2
        setSmo2.circleColors = [UI.Color.lightBlueColor]
        setSmo2.circleHoleColor = UI.Color.lightBlueColor
        if ySmo2Values.count == 1 {
            setSmo2.circleRadius = 2
            setSmo2.circleHoleRadius = 2
        } else {
            setSmo2.circleRadius = 0
            setSmo2.circleHoleRadius = 0
        }

        let setHeartrate = LineChartDataSet(entries: yHeartrateValues, label: "HR")
        setHeartrate.setColor(isHeartrateEnable ?  UI.Color.pinkColor : UI.Color.transparentColor)
        setHeartrate.drawValuesEnabled = false
        setHeartrate.lineWidth = 2
        setHeartrate.circleColors = [UI.Color.pinkColor]
        setHeartrate.circleHoleColor = UI.Color.pinkColor
        setHeartrate.axisDependency = .right
        if yHeartrateValues.count == 1 {
            setHeartrate.circleRadius = 2
            setHeartrate.circleHoleRadius = 2
        } else {
            setHeartrate.circleRadius = 0
            setHeartrate.circleHoleRadius = 0
        }
        if viewModel.data.typeID == ExerciseConstants.FREE_EXERCISE {
            lineChartView.xAxis.setLabelCount(8, force: ySmo2Values.count > 7)
        } else {
            lineChartView.xAxis.labelCount = ySmo2Values.count
        }
        lineChartView.data = LineChartData(dataSets: [setSmo2, setHeartrate])
    }
    
    func setUpFreeSummary() {
        let durationHour: Int = (exerciseResult.totalDuration ?? 0) / 3600
        let durationMin: Int = ((exerciseResult.totalDuration ?? 0) - durationHour * 3600) / 60
        let durationSec: Int = (exerciseResult.totalDuration ?? 0) % 60
        let durationHourStr = durationHour < 10 ? "0\(durationHour)" : "\(durationHour)"
        let durationMinStr = durationMin < 10 ? "0\(durationMin)" : "\(durationMin)"
        let durationSecStr = durationSec < 10 ? "0\(durationSec)" : "\(durationSec)"
        duractionLabel.text = "\(durationHourStr) : \(durationMinStr) : \(durationSecStr)"
        distanceLabel.text = "\((Functions.kmToMile(km: exerciseResult.totalDistance)).to1Decimal)"
//        distanceLabel.text = "\((exerciseResult.totalDistance ?? 0).to1Decimal)"
        calorieLabel.text = "-"
        maxSpeedLabel.text = "\((Functions.kmToMile(km: exerciseResult.speedMax)).to1Decimal)"
        avgSpeedLabel.text = "\((Functions.kmToMile(km: exerciseResult.speedAvg)).to1Decimal)"
//        maxSpeedLabel.text = "\((exerciseResult.speedMax ?? 0).to1Decimal)"
//        avgSpeedLabel.text = "\((exerciseResult.speedAvg ?? 0).to1Decimal)"
        let pace = Double(exerciseResult.totalDuration ?? 0) / ((exerciseResult.totalDistance ?? 1) > 0 ? (exerciseResult.totalDistance ?? 1) : 1)
        let paceMin: Int = Int(pace / 60)
        let paceSec: Int = Int(pace) % 60
        let paceMinStr = paceMin < 10 ? "0\(paceMin)" : "\(paceMin)"
        let paceSecStr = paceSec < 10 ? "0\(paceSec)" : "\(paceSec)"
        paceLabel.text = "\(paceMinStr)' \(paceSecStr)''"
    }
    
    func setUpMapView() {
        mapUIView.layer.cornerRadius = UI.View.radius
        let myResourceOptions = ResourceOptions(accessToken: MapConstants.MAP_KEY)
        let locationCenter = exerciseResult.listLocation?.isEmpty == false ? CLLocationCoordinate2D(latitude: exerciseResult.listLocation?[0].latitude ?? 0, longitude: exerciseResult.listLocation?[0].longitude ?? 0) : CLLocationCoordinate2D(latitude: MapConstants.CENTER_LAT, longitude: MapConstants.CENTER_LON)
        let cameraOptions = CameraOptions(center: locationCenter, zoom: 18, bearing: 0, pitch: 0)
        let myMapInitOptions = MapInitOptions(resourceOptions: myResourceOptions, cameraOptions: cameraOptions, styleURI: StyleURI(rawValue: StyleURI.dark.rawValue))
        mapView = MapView(frame: mapUIView.bounds, mapInitOptions: myMapInitOptions)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mapView.layer.cornerRadius = UI.View.radius
        mapUIView.addSubview(mapView)
        mapUIView.addSubview(topLeftImageView)
        mapUIView.addSubview(topRightImageView)
        mapUIView.addSubview(bottomLeftImageView)
        mapUIView.addSubview(bottomRightImageView)
        // Draw line for map
        var lineCoordinates: [CLLocationCoordinate2D] = []
        exerciseResult.listLocation?.forEach({ (element) in
            lineCoordinates.append(CLLocationCoordinate2DMake(element.latitude ?? 0, element.longitude ?? 0))
        })
//        for (_, element) in (exerciseResult.listLocation ?? []).enumerated() {
//            lineCoordinates.append(CLLocationCoordinate2DMake(element.latitude ?? 0, element.longitude ?? 0))
//        }
        var lineAnnotation = PolylineAnnotation(lineCoordinates: lineCoordinates)
        lineAnnotation.lineColor = StyleColor(.yellow)
        lineAnnotation.lineWidth = 5
        let lineAnnnotationManager = mapView.annotations.makePolylineAnnotationManager()
        lineAnnnotationManager.annotations = [lineAnnotation]

        if exerciseResult.listLocation?.isEmpty == false {
            let startPoint = CLLocationCoordinate2D(latitude: exerciseResult.listLocation?[0].latitude ?? 0, longitude: exerciseResult.listLocation?[0].longitude ?? 0)
            let endPoint = CLLocationCoordinate2D(latitude: exerciseResult.listLocation?[(exerciseResult.listLocation?.count ?? 1) - 1].latitude ?? 0, longitude: exerciseResult.listLocation?[(exerciseResult.listLocation?.count ?? 1) - 1].longitude ?? 0)
            // Set camera depend sharp
            let bounds = CoordinateBounds(southwest: startPoint, northeast: endPoint)
            mapView.mapboxMap.camera(for: bounds, padding: .zero, bearing: 0, pitch: 0)
            // Set start point and end point
            var startPointAnnotation = PointAnnotation(coordinate: startPoint)
            startPointAnnotation.image = .init(image: UI.Icon.ic_map_start!, name: "start")
            startPointAnnotation.iconAnchor = .bottom
            startPointAnnotation.iconSize = 0.05
            var endPointAnnotation = PointAnnotation(coordinate: endPoint)
            endPointAnnotation.image = .init(image: UI.Icon.ic_map_stop!, name: "end")
            endPointAnnotation.iconAnchor = .bottom
            endPointAnnotation.iconSize = 0.05
            let pointAnnotationManager = mapView.annotations.makePointAnnotationManager()
            pointAnnotationManager.annotations = [startPointAnnotation, endPointAnnotation]
        }
    }
    
    func setSmo2ButtonEnable() {
        smo2Button.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        smo2Button.setTitleColor(UIColor.white, for: .normal)
    }
    
    func setSmo2ButtonDisable() {
        smo2Button.layer.backgroundColor = UI.Color.btnBgDisableColor.cgColor
        smo2Button.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
    }
    
    func setHeartrateButtonEnable() {
        heartrateButton.layer.backgroundColor = UI.Color.pinkColor.cgColor
        heartrateButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    func setHeartrateButtonDisable() {
        heartrateButton.layer.backgroundColor = UI.Color.btnBgDisableColor.cgColor
        heartrateButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
    }
    
    @objc func onClickSmo2ChartButton(_ sender: UIButton) {
        if isSmo2Enable == true {
            setSmo2ButtonDisable()
        } else {
            setSmo2ButtonEnable()
        }
        isSmo2Enable = !isSmo2Enable
        setChartData()
    }
    
    @objc func onClickHeartrateChartButton(_ sender: UIButton) {
        if isHeartrateEnable == true {
            setHeartrateButtonDisable()
        } else {
            setHeartrateButtonEnable()
        }
        isHeartrateEnable = !isHeartrateEnable
        setChartData()
    }
    
    @objc func onClickOK(_ sender: UIButton) {
        if let viewController = self.navigationController?.viewControllers.first(where: {$0.isKind(of: MainViewController.self) == true}) as? MainViewController {
            if viewController.openFlag == true {
                viewController.openOrCloseSideMenu()
            }
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 0])
            self.navigationController?.popToViewController(viewController, animated: true)
        } else {
            AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: false), with: .reset)
        }
    }
    
    @IBAction func didTouchSync(_ sender: Any) {
        viewModel.didTouchSync()
    }
    
    private func checkHeartrateData() {
        var isHaveData = false
        for element in (exerciseResult.listHeartRate ?? []) {
            isHaveData = (element.score ?? 0) > 0
            if isHaveData == true {
                break
            }
        }
        self.isHeartrateEnable = !isHaveData
        self.onClickHeartrateChartButton(heartrateButton)
    }
}

extension RxExcerciseResultViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let isFreeExercise = viewModel.data.typeID == ExerciseConstants.FREE_EXERCISE
        if let first = exerciseResult.listSmo2?.first,
           first.name == "1" && isFreeExercise == true {
            return String(Int(value))
        } else {
            return String(Int(value) * 5)
        }
    }
}

extension RxExcerciseResultViewController: HeaderBackDelegate {
    func onClickBack() {}
    
    func onClickShare() {
        setupShareView(isShare: true)
        let shareImage = self.contentView.takeScreenshot()
        shareOtherApp(text: nil, shareImage: shareImage, completion: {[weak self] in
            guard let self = self else { return }
            self.setupShareView(isShare: false)
        }, isJustShareImage: true)
    }
    
    private func setupShareView(isShare: Bool) {
        if isShare {
            userNicknameLabel.isHidden = false
            okButton.isHidden = true
            topLabelDate.constant = 64
            lblTitle.text = headerBack.titleLabel.text
            mapUIView.isHidden = true
            mapViewHeight.constant = 0
        } else {
            self.userNicknameLabel.isHidden = true
            self.okButton.isHidden = false
            topLabelDate.constant = 20
            lblTitle.text = nil
            if let type = viewModel.getExerciseTypeLabel(), (type == ExerciseConstants.RX_EXERCISE_TREADMILL || type == ExerciseConstants.FREE_EXERCISE_TREADMILL) == false {
                mapUIView.isHidden = false
                mapViewHeight.constant = 240
            }
        }
    }
}

extension RxExcerciseResultViewController: RxExcerciseResultModelDelegate {
    func didUpdateState(to state: RxExcerciseResultModelState) {
        switch state {
        case .didGetRxExcerciseResult:
            self.exerciseResult = viewModel.data
            setUpData()
            checkHeartrateData()
        case .hideSync(let isHidden):
            btnSync.isHidden = isHidden
//            okButton.isEnabled = isHidden
//            okButton.backgroundColor = isHidden == false ? UI.Color.btnBgDisableColor : UI.Color.btnBgColor
        case .failWithMessage(let alertString):
            showMessage(title: "Data upload fail", message: alertString, buttonTitle: "Retry", handle: { _ in
                // Retry
                self.viewModel.didTouchRetry()
            }, handlerOK: { _ in
                self.viewModel.didTouchOK()
            })
        case .exerciseUploading:
            showMessage(title: "", message: "Exercise is uploading, please wait")
        case .network(let state):
            networkStatusChanged(to: state)
        case .failAPI(let errSTr):
            showMessage(title: "API Error", message: errSTr)
        }
    }
}
