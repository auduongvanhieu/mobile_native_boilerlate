import Foundation
import UIKit

class RxExcerciseSelectTypeViewController: BaseViewController {
    @IBOutlet weak var lowView: UIView!
    @IBOutlet weak var highView: UIView!
    @IBOutlet weak var lowButton: UIButton!
    @IBOutlet weak var highButton: UIButton!
    @IBOutlet weak var lowMoreButton: UIButton!
    @IBOutlet weak var highMoreButton: UIButton!
    @IBOutlet weak var lowImageView: UIImageView!
    @IBOutlet weak var highImageView: UIImageView!
    @IBOutlet weak var lowTitleLabel: UILabel!
    @IBOutlet weak var highTitleLabel: UILabel!
    @IBOutlet weak var lowContentTextView: UITextView!
    @IBOutlet weak var highContentTextView: UITextView!

    let todayExercise = ExerciseHelper.getTodayExercise()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setUpData()
    }
    
    func setUpView() {
        // Set button click
        lowButton.addTarget(self, action: #selector(onClickLow), for: .touchUpInside)
        highButton.addTarget(self, action: #selector(onClickHigh), for: .touchUpInside)
        lowMoreButton.addTarget(self, action: #selector(onClickLowMore), for: .touchUpInside)
        highMoreButton.addTarget(self, action: #selector(onClickHighMore), for: .touchUpInside)
        // Set radius for view
        lowView.layer.cornerRadius = UI.Button.cornerRadius
        highView.layer.cornerRadius = UI.Button.cornerRadius
        lowContentTextView.text = "lowContentTextView".localized
        highContentTextView.text = "highContentTextView".localized
    }
    
    func setUpData() {
        if todayExercise.type == LTTestConstants.PRESCRIPTION_TYPE_LOW {
            setLowEnable()
            setHighDisable()
        } else {
            setLowEnable()
            setHighEnable()
        }
    }
    
    @objc func onClickLow(_ sender: UIButton) {
        LocalDataManager.intensityId = Constants.LOW_INTENSITY
        AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcercisePre(isLowIntensity: true), with: .push)
    }
    
    @objc func onClickHigh(_ sender: UIButton) {
        LocalDataManager.intensityId = Constants.HIGH_INTENSITY
        AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcercisePre(isLowIntensity: false), with: .push)
    }
    
    @objc func onClickLowMore(_ sender: UIButton) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseLowMore, with: .push)
    }
    
    @objc func onClickHighMore(_ sender: UIButton) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.excerciseHighMore, with: .push)
    }
    
    func setLowEnable() {
        lowView.layer.backgroundColor = UI.Color.exerciseLowIntensityBg.cgColor
        lowImageView.image = UI.Image.img_low_insensity
        lowTitleLabel.textColor = UIColor.white
        lowContentTextView.textColor = UIColor.white
        lowButton.isEnabled = true
        lowMoreButton.isEnabled = true
        lowMoreButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    func setHighEnable() {
        highView.layer.backgroundColor = UI.Color.exerciseHighIntensityBg.cgColor
        highImageView.image = UI.Image.img_high_intensity
        highTitleLabel.textColor = UIColor.white
        highContentTextView.textColor = UIColor.white
        highButton.isEnabled = true
        highMoreButton.isEnabled = true
        highMoreButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    func setLowDisable() {
        self.lowView.layer.backgroundColor = UI.Color.exercisePurposeDisableBg.cgColor
        lowImageView.image = UI.Image.img_low_insensity_disable
        lowTitleLabel.textColor = UI.Color.txtPlaceholderColor
        lowContentTextView.textColor = UI.Color.txtPlaceholderColor
        lowButton.isEnabled = false
        lowMoreButton.isEnabled = false
        lowMoreButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
    }
    
    func setHighDisable() {
        highView.layer.backgroundColor = UI.Color.exercisePurposeDisableBg.cgColor
        highImageView.image = UI.Image.img_high_intensity_disable
        highTitleLabel.textColor = UI.Color.txtPlaceholderColor
        highContentTextView.textColor = UI.Color.txtPlaceholderColor
        highButton.isEnabled = false
        highMoreButton.isEnabled = false
        highMoreButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
    }
}
