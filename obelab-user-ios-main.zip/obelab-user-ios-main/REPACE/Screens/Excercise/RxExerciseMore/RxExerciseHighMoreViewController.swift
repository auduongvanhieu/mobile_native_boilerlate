import UIKit

class RxExerciseHighMoreViewController: BaseViewController {
    
    @IBOutlet weak var tvGuide: UITextView!
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
    }
    
    func setUpView() {
        tvGuide.text = "tvGuideRxExerciseHighMoreViewController".localized
    }
}
