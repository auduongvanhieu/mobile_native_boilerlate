import UIKit

class RxExerciseLowMoreViewController: BaseViewController {
    
    @IBOutlet weak var lblTitleLowMore: UILabel!
    @IBOutlet weak var txtContentLowMore: UITextView!
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
    }
    
    func setUpView() {
        lblTitleLowMore.text = "lblTitleLowMore".localized
        txtContentLowMore.text = "txtContentLowMore".localized
    }
}
