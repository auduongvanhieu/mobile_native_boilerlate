import Foundation
import UIKit

class RxExercisePrepareViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var typeImage: UIImageView!
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var stageLabel: UILabel!
    @IBOutlet weak var warnButton: UIButton!
    @IBOutlet weak var headerBack: HeaderBack!
    
    @IBOutlet weak var lblStopRxExercise: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    var counter = Constants.LT_TEST_PREPARE_TIME_COUNTER
    var timer: Timer?
    var dicText: [Int: String] = [:]
    var isLowIntensity = false
    var isShowCalibration = true
    var isReceivedGainData = false
    var page = ""
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        headerBack.delegate = self
        Functions.startFakeGainData()
        setUpView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        showPopupCircle()
    }
    
    func showPopupCircle() {
        BluetoothHelper.startMeasure()
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkGainData), name: NotificationCenterHelper.BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION, object: nil)
        Functions.startFakeGainData()
        ProgressDialogViewController.showPopup(parentVC: self)
        Timer.scheduledTimer(withTimeInterval: Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_1, repeats: false) { _ in
            ProgressDialogViewController.hidePopup()
            self.startListenerGainData(title: nil, time: Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_2)
        }
    }
    
    private func startListenerGainData(title: String?, time: TimeInterval) {
        if self.isReceivedGainData == false {
            ProgressBarDialogViewController.showPopup(parentVC: self, title: title)
            Timer.scheduledTimer(withTimeInterval: time, repeats: false) { _ in
                ProgressBarDialogViewController.hidePopup()
                if self.isReceivedGainData == false {
                    self.doCalibrationProgress()
                }
            }
        }
    }
    
    private func doCalibrationProgress() {
        if isShowCalibration {
            isShowCalibration = false
            if let peripheral = BluetoothHelper.peripheral {
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA: peripheral])
            }
            BluetoothHelper.stopMeasure()
            BluetoothHelper.startMeasure()
            self.startListenerGainData(title: "Calibration in progress...".localized, time: 30)
        } else {
            if BluetoothHelper.isConnectedDevice == true {
                // Connected but it Abnormal
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_DISCONNECT_DEVICE_DATA, object: nil, userInfo: nil)
            } else {
                // Disconnect
                showDisconnectedDeviceAlert()
            }
        }
    }
    
    func removeObserveNotification() {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION, object: nil)
    }
    
    @objc func checkGainData() {
        if timer == nil {
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            timer?.tolerance = Constants.TIME_INTERVAL * 0.1
            Functions.startFakeMeasureData()
        }
        isReceivedGainData = true
        RealmHelper.share.cleanSmO2Object()
        ProgressDialogViewController.hidePopup()
        ProgressBarDialogViewController.hidePopup()
    }
    
    func setUpView() {
        lblStopRxExercise.text = "lblStopRxExercise".localized
        let todayExercise = ExerciseHelper.getTodayExercise()
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        let speedInUnit = Functions.kmToMile(km: todayExercise.todaySession?.speed).to1Decimal
        let unit = Functions.showUnitLabel(isSpeed: false)
        speedLabel.text = "\(speedInUnit)"
//        speedLabel.text = "\(String(describing: todayExercise.todaySession?.speed ?? 0))"
        stageLabel.text = "0\(String(describing: todayExercise.todaySession?.session ?? 0))"
        let startAt = Constants.LT_TEST_PREPARE_TIME_COUNTER
        let duration = (todayExercise.todaySession?.time ?? 0)
        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
            page = "Rx Exercise prepare Treadmil (page 7)"
            if LocalDataManager.profile?.gender == Constants.GENDER_MALE {
                typeImage.image = UIImage(named: "img_treadmill_man.png")
            } else {
                typeImage.image = UIImage(named: "img_treadmill_woman.png")
            }
            dicText[Constants.LT_TEST_PREPARE_TIME_COUNTER] = "Start running in \(startAt) seconds. Set treadmill speed to \(speedInUnit) \(unit) per hour. Run for \(duration) minutes, do not walk."
        } else {
            page = "Rx Exercise prepare Outdoor (page 7)"
            noteLabel.text = "maintain_your_pace_at".localized
            warnButton.setTitle("on_flat_outdoor_track".localized, for: .normal)
            if LocalDataManager.profile?.gender == Constants.GENDER_MALE {
                typeImage.image = UIImage(named: "img_outdoor_man.png")
            } else {
                typeImage.image = UIImage(named: "img_outdoor_woman.png")
            }
            dicText[Constants.LT_TEST_PREPARE_TIME_COUNTER] = "Start running in \(startAt) seconds. Maintain your pace at \(speedInUnit) \(unit) per hour. Run for \(duration) minutes, do not walk."
        }
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) updateCounter = \(counter)", message: "")
        if let speech = dicText[counter] {
            TextToSpeechHelper.speak(text: speech, countDown: counter, timeUp: Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter, page: "\(page) seesion \(stageLabel.text ?? "")")
            ProgressBarDialogViewController.hidePopup()
        }
        // Example functionality
        if counter > 0 {
            timerLabel.text = counter > 9 ? "\(counter)’’" : "0\(counter)’’"
        } else {
            if counter == 0 {
//                self.navigationController?.viewControllers.removeLast(1)
                Functions.showLog(title: "BLE -> ", message: "exerciseProgress START")
                AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseProgress(isLowIntensity: self.isLowIntensity), with: .push)
            }
        }
        counter -= 1
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopAll()
    }
    
    @IBAction func onClickStop(_ sender: Any) {
        if counter > 0 {
            BluetoothHelper.showStopProgressAlert(textStop: "stopRxExercise".localized, didStop: {[weak self] in
                BluetoothHelper.resetExerciseData()
                self?.stopAll()
            })
        }
    }
    
    func stopAll() {
        self.removeObserveNotification()
        self.timer?.invalidate()
        self.timer = nil
    }
}
extension RxExercisePrepareViewController: HeaderBackDelegate {
    func onClickShare() { }
    
    func onClickBack() {
        BluetoothHelper.stopMeasure()
        Functions.stopFakeDataLTTest()
        BluetoothHelper.resetExerciseData()
        stopAll()
    }
}
