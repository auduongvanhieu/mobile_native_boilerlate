import Foundation
import UIKit

class RxExercisePreViewController: BaseViewController {
    
    @IBOutlet weak var sessionLabel: UILabel!
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var intensityLabel: UILabel!
    @IBOutlet weak var intensityImageView: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var heartrateLabel: UILabel!
    @IBOutlet weak var sessionBottomLabel: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    let todayExercise = ExerciseHelper.getTodayExercise()
    var viewModel = RxExercisePreViewModel()
    var isLowIntensity = false
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
        setUpData()
    }
    
    func setUpView() {
        // Set radius for view
        cardView.layer.cornerRadius = UI.Button.cornerRadius
        viewModel.delegate = self
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
    }
    
    func setUpData() {
        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR {
            typeLabel.text = "title_exercise_rx_outdoor_running".localized
        }
        if !isLowIntensity {
            cardView.layer.backgroundColor = UI.Color.exerciseHighIntensityBg.cgColor
            intensityLabel.text = "title_exercise_high_intensity".localized
            intensityImageView.image = UI.Image.img_high_intensity
            
            timeLabel.text = "\(String(describing: todayExercise.ptMin ?? 0))"
            let speed = Functions.kmToMile(km: todayExercise.ptSpeed).to1Decimal
            speedLabel.text = "\(speed)"
//            speedLabel.text = "\(String(describing: todayExercise.ptSpeed ?? 0))"
            heartrateLabel.text = "<\(String(describing: todayExercise.todaySession?.heartRate ?? 0))"
        } else {
            timeLabel.text = "\(String(describing: todayExercise.leMin ?? 0))"
            let speed = Functions.kmToMile(km: todayExercise.leSpeed).to1Decimal
            speedLabel.text = "\(speed)"
//            speedLabel.text = "\(String(describing: todayExercise.leSpeed ?? 0))"
            heartrateLabel.text = "<\(String(describing: todayExercise.todaySession?.heartRate ?? 0))"
        }
//        timeLabel.text = "\(String(describing: todayExercise.leMin ?? 0))"
//        speedLabel.text = "\(String(describing: todayExercise.todaySession?.speed ?? 0))"
        let heartRate = todayExercise.todaySession?.heartRate ?? 0
        heartrateLabel.text = heartRate == 0 ? " < - " : " < \(String(describing: todayExercise.todaySession?.heartRate ?? 0))"
        let session = todayExercise.todaySession?.session ?? 0
        if session > 0 {
            if session > 99 {
                sessionLabel.text = "99+"
            } else if session < 10 {
                sessionLabel.text = "0\(session)"
            } else {
                sessionLabel.text = "\(session)"
            }
        } else {
            sessionLabel.text = nil
        }
//        sessionLabel.text = "0\(String(describing: todayExercise.todaySession?.session ?? 0))"
//        sessionLabel.text = sessionLabel.text?.replacingOccurrences(of: "01", with: "0\(String(describing: todayExercise.todaySession?.session ?? 0))")
    }
    
    func showAlertPracticedToday() {
        showMessage(title: "", message: "title_exercise_practiced_today".localized)
//        let alert = UIAlertController(title: "", message: "title_exercise_practiced_today".localized, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//        }))
//        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: { _ in
//        }))
//        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func onClickStart(_ sender: Any) {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            if Constants.IS_DEV || (LocalDataManager.batteryLevel ?? 0) >= Constants.BATTERY_LEVEL_WARNING {
                viewModel.checkExerciseToday()
            } else {
                showMessage(title: "", message: "Not enough battery.\nPlease recharge to start.".localized)
//                let alert = UIAlertController(title: "", message: "Not enough battery.\nPlease recharge to start.".localized, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//                }))
//                self.present(alert, animated: true, completion: nil)
            }
        } else {
            showDisconnectedDeviceAlert()
        }
    }
}

extension RxExercisePreViewController: RxExercisePreViewModelDelegate {
    func didUpdateState(to state: RxExercisePreViewModelState) {
        switch state {
        case .doExercise:
            AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcercisePrepare(isLowIntensity: self.isLowIntensity), with: .push)
        case .alertMessage:
            showAlertPracticedToday()
        case .network(let state):
            networkStatusChanged(to: state)
        }
    }
}
