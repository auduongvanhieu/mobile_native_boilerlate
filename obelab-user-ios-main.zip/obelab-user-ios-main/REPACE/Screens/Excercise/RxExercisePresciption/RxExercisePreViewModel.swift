import Foundation

protocol RxExercisePreViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: RxExercisePreViewModelState)
}

enum RxExercisePreViewModelState {
    case doExercise
    case alertMessage
    case network(state: NetworkState)
}

class RxExercisePreViewModel {
    
    weak var delegate: RxExercisePreViewModelDelegate?
    
    private var state: RxExercisePreViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    func checkExerciseToday() {
        state = .network(state: .loading)
        ExerciseServices.getExerciseHistoryToday(
            success: { [weak self] res in
                guard let self = self else {
                    return
                }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .doExercise
                } else {
                    self.state = .alertMessage
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
}
