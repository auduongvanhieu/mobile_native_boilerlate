import Foundation
import UIKit
import CoreLocation
import MapboxMaps

class RxExerciseProgressViewController: OutdoorViewController {
    
    @IBOutlet weak var testProgress: RepaceProgress!
    @IBOutlet weak var smO2Label: UILabel!
    @IBOutlet weak var heartRateLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var pauseButton: UIButton!
    
    @IBOutlet weak var lblUnitDistance: UILabel!
    var todayExercise = ExerciseHelper.getTodayExercise()
    var counterSum: Int!
    var counter: Int!
    var timer: Timer?
    var isPause = false
    var dicText: [Int: String] = [:]
    var isLowIntensity = false
    var previousDistance: Double = 0
    var page: String = ""
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        BluetoothHelper.isRunProgress = true
        if let index = self.navigationController?.viewControllers.firstIndex(where: {$0.isKind(of: RxExercisePrepareViewController.self) == true }) {
            self.navigationController?.viewControllers.remove(at: index)
        }
        timeLabel.text = "60 : 00"
        testProgress.lblTop.text = "Session"
        counterSum = (todayExercise.todaySession?.time ?? 0) * 60
        counter = (todayExercise.todaySession?.time ?? 0) * 60
        LocalDataManager.isSaveSmo2List = true
        setUpView()
        setupDataSpeech()
        // Setup timer
        timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        // Set receive measure data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveMeasureData(_:)), name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        // Set receive heartrate data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveHeartrateData(_:)), name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
    }
    
    func setupDataSpeech() {
        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
            // Treadmill
            if isLowIntensity {
                setupDataSpeechLowIntensity()
            } else {
                setupDataSpeechHightIntensity()
            }
        } else {
            // Outdoor
            if isLowIntensity {
                setupDataSpeechLowIntensityOutdoor()
            } else {
                setupDataSpeechHighIntensityOutdoor()
            }
        }
    }
    
    // LowIntensity Outdoor
    func setupDataSpeechLowIntensityOutdoor() {
        let keepRunning = "Keep running!"
        let letGo = "Let’s go!"
        let fiveMinute = 5 * 60
        var arrText: [String] = []
        if (todayExercise.todaySession?.time ?? 0) == 60 {
            // 60 minute slide 10
            page = "Rx exercise progress Outdoor Low Intensity Page 10"
            arrText = ["Start running", "Good start!", "Already 10 minutes!", keepRunning, letGo, keepRunning, "Halfway through!", letGo, "20 minutes to go!", keepRunning, "10 minutes to go!", "Almost there!", "Workout completed"]
        }
        for (ind, speech) in arrText.enumerated() {
            dicText[counterSum - ind * fiveMinute] = speech
        }
    }
    
    // HightIntensity Outdoor
    func setupDataSpeechHighIntensityOutdoor() {
        let keepRunning = "Keep running!"
        let letGo = "Let’s go!"
        let threeMinute = 3 * 60
        var arrText: [String] = []
        if (todayExercise.todaySession?.time ?? 0) == 30 {
            // 30 minute slide 13
            page = "Rx exercise progress Outdoor High Intensity Page 13"
            arrText = ["Start running", "Good start!", "Already 6 minutes!", keepRunning, letGo, "Halfway through!"]
            dicText[10 * 60] = "10 minutes to go!"
            dicText[5 * 60] = "Almost there!"
            dicText[0] = "Workout completed"
        }
        for (ind, speech) in arrText.enumerated() {
            dicText[counterSum - ind * threeMinute] = speech
        }
    }
    
    // LowIntensity TREADMILL
    func setupDataSpeechLowIntensity() {
        let keepRunning = "Keep running!"
        let letGo = "Let’s go!"
        let fiveMinute = 5 * 60
        var arrText: [String] = []
        if (todayExercise.todaySession?.time ?? 0) == 60 {
            // 60 minute slide 8
            page = "Rx exercise progress Treadmil Low Intensity 60 minutes Page 8"
            arrText = ["Start running", "Good start!", "Already 10 minutes!", keepRunning, letGo, keepRunning, "Halfway through!", letGo, "20 minutes to go!", keepRunning, "10 minutes to go!", "Almost there!", "Workout completed"]
        } else if (todayExercise.todaySession?.time ?? 0) == 90 {
            // 90 minute slide 9
            page = "Rx exercise progress Treadmil Low Intensity 90 minutes Page 9"
            arrText = ["Start running", "Good start!", "Already 10 minutes!", keepRunning, letGo, keepRunning, letGo, keepRunning, letGo, "Halfway through!", keepRunning, letGo, "30 minutes to go!", keepRunning, "20 minutes to go!", letGo, "10 minutes to go!", "Almost there!", "Workout completed"]
        }
        for (ind, speech) in arrText.enumerated() {
            dicText[counterSum - ind * fiveMinute] = speech
        }
    }
    
    // HightIntensity TREADMILL
    func setupDataSpeechHightIntensity() {
        let keepRunning = "Keep running!"
        let letGo = "Let’s go!"
        let threeMinute = 3 * 60
        var arrText: [String] = []
        if (todayExercise.todaySession?.time ?? 0) == 30 {
            // 30 minute slide 11
            page = "Page 11"
            arrText = ["Start running", "Good start!", "Already 6 minutes!", keepRunning, letGo, "Halfway through!"]
            dicText[10 * 60] = "10 minutes to go!"
            dicText[5 * 60] = "Almost there!"
            dicText[0] = "Workout completed"
        } else if (todayExercise.todaySession?.time ?? 0) == 15 {
            // 15 minute slide 12
            page = "Page 12"
            arrText = ["Start running", "Good start!", "Almost halfway through!", "6 minutes to go!", "Almost there!", "Workout completed"]
        }
        for (ind, speech) in arrText.enumerated() {
            dicText[counterSum - ind * threeMinute] = speech
        }
    }
    
    func setUpView() {
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
        testProgress.setStage(value: todayExercise.todaySession?.session ?? 0)
        smO2Label.text = "0"
        distanceLabel.text = "0.0"
        heartRateLabel.text = "-"
        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
            testProgress.setSpeed(value: todayExercise.todaySession?.speed ?? 0)
        } else { // Outdoor
            testProgress.setSpeedStandard(value: todayExercise.todaySession?.speed ?? 0)
            testProgress.setSpeed(value: 0)
            testProgress.lbSpeedStandard.isHidden = false
            // Setup location
//            if CLLocationManager.locationServicesEnabled() {
//                locationManager.delegate = self
//                locationManager.desiredAccuracy = kCLLocationAccuracyBest
//                locationManager.distanceFilter = kCLDistanceFilterNone
//                locationManager.pausesLocationUpdatesAutomatically = true
//                locationManager.activityType = .fitness
//                locationManager.requestLocation()
//                locationManager.startUpdatingLocation()
//            }
        }
        pauseButton.setImage(UI.Icon.ic_pause, for: .normal)
    }
    
    @objc func onReceiveMeasureData(_ notification: NSNotification) {
        if let measureData = notification.userInfo?[NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA] as? RepaceMeasureModel {
            smO2Label.text = "\(Functions.toSmO2(byteArray: measureData.rSO2))"
        }
    }
    
    @objc func onReceiveHeartrateData(_ notification: NSNotification) {
        if let heartrate = notification.userInfo?[NotificationCenterHelper.HR_HEART_RATE_DATA] as? Double {
            DispatchQueue.main.async {
                self.heartRateLabel.text = "\(Int(heartrate))"
            }
        }
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) mytv updateCounter = \(String(describing: counter))", message: "")
        if counter > 0 {
            if counter == counterSum {
                TextToSpeechHelper.speak(text: "Start running", countDown: counter, timeUp: counterSum - counter, page: "\(page) session \(todayExercise.todaySession?.session ?? 0)")
            }
            counter -= 1
            let minStr = counter / 60 > 9 ? "\(counter / 60)" : "0\(counter / 60)"
            let secondStr = counter % 60 > 9 ? "\(counter % 60)" : "0\(counter % 60)"
            timeLabel.text = "\(minStr) : \(secondStr)"
            if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
                distance += (todayExercise.todaySession?.speed ?? 0) / Double(Constants.H_TO_S_COEFFICIENT)
                distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
                if isLowIntensity {
                    updateSpeechLowIntensity(counter: counter)
                } else {
                    updateSpeechHighIntensity(counter: counter)
                }
            } else {
                if isLowIntensity {
                    updateSpeechLowIntensityOutdoor(counter: counter)
                } else {
                    updateSpeechHighIntensityOutdoor(counter: counter)
                }
            }
            if counter % 300 == 0 && counter > 0 {
                period += 1
                BluetoothHelper.saveSmo2AndHeartrateData()
            }
        } else {
            BluetoothHelper.stopMeasure()
            BluetoothHelper.isRunProgress = false
            BluetoothHelper.saveSmo2AndHeartrateData()
            period += 1
            // stop timer
            stopAll()
            AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseCompleted(title: "RX EXERCISE"), with: .push)
            self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
        }
        if counterSum != 0 {
            let progress = (counterSum - counter) * 100 / counterSum
            testProgress.setValue(value: Double(progress))
        }
    }  
    
    // LowIntensity Outdoor 60 minute
    func updateSpeechLowIntensityOutdoor(counter: Int) {
        updateSpeechByTime(counter: counter, periodTime: 5)
    }
    
    // HighIntensity Outdoor 30 minute
    func updateSpeechHighIntensityOutdoor(counter: Int) {
        updateSpeechByTime(counter: counter, periodTime: 3)
    }
    
    // LowIntensity TREADMILL 60 or 90 minutes
    func updateSpeechLowIntensity(counter: Int) {
        updateSpeechByTime(counter: counter, periodTime: 5)
    }
    
    // HighIntensity TREADMILL
    func updateSpeechHighIntensity(counter: Int) {
        updateSpeechByTime(counter: counter, periodTime: 3)
    }
    
    // periodTime: minute
    private func updateSpeechByTime(counter: Int, periodTime: Int) {
        let unit = Functions.showUnitLabel(isSpeed: false)
        let distanceUnit = Functions.kmToMile(km: distance)
        if counter == 0 {
            let ave = Functions.kmToMile(km: distance / Double(counterSum / 60) * 60)
            let speech = "Workout completed! Time \(todayExercise.todaySession?.time ?? 0) minutes, distance \(distanceUnit) \(unit), average pace \(ave) \(unit) per hour"
            TextToSpeechHelper.speak(text: speech, countDown: counter, timeUp: counterSum - counter, page: "\(page) session \(todayExercise.todaySession?.session ?? 0)")
            saveData()
        } else {
            if let speech = dicText[counter] {
                let minute = (counterSum - counter) / 60
                let ave = Functions.kmToMile(km: distance / Double(minute) * 60)
                var speechText = "Time \(minute) minutes, distance \(distanceUnit) \(unit), \(periodTime) minutes average pace \(ave) \(unit) per hour. \(speech)"
                if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_OUTDOOR {
                    let text = getAlertSpeedDidGone(periodTime: periodTime)
                    if text.isEmpty == false {
                        speechText += ". \(text)"
                    }
                }
                TextToSpeechHelper.speak(text: speechText, countDown: counter, timeUp: counterSum - counter, page: "\(page) session \(todayExercise.todaySession?.session ?? 0)")
            }
        }
    }
    
    private func getAlertSpeedDidGone(periodTime: Int) -> String {
        let deltaDistance = distance - previousDistance
        let speed = deltaDistance / Double(periodTime) * 60 // km per hour
        let speedTodaySession = Functions.kmToMile(km: todayExercise.todaySession?.speed)
        let unit = Functions.showUnitLabel(isSpeed: false)
        previousDistance = distance
        if speed > speedTodaySession * 1.1 {
            return "Slow down to keep the pace at \(speedTodaySession) \(unit) per hour."
        } else if speed < speedTodaySession * 0.9 {
            return "Speed up to keep the pace at \(speedTodaySession) \(unit) per hour."
        }
        return ""
    }
    
    private func saveData() {
        LocalDataManager.isSaveSmo2List = false
        Functions.stopFakeDataLTTest()
        if LocalDataManager.exerciseType == ExerciseConstants.RX_EXERCISE_TREADMILL {
            LocalDataManager.exerciseResult.speedMin = todayExercise.todaySession?.speed ?? 0
            LocalDataManager.exerciseResult.speedMax = todayExercise.todaySession?.speed ?? 0
            LocalDataManager.exerciseResult.speedAvg = Double(todayExercise.todaySession?.speed ?? 0)
        } else {
            LocalDataManager.exerciseResult.speedAvg = countSpeed > 0 ? sumSpeed / Double(countSpeed) : sumSpeed
        }
        LocalDataManager.exerciseResult.totalDistance = distance
        LocalDataManager.exerciseResult.totalDuration = counterSum - counter
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopAll()
    }
    
    func stopAll() {
        locationManager.stopUpdatingLocation()
        self.removeObserveNotification()
        self.timer?.invalidate()
        self.timer = nil
    }
    
    @IBAction func onClickStop(_ sender: Any) {
        if counter > 0 {
            BluetoothHelper.showStopProgressAlert(textStop: "stopRxExercise".localized, didStop: {[weak self] in
                guard let self = self else { return }
                BluetoothHelper.resetExerciseData()
                self.stopAll()
                TextToSpeechHelper.speak(text: "Workout stopped.", countDown: self.counter, timeUp: self.counterSum - self.counter, page: "\(self.page) session \(self.todayExercise.todaySession?.session ?? 0)")
            })
        }
//        BluetoothHelper.saveSmo2AndHeartrateData()
//        TextToSpeechHelper.speak(text: "Workout stopped.", countDown: self.counter, timeUp: self.counterSum - self.counter, page: "\(page0 session \(todayExercise.todaySession?.session ?? 0)")
//        AppNavigator.shared.navigate(to: ExcerciseRoutes.exerciseCompleted, with: .push)
//        self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
    }
    
    func removeObserveNotification() {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
    }
    
    @IBAction func onClickPause(_ sender: Any) {
        if isPause == false {
            isPause = true
            timer?.invalidate()
            pauseButton.setImage(UI.Icon.ic_play, for: .normal)
            TextToSpeechHelper.speak(text: "Workout paused.", countDown: self.counter, timeUp: self.counterSum - self.counter, page: "\(page) session \(todayExercise.todaySession?.session ?? 0)")
        } else {
            isPause = false
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            pauseButton.setImage(UI.Icon.ic_pause, for: .normal)
            TextToSpeechHelper.speak(text: "Workout resumed.", countDown: self.counter, timeUp: self.counterSum - self.counter, page: "\(page) session \(todayExercise.todaySession?.session ?? 0)")
        }
        BluetoothHelper.pauseMeasure(isPause: isPause)
    }
    
    override func updateLocationInfo(speed: Double) {
        super.updateLocationInfo(speed: speed)
        let speedTodaySession = todayExercise.todaySession?.speed ?? 1
        if speed > speedTodaySession {
            testProgress.warningToSpeedDown()
        } else if speed < speedTodaySession {
            testProgress.warningToSpeedUp()
        } else {
            testProgress.hideWarning()
        }
        // Check max speed, min speed
        var exerciseResult = LocalDataManager.exerciseResult
        if exerciseResult.speedMax == 0 || (exerciseResult.speedMax ?? 0 < speed) {
            exerciseResult.speedMax = speed
        }
        if exerciseResult.speedMin == 0 || (exerciseResult.speedMin ?? 0 > speed && speed != 0) {
            exerciseResult.speedMin = speed
        }
        LocalDataManager.exerciseResult = exerciseResult
        let value = speed / speedTodaySession * 100
        testProgress.setSpeed(value: speed)
//        testProgress.setValue(value: value)
        Functions.showLog(title: "speed = \(speed) speedTodaySession = \(speedTodaySession) value = \(value)", message: "")
        distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
    }
}

//extension RxExerciseProgressViewController: CLLocationManagerDelegate {
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        let currentLocation: CLLocation = locations[0] as CLLocation
//        Functions.showLog(title: "Location value listener", message: "(\(currentLocation.coordinate.latitude),\(currentLocation.coordinate.longitude))")
//        if let oldLocation = oldLocation {
//            let distanceDelta = Functions.getDistanceFrom2Coordinate(firstLocation: currentLocation, secondLocation: oldLocation)
//            let speed = (distanceDelta / (timeDelta / Double(Constants.H_TO_S_COEFFICIENT))).to1Decimal
//            let speed = currentLocation.speed == -1 ? 0 : currentLocation.speed * 3.6
//            if speed < Constants.HUMAN_MAX_SPEED {
//                let speedTodaySession = todayExercise.todaySession?.speed ?? 0
//                Functions.showLog(title: "Location speed", message: speed)
//                if speed > speedTodaySession {
//                    testProgress.warningToSpeedDown()
//                } else if speed < speedTodaySession {
//                    testProgress.warningToSpeedUp()
//                } else {
//                    testProgress.hideWarning()
//                }
//                // Sum speed in this stage
//                sumSpeed += speed
//                countSpeed += 1
//                // Check max speed, min speed
//                if LocalDataManager.exerciseResult.speedMax == 0 || (LocalDataManager.exerciseResult.speedMax ?? 0 < speed) {
//                    LocalDataManager.exerciseResult.speedMax = speed
//                }
//                if LocalDataManager.exerciseResult.speedMin == 0 || (LocalDataManager.exerciseResult.speedMin ?? 0 > speed && speed != 0) {
//                    LocalDataManager.exerciseResult.speedMin = speed
//                }
//                // Save data
//                LocalDataManager.exerciseResult.listLocation?.append(LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis()))
//                distance += distanceDelta
//                testProgress.setFakeSpeed(speed: 3.6*currentLocation.speedAccuracy)
//                testProgress.setSpeed(value: speed)
//                testProgress.setValue(value: distance * 100 / ((todayExercise.todaySession?.speed ?? 0) * (Double(counterSum) / Constants.H_TO_S_COEFFICIENT)))
//                // Show data
//                distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
//            }
//            if speed > Constants.HUMAN_MAX_SPEED {
//                Functions.showLog(title: "Location speed \(speed) over human speed \(Constants.HUMAN_MAX_SPEED)", message: "")
//            }
//            let speedTodaySession = todayExercise.todaySession?.speed ?? 0
//            if speed > speedTodaySession {
//                testProgress.warningToSpeedDown()
//            } else if speed < speedTodaySession {
//                testProgress.warningToSpeedUp()
//            } else {
//                testProgress.hideWarning()
//            }
//            // Sum speed in this stage
//            sumSpeed += speed
//            countSpeed += 1
//            // Check max speed, min speed
//            var exerciseResult = LocalDataManager.exerciseResult
//            if exerciseResult.speedMax == 0 || (exerciseResult.speedMax ?? 0 < speed) {
//                exerciseResult.speedMax = speed
//            }
//            if exerciseResult.speedMin == 0 || (exerciseResult.speedMin ?? 0 > speed && speed != 0) {
//                exerciseResult.speedMin = speed
//            }
//            // Save data
//            let model = LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis())
//            RealmHelper.share.saveLocationDB(index: countSpeed, model: model, period: "\(period * 5)")
//            LocalDataManager.exerciseResult = exerciseResult
//            distance += distanceDelta
//                testProgress.setFakeSpeed(speed: 3.6*currentLocation.speedAccuracy)
//            testProgress.setSpeed(value: speed)
//            let speedToday = todayExercise.todaySession?.speed ?? 1
//            Functions.showLog(title: "Location update distanceDelta = \(distanceDelta) distance = \(distance) speed \(speed) speedToday = \(speedToday)", message: "")
//            testProgress.setValue(value: distance * 100 / (speedToday * (Double(counterSum) / Constants.H_TO_S_COEFFICIENT)))
//            // Show data
//            distanceLabel.text = "\(Functions.kmToMile(km: distance).to1Decimal)"
//        }
//        oldLocation = currentLocation
//    }
//}
