import Foundation
import UIKit

class RxExerciseRestViewController: BaseViewController {
        
    @IBOutlet weak var sessionLabel: UILabel!
    @IBOutlet weak var sessionBottomLabel: UILabel!

    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
    }
    
    func setUpView(){
        let todayExercise = ExerciseHelper.getTodayExercise()
        sessionLabel.text = "0\(String(describing: todayExercise.todaySession?.session ?? 0))"
        if let text = sessionBottomLabel.text {
            sessionBottomLabel.text = text.replacingOccurrences(of: "XX", with: "0\(String(describing: todayExercise.todaySession?.session ?? 0))")
        }
    }
    
    @IBAction func onClickNext(_ sender: Any) {
        AppNavigator.shared.pop()
    }
}
