//
//  ExcerciseStatisticViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/14/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation

class ExcerciseStatisticViewController: BaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btnRxExcercise_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.rxExcerciseStatistic, with: .push)
    }
    
    @IBAction func btnFreeExcercise_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: ExcerciseRoutes.freeExcerciseStatistic, with: .push)
    }
}
