//
//  FreeExcerciseStatisticViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/14/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class FreeExcerciseStatisticViewController: BaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func btnOutdoor_Click(_ sender: Any) {
        if Constants.IS_DISABLE_OUTDOOR_EXERCISE == true {
            showMessage(title: "", message: "Outdoor update coming soon!".localized, handler: nil)
        } else {
            goToDetail(ExerciseConstants.EX_OUTDOOR)
        }
    }
    @IBAction func btnTreadmill(_ sender: Any) {
        goToDetail(ExerciseConstants.EX_TREADMILL)
    }
    @IBAction func btnAll_Click(_ sender: Any) {
        goToDetail()
    }
    
    func goToDetail(_ activity: String = "") {
        let detailPage = ExcerciseRoutes.details.screen as? StatisticDetailViewController ?? StatisticDetailViewController()
        detailPage.viewModel = StatisticDetailViewModel()
        detailPage.viewModel.activityName = activity
        detailPage.viewModel.exerciseType = "free_exercise"
        self.navigationController?.pushViewController(detailPage, animated: true)
    }
    
}
