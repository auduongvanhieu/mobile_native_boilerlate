//
//  StatisticCompleteDetailViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/22/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import Charts
import UIKit

class StatisticCompleteDetailViewController: BaseViewController {
    
    var viewModel: StatisticCompleteDetailViewModel!
    var chartAvgSpeedValues: [BarChartDataEntry] = []
    var chartMaxSpeedValues: [BarChartDataEntry] = []
    var chartMinSpeedValues: [BarChartDataEntry] = []
    var chartAvgHRValues: [BarChartDataEntry] = []
    var chartMaxHRValues: [BarChartDataEntry] = []
    var chartMinHRValues: [BarChartDataEntry] = []
    var chartAvgSmO2Values: [BarChartDataEntry] = []
    var chartMaxSmO2Values: [BarChartDataEntry] = []
    var chartMinSmO2Values: [BarChartDataEntry] = []
    
    var chartDistanceValues: [BarChartDataEntry] = []
    
    var chartView = CombinedChartView()
    var lineChartView = LineChartView()
    var days: [String] = []
    
    @IBOutlet weak var vwChartCointainer2: UIStackView!
    @IBOutlet weak var vwChartContainer: UIStackView!
    
    @IBOutlet weak var lbSmO2Min: UILabel!
    @IBOutlet weak var lbSmO2Max: UILabel!
    @IBOutlet weak var lbSmO2Avg: UILabel!
    
    @IBOutlet weak var lbHRMin: UILabel!
    @IBOutlet weak var lbHRMax: UILabel!
    @IBOutlet weak var lbHRAvg: UILabel!
    
    @IBOutlet weak var lbDuration: UILabel!
    @IBOutlet weak var lbDistance: UILabel!
    @IBOutlet weak var lbCalorie: UILabel!

    @IBOutlet weak var lbSpeedMax: UILabel!
    @IBOutlet weak var lbSpeedAvg: UILabel!
    @IBOutlet weak var lbPace: UILabel!
    
    @IBOutlet weak var lbDateRange: UILabel!
    
    @IBOutlet weak var header: HeaderBack!
    
    @IBOutlet weak var lblUnitAvgSpeed: UILabel!
    @IBOutlet weak var lblUnitMaxSpeed: UILabel!
    @IBOutlet weak var lblDistanceSummary: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    @IBOutlet weak var lblUnitDistance: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // viewModel = StatisticCompleteDetailViewModel()
        viewModel.delegate = self
        initChart()
        initChart2()
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
        lblDistanceSummary.text = Functions.showUnitLabel(isSpeed: false)
        lblUnitAvgSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitMaxSpeed.text = Functions.showUnitLabel(isSpeed: true)
        viewModel?.getExerciseStatisticByDay()
    }
    
    func initChart2() {
        lineChartView.legend.enabled = false
        lineChartView.leftAxis.labelTextColor = .white
        lineChartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.valueFormatter = self
        lineChartView.xAxis.labelTextColor = .white
        lineChartView.xAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.rightAxis.labelTextColor = .white
        lineChartView.leftAxis.axisMinimum = 0.0
        lineChartView.leftAxis.axisMaximum = 100.0
        lineChartView.rightAxis.axisMinimum = 0.0
        lineChartView.rightAxis.axisMaximum = 200.0
        lineChartView.xAxis.spaceMin = 0.3
        lineChartView.xAxis.spaceMax = 0.3
        lineChartView.xAxis.granularityEnabled = true
        lineChartView.xAxis.granularity = 1
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.doubleTapToZoomEnabled = false
        lineChartView.scaleXEnabled = false
        lineChartView.scaleYEnabled = false
        lineChartView.dragEnabled = false
        vwChartCointainer2.addArrangedSubview(lineChartView)
    }
    
    func initChart() {
        var max: Double = 500.0
        if viewModel.type == "1" {
            max = 50.0
        } else if viewModel.type == "2" {
            max = 200.0
        }
        chartView.legend.enabled = false
        chartView.leftAxis.labelTextColor = .white
        chartView.leftAxis.axisMinimum = 0.0
        chartView.leftAxis.axisMaximum = max
        chartView.rightAxis.axisMinimum = 0.0
        chartView.rightAxis.axisMaximum = 100.0
        chartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        chartView.xAxis.labelPosition = .bottom
        chartView.xAxis.valueFormatter = self
        chartView.xAxis.labelTextColor = .white
        chartView.xAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        chartView.xAxis.spaceMin = 0.3
        chartView.xAxis.spaceMax = 0.3
        chartView.rightAxis.labelTextColor = .white
        chartView.xAxis.granularityEnabled = true
        chartView.xAxis.granularity = 1
        chartView.xAxis.drawGridLinesEnabled = false
        chartView.leftAxis.drawGridLinesEnabled = false
        chartView.drawOrder = [DrawOrder.bar.rawValue,
                               DrawOrder.line.rawValue,
                               DrawOrder.line.rawValue]
        chartView.doubleTapToZoomEnabled = false
        chartView.scaleXEnabled = false
        chartView.scaleYEnabled = false
        chartView.dragEnabled = false
        vwChartContainer.addArrangedSubview(chartView)
    }
    
    func setupBarData(_ values: [BarChartDataEntry], _ color: UIColor, _ label: String ) -> BarChartData {
        let set1 = BarChartDataSet(entries: values, label: label)
        set1.setColor(color)
        set1.drawValuesEnabled = false
        
        let data = BarChartData(dataSets: [set1])
        data.barWidth = 0.45
        return data
    }
    
    func resetAllChartData() {
        chartDistanceValues.removeAll()
        chartAvgSpeedValues.removeAll()
        chartMinSpeedValues.removeAll()
        chartMaxSpeedValues.removeAll()
        chartAvgHRValues.removeAll()
        chartMinHRValues.removeAll()
        chartMaxHRValues.removeAll()
        chartAvgSmO2Values.removeAll()
        chartMinSmO2Values.removeAll()
        chartMaxSmO2Values.removeAll()
    }
    
    func bindAverage() {
        let date = Functions.convertDateStrToDate(dateStr: viewModel.date, inputFormat: "yyyy-MM-dd")
        switch viewModel.type {
        case "1":
            lbDateRange.text = Functions.dateToString(date: date, outFormat: "MMM dd, yyyy").uppercased()
            header.setTitle(title: "STATISTICS BY DAY")
        case "2":
            let next7Days = Calendar.current.date(byAdding: .day, value: 6, to: date) ?? date
            let dateStr = Functions.dateToString(date: next7Days, outFormat: "MMM dd, yyy")
            let startDateStr = Functions.dateToString(date: date, outFormat: "MMM dd")
            lbDateRange.text = "\(startDateStr) ~ \(dateStr)".uppercased()
            header.setTitle(title: "STATISTICS BY WEEK")
        case "3":
            lbDateRange.text = Functions.dateToString(date: date, outFormat: "MMM, yyyy").uppercased()
            header.setTitle(title: "STATISTICS BY MONTH")
        default:
            lbDateRange.text = nil
        }
        if let model = viewModel.exerciseStatisticAvg {
            lbSmO2Min.text = String(model.smO2Min?.to1Decimal ?? 0)
            lbSmO2Max.text = String(model.smO2Max?.to1Decimal ?? 0)
            lbSmO2Avg.text = String(model.smO2Avg?.to1Decimal ?? 0)
            
            lbSpeedAvg.text = String(Functions.kmToMile(km: model.speedAvg).to1Decimal)
            lbSpeedMax.text = String(Functions.kmToMile(km: Double(model.speedMax ?? 0)).to1Decimal)
//            lbSpeedAvg.text = String(model.speedAvg?.to1Decimal ?? 0)
//            lbSpeedMax.text = String(model.speedMax ?? 0)
            let avgHeartrate = Int((model.heartRateAvg ?? 0).rounded(.toNearestOrAwayFromZero))
            lbHRAvg.text = "\(avgHeartrate)"
            lbHRMax.text = String(model.heartRateMax ?? 0)
            lbHRMin.text = String(model.heartRateMin ?? 0)
            
            lbDistance.text = String(Functions.kmToMile(km: model.distance).to1Decimal)
//            lbDistance.text = String(model.distance?.to1Decimal ?? 0)
            lbDuration.text = Functions.getTimeDisplayStrFromSeconds(Int(model.duration ?? 0))
            lbCalorie.text = ""
            lbPace.text = ""
        }
    }
    
    func setupChartData() {
        var index: Double = 0
        resetAllChartData()
        if !(viewModel?.exerciseStatisticList.isEmpty ?? true) {
            let itemForDay = ["1st", "2nd", "3rd"]
            for month in self.viewModel.exerciseStatisticList {
                var dayStr = ""
                if viewModel.type == "1" {
                    if index > 2 {
                        dayStr = "\(index + 1)th"
                    } else {
                        dayStr = itemForDay[Int(index)]
                    }
                } else if viewModel.type == "2" {
                    if let date = month.date {
                        let dateConvert = Functions.convertDateStrToDate(dateStr: date, inputFormat: "yyyy-MM-dd")
                        dayStr = Functions.dateToString(date: dateConvert, outFormat: "MM/dd")
                    }
                } else if viewModel.type == "3" {
                    if let date = month.date {
                        let dateConvert = Functions.convertDateStrToDate(dateStr: date, inputFormat: "yyyy-MM-dd")
                        let endDate = Calendar.current.date(byAdding: .day, value: 6, to: dateConvert) ?? dateConvert
                        let startDtStr = Functions.dateToString(date: dateConvert, outFormat: "MM/dd")
                        let endDateStr = Functions.dateToString(date: endDate, outFormat: "dd")
                        dayStr = "\(startDtStr)-\(endDateStr)"
                    }
                }
               
                days.append(dayStr)
                let distance = Functions.kmToMile(km: Double(month.distance ?? 0)).to1Decimal
                chartDistanceValues.append(BarChartDataEntry(x: index, y: distance))
                let avgSpeed = Functions.kmToMile(km: Double(month.speedAvg ?? 0)).to1Decimal
                chartAvgSpeedValues.append(BarChartDataEntry(x: index, y: avgSpeed))
                let minSpeed = Functions.kmToMile(km: Double(month.speedMin ?? 0)).to1Decimal
                chartMinSpeedValues.append(BarChartDataEntry(x: index, y: minSpeed))
                let maxSpeed = Functions.kmToMile(km: Double(month.speedMax ?? 0)).to1Decimal
                chartMaxSpeedValues.append(BarChartDataEntry(x: index, y: maxSpeed))
                
                chartAvgSmO2Values.append(BarChartDataEntry(x: index, y: Double(month.smO2Avg ?? 0)))
                chartMinSmO2Values.append(BarChartDataEntry(x: index, y: Double(month.smO2Min ?? 0)))
                chartMaxSmO2Values.append(BarChartDataEntry(x: index, y: Double(month.smO2Max ?? 0)))
                
                chartAvgHRValues.append(BarChartDataEntry(x: index, y: Double(month.heartRateAvg ?? 0)))
                chartMinHRValues.append(BarChartDataEntry(x: index, y: Double(month.heartRateMin ?? 0)))
                chartMaxHRValues.append(BarChartDataEntry(x: index, y: Double(month.heartRateMax ?? 0)))
                index += 1
            }
        }
    }
    
    func setupLineData() -> LineChartData {
        
        let set1 = LineChartDataSet(entries: chartAvgSpeedValues, label: "Avg. Speed")
        set1.setColor(UI.Color.violetColor)
        set1.drawValuesEnabled = false
        set1.lineWidth = 2
        set1.circleColors = [.white]
        set1.circleHoleColor = UI.Color.violetColor
        set1.circleHoleRadius = 3
        set1.circleRadius = 4
        set1.axisDependency = .right
        
        let set2 = LineChartDataSet(entries: chartMaxSpeedValues, label: "Max. Speed")
        set2.setColor(UI.Color.pinkColor)
        set2.drawValuesEnabled = false
        set2.lineWidth = 2
        set2.circleColors = [.white]
        set2.circleHoleColor = UI.Color.pinkColor
        set2.circleRadius = 4
        set2.circleHoleRadius = 3
        set2.axisDependency = .right
        
        let set3 = LineChartDataSet(entries: chartMinSpeedValues, label: "Min. Speed")
        set3.setColor(UI.Color.lightPinkColor)
        set3.drawValuesEnabled = false
        set3.lineWidth = 2
        set3.circleColors = [.white]
        set3.circleHoleColor = UI.Color.lightPinkColor
        set3.circleRadius = 4
        set3.circleHoleRadius = 3
        set3.axisDependency = .right
        
        let data = LineChartData(dataSets: [set1, set2, set3])
        return data
    }
    
    func setBarChart() {
        let data = CombinedChartData()
        data.lineData = setupLineData()
        
        data.barData = setupBarData(chartDistanceValues, UI.Color.orangeColor, "Distance")

        chartView.xAxis.axisMaximum = data.xMax + 0.25
        
        chartView.data = data
    }
    
    func setLineChart() {
        let set1 = LineChartDataSet(entries: chartMinSmO2Values, label: "Min. SmO2")
        set1.setColor(UI.Color.lightBlueColor)
        set1.drawValuesEnabled = false
        set1.lineWidth = 2
        set1.circleColors = [.white]
        set1.circleHoleColor = UI.Color.lightBlueColor
        set1.circleRadius = 4
        set1.circleHoleRadius = 3
        
        let set2 = LineChartDataSet(entries: chartMaxSmO2Values, label: "Max. SmO2")
        set2.setColor(UI.Color.highBlueColor)
        set2.drawValuesEnabled = false
        set2.lineWidth = 2
        set2.circleColors = [.white]
        set2.circleHoleColor = UI.Color.highBlueColor
        set2.circleRadius = 4
        set2.circleHoleRadius = 3
        
        let set3 = LineChartDataSet(entries: chartAvgSmO2Values, label: "Avg. SmO2")
        set3.setColor(UI.Color.blueColor)
        set3.drawValuesEnabled = false
        set3.lineWidth = 2
        set3.circleColors = [.white]
        set3.circleHoleColor = UI.Color.blueColor
        set3.circleRadius = 4
        set3.circleHoleRadius = 3
        
        let set4 = LineChartDataSet(entries: chartMinHRValues, label: "Min. HR")
        set4.setColor(UI.Color.lightPinkColor)
        set4.drawValuesEnabled = false
        set4.lineWidth = 2
        set4.circleColors = [.white]
        set4.circleHoleColor = UI.Color.lightPinkColor
        set4.circleRadius = 4
        set4.circleHoleRadius = 3
        set4.axisDependency = .right
        
        let set5 = LineChartDataSet(entries: chartMaxHRValues, label: "Max. HR")
        set5.setColor(UI.Color.violetColor)
        set5.drawValuesEnabled = false
        set5.lineWidth = 2
        set5.circleColors = [.white]
        set5.circleHoleColor = UI.Color.violetColor
        set5.circleRadius = 4
        set5.circleHoleRadius = 3
        set5.axisDependency = .right
        
        let set6 = LineChartDataSet(entries: chartAvgHRValues, label: "Avg. HR")
        set6.setColor(UI.Color.pinkColor)
        set6.drawValuesEnabled = false
        set6.lineWidth = 2
        set6.circleColors = [.white]
        set6.circleHoleColor = UI.Color.pinkColor
        set6.circleRadius = 4
        set6.circleHoleRadius = 3
        set6.axisDependency = .right
        
        lineChartView.data = LineChartData(dataSets: [set1, set2, set3, set3, set5, set6])
    }
}

extension StatisticCompleteDetailViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        days[Int(value) % days.count]
    }
}

extension StatisticCompleteDetailViewController: StatisticCompleteDetailViewModelDelegate {
    func didUpdateState(to state: StatisticCompleteDetailViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getStatisticDetailSuccess:
            setupChartData()
            setBarChart()
            setLineChart()
            bindAverage()
        }
    }
}
