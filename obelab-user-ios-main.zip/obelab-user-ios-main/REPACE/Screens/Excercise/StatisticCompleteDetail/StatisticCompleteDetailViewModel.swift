//
//  StatisticCompleteDetailViewModel.swift
//  REPACE
//
//  Created by Pham Van Huy on 26/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

protocol StatisticCompleteDetailViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: StatisticCompleteDetailViewModelState)
}

enum StatisticCompleteDetailViewModelState {
    case getStatisticDetailSuccess
    case network(state: NetworkState)
}

class StatisticCompleteDetailViewModel {
    
    private var state: StatisticCompleteDetailViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: StatisticCompleteDetailViewModelDelegate?
    var page = 0
    var totalPages = 0
    var day = ""
    var type = "1"
    var typeExercise = ""
    var activity = ""
    var date = ""
    var endDate = ""
    var exerciseStatisticList: [ExerciseStatisticDetailModel] = []
    var exerciseStatisticAvg: ExerciseStatisticDetailModel?
    
    func getExerciseStatisticByDay() {
        state = .network(state: .loading)
        ExerciseServices.getStatisticDetails(
            type: self.type,
            typeExercise: self.typeExercise,
            activity: self.activity,
            fromDate: self.date,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.exerciseStatisticList = res.statistic
                self.exerciseStatisticAvg = res.average
                self.state = .getStatisticDetailSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
}
