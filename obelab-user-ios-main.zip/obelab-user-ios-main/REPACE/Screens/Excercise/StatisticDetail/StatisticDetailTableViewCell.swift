//
//  StatisticDetailTableViewCell.swift
//  REPACE
//
//  Created by Pham Van Huy on 24/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit

class StatisticDetailTableViewCell: UITableViewCell {
    
    var cellModel: StatisticDetailCellModel?
    
    weak var delegate: StatisticDetailTableViewCellDelegate?
    
    @IBOutlet weak var lbDateRange: UILabel!
    
    @IBAction func btnDetail_Click(_ sender: Any) {
        delegate?.cellItemClick(sender, cellModel ?? StatisticDetailCellModel())
    }
    override func awakeFromNib() {
       super.awakeFromNib()
    }
    
    func bindData(history: ExerciseStatisticModel, cellModel: StatisticDetailCellModel) {
        self.cellModel = cellModel
        self.cellModel?.date = history.date ?? ""
        var displayDate: String = ""
        var dateFormat = "MMM dd, yyyy"
        let date = Functions.convertDateStrToDate(dateStr: history.date ?? "", inputFormat: "yyyy-MM-dd")
        if cellModel.dateRangeType == "2" {
            let endDate = Calendar.current.date(byAdding: .day, value: 6, to: date) ?? date
            displayDate = "\(Functions.dateToString(date: date, outFormat: "MMM dd")) ~ \(Functions.dateToString(date: endDate, outFormat: dateFormat))"
        } else if cellModel.dateRangeType == "3" {
            dateFormat = "MMM, yyyy"
            displayDate = Functions.dateToString(date: date, outFormat: dateFormat)
        } else {
            displayDate = Functions.dateToString(date: date, outFormat: dateFormat)
        }
        self.lbDateRange.text = displayDate
        self.contentView.sizeToFit()
    }
}

struct StatisticDetailCellModel {
    // state
    var date: String = ""
    var exerciseType: String? = ""
    var activity: String? = ""
    var dateRangeType: String = ""
}

protocol StatisticDetailTableViewCellDelegate: NSObjectProtocol {
    func cellItemClick(_ sender: Any, _ cellModel: StatisticDetailCellModel)
}
