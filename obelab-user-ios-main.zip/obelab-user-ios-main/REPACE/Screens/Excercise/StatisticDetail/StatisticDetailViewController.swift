//
//  StatisticDetailViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/17/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit
import Charts

class StatisticDetailViewController: BaseViewController, ChartViewDelegate {
    var viewModel: StatisticDetailViewModel = StatisticDetailViewModel()
    var dateRangeState: DateRangeState = .days
    var specState: SpecState = .speed
    var dateRangeFrom: Date = Date()
    var dateRangeTo: Date = Date()
    var days: [String] = []
    var chartSpeedValues: [BarChartDataEntry] = []
    var chartDistanceValues: [BarChartDataEntry] = []
    var chartSmO2Values: [BarChartDataEntry] = []
    var chartTimeValues: [BarChartDataEntry] = []
    var barChartView = BarChartView()
    var dateFormatStr = "MMM dd, yyyy"
    
    @IBOutlet weak var lbSelectedActivity: UILabel!
    @IBOutlet weak var lbSmO2: UILabel!
    @IBOutlet weak var lbTime: UILabel!
    @IBOutlet weak var lbDistance: UILabel!
    @IBOutlet weak var lbSpeed: UILabel!
    @IBOutlet weak var lbUnit: UILabel!
    @IBOutlet weak var vwChartContainer: UIStackView!
    @IBOutlet weak var vwDetailContainer: DesignableView!
    @IBOutlet weak var tbDetails: UITableView!
    @IBOutlet weak var ctScrollViewHeight: NSLayoutConstraint!
    @IBOutlet weak var ctDetailContainerHeight: NSLayoutConstraint!
    @IBOutlet weak var lblUnitDistance: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        tbDetails.delegate = self
        tbDetails.dataSource = self
        dateRangeTo = Date()
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: -6, to: dateRangeTo) ?? dateRangeTo
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.initComponents()
        }
        loadData()
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
    }
    
    func initComponents() {
        var activityNameDisplay = ""
        var exerciseTypeDisplay = ""
        if viewModel.activityName == ExerciseConstants.EX_TREADMILL {
            activityNameDisplay = "Treadmill Running"
        } else if viewModel.activityName == ExerciseConstants.EX_OUTDOOR {
            activityNameDisplay = "Outdoor Running"
        } else {
            activityNameDisplay = "All"
        }
        
        if viewModel.exerciseType == ExerciseConstants.RX_EXERCISE {
            exerciseTypeDisplay = "Rx Exercise"
        } else if viewModel.exerciseType == ExerciseConstants.FREE_EXERCISE {
            exerciseTypeDisplay = "Free Exercise"
        }
        
        lbSelectedActivity.text = "\(exerciseTypeDisplay) > \(activityNameDisplay)"
        switchButton(dateRangeState)
        switchSpecButton(specState)
        
        initChart()
    }
    
    func loadData() {
        // set date range label
        setRangDate()
        // load data
        let toDate = Functions.dateToString(date: dateRangeTo, outFormat: "yyyy-MM-dd")
        switch dateRangeState {
        case .days:
            viewModel.getLast7DaysStatistic(type: viewModel.exerciseType, activity: viewModel.activityName, fromDate: toDate)
            
        case .weeks:
            viewModel.getLast4WeeksStatistic(type: viewModel.exerciseType, activity: viewModel.activityName, fromDate: toDate)
            
        case .year:
            viewModel.getLast1YearStatistic(type: viewModel.exerciseType, activity: viewModel.activityName, fromDate: toDate)
        }
    }
    
    private func setRangDate() {
        let yearFrom = Calendar.current.component(.year, from: dateRangeFrom)
        let yearTo = Calendar.current.component(.year, from: dateRangeTo)
        let from = yearFrom != yearTo ? Functions.dateToString(date: dateRangeFrom, outFormat: "MMM dd, yyyy") : Functions.dateToString(date: dateRangeFrom, outFormat: "MMM dd")
        let to = Functions.dateToString(date: dateRangeTo, outFormat: "MMM dd, yyyy")
        lbDateRange.text = "\(from) ~ \(to)"
    }
    
    func initChart() {
        barChartView.legend.enabled = false
        barChartView.rightAxis.enabled = false
        barChartView.leftAxis.labelTextColor = .white
        barChartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        barChartView.xAxis.labelPosition = .bottom
        barChartView.xAxis.valueFormatter = self
        barChartView.xAxis.labelTextColor = .white
        barChartView.xAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        vwChartContainer.addArrangedSubview(barChartView)
        // xaxis label center bar graph
        barChartView.xAxis.spaceMin = 0.3
        barChartView.xAxis.spaceMax = 0.3
        barChartView.xAxis.granularityEnabled = true
        barChartView.xAxis.granularity = 1
        barChartView.leftAxis.axisMinimum = 0.0
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.doubleTapToZoomEnabled = false
        barChartView.scaleXEnabled = false
        barChartView.scaleYEnabled = false
        barChartView.dragEnabled = false
        setData()
    }
    
    func setData() {
        // bind average data
        let speed = Functions.kmToMile(km: viewModel.average.speed)
        lbSpeed.text = speed == 0.0 ? "-" : String(speed.to1Decimal)
//        String(format: "%.2f", history.lactateOnset ?? 0)
        let distance = Functions.kmToMile(km: (viewModel.average.distance ?? 0)).to1Decimal
        lbDistance.text = "\(distance)"
//        lbDistance.text = viewModel.average.distance == nil ? "-" : String(format: "%.1f", (viewModel.average.distance ?? 0))
        lbTime.text = Functions.getTimeDisplayStrFromSeconds(Int(viewModel.average.time ?? 0))
        lbSmO2.text = viewModel.average.smO2 == nil ? "-" : String(format: "%.1f", viewModel.average.smO2 ?? 0)
        
        if viewModel.average.isDataEmpty() {
            vwDetailContainer.isHidden = true
            lbStatisticBy.isHidden = true
        } else {
            vwDetailContainer.isHidden = false
            lbStatisticBy.isHidden = false
        }
        
        // bind chart data
        days.removeAll()
        chartSpeedValues.removeAll()
        chartTimeValues.removeAll()
        chartDistanceValues.removeAll()
        chartSmO2Values.removeAll()
        var index: Double = 0
        if !self.viewModel.exerciseStatisticList.isEmpty {
            var format = "MM/dd"
            switch dateRangeState {
            case .days:
                format = "MM/dd"
            case .weeks:
                format = "MM/dd"
            case .year:
                format = "MM"
            }
            for day in self.viewModel.exerciseStatisticList {
                guard let inputDateStr = day.date else {
                    break
                }
                var inputDate: Date?
                if dateRangeState == .year {
                    let inputDateStr = String((day.date ?? "2021-01-01").prefix(10))
                    inputDate = Functions.convertDateStrToDate(dateStr: inputDateStr)
                } else {
                    inputDate = Functions.convertSqlDateToDate(sqlDate: inputDateStr)
                }
                if let inputDate = inputDate {
                    let dateFormatterGet = DateFormatter()
                    dateFormatterGet.locale = Locale(identifier: Constants.LOCAL_IDENTIFIER_DEFAULT)
                    dateFormatterGet.dateFormat = format
                    var monthStr = dateFormatterGet.string(from: inputDate)
                    if dateRangeState == .weeks {
                        let dateEndOfWeek = Calendar.current.date(byAdding: .day, value: 6, to: inputDate) ?? inputDate
                        let monthEndOfWeek = Calendar.current.component(.month, from: dateEndOfWeek)
                        let monthFirstOfWeek = Calendar.current.component(.month, from: inputDate)
                        if monthFirstOfWeek == monthEndOfWeek {
                            let dateStr = "\(Calendar.current.component(.day, from: dateEndOfWeek))"
                            monthStr = "\(monthStr)~\(dateStr)"
                        } else {
                            let dateStr = dateFormatterGet.string(from: dateEndOfWeek)
                            monthStr = "\(monthStr)~\(dateStr)"
                        }
                    } else if dateRangeState == .year {
    //                    if monthStr == "01" || monthStr == "12" {
    //                        let year = Calendar.current.component(.year, from: inputDate)
    //                        monthStr = "\(monthStr)\n\(year)"
    //                    }
                    }
                    days.append(monthStr)
                    let speed = Functions.kmToMile(km: Double(day.speed ?? 0)).to1Decimal
                    chartSpeedValues.append(BarChartDataEntry(x: index, y: speed))
//                    chartSpeedValues.append(BarChartDataEntry(x: index, y: Double(day.speed ?? 0)))
                    let distance = Functions.kmToMile(km: Double(day.distance ?? 0)).to1Decimal
                    chartDistanceValues.append(BarChartDataEntry(x: index, y: distance))
//                    chartDistanceValues.append(BarChartDataEntry(x: index, y: Double(day.distance ?? 0)))
                    chartSmO2Values.append(BarChartDataEntry(x: index, y: Double(day.smO2 ?? 0)))
                    chartTimeValues.append(BarChartDataEntry(x: index, y: Double(day.time ?? 0) / 3600))
                    index += 1
                }
            }
        }
        
        setChartData()
        
        // optimize view, scroll height
        if !viewModel.average.isDataEmpty() {
            ctDetailContainerHeight.constant = CGFloat(viewModel.exerciseListHaveData.count * 50) + 24
            ctScrollViewHeight.constant = CGFloat(624 + ctDetailContainerHeight.constant)
        }
    }
    
    func setChartData() {
        var color = UI.Color.pinkColor
        var label = "km/h"
        
        var values: [BarChartDataEntry] = []
        switch specState {
        case .speed:
            values = chartSpeedValues
            color = UI.Color.pinkColor
            label = Functions.showUnitLabel(isSpeed: true)
        case .distance:
            values = chartDistanceValues
            color = UI.Color.orangeColor
            label = Functions.showUnitLabel(isSpeed: false)
        case .time:
            values = chartTimeValues
            color = UI.Color.cyanColor
            label = "h"
        case .smo2:
            values = chartSmO2Values
            color = UI.Color.btnBgColor
            label = "%"
        }
        
        let set1 = BarChartDataSet(entries: values, label: label)
        set1.highlightEnabled = false
        set1.setColor(color)
        set1.drawValuesEnabled = false
        
        let data = BarChartData(dataSet: set1)
        data.barWidth = dateRangeState == DateRangeState.weeks ? 0.25 : 0.45
        barChartView.data = data
        
        lbUnit.text = label
        self.barChartView.xAxis.labelCount = days.count
    }
    
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
//        print(entry)
    }
    
    func switchSpecButton(_ state: SpecState) {
        btnSpeed.backgroundColor = UI.Color.btnBgDisableColor
        btnDistance.backgroundColor = UI.Color.btnBgDisableColor
        btnTime.backgroundColor = UI.Color.btnBgDisableColor
        btnSmo2.backgroundColor = UI.Color.btnBgDisableColor
        switch state {
        case .speed:
            btnSpeed.backgroundColor = UI.Color.pinkColor
        case .distance:
            btnDistance.backgroundColor = UI.Color.orangeColor
        case .time:
            btnTime.backgroundColor = UI.Color.cyanColor
        case .smo2:
            btnSmo2.backgroundColor = UI.Color.btnBgColor
        }
        setChartData()
    }
    
    func switchButton(_ state: DateRangeState) {
        btn7Days.backgroundColor = UI.Color.btnBgDisableColor
        btn4Weeks.backgroundColor = UI.Color.btnBgDisableColor
        btn1Year.backgroundColor = UI.Color.btnBgDisableColor
        switch state {
        case .days:
            btn7Days.backgroundColor = UI.Color.btnBgColor
            lbStatisticBy.text = "Statistics by Day"
        case .weeks:
            btn4Weeks.backgroundColor = UI.Color.btnBgColor
            lbStatisticBy.text = "Statistics by Week"
        case .year:
            btn1Year.backgroundColor = UI.Color.btnBgColor
            lbStatisticBy.text = "Statistics by Month"
        }
    }
    
    @IBOutlet weak var btnSmo2: DesignableButton!
    @IBOutlet weak var btnTime: DesignableButton!
    @IBOutlet weak var btnDistance: DesignableButton!
    @IBOutlet weak var btnSpeed: DesignableButton!
    @IBOutlet weak var btn1Year: DesignableButton!
    @IBOutlet weak var btn4Weeks: DesignableButton!
    @IBOutlet weak var btn7Days: DesignableButton!
    @IBOutlet weak var lbDateRange: UILabel!
    
    @IBOutlet weak var lbStatisticBy: UILabel!
    
    @IBAction func btnNext_Click(_ sender: Any) {
        switch dateRangeState {
        case .days:
            selectNext7Days()
        case .weeks:
            selectNext4Weeks()
        case .year:
            selectNext1Year()
        }
        loadData()
    }
    
    @IBAction func btnPrev_Click(_ sender: Any) {
        switch dateRangeState {
        case .days:
            selectPrev7Days()
        case .weeks:
           selectPrev4Weeks()
        case .year:
            selectPrev1Year()
        }
        loadData()
    }
    
    func selectNext7Days() {
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: 1, to: dateRangeTo) ?? dateRangeTo
        dateRangeTo = Calendar.current.date(byAdding: .day, value: 7, to: dateRangeTo) ?? dateRangeTo
    }
    
    func selectNext4Weeks() {
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: 1, to: dateRangeTo) ?? dateRangeTo
        dateRangeTo = Calendar.current.date(byAdding: .day, value: 28, to: dateRangeTo) ?? dateRangeTo
    }
    
    func selectNext1Year() {
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: 1, to: dateRangeTo) ?? dateRangeTo
        dateRangeTo = Calendar.current.date(byAdding: .year, value: 1, to: dateRangeTo) ?? dateRangeTo
    }
    
    func selectPrev7Days() {
        dateRangeTo = Calendar.current.date(byAdding: .day, value: -1, to: dateRangeFrom) ?? dateRangeFrom
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: -7, to: dateRangeFrom) ?? dateRangeFrom
    }
    
    func selectPrev4Weeks() {
        dateRangeTo = Calendar.current.date(byAdding: .day, value: -1, to: dateRangeFrom) ?? dateRangeFrom
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: -28, to: dateRangeFrom) ?? dateRangeFrom
    }
    
    func selectPrev1Year() {
        dateRangeTo = Calendar.current.date(byAdding: .day, value: -1, to: dateRangeFrom) ?? dateRangeFrom
        dateRangeFrom = Calendar.current.date(byAdding: .year, value: -1, to: dateRangeFrom) ?? dateRangeFrom
    }
    
    @IBAction func btn7Days_Click(_ sender: Any) {
        dateRangeState = .days
        switchButton(dateRangeState)
        dateRangeTo = Date()
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: -6, to: dateRangeTo) ?? dateRangeTo
        loadData()
    }
    
    @IBAction func btn4Weeks_Click(_ sender: Any) {
        dateRangeState = .weeks
        switchButton(dateRangeState)
        dateRangeTo = Date()
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: -27, to: dateRangeTo) ?? dateRangeTo
        loadData()
    }
    
    @IBAction func btn1Year_Click(_ sender: Any) {
        dateRangeState = .year
        switchButton(dateRangeState)
        dateRangeTo = Date()
        dateRangeFrom = Calendar.current.date(byAdding: .year, value: -1, to: dateRangeTo) ?? dateRangeTo
        dateRangeFrom = Calendar.current.date(byAdding: .day, value: 1, to: dateRangeFrom) ?? dateRangeFrom
        loadData()
    }
    
    @IBAction func btnSpeed_Click(_ sender: Any) {
        specState = .speed
        switchSpecButton(specState)
    }
    
    @IBAction func btnDistance_Click(_ sender: Any) {
        specState = .distance
        switchSpecButton(specState)
        
    }
    
    @IBAction func btnTime_Click(_ sender: Any) {
        specState = .time
        switchSpecButton(specState)
        
    }
    
    @IBAction func btnSmo2_Click(_ sender: Any) {
        specState = .smo2
        switchSpecButton(specState)
    }
}

extension StatisticDetailViewController: StatisticDetailViewModelDelegate {
    func didUpdateState(to state: StatisticDetailViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getStatisticDetailListSuccess:
            initChart()
            tbDetails.reloadData()
        }
    }
}

extension StatisticDetailViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        days[Int(value) % days.count]
    }
}

extension StatisticDetailViewController: StatisticDetailTableViewCellDelegate {
    func cellItemClick(_ sender: Any, _ cellModel: StatisticDetailCellModel) {
        
        let detailPage = ExcerciseRoutes.exerciseStatisticCompleteDetail.screen as? StatisticCompleteDetailViewController ?? StatisticCompleteDetailViewController()
        let viewModel = StatisticCompleteDetailViewModel()
        viewModel.type = cellModel.dateRangeType
        viewModel.typeExercise = cellModel.exerciseType ?? ""
        viewModel.date = cellModel.date
        viewModel.activity = cellModel.activity ?? ""
        detailPage.viewModel = viewModel
//        detailPage.viewModel = StatisticCompleteDetailViewModel()
//        detailPage.viewModel.type = cellModel.dateRangeType
//        detailPage.viewModel.typeExercise = cellModel.exerciseType ?? ""
//        detailPage.viewModel.date = cellModel.date
//        detailPage.viewModel.activity = cellModel.activity ?? ""
        self.navigationController?.pushViewController(detailPage, animated: true)
        // type=3&date=2021-12-30&typeexercise=free_exercise&activity=
    }
}

extension StatisticDetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.exerciseListHaveData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        50
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "StatisticDetailTableViewCell", for: indexPath) as? StatisticDetailTableViewCell {
            let model = self.viewModel.exerciseListHaveData[indexPath.row]
            let cellModel = createStatisticDetailCellModel(indexPath: indexPath)
            cell.bindData(history: model, cellModel: cellModel)
            cell.delegate = self
            cell.selectionStyle = .none
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = createStatisticDetailCellModel(indexPath: indexPath)
        cellItemClick(1, model)
    }
    
    private func createStatisticDetailCellModel(indexPath: IndexPath) -> StatisticDetailCellModel {
        let model = self.viewModel.exerciseListHaveData[indexPath.row]
        var date = model.date ?? ""
        if date.count > 10 {
            date = String(date.prefix(10))
        }
        var cellModel = StatisticDetailCellModel()
        cellModel.exerciseType = viewModel.exerciseType
        cellModel.activity = viewModel.activityName
        cellModel.date = date
        switch dateRangeState {
        case .days:
            cellModel.dateRangeType = "1"
        case .weeks:
            cellModel.dateRangeType = "2"
        case .year:
            cellModel.dateRangeType = "3"
        }
        return cellModel
    }
}

let yValues: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 10.0),
    BarChartDataEntry(x: 1.0, y: 9),
    BarChartDataEntry(x: 2.0, y: 8),
    BarChartDataEntry(x: 3.0, y: 7),
    BarChartDataEntry(x: 4.0, y: 6),
    BarChartDataEntry(x: 5.0, y: 5),
    BarChartDataEntry(x: 6.0, y: 4)
]
let yValues2: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 1.0),
    BarChartDataEntry(x: 1.0, y: 8),
    BarChartDataEntry(x: 2.0, y: 7),
    BarChartDataEntry(x: 3.0, y: 6),
    BarChartDataEntry(x: 4.0, y: 5),
    BarChartDataEntry(x: 5.0, y: 4),
    BarChartDataEntry(x: 6.0, y: 3)
]
let yValues3: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 10.0),
    BarChartDataEntry(x: 1.0, y: 7),
    BarChartDataEntry(x: 2.0, y: 6),
    BarChartDataEntry(x: 3.0, y: 5),
    BarChartDataEntry(x: 4.0, y: 4),
    BarChartDataEntry(x: 5.0, y: 3),
    BarChartDataEntry(x: 6.0, y: 2)
]
let yValues4: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 30),
    BarChartDataEntry(x: 1.0, y: 6),
    BarChartDataEntry(x: 2.0, y: 5),
    BarChartDataEntry(x: 3.0, y: 4),
    BarChartDataEntry(x: 4.0, y: 3),
    BarChartDataEntry(x: 5.0, y: 2),
    BarChartDataEntry(x: 6.0, y: 1)
]
let yValues5: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 40),
    BarChartDataEntry(x: 1.0, y: 1),
    BarChartDataEntry(x: 2.0, y: 5),
    BarChartDataEntry(x: 3.0, y: 4),
    BarChartDataEntry(x: 4.0, y: 3),
    BarChartDataEntry(x: 5.0, y: 2),
    BarChartDataEntry(x: 6.0, y: 1)
]
let yValues6: [BarChartDataEntry] = [
    BarChartDataEntry(x: 0.0, y: 35),
    BarChartDataEntry(x: 1.0, y: 6),
    BarChartDataEntry(x: 2.0, y: 5),
    BarChartDataEntry(x: 3.0, y: 4),
    BarChartDataEntry(x: 4.0, y: 1),
    BarChartDataEntry(x: 5.0, y: 2),
    BarChartDataEntry(x: 6.0, y: 1)
]

enum DateRangeState {
    case days
    case weeks
    case year
}

enum SpecState {
    case speed
    case distance
    case time
    case smo2
}
