//
//  StatisticDetailViewModel.swift
//  REPACE
//
//  Created by Pham Van Huy on 22/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

protocol StatisticDetailViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: StatisticDetailViewModelState)
}

enum StatisticDetailViewModelState {
    case getStatisticDetailListSuccess
    case network(state: NetworkState)
}

class StatisticDetailViewModel {
    
    private var state: StatisticDetailViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: StatisticDetailViewModelDelegate?
    
    var page = 0
    var totalPages = 0
    var exerciseStatisticList: [ExerciseStatisticModel] = []
    var exerciseListHaveData: [ExerciseStatisticModel] = []
    var average = ExerciseStatisticModel()
    var activityName = ""
    var exerciseType = ""
    
    func getLast7DaysStatistic(type: String, activity: String = "", fromDate: String = "") {
        state = .network(state: .loading)
        ExerciseServices.getLast7DaysStatistic(
            type: type,
            activity: activity,
            fromDate: fromDate,
            success: { [weak self] res in
                guard let self = self else { return }
                self.getDataFromResponse(res: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func getLast4WeeksStatistic(type: String, activity: String = "", fromDate: String = "") {
        state = .network(state: .loading)
        ExerciseServices.getLast4WeeksStatistic(
            type: type,
            activity: activity,
            fromDate: fromDate,
            success: { [weak self] res in
                guard let self = self else { return }
                self.getDataFromResponse(res: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func getLast1YearStatistic(type: String, activity: String = "", fromDate: String = "") {
        state = .network(state: .loading)
        ExerciseServices.getLast1YearStatistic(
            type: type,
            activity: activity,
            fromDate: fromDate,
            success: { [weak self] res in
                guard let self = self else { return }
                self.getDataFromResponse(res: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    private func getDataFromResponse(res: ExerciseStatisticResultModel) {
        self.state = .network(state: .hideLoading)
        self.exerciseStatisticList = res.statistic
        self.exerciseListHaveData = res.statistic.filter({$0.isDataEmpty() == false})
        self.average = res.average
        self.state = .getStatisticDetailListSuccess
    }
}
