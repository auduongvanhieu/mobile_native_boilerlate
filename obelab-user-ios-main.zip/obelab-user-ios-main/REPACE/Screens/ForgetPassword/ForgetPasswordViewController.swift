import Foundation
import UIKit
import SkyFloatingLabelTextField

class ForgetPasswordViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var emailField: SkyFloatingLabelTextField!
    
    @IBOutlet weak var bottomEmailField: NSLayoutConstraint!
    @IBOutlet weak var topEmailField: NSLayoutConstraint!
    var viewModel: ForgetPasswordViewModel!
    
    var isDidError = false
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        emailField.delegate = self
        setUpView()
    }
    
    func setUpView() {
        // Header
        let header = HeaderBackView()
        header.setUp(width: Double(self.view.frame.width), title: "title_forgot_password".localized)
        self.view.addSubview(header)
        // Button
        sendButton.setRoundBorders(UI.Button.cornerRadius)
        setSendButton(enabled: false)
        // Input Field
        emailView.layer.cornerRadius = UI.Button.cornerRadius
        emailField.lineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedTitleColor = UI.Color.btnBgColor
        emailField.titleColor = UI.Color.txtFloatTitleColor
        emailField.textColor = UIColor.white
        emailField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
    }
    
    private func adjustContraintsOfTextField(_ updatedText: String, top: NSLayoutConstraint, bottom: NSLayoutConstraint) {
        top.constant = updatedText.isEmpty ? -2 : 2
        bottom.constant = updatedText.isEmpty ? 12 : 0
    }
    
    // MARK: - Actions
    @IBAction func onEmailChanged(_ sender: UITextField) {
        let newValue = sender.text ?? ""
        viewModel.email = newValue
        setSendButton(enabled: viewModel.hasValidEmail)
        emailView.layer.borderColor = isDidError ? UI.Color.txtErrorColor.cgColor : UI.Color.btnBgColor.cgColor
    }
    
    @IBAction func onEmailFocus(_ sender: Any) {
        emailView.layer.borderWidth = 1
        emailView.layer.borderColor = isDidError ? UI.Color.txtErrorColor.cgColor : UI.Color.btnBgColor.cgColor
    }
    
    @IBAction func onPressSend(_ sender: Any) {
        viewModel.forgetPassword()
    }
    
    func setSendButton(enabled: Bool) {
        sendButton.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        sendButton.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        sendButton.setTitleColor(titleColor, for: .normal)
    }
}

extension ForgetPasswordViewController: ForgetPasswordViewModelDelegate {
    func didUpdateState(to state: ForgetPasswordViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .forgetPasswordSuccess:
            isDidError = false
            emailField.selectedTitleColor = UI.Color.btnBgColor
            emailField.titleColor = UI.Color.btnBgColor
            emailView.layer.borderColor = UI.Color.btnBgColor.cgColor
            showMessage(title: "", message: "forget_password_success".localized, handler: { _ in
                AppNavigator.shared.pop()
            }, titleButton: "continue".localized)
//            let alert = UIAlertController(title: "", message: "forget_password_success".localized, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "continue".localized, style: .default, handler: { _ in
//                AppNavigator.shared.pop()
//            }))
//            self.present(alert, animated: true, completion: nil)
        case .forgetPasswordFail(message: let message):
            isDidError = true
            emailView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            emailField.selectedTitleColor = UI.Color.txtErrorColor
            showToast(message: message)
        }
    }
}

extension ForgetPasswordViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: false)
    }
    
    private func textFieldEditing(_ textField: UITextField, isBegin: Bool) {
        var isEmpty = false
        if isBegin == false {
            isEmpty = (textField.text ?? "").isEmpty
        }
        let text = isEmpty ? "" : " "
        adjustContraintsOfTextField(text, top: topEmailField, bottom: bottomEmailField)
    }
}
