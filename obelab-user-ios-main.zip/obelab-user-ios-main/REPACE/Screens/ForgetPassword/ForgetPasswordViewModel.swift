import Foundation

protocol ForgetPasswordViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: ForgetPasswordViewModelState)
}

enum ForgetPasswordViewModelState {
    case forgetPasswordSuccess
    case forgetPasswordFail(message: String)
    case network(state: NetworkState)
}

class ForgetPasswordViewModel {
    
    private var state: ForgetPasswordViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: ForgetPasswordViewModelDelegate?
    
    var email = ""
    
    var hasValidEmail: Bool {
        return email.isEmailFormatted()
    }
    
    func forgetPassword() {
        state = .network(state: .loading)
        AuthenticationServices.forgetPassword(
            email: email,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .forgetPasswordSuccess
                } else {
                    self.state = .forgetPasswordFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
