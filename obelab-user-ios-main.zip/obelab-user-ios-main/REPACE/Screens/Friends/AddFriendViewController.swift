//
//  AddFriendViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/16/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class AddFriendViewController: BaseViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        tvSearchKey.attributedPlaceholder = NSAttributedString(
            string: "search_friend_key".localized,
            attributes: [NSAttributedString.Key.foregroundColor: UI.Color.txtPlaceholderColor]
        )
    }
    @IBOutlet weak var tvSearchKey: UITextField!
}
