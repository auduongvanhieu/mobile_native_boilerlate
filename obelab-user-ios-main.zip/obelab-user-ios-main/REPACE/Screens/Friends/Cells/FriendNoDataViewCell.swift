//
//  FriendNoDataViewCell.swift
//  REPACE
//
//  Created by ThienBanh on 20/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit

class FriendNoDataViewCell: UITableViewCell {

    @IBOutlet weak var lblNoData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
