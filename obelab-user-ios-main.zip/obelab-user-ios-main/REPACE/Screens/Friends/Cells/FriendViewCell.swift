//
//  FriendViewCell.swift
//  REPACE
//
//  Created by ThienBanh on 20/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit
import SDWebImage
public enum FriendCellType: Int {
  case friendList        = 1
  case friendRequest     = 2
  case friendAll         = 3
}
class FriendViewCell: UITableViewCell {

    @IBOutlet weak var constraintLeftButtonWidth: NSLayoutConstraint!
    @IBOutlet weak var constraintRightButtonWidth: NSLayoutConstraint!
    @IBOutlet weak var btnRight: DesignableButton!
    @IBOutlet weak var btnLeft: DesignableButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgAvatar: DesignableImageView!
    var cellType: FriendCellType = .friendList
    var tapUnfriend: ( (UserInfo) -> Void)?
    var tapReject: ( (UserInfo) -> Void)?
    var tapAccept: ( (UserInfo) -> Void)?
    var tapRequest: ( (UserInfo, Int) -> Void)?
    var userObj: UserInfo?
    var index = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setupCellDes(user: UserInfo, type: FriendCellType) {
        
        userObj = user
        if user.avatar?.count ?? 0 != 0, let avatarUrl = URL(string: userObj?.avatar ?? Constants.AVATAR_DEFAULT) {
            imgAvatar.sd_setImage(with: avatarUrl, placeholderImage: UIImage(named: "img_avartar_default"))
        }
        else {
            imgAvatar.image = UIImage(named: "img_avartar_default")
        }
        
        lblName.text = userObj?.nickname
        cellType = type
        setupType()
    }
    
    func setupType() {
        constraintRightButtonWidth.constant = 72
        constraintLeftButtonWidth.constant = 72
        switch cellType {
        case .friendList:
            btnLeft.isHidden = true
            btnRight.setTitle("unfriendAlert".localized, for: .normal)
            btnRight.backgroundColor = #colorLiteral(red: 0.9843137255, green: 0.1960784314, blue: 0.6, alpha: 1)
        case .friendRequest:
            btnLeft.isHidden = false
            btnRight.setTitle("accept".localized, for: .normal)
            btnRight.backgroundColor = #colorLiteral(red: 0.1803921569, green: 0.3607843137, blue: 1, alpha: 1)
            btnLeft.setTitle("alertRejectTitle".localized, for: .normal)
            btnLeft.backgroundColor = #colorLiteral(red: 0.9843137255, green: 0.1960784314, blue: 0.6, alpha: 1)
        case .friendAll:
            btnLeft.isHidden = true
            if userObj?.requested ?? false {
                constraintRightButtonWidth.constant = 110
                constraintLeftButtonWidth.constant = 0
                btnRight.setTitle("cancelRequest".localized, for: .normal)
                btnRight.backgroundColor = .clear
                btnRight.layer.borderColor = UIColor.white.cgColor
                btnRight.layer.borderWidth = 1
            } else {
                btnRight.layer.borderWidth = 0
                btnRight.setTitle("request".localized, for: .normal)
                btnRight.backgroundColor = #colorLiteral(red: 0.1803921569, green: 0.3607843137, blue: 1, alpha: 1)
            }
        }
    }
    
    @IBAction func btnLeftPress(_ sender: Any) {
        switch cellType {
        case .friendList:
            break
        case .friendRequest:
            tapReject?(userObj ?? UserInfo())
        case .friendAll:
            break
        }
    }
    
    @IBAction func actionRightPress(_ sender: Any) {
        switch cellType {
        case .friendList:
            tapUnfriend?(userObj ?? UserInfo())
        case .friendRequest:
            tapAccept?(userObj ?? UserInfo())
        case .friendAll:
            tapRequest?(userObj ?? UserInfo(), index)
        }
    }
}
