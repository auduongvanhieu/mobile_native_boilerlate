//
//  FriendViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/16/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit
import FBSDKLoginKit
//import Speech

enum ButtonStartState: Int {
    case start = 0
    case stop
    case reStart
}

class FriendViewController: BaseViewController, HeaderBackDelegate {
    func onClickBack() {}
    
    func onClickShare() {}

    @IBOutlet weak var tvSearchKey: UITextField!
    @IBOutlet weak var headerBack: HeaderBack!
    @IBOutlet weak var tbvFriend: UITableView!
    @IBOutlet weak var viewFriendList: UIView!
    @IBOutlet weak var tbvNotFriend: UITableView!
    @IBOutlet weak var viewContainerVoiceSearch: UIView!
    @IBOutlet weak var lblVoiceSearchText: UILabel!
    @IBOutlet weak var btnStartRecognizeVoice: DesignableButton!
    @IBOutlet weak var btnFinishRecognizeVoice: DesignableButton!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var userInfo : UserInfo?
    var timer: Timer?
    var viewModel: FriendViewModel!
    var reloadIndex = 0
    var isNoFriendList = false
    
    var startState: ButtonStartState = .start {
        didSet {
            didChangeStateButtonStart()
        }
    }
    
    // MARK: - Local Properties
    var isGrantedPermisionSpeech = false
//    let audioEngine = AVAudioEngine()
//    let speechReconizer: SFSpeechRecognizer? = SFSpeechRecognizer()
//    let request = SFSpeechAudioBufferRecognitionRequest()
//    var task: SFSpeechRecognitionTask!
    
    fileprivate var isSimulator: Bool = {
        #if targetEnvironment(simulator)
            return true
        #else
            return false
        #endif
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTable()
        setupViewRecognizeVoice()
        viewModel = FriendViewModel()
        viewModel.delegate = self
        headerBack.delegate = self
        tvSearchKey.attributedPlaceholder = NSAttributedString(
            string: "search_friend_key".localized ,
            attributes: [NSAttributedString.Key.foregroundColor: UI.Color.txtPlaceholderColor]
        )
        
        tvSearchKey.delegate = self
        headerBack.btnRightAction.isHidden = true
        
        //        tbvFriend.reloadData()
        viewModel.getListFriends()
        viewModel.getFriendRequest()
        tvSearchKey.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)

    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate()
        timer = nil
    }
    
    func setupTable() {
        tbvFriend.delegate = self
        tbvFriend.dataSource = self
        tbvFriend.register(UINib(nibName: "FriendViewCell", bundle: nil), forCellReuseIdentifier: "FriendViewCell")
        tbvFriend.register(UINib(nibName: "FriendNoDataViewCell", bundle: nil), forCellReuseIdentifier: "FriendNoDataViewCell")
        tbvFriend.backgroundColor = .clear
        
        tbvNotFriend.backgroundColor = .clear
        tbvNotFriend.isHidden = true
        tbvNotFriend.delegate = self
        tbvNotFriend.dataSource = self
        tbvNotFriend.register(UINib(nibName: "FriendViewCell", bundle: nil), forCellReuseIdentifier: "FriendViewCell")
    }
    
    func setupViewRecognizeVoice() {
        lblVoiceSearchText.text = "press_start".localized
        btnFinishRecognizeVoice.layer.borderColor = UI.Color.btnBgColor.cgColor
        btnFinishRecognizeVoice.layer.borderWidth = 1.0
        btnFinishRecognizeVoice.layer.cornerRadius = 12.0
        btnFinishRecognizeVoice.clipsToBounds = true
        btnFinishRecognizeVoice.isHidden = true
        viewContainerVoiceSearch.isHidden = true
//        checkMicroPermission()
    }
    
    func requestPermission() {
//        SFSpeechRecognizer.requestAuthorization { [weak self] authStatus in
//            guard let self = self else { return }
//            switch authStatus {
//            case .authorized:
//                self.checkAvailableSpeech()
//            case .denied:
//                Functions.showLog(title: "Speech recognition authorization denied")
//                self.isGrantedPermisionSpeech = false
//            case .restricted:
//                Functions.showLog(title: "Not available on this device")
//                self.isGrantedPermisionSpeech = false
//            case .notDetermined:
//                Functions.showLog(title: "Not determined")
//                self.isGrantedPermisionSpeech = false
//            @unknown default:
//                fatalError("unknow authStatus SFSpeechRecognizer")
//            }
//        }
    }
    
    func checkMicroPermission() {
//        AVAudioSession.sharedInstance().requestRecordPermission { allowed in
//            if allowed {
//                // Request speech recognition authorization
//                SFSpeechRecognizer.requestAuthorization { status in
//                    switch status {
//                    case .authorized:
//                        self.checkAvailableSpeech()
//                    case .notDetermined, .denied, .restricted:
//                        Functions.showLog(title: "SFSpeechRecognizer authorization status: \(status).")
//                    @unknown default:
//                        fatalError("unknow SFSpeechRecognizer ")
//                    }
//                }
//            } else {
//                Functions.showLog(title: "AVAudioSession record permission: \(allowed).")
//            }
//        }
        self.isGrantedPermisionSpeech = true
    }
    
    func checkAvailableSpeech() {
//        guard let recognizer = SFSpeechRecognizer() else {
//            return
//        }
//        if recognizer.isAvailable && isSimulator == false {
//            self.isGrantedPermisionSpeech = true
//        } else {
//            Functions.showLog(title: "Speech recognition not available")
//        }
    }
    
    func animateVoiceView(isHidden: Bool) {
        if isHidden {
            let transitionAnimation = CATransform3DTranslate(CATransform3DIdentity, UIScreen.main.bounds.width, 0, 0)
            UIView.animate(withDuration: 0.25) {
                self.viewContainerVoiceSearch.layer.transform = transitionAnimation
            } completion: { _ in
                self.view.bringSubviewToFront(self.scrollView)
                self.viewContainerVoiceSearch.layer.transform = CATransform3DIdentity
                self.viewContainerVoiceSearch.isHidden = true
            }
        } else {
            self.viewContainerVoiceSearch.isHidden = false
            let transitionAnimation = CATransform3DTranslate(CATransform3DIdentity, UIScreen.main.bounds.width, 0, 0)
            self.viewContainerVoiceSearch.layer.transform = transitionAnimation
            self.view.bringSubviewToFront(self.viewContainerVoiceSearch)
            let transitionAnimationAppear = CATransform3DTranslate(transitionAnimation, -UIScreen.main.bounds.width, 0, 0)
            UIView.animate(withDuration: 0.25) {
                self.viewContainerVoiceSearch.layer.transform = transitionAnimationAppear
            } completion: { _ in
                self.viewContainerVoiceSearch.layer.transform = CATransform3DIdentity
            }
        }
    }
    
    func shareApp() {
        shareOtherApp(text: "share_app".localized, shareImage: nil)
    }
    
    func handleSearchWithText(_ text: String) {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(searchAction), userInfo: nil, repeats: true)
        timer?.tolerance = 0.1
        tbvNotFriend.reloadData()
    }
    
    @objc func searchAction() {
        timer?.invalidate()
        timer = nil
        viewModel.getListNotFriends(name: tvSearchKey.text ?? "", isLoading: false)
    }
    
    func onLoadMore() {
        viewModel.page += 1
        viewModel.getListNotFriends(name: tvSearchKey.text ?? "", isLoading: false)
    }
    
    func startSpeechRecognization() {
//        let node = audioEngine.inputNode
//        let recordingFormat = node.outputFormat(forBus: 0)
//
//        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, _) in
//            self.request.append(buffer)
//        }
//
//        audioEngine.prepare()
//        do {
//            try audioEngine.start()
//        } catch let error {
//            Functions.showLog(title: "Error comes here for starting the audio listner =\(error.localizedDescription)")
//        }
//
//        guard let myRecognization = SFSpeechRecognizer() else {
//            self.lblVoiceSearchText.text = "Recognization is not allow on your local"
//            return
//        }
//
//        if !myRecognization.isAvailable {
//            self.lblVoiceSearchText.text = "Recognization is free right now, Please try again after some time."
//        }
//
//        task = speechReconizer?.recognitionTask(with: request, resultHandler: { (response, error) in
//            guard let response = response else {
//                if error != nil {
//                    self.lblVoiceSearchText.text = error.debugDescription
//                } else {
//                    self.lblVoiceSearchText.text = "Problem in giving the response"
//                }
//                return
//            }
//            let message = response.bestTranscription.formattedString
//            self.lblVoiceSearchText.text = message
//            self.lblVoiceSearchText.textColor = .black
//        })
    }
    
    @IBAction func actionFacebook(_ sender: Any) {
        let loginManager = LoginManager()
//
//        if let _ = AccessToken.current {
//            // Perform log out
//            loginManager.logOut()
//        } else {
            loginManager.logIn(permissions: ["public_profile", "user_friends"], from: self) { [weak self] (result, error) in
                // Check for error
                guard error == nil else {
                    Functions.showLog(title: "FacebookLoginError", message: error?.localizedDescription ?? "")
                    return
                }
                // Check for cancel
                guard let result = result, !result.isCancelled else {
                    Functions.showLog(title: "FacebookLoginCancel", message: "")
                    return
                }
                self?.viewModel.linkFacebook(socialId: result.token?.userID ?? "", token: result.token?.tokenString ?? "")
            }
//        }
    }
    
    @IBAction func didClickVoiceSearch(_ sender: Any) {
//        if isSimulator {
//            showMessage(title: "", message: "voiceSimulator".localized)
//        } else {
//            if viewContainerVoiceSearch.isHidden == true && isGrantedPermisionSpeech == true {
//                animateVoiceView(isHidden: false)
//            }
//        }
    }
    
    @IBAction func actionInvite(_ sender: Any) {
        shareApp()
    }
    
    func didChangeStateButtonStart() {
        switch startState {
        case .start:
            lblVoiceSearchText.textColor = UI.Color.txtFloatTitleColor
            lblVoiceSearchText.text = "press_start".localized
            btnStartRecognizeVoice.setTitle("start_recognize_voice".localized, for: .normal)
            btnFinishRecognizeVoice.isHidden = true
        case .stop:
            lblVoiceSearchText.textColor = UI.Color.txtFloatTitleColor
            lblVoiceSearchText.text = "say_something".localized
            btnStartRecognizeVoice.setTitle("stop_recognize_voice".localized, for: .normal)
            btnFinishRecognizeVoice.isHidden = true
        case .reStart:
            lblVoiceSearchText.textColor = UIColor.black
            btnStartRecognizeVoice.setTitle("restart_recognize_voice".localized, for: .normal)
            btnFinishRecognizeVoice.isHidden = false
        }
    }
    
    func changeStateButtonStart() {
//        switch startState {
//        case .start:
//            startState = .stop
//            startSpeechRecognization()
//        case .stop:
//            stopSpeechRecognization()
//            startState = .reStart
//        case .reStart:
//            startSpeechRecognization()
//            startState = .stop
//        }
    }
    
//    func stopSpeechRecognization() {
//        task.finish()
//        task.cancel()
//        task = nil
//
//        request.endAudio()
//        audioEngine.stop()
//        // UPDATED
//        if audioEngine.inputNode.numberOfInputs > 0 {
//            audioEngine.inputNode.removeTap(onBus: 0)
//        }
//    }
    
    private func resetVoiceRecognize() {
        animateVoiceView(isHidden: true)
        startState = .start
    }
    
    @IBAction func didTouchCancelVoiceRecognize(_ sender: Any) {
        resetVoiceRecognize()
    }
    
    @IBAction func didClickStartVoiceRecognize(_ sender: Any) {
        changeStateButtonStart()
    }
    
    @IBAction func didClickFinishVoiceRecognize(_ sender: Any) {
        tvSearchKey.text = lblVoiceSearchText.text
        viewFriendList.isHidden = true
        tbvNotFriend.isHidden = false
        viewModel.getListNotFriends(name: tvSearchKey.text ?? "", isLoading: true)
        resetVoiceRecognize()
    }
}

extension FriendViewController: FriendViewModelDelegate {
    func didUpdateState(to state: FriendViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getFriendSuccess:
            tbvFriend.reloadData()
        case .unfriendSuccess:
            viewModel.getListFriends()
        case .rejectSuccess:
            viewModel.getFriendRequest()
        case .acceptSuccess:
            viewModel.getFriendRequest()
            viewModel.getListFriends()
        case .getNoFriendSuccess:
            tbvNotFriend.reloadData()
        case .requestFriend:
            if viewModel.noFriends.isEmpty == false {
                viewModel.noFriends[reloadIndex].requested = true
                tbvNotFriend.reloadRows(at: [IndexPath(row: reloadIndex, section: 0)], with: .none)
            }
        case .cancelRequest:
            if viewModel.noFriends.isEmpty == false {
                viewModel.noFriends[reloadIndex].requested = false
                tbvNotFriend.reloadRows(at: [IndexPath(row: reloadIndex, section: 0)], with: .none)
            }
        case .linkFacebook:
            viewFriendList.isHidden = true
            tbvNotFriend.isHidden = false
            tbvNotFriend.reloadData()
        case .canAccessProfile:
            guard let user = userInfo else {
                return
            }
            let otherUserVC = OtherUserViewController()
            otherUserVC.userInfo = user
            self.navigationController?.pushViewController(otherUserVC, animated: true)
        case .cannotAccessProfile:
            let alert = UIAlertController(title: "", message: "The profile is private. The information cannot be viewed".localized, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
extension FriendViewController: UITextFieldDelegate {
    @objc func textFieldDidChange(_ textField: UITextField) {
        if textField.text?.count ?? 0 == 0 {
            viewFriendList.isHidden = false
            tbvNotFriend.isHidden = true
            headerBack.title = "FRIENDS".localized
        } else {
            viewFriendList.isHidden = true
            tbvNotFriend.isHidden = false
            handleSearchWithText(textField.text ?? "")
            headerBack.title = "ADD FRIENDS".localized
        }
    }
}
extension FriendViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == tbvNotFriend {
            return 1
        }
        return 2
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if tableView == tbvNotFriend {
            return nil
        }
        let rect = CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 30)
        let label = UILabel(frame: CGRect(x: 20, y: 5, width: tableView.frame.size.width - 40, height: 25))
        label.font = UIFont(name: "NotoSansKR-Bold", size: 18) ?? .systemFont(ofSize: 18)
        label.textColor = .white
        if section == 1 {
            label.text = "friendList".localized + " (\(viewModel.friends.data?.count ?? 0))"
        } else {
            label.text = "friendRequest".localized + " (\(viewModel.friendsRequest.data?.count ?? 0))"
        }
        
        let footerView = UIView(frame: rect)
        footerView.backgroundColor = UIColor.clear
        footerView.addSubview(label)
        return footerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == tbvNotFriend {
            return 0
        }
        return 35
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tbvNotFriend {
            return viewModel.noFriends.count
        }
        if section == 0 {
            if viewModel.friendsRequest.data?.count ?? 0 == 0 {
                return 1
            }
            return viewModel.friendsRequest.data?.count ?? 1
        }
        if viewModel.friends.data?.count ?? 0 == 0 {
            return 1
        }
        return viewModel.friends.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tbvNotFriend {
            if indexPath.row == self.viewModel.noFriends.count - 1 && self.viewModel.page < self.viewModel.totalPages {
                self.onLoadMore()
            }
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendViewCell") as? FriendViewCell else {
                return FriendViewCell()
            }
            if viewModel.noFriends.isEmpty == false {
                let friend = viewModel.noFriends[indexPath.row]
                cell.index = indexPath.row
                cell.setupCellDes(user: friend, type: .friendAll)
                cell.tapRequest = {(obj, index) -> Void in
                    if obj.requested ?? false {
                        self.viewModel.cancelRequest(id: obj.id ?? 0)
                    } else {
                        self.viewModel.requestAddFriend(id: obj.id ?? 0)
                    }
                    self.reloadIndex = index
                }
            }
            
            return cell
        }
        if indexPath.section == 0 {
            if viewModel.friendsRequest.data?.count ?? 0 == 0 {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendNoDataViewCell") as? FriendNoDataViewCell else {
                    return FriendNoDataViewCell()
                }
                cell.lblNoData.text = "noFriendRequest".localized
                return cell
            } else {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendViewCell") as? FriendViewCell else {
                    return FriendViewCell()
                }
                if let friend = viewModel.friendsRequest.data?[indexPath.row] {
                    cell.setupCellDes(user: friend, type: .friendRequest)
                }
                cell.tapReject = {(obj) -> Void in
                    self.showMessage(title: "alertRejectTitle".localized, message: "rejectFriendRequest".localized + "\(obj.nickname ?? "") ?", buttonTitle: "cancel".localized, handle: nil) { _ in
                        self.viewModel.rejectRequest(id: obj.id ?? 0)
                    }
                }
                cell.tapAccept = {(obj) -> Void in
                    self.viewModel.acceptRequest(id: obj.id ?? 0)
                }
                return cell
            }
        } else {
            if viewModel.friends.data?.count ?? 0 == 0 {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendNoDataViewCell") as? FriendNoDataViewCell else {
                    return FriendNoDataViewCell()
                }
                cell.lblNoData.text = "noFriend".localized
                return cell
            } else {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendViewCell") as? FriendViewCell else {
                    return FriendViewCell()
                }
                let friend = viewModel.friends.data?[indexPath.row]
                cell.setupCellDes(user: friend ?? UserInfo(), type: .friendList)
                cell.tapUnfriend = {(obj) -> Void in
                    self.showMessage(title: "unfriendAlert".localized, message: "sureUnfriend".localized + "\(obj.nickname ?? "")", buttonTitle: "cancel".localized, handle: nil) { action in
                        self.viewModel.unfriend(id: obj.id ?? 0)
                    }
                }
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var user: UserInfo?
        if tableView == tbvNotFriend {
            user = viewModel.noFriends[indexPath.row]
        } else if indexPath.section == 0 && viewModel.friendsRequest.data?.count ?? 0 > 0 {
            user = viewModel.friendsRequest.data?[indexPath.row]
        } else if indexPath.section == 1 && viewModel.friends.data?.count ?? 0 > 0 {
            user = viewModel.friends.data?[indexPath.row]
        }
        if let user = user {
            userInfo = user
            let id = user.id ?? 0
            viewModel.checkProfilePrivate(id: id)
        }
    }
}
