//
//  FriendViewModel.swift
//  REPACE
//
//  Created by ThienBanh on 20/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit
import CloudKit
protocol FriendViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: FriendViewModelState)
}

enum FriendViewModelState {
    case canAccessProfile
    case cannotAccessProfile
    case getNoFriendSuccess
    case getFriendSuccess
    case unfriendSuccess
    case rejectSuccess
    case acceptSuccess
    case requestFriend
    case cancelRequest
    case linkFacebook
    case network(state: NetworkState)
}
class FriendViewModel: NSObject {
    private var state: FriendViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    weak var delegate: FriendViewModelDelegate?
    
    var page = 0
    var totalPages = 0
    var friends = FriendModel()
    var friendsRequest = FriendModel()
    var noFriends : [UserInfo] = []
    var keyword = ""
    
    func checkProfilePrivate(id: Int){
        state = .network(state: .loading)


        FriendServices.checkProfilePrivate(id: id) {[weak self] canAccess in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            self.state = canAccess ? .canAccessProfile : .cannotAccessProfile
        } failure: { error in
            self.state = .network(state: .hideLoading)
            self.state = .network(state: .error(error.localizedDescription))
        }

    }
    func getListFriends() {
        state = .network(state: .loading)
        FriendServices.getListFriends(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.friends = res
                self.state = .getFriendSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getListFriends", message: error)
            })
    }
    
    func getFriendRequest() {
        state = .network(state: .loading)
        FriendServices.getFriendRequest(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.friendsRequest = res
                self.state = .getFriendSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getFriendRequest", message: error)
            })
    }
    
    func getListNotFriends(name: String, isLoading: Bool) {
        if keyword != name {
            keyword = name
            page = 0
            totalPages = 0
            noFriends.removeAll()
        }
        if isLoading {
            state = .network(state: .loading)
        }
        FriendServices.getListNotFriends(page: page, name: name,
                                         success: { [weak self] res in
            guard let self = self else { return }
            if isLoading {
                self.state = .network(state: .hideLoading)
            }
            self.noFriends += res.data ?? []
            self.totalPages = res.totalPages ?? 0
            self.state = .getNoFriendSuccess
        },
                                         failure: { [weak self] error in
            if isLoading {
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
            Functions.showLog(title: "getFriendRequest", message: error)
        })
    }
    
    func unfriend(id: Int) {
        state = .network(state: .loading)  
        FriendServices.unfriend(
            id: id, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                //                self.friendsRequest = res
                self.state = .unfriendSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
    func rejectRequest(id : Int) {
        state = .network(state: .loading)
        FriendServices.rejectRequest(
            id: id, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .rejectSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
    func acceptRequest(id : Int) {
        state = .network(state: .loading)
        FriendServices.acceptRequest(
            id: id, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .acceptSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
    func requestAddFriend(id : Int) {
        state = .network(state: .loading)
        FriendServices.requestAddFriend(
            id: id, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .requestFriend
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
    func cancelRequest(id : Int) {
        state = .network(state: .loading)
        FriendServices.cancelRequest(
            id: id, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .cancelRequest
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
    func linkFacebook(socialId: String, token: String) {
        noFriends.removeAll()
        FriendServices.linkFacebook(
            socialID: socialId, token: token, success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.noFriends = res.data ?? [UserInfo]()
                self.state = .linkFacebook
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "unfriend", message: error)
            })
    }
}
