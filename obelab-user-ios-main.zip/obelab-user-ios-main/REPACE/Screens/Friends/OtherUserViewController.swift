//
//  OtherUserViewController.swift
//  REPACE
//
//  Created by ThienBanh on 26/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import UIKit
import SDWebImage
class OtherUserViewController: BaseViewController {
    @IBOutlet weak var headerBack: HeaderBack!

    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var imgAvatar: UIImageView!
    @IBOutlet weak var lblWeight: UILabel!
    @IBOutlet weak var lblHeight: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblBirthDate: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var leftSwitchButton: UIButton!
    @IBOutlet weak var rightSwitchButton: UIButton!
    @IBOutlet weak var measureItemView: MeasureItem!
    @IBOutlet weak var ltTestResultView: UIView!
    @IBOutlet weak var ltTestResultEmptyView: UIView!
    @IBOutlet weak var rxExerciseView: UIView!
    @IBOutlet weak var rxExerciseEmptyView: UIView!
    @IBOutlet weak var stageLabel: UILabel!
    @IBOutlet weak var lactateOnsetLabel: UILabel!
    @IBOutlet weak var smO2Label: UILabel!
    @IBOutlet weak var exerciseTypeLabel: UILabel!
    @IBOutlet weak var timesPerWeekLabel: UILabel!
    @IBOutlet weak var weeksLabel: UILabel!
    @IBOutlet weak var kmPerHoursLabel: UILabel!
    
    var viewModel = HomeViewModel()
    var userInfo: UserInfo!
    
    var isCumulative = false {
        didSet {
            toggleCumulative()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        headerBack.title = userInfo.nickname ?? "USER NAME"
        headerBack.btnRightAction.isHidden = true
        setupProfile()
        switchToLeft()
        if let id = userInfo.id {
            viewModel.loadAllDataForOtherUser(id: id)
        }
    }
    
    private func toggleCumulative() {
        if isCumulative {
            switchToRight()
        } else {
            switchToLeft()
        }
        setUpMyExerciseAverage()
//        setLTTestResult()
    }

    func setupProfile() {
        topView.layer.cornerRadius = UI.View.radius
        imgAvatar.layer.cornerRadius = imgAvatar.frame.width / 2
        if userInfo?.avatar?.count ?? 0 != 0, let avatarUrl = URL(string: userInfo?.avatar ?? Constants.AVATAR_DEFAULT) {
            imgAvatar.sd_setImage(with: avatarUrl, placeholderImage: UIImage(named: "img_avartar_default"))
        } else {
            imgAvatar.image = UIImage(named: "img_avartar_default")
        }
        
//        let avatarUrl = URL(string: userInfo?.avatar ?? Constants.AVATAR_DEFAULT)!
//        imgAvatar.load(url: avatarUrl)
        lblName.text = userInfo?.nickname
        lblEmail.text = userInfo?.email
        lblBirthDate.text = Functions.convertDateStrToProfileDateStr(dateStr: userInfo?.birthday ?? Constants.DATE_DEFAULT)
        lblGender.text = userInfo?.gender?.localized 
        lblHeight.text = "\(Functions.getHeightUnitValue(height: userInfo?.height ?? 0.0)) \(Functions.getHeightUnitName())"
        lblWeight.text = "\(Functions.getWeightUnitValue(weight: userInfo?.weight ?? 0.0)) \(Functions.getWeightUnitName())"
    }
    
    func switchToLeft() {
        leftSwitchButton.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        leftSwitchButton.setTitleColor(UIColor.white, for: .normal)
        rightSwitchButton.layer.backgroundColor = UI.Color.transparentColor.cgColor
        rightSwitchButton.setTitleColor(UI.Color.btnBgDisableColor, for: .normal)
    }
    
    func switchToRight() {
        leftSwitchButton.layer.backgroundColor = UI.Color.transparentColor.cgColor
        leftSwitchButton.setTitleColor(UI.Color.btnBgDisableColor, for: .normal)
        rightSwitchButton.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        rightSwitchButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    @IBAction func onClickLeftSwitch(_ sender: Any) {
        isCumulative = false
    }
    
    @IBAction func onClickRightSwitch(_ sender: Any) {
        isCumulative = true
    }
    
    func setUpMyExerciseAverage() {
        let exerciseUnit = isCumulative ? "/Total" : "/Week"
        if isCumulative {
            measureItemView.bindToData(model: viewModel.myExerciseAverageRight, exerciseUnit: exerciseUnit)
        } else {
            measureItemView.bindToData(model: viewModel.myExerciseAverageLeft, exerciseUnit: exerciseUnit)
        }
    }
    
    func setLTTestResult() {
        if (viewModel.ltTestResultLeft.stageCnt ?? 0) > 0 {
            let stage = viewModel.ltTestResultLeft.stageCnt ?? 0
            stageLabel.text = "\(stage)"
            lactateOnsetLabel.text = "\((viewModel.ltTestResultLeft.onset?.to1Decimal ?? 0.0))"
            smO2Label.text = "\((viewModel.ltTestResultLeft.smo2Avg?.to1Decimal ?? 0.0))"
            ltTestResultView.isHidden = false
            ltTestResultEmptyView.isHidden = true
        } else {
            ltTestResultView.isHidden = true
            ltTestResultEmptyView.isHidden = false
        }
    }
    func setUpRXExercise() {
        if (viewModel.exercisePresciption.type ?? 0) != 0 {
            if viewModel.exercisePresciption.type == LTTestConstants.PRESCRIPTION_TYPE_LOW {
                exerciseTypeLabel.text = "title_exercise_low".localized
                timesPerWeekLabel.text = "\(viewModel.exercisePresciption.leTime ?? 0)"
                weeksLabel.text = "\(viewModel.exercisePresciption.leWeek ?? 0)"
                kmPerHoursLabel.text = "\(viewModel.exercisePresciption.leSpeed ?? 0)"
            } else {
                exerciseTypeLabel.text = "title_exercise_polarized".localized
                timesPerWeekLabel.text = "\(viewModel.exercisePresciption.leTime ?? 0)/\(viewModel.exercisePresciption.ptTime ?? 0)"
                weeksLabel.text = "\(viewModel.exercisePresciption.ptWeek ?? 0)"
                kmPerHoursLabel.text = "\(viewModel.exercisePresciption.ptSpeed ?? 0)/\(viewModel.exercisePresciption.ptSpeed ?? 0)"
            }
            rxExerciseView.isHidden = false
            rxExerciseEmptyView.isHidden = true
        } else {
            rxExerciseView.isHidden = true
            rxExerciseEmptyView.isHidden = false
        }
    }
}
extension OtherUserViewController: HomeViewModelDelegate {
    func didUpdateState(to state: HomeViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMyExerciseAverageSuccess:
            setUpMyExerciseAverage()
        case .getLtTestResultHomeSuccess:
            setLTTestResult()
        case .getRXExerciseHomeSuccess:
            setUpRXExercise()
        }
    }
}
