//
//  GoalViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 12/14/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit
import Lottie

enum GoalType {
    case trophy
    case medal
    case badge
}

class GoalViewController: BaseViewController {
    
//    let maxTrophyLevels = 100
//    let maxMedalLevels = 100
//    let maxBadgeLevels = 100
    
    @IBOutlet weak var avBanner: AnimationView!
    @IBOutlet weak var svTrophies: UIStackView!
    
    @IBOutlet weak var trophyItemView: GoalItem!
    @IBOutlet weak var medalItemView: GoalItem!
    @IBOutlet weak var badageItemView: GoalItem!
    
    @IBOutlet weak var svMedals: UIStackView!
    @IBOutlet weak var svBadges: UIStackView!
    
    var viewModel: GoalViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = GoalViewModel()
        viewModel.delegate = self
        // 1. Set animation content mode
          
        avBanner.contentMode = .scaleAspectFit
          
          // 2. Set animation loop mode
          
        avBanner.loopMode = .loop
          
          // 3. Adjust animation speed
          
        avBanner.animationSpeed = 0.5
          
          // 4. Play animation
        avBanner.play()
        self.trophyItemView.setImage(#imageLiteral(resourceName: "trophydis"))
        self.trophyItemView.setLevel(level: 1)
        self.trophyItemView.setDescription("complete")
        self.trophyItemView.setTextColor(UIColor(named: "textPlaceholder") ?? .lightGray)
        self.medalItemView.setImage(#imageLiteral(resourceName: "medaldis"))
        self.medalItemView.setLevel(level: 4)
        self.medalItemView.setDescription("times")
        self.medalItemView.setTextColor(UIColor(named: "textPlaceholder") ?? .lightGray)
        self.badageItemView.setImage(#imageLiteral(resourceName: "badgedis"))
        self.badageItemView.setLevel(level: 4)
        self.badageItemView.setDescription("times")
        self.badageItemView.setTextColor(UIColor(named: "textPlaceholder") ?? .lightGray)
//        createGoalSubView()
        viewModel.getAchievements()
    }
    
    func createGoalSubView() {
        let trophy_cnt = viewModel.goalObj.trophy_cnt ?? 0
        let medal_cnt = viewModel.goalObj.medal_cnt ?? 0
        let badge_cnt = viewModel.goalObj.badge_cnt ?? 0
        
        addIcons(forStackView: svTrophies, firstView: trophyItemView, cnt: trophy_cnt, kind: .trophy)
        addIcons(forStackView: svMedals, firstView: medalItemView, cnt: medal_cnt, kind: .medal)
        addIcons(forStackView: svBadges, firstView: badageItemView, cnt: badge_cnt, kind: .badge)
    }
    
    private func addIcons(forStackView: UIStackView, firstView: GoalItem, cnt: Int, kind: GoalType) {
        let multiple = getMultipleTimes(kind: kind)
        // First Icons
        if cnt > 0 {
            let imgStr = getImageString(isActive: true, kind: kind)
            if let image = UIImage(named: imgStr) {
                firstView.setImage(image)
                firstView.setTextColor(.white)
            }
        }
        // Middle Icons
        if cnt > 1 {
            for level in 2...cnt {
                let levels = level * multiple
                addGoldItem(superView: forStackView, level: levels, isActive: true, kind: kind)
            }
        }
        // Last Icons
//        if cnt > 0 {
//            let levels = (cnt + 1) * multiple
//            addGoldItem(superView: forStackView, level: levels, isActive: false, kind: kind)
//        }
    }
    
    private func getMultipleTimes(kind: GoalType) -> Int {
        switch kind {
        case .trophy:
            return 1
        case .medal:
            return 4
        case .badge:
            return 4
        }
    }
    
    private func getImageString(isActive: Bool, kind: GoalType) -> String {
        switch kind {
        case .trophy:
            return isActive ? "trophyon" : "trophydis"
        case .medal:
            return isActive ? "icmedal" : "medaldis"
        case .badge:
            return isActive ? "ic_badge-1" : "badgedis"
        }
    }
    
    private func addGoldItem(superView: UIStackView, level: Int, isActive: Bool, kind: GoalType) {
        let goal = GoalItem()
        goal.setLevel(level: level)
        let imageStr = getImageString(isActive: isActive, kind: kind)
        if let image = UIImage(named: imageStr) {
            goal.setImage(image)
        }
        if kind == .trophy {
            goal.setDescription("complete")
        } else {
            goal.setDescription("times")
        }
        
        goal.setTextColor(isActive ? .white : UIColor(named: "textPlaceholder") ?? .lightGray)
        
        superView.addArrangedSubview(goal)
    }
}

extension GoalViewController: GoalViewModelDelegate {
    func didUpdateState(to state: GoalViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getAchievementsSuccess:
            self.createGoalSubView()
        }
    }
}
