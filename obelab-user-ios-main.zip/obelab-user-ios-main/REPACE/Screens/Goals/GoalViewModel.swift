//
//  GoalViewModel.swift
//  REPACE
//
//  Created by ThienBanh on 19/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import Foundation

protocol GoalViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: GoalViewModelState)
}

enum GoalViewModelState {
    case getAchievementsSuccess
    case network(state: NetworkState)
}

class GoalViewModel {
    private var state: GoalViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    var goalObj = GoalModel()
    weak var delegate: GoalViewModelDelegate?
    func getAchievements() {
        state = .network(state: .loading)
        UserServices.getAchievements(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.goalObj = res
                self.state = .getAchievementsSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getAchievementsError", message: error)
            })
    }
    
}
