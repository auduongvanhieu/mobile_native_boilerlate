//
//  HelpDetailViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/3/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class HelpDetailViewController: BaseViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var contentTextview: UITextView!
    @IBOutlet weak var contentViewHeight: NSLayoutConstraint!
    
    var faqModel = FaqModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
        vwSendMail.setViewController(self)
        setUpData()
    }
    
    @IBOutlet weak var vwSendMail: SendMailView!
    
    func setUpView() {
        // Content
        contentTextview.layer.cornerRadius = UI.View.radius
        contentTextview.textContainerInset = UIEdgeInsets(top: UI.View.paddingText, left: UI.View.paddingText, bottom: UI.View.paddingText, right: UI.View.paddingText)
    }
    
    func setUpData() {
        titleLabel.text = faqModel.question
        dateLabel.text = Functions.convertSqlDateToNoticeDateStr(sqlDate: faqModel.updatedAt ?? Constants.SQL_DATE_DEFAULT)
        contentTextview.text = faqModel.answer
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [self] in
            contentViewHeight.constant = titleLabel.layer.frame.height + contentTextview.layer.frame.height + 250
            self.view.layoutIfNeeded()
        }
    }
}
