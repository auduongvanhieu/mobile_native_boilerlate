//
//  HelpTableCell.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/3/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class HelpTableViewCell: UITableViewCell {

    @IBOutlet weak var tvTitle: UILabel!
    
    override func awakeFromNib() {
       super.awakeFromNib()
    }
    
    func bindData(faq: FaqModel) {
        self.tvTitle.text = faq.question ?? ""
    }
}
