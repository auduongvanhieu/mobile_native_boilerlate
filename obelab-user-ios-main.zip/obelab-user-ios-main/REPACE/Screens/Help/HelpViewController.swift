import Foundation
import UIKit

class HelpViewController: BaseViewController , UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableNotices: UITableView!
    @IBOutlet weak var vwSendMail: SendMailView!
    
    var viewModel: HelpViewModel!
    let refreshControl = UIRefreshControl()

    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setupTableView()
        vwSendMail.setViewController(self)
        onRefresh()
    }
    
    @objc private func onRefreshData(_ sender: Any) {
        onRefresh()
    }
    
    func onRefresh() {
        viewModel.faqList.removeAll()
        viewModel.getFaqList()
    }
    
    func setupTableView() {
        // delegate & datasouce
        tableNotices.delegate = self
        tableNotices.dataSource = self
        // Add Refresh Control to Table View
        if #available(iOS 10.0, *) {
            tableNotices.refreshControl = refreshControl
        } else {
            tableNotices.addSubview(refreshControl)
        }
        // Configure Refresh Control
        refreshControl.addTarget(self, action: #selector(onRefreshData(_:)), for: .valueChanged)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.faqList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "helpCellId", for: indexPath) as? HelpTableViewCell {
            cell.bindData(faq: self.viewModel.faqList[indexPath.row])
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AppNavigator.shared.navigate(to: SettingRoutes.helpDetail(faq: self.viewModel.faqList[indexPath.row]), with: .push)
    }
}

extension HelpViewController: HelpViewModelDelegate {
    func didUpdateState(to state: HelpViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getFaqListSuccess:
            refreshControl.endRefreshing()
            tableNotices.reloadData()
        }
    }
}
