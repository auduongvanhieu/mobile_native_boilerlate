import Foundation

protocol HelpViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: HelpViewModelState)
}

enum HelpViewModelState {
    case getFaqListSuccess
    case network(state: NetworkState)
}

class HelpViewModel {
    
    private var state: HelpViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: HelpViewModelDelegate?
    
    var faqList: [FaqModel] = []
    
    func getFaqList() {
        state = .network(state: .loading)
        GeneralServices.getFaqList(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.faqList = res
                self.state = .getFaqListSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
