//
//  HomeViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 27/10/2021.
//  Copyright © 2017 Rootstrap Inc. All rights reserved.
//

import UIKit

class HomeViewController: BaseViewController {
    // MARK: - Outlets
    @IBOutlet weak var leftSwitchButton: UIButton!
    @IBOutlet weak var rightSwitchButton: UIButton!
    @IBOutlet weak var measureItemView: MeasureItem!
    @IBOutlet weak var ltTestResultView: UIView!
    @IBOutlet weak var ltTestResultEmptyView: UIView!
    @IBOutlet weak var rxExerciseView: UIView!
    @IBOutlet weak var rxExerciseEmptyView: UIView!
    @IBOutlet weak var stageLabel: UILabel!
    @IBOutlet weak var lactateOnsetLabel: UILabel!
    @IBOutlet weak var smO2Label: UILabel!
    @IBOutlet weak var exerciseTypeLabel: UILabel!
    @IBOutlet weak var timesPerWeekLabel: UILabel!
    @IBOutlet weak var weeksLabel: UILabel!
    @IBOutlet weak var kmPerHoursLabel: UILabel!
    
    @IBOutlet weak var lblUnitExerciseTest: UILabel!
    @IBOutlet weak var lblUnitLTTest: UILabel!
    var viewModel = HomeViewModel()
    
    var isCumulative = false {
        didSet {
            toggleCumulative()
        }
    }
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        switchToLeft()
        toggleCumulative()
        
        // Test Measure Data
        // testMeasureData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.viewModel.loadAllData()
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let home = R.storyboard.main.homeViewController() else {
            return UIViewController()
        }
        return home
    }
    
    private func toggleCumulative() {
        if isCumulative {
            switchToRight()
        } else {
            switchToLeft()
        }
        setUpMyExerciseAverage()
    }
    
    func testMeasureData() {
        let dataStr = "0A0B0C0142000000160000000000000000000000000000000000000000000000000000000000000000002F001E0000000000470019FFFF000000000006FFCD08D7009CFEA2FE9E4A"
        let measureData: [UInt8] = dataStr.toBytes()
        Functions.showLog(title: "measureDataArray", message: measureData)
        Functions.showLog(title: "measureDataHexStr", message: Functions.toHexString(byteArray: measureData))
        Functions.showLog(title: "measureDataHexArrayStr", message: Functions.toHexArrayString(byteArray: measureData))
        Functions.showLog(title: "measureDataObject", message: BluetoothHelper.getPayloadData(data: measureData))
        Functions.showLog(title: "measureDataRSO2", message: measureData[57] + measureData[58])
    }
    
    func switchToLeft() {
        leftSwitchButton.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        leftSwitchButton.setTitleColor(UIColor.white, for: .normal)
        rightSwitchButton.layer.backgroundColor = UI.Color.transparentColor.cgColor
        rightSwitchButton.setTitleColor(UI.Color.btnBgDisableColor, for: .normal)
    }
    
    func switchToRight() {
        leftSwitchButton.layer.backgroundColor = UI.Color.transparentColor.cgColor
        leftSwitchButton.setTitleColor(UI.Color.btnBgDisableColor, for: .normal)
        rightSwitchButton.layer.backgroundColor = UI.Color.btnBgColor.cgColor
        rightSwitchButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    @IBAction func onClickLeftSwitch(_ sender: Any) {
        isCumulative = false
    }
    
    @IBAction func onClickRightSwitch(_ sender: Any) {
        isCumulative = true
    }
    
    @IBAction func onClickGoToLTTest(_ sender: Any) {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 1])
        } else {
            showDisconnectedDeviceAlert()
        }
    }
    
    func setUpMyExerciseAverage() {
        let exerciseUnit = isCumulative ? "/Total" : "/Week"
        if isCumulative {
            measureItemView.bindToData(model: viewModel.myExerciseAverageRight, exerciseUnit: exerciseUnit)
        } else {
            measureItemView.bindToData(model: viewModel.myExerciseAverageLeft, exerciseUnit: exerciseUnit)
        }
    }
    
    func setLTTestResult() {
        if (viewModel.ltTestResultLeft.stageCnt ?? 0) > 0 {
            let stage = viewModel.ltTestResultLeft.stageCnt ?? 0
            stageLabel.text = "\(stage)"
            lactateOnsetLabel.text = "\(Functions.kmToMile(km: viewModel.ltTestResultLeft.onset).to1Decimal)"
//            lactateOnsetLabel.text = "\((viewModel.ltTestResultLeft.onset?.to1Decimal ?? 0.0))"
            smO2Label.text = "\((viewModel.ltTestResultLeft.smo2Avg?.to1Decimal ?? 0.0))"
            ltTestResultView.isHidden = false
            ltTestResultEmptyView.isHidden = true
        } else {
            ltTestResultView.isHidden = true
            ltTestResultEmptyView.isHidden = false
        }
        lblUnitLTTest.text = Functions.showUnitLabel(isSpeed: true)
    }
    
    func setUpRXExercise() {
        if (viewModel.exercisePresciption.type ?? 0) != 0 {
            if viewModel.exercisePresciption.type == LTTestConstants.PRESCRIPTION_TYPE_LOW {
                exerciseTypeLabel.text = "title_exercise_low".localized
                timesPerWeekLabel.text = "\(viewModel.exercisePresciption.leTime ?? 0)"
                weeksLabel.text = "\(viewModel.exercisePresciption.leWeek ?? 0)"
                let leSpeed = Functions.kmToMile(km: viewModel.exercisePresciption.leSpeed)
                kmPerHoursLabel.text = "\(leSpeed)"
            } else {
                exerciseTypeLabel.text = "title_exercise_polarized".localized
                timesPerWeekLabel.text = "\(viewModel.exercisePresciption.leTime ?? 0)/\(viewModel.exercisePresciption.ptTime ?? 0)"
                weeksLabel.text = "\(viewModel.exercisePresciption.ptWeek ?? 0)"
//                kmPerHoursLabel.text = "\(viewModel.exercisePresciption.leSpeed ?? 0)/\(viewModel.exercisePresciption.ptSpeed ?? 0)"
                let leSpeed = Functions.kmToMile(km: viewModel.exercisePresciption.leSpeed)
                let ptSpeed = Functions.kmToMile(km: viewModel.exercisePresciption.ptSpeed)
                kmPerHoursLabel.text = "\(leSpeed)/\(ptSpeed)"
            }
            rxExerciseView.isHidden = false
            rxExerciseEmptyView.isHidden = true
        } else {
            rxExerciseView.isHidden = true
            rxExerciseEmptyView.isHidden = false
        }
        lblUnitExerciseTest.text = Functions.showUnitLabel(isSpeed: true)
    }
}

extension HomeViewController: HomeViewModelDelegate {
    func didUpdateState(to state: HomeViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMyExerciseAverageSuccess:
            setUpMyExerciseAverage()
        case .getLtTestResultHomeSuccess:
            setLTTestResult()
        case .getRXExerciseHomeSuccess:
            setUpRXExercise()
        }
    }
}
