import Foundation

protocol HomeViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: HomeViewModelState)
}

enum HomeViewModelState {
    case getMyExerciseAverageSuccess
    case getLtTestResultHomeSuccess
    case getRXExerciseHomeSuccess
    case network(state: NetworkState)
}

class HomeViewModel {
    
    typealias Completion = () -> Void
    weak var delegate: HomeViewModelDelegate?
    
    private var state: HomeViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    var myExerciseAverageLeft = ExerciseAverage()
    var myExerciseAverageRight = ExerciseAverage()
    var ltTestResultLeft = LTTestResultModel()
    var exercisePresciption = ExercisePresciptionModel()
    
    func loadAllData() {
        self.state = .network(state: .loading)
        self.getUserPreferrenceSetting(completion: { [weak self] in
            self?.getMyExerciseAverage(isCumulative: false, completion: { [weak self] in
                self?.getLtTestResultHome(completion: { [weak self] in
                    self?.getRXExerciseHome(completion: { [weak self] in
                        self?.state = .network(state: .hideLoading)
                    })
                })
            })
            self?.getMyExerciseAverage(isCumulative: true, completion: nil)
        })
        getLtTestSetting()
    }
    
    func loadAllDataForOtherUser(id: Int) {
        self.state = .network(state: .loading)
        getOtherExerciseAverage(id: id, isCumulative: false, completion: { [weak self] in
            self?.getOtherLtTestResultHome(id: id, completion: { [weak self] in
                self?.getOtherRXExerciseHome(id: id, completion: { [weak self] in
                    self?.state = .network(state: .hideLoading)
                })
            })
        })
        getOtherExerciseAverage(id: id, isCumulative: true, completion: nil)
    }
    
    func getMyExerciseAverage(isCumulative: Bool, completion: Completion?) {
        HomeServices.getMyExerciseAverage(
            cumulative: isCumulative,
            success: { [weak self] res in
                if isCumulative == false {
                    self?.myExerciseAverageLeft = res
                } else {
                    self?.myExerciseAverageRight = res
                }
                self?.state = .getMyExerciseAverageSuccess
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    
    func getLtTestResultHome(completion: Completion?) {
        HomeServices.getLastestLtTestResultHome(
            success: { [weak self] res in
                self?.ltTestResultLeft = res
                self?.state = .getLtTestResultHomeSuccess
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    
    func getRXExerciseHome(completion: Completion?) {
        HomeServices.getExercisePrescription(
            success: { [weak self] res in
                completion?()
                self?.exercisePresciption = res
                self?.state = .getRXExerciseHomeSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    
    func getOtherExerciseAverage(id: Int, isCumulative: Bool, completion: Completion?) {
        HomeServices.getOtherExerciseAverage(
            id: id,
            cumulative: isCumulative,
            success: { [weak self] res in
                if isCumulative == false {
                    self?.myExerciseAverageLeft = res
                } else {
                    self?.myExerciseAverageRight = res
                }
                self?.state = .getMyExerciseAverageSuccess
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    func getOtherLtTestResultHome(id: Int, completion: Completion?) {
        HomeServices.getLastestLtTestOtherUser(
            id: id,
            success: { [weak self] res in
                self?.ltTestResultLeft = res
                self?.state = .getLtTestResultHomeSuccess
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                
            }
        )
    }
    func getOtherRXExerciseHome(id: Int, completion: Completion?) {
        HomeServices.getOtherExercisePrescription(
            id: id,
            success: { [weak self] res in
                completion?()
                self?.exercisePresciption = res
                self?.state = .getRXExerciseHomeSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            }
        )
    }
    
    private func getLtTestSetting() {
        LTTestServices.getLtTestSetting { (model) in
            let repaceLibrary = RepaceLibrary()
            let protocolObjectValue = repaceLibrary.getProtocol(Functions.getLTTestUserType().toInt32, LocalDataManager.profile?.getAge().toInt32 ?? 28, model.distance?.toInt32 ?? 0, model.number?.toInt32 ?? 0, model.time ?? 0.0)
            LocalDataManager.ltTestProtocol = RepaceProtocolModel(protocolValue: Int(protocolObjectValue.protocol), startSpeed: protocolObjectValue.startSpeed, heartRate: Int(protocolObjectValue.heartRate))
        } failure: { (err) in
            Functions.showLog(title: "Error API", message: err)
        }
    }
    
    private func getUserPreferrenceSetting(completion: (() -> Void)?) {
        UserServices.getMemberSetting(success: { _ in
            completion?()
        }, failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
}
