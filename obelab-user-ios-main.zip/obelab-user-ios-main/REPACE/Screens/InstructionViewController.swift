import Foundation
import UIKit

protocol InstructionViewDialogDelegate: NSObjectProtocol {
    func onFinish()
}

class InstructionViewController: UIViewController, UIScrollViewDelegate {
    var slides: [InstructionItem] = []
    
    @IBOutlet weak var viewSlider: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var btnCheck: UIButton!
    var doNotShow = false
    
    weak var delegate: InstructionViewDialogDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        slides = createSlides()
        pageControl.numberOfPages = slides.count
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = UI.Color.txtPlaceholderColor
        pageControl.currentPageIndicatorTintColor = UI.Color.btnBgColor
        scrollView.showsVerticalScrollIndicator = false
        view.bringSubviewToFront(pageControl)
        
        setupOverlay()
        scrollView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupSlideScrollView(slides: slides)
    }
    
    @IBAction func btnNext_Click(_ sender: Any) {
        if doNotShow == true {
            LocalDataManager.isShowLTTestGuide = false
        }
        
        if pageControl.currentPage == pageControl.numberOfPages - 1 {
            self.dismiss(animated: true, completion: nil)
            delegate?.onFinish()
        } else {
            pageControl.currentPage += 1
            pageControl_ValueChanged(pageControl as Any)
        }
    }
    
    @IBAction func btnCheck_Click(_ sender: Any) {
        if doNotShow == false {
            doNotShow = true
            btnCheck.setImage(UI.Icon.ic_check_checked_dark, for: .normal)
        } else {
            doNotShow = false
            btnCheck.setImage(UI.Icon.ic_check_empty_dark, for: .normal)
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        // This method is called when the scrollview finally stops scrolling.
        let width = scrollView.frame.size.width
        let page = (scrollView.contentOffset.x + (0.5 * width)) / width
        pageControl.currentPage = Int(page)
        changeTitleButtonNext()
    }
    
    private func changeTitleButtonNext() {
        if pageControl.currentPage == pageControl.numberOfPages - 1 {
            btnNext.setTitle("btn_skip".localized, for: .normal)
        } else {
            btnNext.setTitle("btn_next".localized, for: .normal)
        }
    }
    
    func setupOverlay() {
        // adding an overlay to the view to give focus to the dialog box
        view.backgroundColor = UIColor.black.withAlphaComponent(0.50)
    }
    
    @IBAction func pageControl_ValueChanged(_ sender: Any) {
        var frame = scrollView.frame
        frame.origin.x = frame.size.width * CGFloat(pageControl.currentPage)
        frame.origin.y = 0
        scrollView.scrollRectToVisible(frame, animated: true)
        changeTitleButtonNext()
    }
    
    func createSlides() -> [InstructionItem] {
        
        let slide2 = InstructionItem()
        slide2.ivImage.image = UIImage(named: "img_instruction-step1")
        slide2.tvContent.text = "slide2".localized
        
        let slide3 = InstructionItem()
        slide3.ivImage.image = UIImage(named: "img_instruction-step2")
        slide3.tvContent.text = "slide3".localized
        //
        let slide4 = InstructionItem()
        slide4.ivImage.image = UIImage(named: "img_instruction-step3")
        slide4.tvContent.text = "slide4".localized
        //
        let slide5 = InstructionItem()
        slide5.ivImage.image = UIImage(named: "img_instruction-step4")
        slide5.tvContent.text = "slide5".localized
        
        return [slide2, slide3, slide4, slide5]
    }
    
    func setupSlideScrollView(slides: [InstructionItem]) {
        let width = scrollView.frame.width
        scrollView.frame = CGRect(x: 0, y: 0, width: width, height: viewSlider.frame.height)
        scrollView.contentSize = CGSize(width: width * CGFloat(slides.count), height: viewSlider.frame.height)
        scrollView.isPagingEnabled = true
        
        for index in 0 ..< slides.count {
            slides[index].frame = CGRect(x: width * CGFloat(index), y: 0, width: width, height: viewSlider.frame.height)
            scrollView.addSubview(slides[index])
        }
    }
}
