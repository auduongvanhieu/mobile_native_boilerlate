import Foundation
import UIKit
import RealmSwift

class ExerciseAmountSettingViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var timeSlider: SettingSlider!
    @IBOutlet weak var distanceSlider: SettingSlider!
    @IBOutlet weak var numberSlider: SettingSlider!
    
    @IBOutlet weak var lblRightButton: UILabel!
    @IBOutlet weak var lblCenterButton: UILabel!
    @IBOutlet weak var lblLeftButton: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    var viewModel = ExerciseAmountSettingViewModel()
    var isDisableLinkButton = true
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        setUpUserTypeButton()
        viewModel.getLtTestSetting()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        scrollView.isScrollEnabled = scrollView.bounds.height < 135.0 * 3
    }
    
    func setUpView() {
        timeSlider.type = LTTestConstants.TIME
        distanceSlider.type = LTTestConstants.DISTANCE
        numberSlider.type = LTTestConstants.NUMBER
        timeSlider.delegate = self
        distanceSlider.delegate = self
        numberSlider.delegate = self
        distanceSlider.unit = Functions.showUnitLabel(isSpeed: false)
        lblRightButton.layer.cornerRadius = 12.0
        lblRightButton.clipsToBounds = true
        lblCenterButton.layer.cornerRadius = 12.0
        lblCenterButton.clipsToBounds = true
        lblLeftButton.layer.cornerRadius = 12.0
        lblLeftButton.clipsToBounds = true
        distanceSlider.step = Float(Functions.kmToMile(km: 1.0))
        distanceSlider.max = distanceSlider.step * 12 // 12 km
    }
    
    func setUpUserTypeButton() {
        timeSlider.setValue(value: viewModel.settingModel.time ?? 0.0)
        distanceSlider.setValue(value: Functions.kmToMile(km: Double(viewModel.settingModel.distance ?? 0)))
//        distanceSlider.setValue(value: Double(viewModel.settingModel.distance ?? 0))
        numberSlider.setValue(value: Double(viewModel.settingModel.number ?? 0))
        
        switch viewModel.settingModel.userType {
        case LTTestConstants.ORDINARY_USER:
            setLeftEnable()
            setCenterDisable()
            setRightDisable()
        case LTTestConstants.RUNNING_USER:
            setLeftDisable()
            setCenterEnable()
            setRightDisable()
        case LTTestConstants.ETC_USER:
            setLeftDisable()
            setCenterDisable()
            setRightEnable()
        case .none:
            setLeftEnable()
            setCenterDisable()
            setRightDisable()
        case .some:
            setLeftEnable()
            setCenterDisable()
            setRightDisable()
        }
    }
    
    func setLeftEnable() {
        lblLeftButton.backgroundColor = UI.Color.btnBgColor
        lblLeftButton.textColor = UIColor.white
    }
    
    func setLeftDisable() {
        lblLeftButton.backgroundColor = UI.Color.btnBgDisableColor
        lblLeftButton.textColor = UI.Color.txtPlaceholderColor
    }
    
    func setCenterEnable() {
        lblCenterButton.backgroundColor = UI.Color.btnBgColor
        lblCenterButton.textColor = UIColor.white
    }
    
    func setCenterDisable() {
        lblCenterButton.backgroundColor = UI.Color.btnBgDisableColor
        lblCenterButton.textColor = UI.Color.txtPlaceholderColor
    }
    
    func setRightEnable() {
        lblRightButton.backgroundColor = UI.Color.btnBgColor
        lblRightButton.textColor = UIColor.white
    }
    
    func setRightDisable() {
        lblRightButton.backgroundColor = UI.Color.btnBgDisableColor
        lblRightButton.textColor = UI.Color.txtPlaceholderColor
    }
    
    @IBAction func onClickLeft(_ sender: Any) {
        viewModel.settingModel.userType = LTTestConstants.ORDINARY_USER
        if isDisableLinkButton == false {
            viewModel.settingModel.time = 0
            viewModel.settingModel.distance = 0
            viewModel.settingModel.number = 0
        }
        setUpUserTypeButton()
    }
    
    @IBAction func onClickCenter(_ sender: Any) {
        viewModel.settingModel.userType = LTTestConstants.RUNNING_USER
        if isDisableLinkButton == false {
            viewModel.settingModel.time = 2.5
            viewModel.settingModel.distance = 6
            viewModel.settingModel.number = 5
        }
        setUpUserTypeButton()
    }
    
    @IBAction func onClickRight(_ sender: Any) {
        viewModel.settingModel.userType = LTTestConstants.ETC_USER
        if isDisableLinkButton == false {
            viewModel.settingModel.time = 5
            viewModel.settingModel.distance = 12
            viewModel.settingModel.number = 10
        }
        setUpUserTypeButton()
    }
    
    @IBAction func onClickSave(_ sender: Any) {
        viewModel.updateLtTestSetting()
    }
}
extension ExerciseAmountSettingViewController: SettingSliderDelegate {
    func onSeek(type: String, value: Double) {
        Functions.showLog(title: "onSeekType", message: type)
        Functions.showLog(title: "onSeekValue", message: value)
        if type == LTTestConstants.TIME {
            viewModel.settingModel.time = value
        } else if type == LTTestConstants.DISTANCE {
            var km = value
            // Convert mile to km, server save km data
            if LocalDataManager.unit != Constants.UNIT_METRIC {
                km = Functions.mileToKm(mile: km).rounded(.toNearestOrAwayFromZero)
            }
            viewModel.settingModel.distance = Int(km)
        } else {
            viewModel.settingModel.number = Int(value)
        }
    }
}

extension ExerciseAmountSettingViewController: ExerciseAmountSettingViewModelDelegate {
    func didUpdateState(to state: ExerciseAmountSettingViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getTermOfUseSuccess:
            setUpUserTypeButton()
        case .updateLtTestSettingSuccess:
            Functions.showLog(title: "updateLtTestSettingSuccess", message: "BACK")
            AppNavigator.shared.pop()
        }
    }
}
