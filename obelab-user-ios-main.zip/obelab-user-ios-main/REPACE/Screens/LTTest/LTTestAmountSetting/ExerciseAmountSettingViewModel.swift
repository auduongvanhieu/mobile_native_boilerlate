import Foundation

protocol ExerciseAmountSettingViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: ExerciseAmountSettingViewModelState)
}

enum ExerciseAmountSettingViewModelState {
    case getTermOfUseSuccess
    case updateLtTestSettingSuccess
    case network(state: NetworkState)
}

class ExerciseAmountSettingViewModel {
    
    private var state: ExerciseAmountSettingViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: ExerciseAmountSettingViewModelDelegate?
    
    var settingModel = LTTestSettingModel()
    
    func getLtTestSetting() {
        state = .network(state: .loading)
        LTTestServices.getLtTestSetting(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.settingModel = res
                self.state = .getTermOfUseSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func updateLtTestSetting() {
        state = .network(state: .loading)
        LTTestServices.updateLtTestSetting(ltTestSetting: settingModel,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .updateLtTestSettingSuccess
                } else {
                    self.state = .updateLtTestSettingSuccess
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
