import Foundation
import UIKit
import CoreLocation

class TestSummaryOffViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var treadmillView: UIView!
    @IBOutlet weak var outdoorView: UIView!
    @IBOutlet weak var treadmillLabel: UILabel!
    @IBOutlet weak var outdoorLabel: UILabel!
    @IBOutlet weak var treadmillButton: UIButton!
    @IBOutlet weak var outdoorButton: UIButton!
    @IBOutlet weak var startSpeedLabel: UILabel!
    @IBOutlet weak var increaseLabel: UILabel!
    @IBOutlet weak var restTimeLabel: UILabel!
    @IBOutlet weak var stageTimeLabel: UILabel!
    @IBOutlet weak var lblUnitStartSpeed: UILabel!
    @IBOutlet weak var topTextView: UITextView!
    @IBOutlet weak var bottomTextView: UITextView!
    
    var btnBluetooth: UIButton!
    var viewModel = TestSummaryOffViewModel()
    let locationManager = CLLocationManager()
    var isRequestPermission = false
    var isTreadMill = false
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        let button = UIButton()
        button.setImage(UIImage(named: "ic_bar"), for: .normal)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: button)
        button.addTarget(self, action: #selector(self.actionMenu), for: .touchUpInside)
        let icon = UIImage(named: "ic_bluetooth_off")
        let iconSize = CGRect(origin: CGPoint.zero, size: CGSize(width: 25, height: 25))
        btnBluetooth = UIButton(frame: iconSize)
        btnBluetooth.setImage(icon, for: .normal)
        btnBluetooth.addTarget(self, action: #selector(self.actionBluetooth), for: .touchUpInside)
        let menuBarItem = UIBarButtonItem(customView: btnBluetooth)
        let currWidth = menuBarItem.customView?.widthAnchor.constraint(equalToConstant: 25)
        currWidth?.isActive = true
        let currHeight = menuBarItem.customView?.heightAnchor.constraint(equalToConstant: 25)
        currHeight?.isActive = true
        self.navigationItem.rightBarButtonItem = menuBarItem
        checkConnection()
        viewModel.getLtTestSetting()
        locationManager.delegate = self
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkConnection), name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(reloadString), name: NotificationCenterHelper.CHANGE_LANGUAGE_ACTION, object: nil)
        
        lblUnitStartSpeed.text = Functions.showUnitLabel(isSpeed: true)
        topTextView.text = "topTextView".localized
        bottomTextView.text = "bottomTextView".localized
    }
    func setButtonIsConnected(){
        btnBluetooth.setImage(UI.Icon.ic_bluetooth_on, for: .normal)
    }
    func setButtonIsDisconnected(){
        btnBluetooth.setImage(UI.Icon.ic_bluetooth_off, for: .normal)
    }
    @objc func actionBluetooth() {
        AppNavigator.shared.navigate(to: AuthRoutes.pairing(goToHome: true), with: .push)
    }
    @objc func actionMenu() {
        let notificationOpenOrCloseSideMenu = Notification.Name("notificationOpenOrCloseSideMenu")
        NotificationCenter.default.post(name: notificationOpenOrCloseSideMenu, object: nil)
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: Notification.Name("notificationOpenOrCloseSideMenu"), object: nil)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        checkConnection()
    }
    
    @objc func reloadString() {
        topTextView.text = "topTextView".localized
        bottomTextView.text = "bottomTextView".localized
    }
    
    func checkLTTestSetting() {
        let ltTestSetting = LocalDataManager.ltTestSetting
        if ltTestSetting.userType == "" {
            setButtonDisable()
        } else {
            setButtonEnable()
        }
    }
    
    @objc func checkConnection() {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            let icon = UIImage(named: "ic_bluetooth_on")
            btnBluetooth.setImage(icon, for: .normal)
            checkLTTestSetting()
        } else {
            let icon = UIImage(named: "ic_bluetooth_off")
            btnBluetooth.setImage(icon, for: .normal)
            setButtonDisable()
        }
    }
    
    func setButtonEnable() {
        treadmillView.backgroundColor = UI.Color.btnBgColor
        treadmillLabel.textColor = UIColor.white
        treadmillButton.setTitleColor(UIColor.white, for: .normal)
        treadmillButton.isEnabled = true
        outdoorView.backgroundColor = UI.Color.btnBgColor
        outdoorLabel.textColor = UIColor.white
        outdoorButton.setTitleColor(UIColor.white, for: .normal)
        outdoorButton.isEnabled = true
        increaseLabel.text = "\(LTTestConstants.INCREASE_IN_SPEED_PER_STAGE)"
        restTimeLabel.text = "\(LTTestConstants.REST_TIME)"
        stageTimeLabel.text = "\(LTTestConstants.STAGE_TIME)"
        let repaceLibrary = RepaceLibrary()
        let protocolObjectValue = repaceLibrary.getProtocol(Functions.getLTTestUserType().toInt32, LocalDataManager.profile?.getAge().toInt32 ?? 28, LocalDataManager.ltTestSetting.distance?.toInt32 ?? 0, LocalDataManager.ltTestSetting.number?.toInt32 ?? 0, LocalDataManager.ltTestSetting.time ?? 0.0)
        Functions.showLog(title: "protocolObjectValue", message: protocolObjectValue)
        startSpeedLabel.text = "\(Functions.kmToMile(km: protocolObjectValue.startSpeed))"
//        startSpeedLabel.text = "\(protocolObjectValue.startSpeed)"
        if protocolObjectValue.startSpeed == 5.4 {
            increaseLabel.text = "0.5"
        }
        LocalDataManager.ltTestProtocol = RepaceProtocolModel(protocolValue: Int(protocolObjectValue.protocol), startSpeed: protocolObjectValue.startSpeed, heartRate: Int(protocolObjectValue.heartRate))
    }
    
    func setButtonDisable() {
        treadmillView.backgroundColor = UI.Color.btnBgDisableColor
        treadmillLabel.textColor = UI.Color.txtPlaceholderColor
        treadmillButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
        treadmillButton.isEnabled = false
        outdoorView.backgroundColor = UI.Color.btnBgDisableColor
        outdoorLabel.textColor = UI.Color.txtPlaceholderColor
        outdoorButton.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
        outdoorButton.isEnabled = false
        startSpeedLabel.text = "-"
        increaseLabel.text = "-"
        restTimeLabel.text = "-"
        stageTimeLabel.text = "-"
    }
    
    @IBAction func btnSetProtocol_Click(_ sender: Any) {
        AppNavigator.shared.navigate(to: MainRoutes.excerciseAmountSetting, with: .push)
    }
    
    @IBAction func btnTreadMill_Click(_ sender: Any) {
        isTreadMill = true
        showPopupInstruction()
    }
    
    @IBAction func btnOutdoor_Click(_ sender: Any) {
        isTreadMill = false
        showPopupInstruction()
    }
    
    func doOudoorTest() {
        if Constants.IS_DISABLE_OUTDOOR_EXERCISE == true {
            showMessage(title: "", message: "Outdoor update coming soon!".localized, handler: nil)
        } else {
            if CLLocationManager.locationServicesEnabled() {
                switch CLLocationManager.authorizationStatus() {
                case .denied:
                    showToast(message: "location_permission_deny".localized)
                case .notDetermined, .restricted:
                    isRequestPermission = true
                    locationManager.requestAlwaysAuthorization()
                case .authorizedAlways, .authorizedWhenInUse:
                    goToOudoorTest()
                @unknown default: break
                }
            } else {
                showToast(message: "location_permission_deny".localized)
            }
        }
    }
    
    func goToOudoorTest() {
        if Constants.IS_DEV {
            LocalDataManager.ltTestType = LTTestConstants.OUTDOOR_TEST
            BluetoothHelper.resetLtTestData()
            AppNavigator.shared.navigate(to: LTTestRoutes.test, with: .push)
            //            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestResult, with: .push)
        } else {
            LocalDataManager.ltTestType = LTTestConstants.OUTDOOR_TEST
            BluetoothHelper.resetLtTestData()
            AppNavigator.shared.navigate(to: LTTestRoutes.test, with: .push)
        }
    }
    
    func goTreadMill() {
        if LocalDataManager.batteryLevel ?? 0 < Constants.BATTERY_LEVEL_WARNING && Constants.IS_DEV == false {
            showMessage(title: "", message: "Not enough battery.\nPlease recharge to start.".localized)
//            let alert = UIAlertController(title: "", message: "Not enough battery.\nPlease recharge to start.".localized, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: nil))
//            self.present(alert, animated: true, completion: nil)
        } else {
            LocalDataManager.ltTestType = LTTestConstants.TREADMILL_TEST
            BluetoothHelper.resetLtTestData()
            AppNavigator.shared.navigate(to: LTTestRoutes.test, with: .push)
        }
    }
    
    private func showPopupInstruction() {
        if LocalDataManager.isShowLTTestGuide == true {
            showPopup(parentVC: self)
        } else {
            doLTExercise()
        }
    }
    
    private func doLTExercise() {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            if isTreadMill {
                goTreadMill()
            } else {
                doOudoorTest()
            }
        }
    }
    
    func showPopup(parentVC: UIViewController) {
        if let popupViewController = UIStoryboard(name: "LTTest", bundle: nil).instantiateViewController(withIdentifier: "InstructionViewController") as? InstructionViewController {
            popupViewController.modalPresentationStyle = .custom
            popupViewController.modalTransitionStyle = .crossDissolve
            popupViewController.delegate = self
            parentVC.present(popupViewController, animated: true)
        }
    }
}

extension TestSummaryOffViewController: TestSummaryOffViewModelDelegate, CLLocationManagerDelegate {
    func didUpdateState(to state: TestSummaryOffViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getTermOfUseSuccess:
            checkLTTestSetting()
        }
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = CLLocationManager.authorizationStatus()
        Functions.showLog(title: "Location status", message: status.rawValue)
        if (status == .authorizedWhenInUse || status == .authorizedAlways) && isRequestPermission {
            goToOudoorTest()
        } else {
            locationManager.requestAlwaysAuthorization()
        }
    }
}

extension TestSummaryOffViewController: InstructionViewDialogDelegate {
    func onFinish() {
        doLTExercise()
    }
}
