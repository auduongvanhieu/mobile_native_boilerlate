import Foundation

protocol TestSummaryOffViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: TestSummaryOffViewModelState)
}

enum TestSummaryOffViewModelState {
    case getTermOfUseSuccess
    case network(state: NetworkState)
}

class TestSummaryOffViewModel {
    
    private var state: TestSummaryOffViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: TestSummaryOffViewModelDelegate?
    
    var settingModel = LTTestSettingModel()
    
    func getLtTestSetting() {
        state = .network(state: .loading)
        LTTestServices.getLtTestSetting(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.settingModel = res
                self.state = .getTermOfUseSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
