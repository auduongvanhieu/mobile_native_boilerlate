import Foundation
import UIKit

class LTTestCompleteViewController: BaseViewController {
    
    var viewModel = LTTestCompleteViewModel()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        BluetoothHelper.restoreConnectDevice(fromViewController: self)
        setUpView()
//        let delegate = UIApplication.shared.delegate as? AppDelegate
//        delegate?.viewModel.uploadImageToS3(isFromLTest: true)
        viewModel.uploadExercise()
    }
    
    func setUpView() {
        viewModel.delegate = self
        TextToSpeechHelper.speak(text: "Congratulations! Your LT TEST is completed.", countDown: nil, timeUp: 0, page: "LT Test Completed (Page 6)")
    }
    
    @IBAction func onClickResult(_ sender: Any) {
        let detailPage = LTTestRoutes.ltTestResult.screen as? LTTestResultViewController ?? LTTestResultViewController()
        if let ltTestObject = viewModel.object as? LTTestResultObject,
           ltTestObject.isInvalidated == false {
            detailPage.viewModel = LTTestResultViewModel()
            detailPage.viewModel.ltTestTemp = ltTestObject.convertToLTTestHistoryTempModel()
        } else {
            detailPage.viewModel = LTTestResultViewModel()
            detailPage.viewModel.ltTestTemp = LTTestHistoryTempModel(0, nil, nil, 0, nil, isFromLocal: true)
        }
        
//        detailPage.viewModel = LTTestResultViewModel()
//        detailPage.viewModel.ltTestResultId = id
        self.navigationController?.pushViewController(detailPage, animated: true)
//        AppNavigator.shared.navigate(to: LTTestRoutes.ltTestResult, with: .push)
        self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
    }
}

extension LTTestCompleteViewController: LTTestCompleteViewModelDelegate {
    func didUpdateState(to state: LTTestCompleteViewModelState) {
        switch state {
        case .network(let state):
            networkStatusChanged(to: state)
        case .failWithMessage(let alertString):
            showMessage(title: "Data upload fail", message: alertString, buttonTitle: "Retry", handle: { _ in
                // Retry
                self.viewModel.didTouchRetry()
            }, handlerOK: { _ in
                self.viewModel.didTouchOK()
            })
        case .failAPI(let errStr):
            showMessage(title: "", message: errStr)
        }
    }
}
