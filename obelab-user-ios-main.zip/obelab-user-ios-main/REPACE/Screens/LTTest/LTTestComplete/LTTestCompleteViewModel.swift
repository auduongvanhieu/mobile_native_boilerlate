import Foundation
import RealmSwift

protocol LTTestCompleteViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: LTTestCompleteViewModelState)
}

enum LTTestCompleteViewModelState {
    case network(state: NetworkState)
    case failAPI(errStr: String)
    case failWithMessage(message: String)
}

class LTTestCompleteViewModel: ExerciseModelService {

    weak var delegate: LTTestCompleteViewModelDelegate?
    var state: LTTestCompleteViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    func uploadExercise() {
        self.state = .network(state: .loading)
        BluetoothHelper.getNewestLTTestResultModel { [weak self] ltTestResult in
            guard let self = self else { return }
            let list = LocalDataManager.listTestAnalysis
            self.object = ltTestResult.convertToSaveObject(list: list)
            // Upload S3 File
            self.uploadFile(object: self.object, updatePercent: { percent in
                self.state = .network(state: .loadingPercent(percent: percent))
            }, failAPI: { errStr in
                self.state = .network(state: .hideLoading)
                self.state = .failAPI(errStr: errStr)
            })
        }
    }
    
    func didTouchRetry() {
        Functions.showLog(title: "Mytv didTouchRetry", message: "")
        FileHelper.writeStringToLogFile(title: "LTTestCompleteViewModel didTouchRetry", content: "")
        self.state = .network(state: .loading)
        uploadExerciseData(failAPI: { errStr in
            self.state = .network(state: .hideLoading)
            self.state = .failAPI(errStr: errStr)
        }, updatePercent: { percent in
            self.state = .network(state: .loadingPercent(percent: percent))
        })
    }
    
    func didTouchOK() {
        FileHelper.writeStringToLogFile(title: "LTTestCompleteViewModel didTouchOK", content: "")
        Functions.showLog(title: "Mytv didTouchOK", message: "")
        self.state = .network(state: .hideLoading)
        self.updateCreatedAt()
    }
    
    override func didFailUploadingData(isFailByConnection: Bool) {
        FileHelper.writeStringToLogFile(title: "LTTestCompleteViewModel didFailUploadingData fail uploading data because of disconnect internet", content: "")
        let message = "noInternetPostLTTest".localized
        self.state = .network(state: .hideLoading)
        self.state = .failWithMessage(message: message)
    }
    
    override func didFinishUploadingData(res: Any) {
        FileHelper.writeStringToLogFile(title: "LTTestCompleteViewModel didFinishUploadingData success uploading data ", content: "")
        super.didFinishUploadingData(res: res)
        self.state = .network(state: .hideLoading)
    }
}
