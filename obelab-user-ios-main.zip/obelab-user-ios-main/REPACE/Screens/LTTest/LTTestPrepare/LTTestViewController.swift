import Foundation
import UIKit

class LTTestViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var typeImage: UIImageView!
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var stageLabel: UILabel!
    @IBOutlet weak var warnButton: UIButton!
    @IBOutlet weak var headerBack: HeaderBack!
    
    @IBOutlet weak var lblStopLTTest: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    var counter = Constants.LT_TEST_PREPARE_TIME_COUNTER
    var timer: Timer?
    var isReceivedGainData = false
    var isShowCalibration = true
    var isDidGonePairing = false
    var page: String = ""
    
    var dicText: [Int: String] = [:]
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        // Increase LT Test stage
        if LocalDataManager.ltTestStage == 0 {
            _ = BluetoothHelper.updateAnalysis()
            showPopupCircle()
        } else {
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            timer?.tolerance = Constants.TIME_INTERVAL * 0.1
        }
        LocalDataManager.ltTestStage += 1
        setUpView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if isDidGonePairing == true {
            showPopupCircle()
        }
    }
    
    func showPopupCircle() {
        BluetoothHelper.startMeasure()
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkConnectBLE), name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkGainData), name: NotificationCenterHelper.BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION, object: nil)
        Functions.startFakeGainData()
        ProgressDialogViewController.showPopup(parentVC: self)
        Timer.scheduledTimer(withTimeInterval: Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_1, repeats: false) { _ in
            ProgressDialogViewController.hidePopup()
            self.startListenerGainData(title: nil, time: Constants.WAIT_FOR_GAIN_DATA_TIME_STEP_2)
        }
    }
    
    func removeObserveNotification() {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_RECEIVE_GAIN_DATA_SUCCESS_ACTION, object: nil)
    }
    
    private func startListenerGainData(title: String?, time: TimeInterval) {
        if self.isReceivedGainData == false {
            ProgressBarDialogViewController.showPopup(parentVC: self, title: title)
            Timer.scheduledTimer(withTimeInterval: time, repeats: false) { _ in
                ProgressBarDialogViewController.hidePopup()
                if self.isReceivedGainData == false {
                    self.doCalibrationProgress()
                }
            }
        }
    }
    
    private func doCalibrationProgress() {
        if isShowCalibration {
            isShowCalibration = false
            if let peripheral = BluetoothHelper.peripheral {
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA: peripheral])
            }
            BluetoothHelper.stopMeasure()
            BluetoothHelper.startMeasure()
            self.startListenerGainData(title: "Calibration in progress...".localized, time: 30)
        } else {
            isDidGonePairing = true
            if BluetoothHelper.isConnectedDevice == true {
                // Connected but it Abnormal
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_DISCONNECT_DEVICE_DATA, object: nil, userInfo: nil)
            } else {
                // Disconnect
                showDisconnectedDeviceAlert()
            }
        }
    }

    @objc func checkGainData() {
        if timer == nil {
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
//            timer?.tolerance = Constants.TIME_INTERVAL * 0.1
            Functions.startFakeMeasureData()
        }
        RealmHelper.share.cleanSmO2Object()
        isReceivedGainData = true
        ProgressDialogViewController.hidePopup()
        ProgressBarDialogViewController.hidePopup()
    }
    
    @objc func checkConnectBLE() {
        if BluetoothHelper.isConnectedDevice == false {
            timer?.invalidate()
            timer = nil
        } else {
            if timer == nil && counter > 0 {
                timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
            }
        }
    }
    
    func setUpView() {
        lblStopLTTest.text = "lblStopLTTest".localized
        headerBack.delegate = self
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
        var speed = LocalDataManager.ltTestAnalysis.speed
        if LocalDataManager.ltTestStage == 1 {
            speed = LocalDataManager.ltTestProtocol.startSpeed
        }
        speed = Functions.kmToMile(km: speed).to1Decimal
        speedLabel.text = "\(speed)"
        let unit = Functions.showUnitLabel(isSpeed: false)
        stageLabel.text = LocalDataManager.ltTestStage > 9 ? "\(LocalDataManager.ltTestStage)" : "0\(LocalDataManager.ltTestStage)"
        let stage = LocalDataManager.ltTestStage
        let startAt = Constants.LT_TEST_PREPARE_TIME_COUNTER
        let duration = Constants.LT_TEST_PROGRESS_TIME_COUNTER / 60
        let completed = stage > 1 ? "Stage \(stage - 1) completed. " : ""
        if LocalDataManager.ltTestType == LTTestConstants.TREADMILL_TEST {
            page = "LT Test prepare Treadmil (Page 2)"
            if LocalDataManager.profile?.gender == Constants.GENDER_MALE {
                typeImage.image = UIImage(named: "img_treadmill_man.png")
            } else {
                typeImage.image = UIImage(named: "img_treadmill_woman.png")
            }
            dicText[Constants.LT_TEST_PREPARE_TIME_COUNTER] = "\(completed)Stage \(stage) will start in \(startAt) seconds. Set Treadmill Speed to \(speed) \(unit) per hour. Run for \(duration) minutes, do not walk"
        } else {
            page = "LT Test prepare Outdoor (Page 3)"
            noteLabel.text = "maintain_your_pace_at".localized
            warnButton.setTitle("on_flat_outdoor_track".localized, for: .normal)
            if LocalDataManager.profile?.gender == Constants.GENDER_MALE {
                typeImage.image = UIImage(named: "img_outdoor_man.png")
            } else {
                typeImage.image = UIImage(named: "img_outdoor_woman.png")
            }
            dicText[Constants.LT_TEST_PREPARE_TIME_COUNTER] = "\(completed)Stage \(stage) will start in \(startAt) seconds. Maintain your pace at \(speed) \(unit) per hour. Run for \(duration) minutes on a flat outdoor track, do not walk"
        }
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) updateCounter = \(counter)", message: "")
        if let speech = dicText[counter] {
            TextToSpeechHelper.speak(text: speech, countDown: counter, timeUp: Constants.LT_TEST_PREPARE_TIME_COUNTER - counter, page: "\(page) stage \(stageLabel.text ?? "")")
            ProgressBarDialogViewController.hidePopup()
        }
        // example functionality
        counter -= 1
        timerLabel.text = counter > 9 ? "\(counter)’’" : "0\(counter)’’"
        if counter == 0 {
            disableTimer()
            Functions.showLog(title: "BLE -> ", message: "ltTestProgress START")
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestProgress, with: .push)
        }
    }
    
    func disableTimer() {
        self.timer?.invalidate()
        self.timer = nil
    }
    
    func stopAll() {
        self.removeObserveNotification()
        self.timer?.invalidate()
        self.timer = nil
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopAll()
    }
    
    @IBAction func onClickStop(_ sender: Any) {
        if counter > 0 {
            if LocalDataManager.ltTestStage == 1 {
                BluetoothHelper.showStopProgressAlert(textStop: "are_you_sure_exit_lt_test".localized, didStop: {
                    BluetoothHelper.resetLtTestData()
                    self.stopAll()
                })
            } else {
                showMessage(title: "", message: "ltTestStopSaveData".localized, buttonTitle: "cancel".localized, handle: nil) { _ in
                    self.saveDataWhenStop()
                }
//                let alert = UIAlertController(title: "", message: "ltTestStopSaveData".localized, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//                    self.saveDataWhenStop()
//                }))
//                alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
//                self.present(alert, animated: true)
            }
        }
    }
    
    private func saveDataWhenStop() {
        Functions.stopFakeDataLTTest()
        BluetoothHelper.stopMeasure()
        timer?.invalidate()
        timer = nil
        AppNavigator.shared.navigate(to: LTTestRoutes.ltTestComplete, with: .push)
        self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
    }
}

extension LTTestViewController: HeaderBackDelegate {
    func onClickShare() { }
    
    func onClickBack() {
        BluetoothHelper.stopMeasure()
        Functions.stopFakeDataLTTest()
        BluetoothHelper.resetLtTestData()
        stopAll()
    }
}
