//
//  LTTestNavigationController.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/10/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class LTTestNavigationController: UINavigationController {
    override func viewDidLoad() {
      super.viewDidLoad()
      
      self.navigationBar.setBackgroundImage(UIImage(), for: .default)
         self.navigationBar.shadowImage = UIImage()
         self.navigationBar.isTranslucent = true
    }
}
