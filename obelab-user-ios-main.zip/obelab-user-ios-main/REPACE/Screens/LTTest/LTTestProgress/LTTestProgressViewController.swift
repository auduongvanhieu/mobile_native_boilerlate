import Foundation
import UIKit
import CoreLocation

class LTTestProgressViewController: BaseViewController {
    
    @IBOutlet weak var testProgress: RepaceProgress!
    @IBOutlet weak var smO2Label: UILabel!
    @IBOutlet weak var heartRateLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var lblUnitTotlaDistance: UILabel!
    
    var counter = Constants.LT_TEST_PROGRESS_TIME_COUNTER
    var timer: Timer?
    var distance: Double = 0
    let locationManager = CLLocationManager()
    var oldDate = Date()
    var oldLocation: CLLocation?
    var sumSpeed: Double = 0.0
    var countSpeed: Int = 0
    var isDone = false
    var previousDistance: Double = 0
    var isOpenCompleteScreen = false
    var page = ""
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        BluetoothHelper.isRunProgress = true
        setUpView()
        LocalDataManager.isSaveSmo2List = true
        // Setup timer
        timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        timer?.tolerance = Constants.TIME_INTERVAL * 0.1
        setupNotification()
        if let index = self.navigationController?.viewControllers.firstIndex(where: {$0.isKind(of: LTTestViewController.self) == true}) {
            self.navigationController?.viewControllers.remove(at: index)
        }
        page = LocalDataManager.ltTestType == LTTestConstants.TREADMILL_TEST ? "LT Test Progress Treadmil (page 4)" : "LT Test Progress Outdoor (page 4)"
        TextToSpeechHelper.speak(text: "Start running", countDown: counter, timeUp: Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter, page: "\(page) stage \(LocalDataManager.ltTestStage)")
        lblUnitTotlaDistance.text = Functions.showUnitLabel(isSpeed: false)
    }
    
    func setupNotification() {
        // Set receive measure data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveMeasureData(_:)), name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        // Set receive heartrate data
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveHeartrateData(_:)), name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(onReceiveEndOfMeasure(_:)), name: NotificationCenterHelper.BLE_TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE, object: nil)
    }
    
    func removeNotification() {
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA_SUCCESS_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_TYPE_END_OF_MEASURE_DATA_WITH_TOTAL_SIZE, object: nil)
    }
    
    func setUpView() {
        testProgress.setStage(value: LocalDataManager.ltTestStage)
        smO2Label.text = BluetoothHelper.getCurrentSMO2() == 0 ? "-" : "\(BluetoothHelper.getCurrentSMO2())"
        distanceLabel.text = "0.0"
        heartRateLabel.text = "-"
        if LocalDataManager.ltTestType == LTTestConstants.TREADMILL_TEST {
            if LocalDataManager.ltTestStage == 1 {
                testProgress.setSpeed(value: LocalDataManager.ltTestProtocol.startSpeed)
                LocalDataManager.ltTestResult.speedMin = LocalDataManager.ltTestAnalysis.speed
            } else {
                testProgress.setSpeed(value: LocalDataManager.ltTestAnalysis.speed)
            }
        } else {
            // Outdoor
            if LocalDataManager.ltTestStage == 1 {
                testProgress.setSpeedStandard(value: LocalDataManager.ltTestProtocol.startSpeed)
            } else {
                testProgress.setSpeedStandard(value: LocalDataManager.ltTestAnalysis.speed)
            }
            testProgress.setSpeed(value: 0)
            testProgress.lbSpeedStandard.isHidden = false
            // Setup location
            if CLLocationManager.locationServicesEnabled() {
                locationManager.requestAlwaysAuthorization()
                locationManager.requestWhenInUseAuthorization()
                locationManager.delegate = self
                locationManager.desiredAccuracy = kCLLocationAccuracyBest
                locationManager.distanceFilter = 8.0
                locationManager.pausesLocationUpdatesAutomatically = true
                locationManager.activityType = .fitness
                locationManager.startUpdatingLocation()
            }
        }
    }
    
    @objc func onReceiveMeasureData(_ notification: NSNotification) {
        if let measureData = notification.userInfo?[NotificationCenterHelper.BLE_RECEIVE_MEASURE_DATA] as? RepaceMeasureModel {
            let smo2 = Functions.toSmO2(byteArray: measureData.rSO2)
            smO2Label.text = "\(smo2)"
            Functions.showLog(title: "Smo2 value", message: smo2)
        }
    }
    
    @objc func onReceiveHeartrateData(_ notification: NSNotification) {
        if let heartrate = notification.userInfo?[NotificationCenterHelper.HR_HEART_RATE_DATA] as? Double {
            DispatchQueue.main.async {
                self.heartRateLabel.text = "\(Int(heartrate))"
            }
        }
    }
    @objc func onReceiveEndOfMeasure(_ notification: NSNotification) {
        if isDone && isOpenCompleteScreen == false {
            isOpenCompleteScreen = true
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestComplete, with: .push)
            Functions.stopFakeDataLTTest()
            self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
        }
    }
    
    @objc func updateCounter() {
//        Functions.showLog(title: "\(self) updateCounter = \(counter)", message: "")
        if counter > 0 {
            if counter == Constants.LT_TEST_PROGRESS_TIME_COUNTER - 60 {
                LocalDataManager.ltTestSmo2BaseLineList = []
                BluetoothHelper.isSaveBaseline = true
            }
            if counter == Constants.LT_TEST_PROGRESS_TIME_COUNTER - 70 {
                BluetoothHelper.isSaveBaseline = false
            }
            if counter == 10 {
                LocalDataManager.ltTestSmo2CurrentList = []
                BluetoothHelper.isSaveCurrentSmo2 = true
            }
            counter -= 1
            let minStr = counter / 60 > 9 ? "\(counter / 60)" : "0\(counter / 60)"
            let secondStr = counter % 60 > 9 ? "\(counter % 60)" : "0\(counter % 60)"
            timeLabel.text = "\(minStr) : \(secondStr)"
            if LocalDataManager.ltTestType == LTTestConstants.TREADMILL_TEST {
                testProgress.setValue(value: Double((Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter) * 100 / Constants.LT_TEST_PROGRESS_TIME_COUNTER))
                if LocalDataManager.ltTestStage == 1 {
                    LocalDataManager.ltTestResult.totalDistance = (LocalDataManager.ltTestResult.totalDistance ?? 0) + LocalDataManager.ltTestProtocol.startSpeed / Double(Constants.H_TO_S_COEFFICIENT)
                    distance += LocalDataManager.ltTestProtocol.startSpeed / Double(Constants.H_TO_S_COEFFICIENT)
                } else {
                    LocalDataManager.ltTestResult.totalDistance = (LocalDataManager.ltTestResult.totalDistance ?? 0) + LocalDataManager.ltTestAnalysis.speed / Double(Constants.H_TO_S_COEFFICIENT)
                    distance += LocalDataManager.ltTestAnalysis.speed / Double(Constants.H_TO_S_COEFFICIENT)
                }
                let totalDistance = Functions.kmToMile(km: LocalDataManager.ltTestResult.totalDistance)
                distanceLabel.text = "\(totalDistance.to1Decimal)"
//                distanceLabel.text = "\((LocalDataManager.ltTestResult.totalDistance ?? 0).to1Decimal)"
            } else {
                // once per 15 seconds
                if counter % 15 == 0 {
                    let deltaDistance = distance - previousDistance
                    let speed = LocalDataManager.ltTestStage == 1 ? LocalDataManager.ltTestProtocol.startSpeed : LocalDataManager.ltTestAnalysis.speed
                    let speedRun = deltaDistance / 15 * 3600
                    var text: String?
                    if speedRun > speed * 1.1 {
                        text = "Slow down"
                    } else if speedRun < speed * 0.9 {
                        text = "Speed up"
                    }
                    if let text = text {
                        let speedUnit = Functions.kmToMile(km: speed)
                        let unit = Functions.showUnitLabel(isSpeed: false)
                        TextToSpeechHelper.speak(text: "\(text) to keep the pace at \(speedUnit) \(unit) per hour.", countDown: counter, timeUp: Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter, page: "\(page) stage \(LocalDataManager.ltTestStage)")
                    }
                    previousDistance = distance
                }
            }
        } else {
            BluetoothHelper.isSaveCurrentSmo2 = false
            // Add lactate to list
            let analysis = BluetoothHelper.updateAnalysis(isCalculate: true)
            let name = LocalDataManager.ltTestResult.listLactate?.count ?? 0
            if name == 0 {
                LocalDataManager.listTestAnalysis = [analysis]
                LocalDataManager.ltTestResult.listLactate = [SmO2ChartModel(name: "\(name + 1)", score: LocalDataManager.ltTestAnalysis.lactate)]
            } else {
                LocalDataManager.listTestAnalysis.append(analysis)
                LocalDataManager.ltTestResult.listLactate?.append(SmO2ChartModel(name: "\(name + 1)", score: LocalDataManager.ltTestAnalysis.lactate))
            }
            if analysis.isNext && LocalDataManager.ltTestStage <= 12 {
//            if analysis.isNext && LocalDataManager.ltTestStage <= 12 && LocalDataManager.ltTestStage < 2 {
                saveData()
                AppNavigator.shared.navigate(to: LTTestRoutes.test, with: .push)
                self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
            } else {
                isDone = true
                BluetoothHelper.stopMeasure()
                saveData()
                if Constants.IS_DEV {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        AppNavigator.shared.navigate(to: LTTestRoutes.ltTestComplete, with: .push)
                        Functions.stopFakeDataLTTest()
                        self.navigationController?.viewControllers.remove(at: (self.navigationController?.viewControllers.count ?? 2) - 2)
                    }
                }
            }
        }
    }
    
    private func saveData() {
        BluetoothHelper.isRunProgress = false
        LocalDataManager.isSaveSmo2List = false
        BluetoothHelper.saveSmo2AndHeartrateData()
        timer?.invalidate()
        timer = nil
        if LocalDataManager.ltTestType == LTTestConstants.TREADMILL_TEST {
            let stageModel = RepaceStageModel(stage: LocalDataManager.ltTestStage,
                                              speed: testProgress.xSpeed.to1Decimal,
                                              distance: (testProgress.xSpeed / 12).to1Decimal,
                                              duration: (Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter) / 60,
                                              avgSmO2: BluetoothHelper.getCurrentSMO2(),
                                              avgHeartRate: 0.0)
            LocalDataManager.ltTestStageModelList.append(stageModel)
            LocalDataManager.ltTestResult.speedMax = LocalDataManager.ltTestAnalysis.speed
        } else {
            // Outdoor
            let stageModel = RepaceStageModel(stage: LocalDataManager.ltTestStage,
                                              speed: testProgress.xSpeed,
                                              distance: distance,
                                              duration: (Constants.LT_TEST_PROGRESS_TIME_COUNTER - counter) / 60,
                                              avgSmO2: BluetoothHelper.getCurrentSMO2(),
                                              avgHeartRate: 0.0)
            LocalDataManager.ltTestStageModelList.append(stageModel)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if self.timer == nil {
            setupNotification()
            timer = Timer.scheduledTimer(timeInterval: Constants.TIME_INTERVAL, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.stopAll()
    }
    
    func stopAll() {
        self.removeNotification()
        self.timer?.invalidate()
        self.timer = nil
    }
    
    @IBAction func onClickStop(_ sender: Any) {
        if counter > 0 {
            if LocalDataManager.ltTestStage == 1 {
                BluetoothHelper.showStopProgressAlert(textStop: "are_you_sure_exit_lt_test".localized, didStop: {[weak self] in
                    BluetoothHelper.resetLtTestData()
                    self?.stopAll()
                })
            } else {
                showMessage(title: "", message: "ltTestStopSaveData".localized, buttonTitle: "cancel".localized, handle: nil) { _ in
                    self.saveDataWhenStop()
                }
//                let alert = UIAlertController(title: "", message: "ltTestStopSaveData".localized, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//                    self.saveDataWhenStop()
//                }))
//                alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
//                self.present(alert, animated: true)
            }
        }
    }
    
    private func saveDataWhenStop() {
        BluetoothHelper.isRunProgress = false
        LocalDataManager.isSaveSmo2List = false
        isDone = true
        BluetoothHelper.stopMeasure()
        timer?.invalidate()
        timer = nil
    }
}

extension LTTestProgressViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation: CLLocation = locations[0] as CLLocation
        Functions.showLog(title: "Location value listener", message: "(\(currentLocation.coordinate.latitude),\(currentLocation.coordinate.longitude))")
        let newDate = Date()
        if let oldLocation = oldLocation {
            let distanceDelta = Functions.getDistanceFrom2Coordinate(firstLocation: currentLocation, secondLocation: oldLocation) // Km
            let speed = currentLocation.speed == -1 ? 0 : currentLocation.speed * 3.6
//            if speed < Constants.HUMAN_MAX_SPEED {
//                Functions.showLog(title: "Location speed", message: speed)
//                if speed > LocalDataManager.ltTestAnalysis.speed {
//                    testProgress.warningToSpeedDown()
//                } else if speed < LocalDataManager.ltTestAnalysis.speed {
//                    testProgress.warningToSpeedUp()
//                } else {
//                    testProgress.hideWarning()
//                }
//                // Sum speed in this stage
//                sumSpeed += speed
//                countSpeed += 1
//                // Check max speed, min speed
//                if LocalDataManager.ltTestResult.speedMax == 0 || (LocalDataManager.ltTestResult.speedMax ?? 0) < speed {
//                    LocalDataManager.ltTestResult.speedMax = speed
//                }
//                if LocalDataManager.ltTestResult.speedMin == 0 || ((LocalDataManager.ltTestResult.speedMin ?? 0) > speed && speed != 0 ) {
//                    LocalDataManager.ltTestResult.speedMin = speed
//                }
//                // Save data
//                LocalDataManager.ltTestLocationList.append(LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis()))
//                distance += distanceDelta // km
//                LocalDataManager.ltTestResult.totalDistance = distance
//                testProgress.setSpeed(value: speed)
//                let targetDistance = LocalDataManager.ltTestAnalysis.speed * Double((Double(Constants.LT_TEST_PROGRESS_TIME_COUNTER) / Constants.H_TO_S_COEFFICIENT))
//                testProgress.setValue(value: distance * 100 / targetDistance)
//                // Show data
//                distanceLabel.text = "\(Functions.kmToMile(km: distance))"
////                distanceLabel.text = "\(distance.to1Decimal)"
//            }
            if speed > Constants.HUMAN_MAX_SPEED {
                Functions.showLog(title: "Location speed \(speed) over human speed \(Constants.HUMAN_MAX_SPEED)", message: "")
            }
            if speed > LocalDataManager.ltTestAnalysis.speed {
                testProgress.warningToSpeedDown()
            } else if speed < LocalDataManager.ltTestAnalysis.speed {
                testProgress.warningToSpeedUp()
            } else {
                testProgress.hideWarning()
            }
            // Sum speed in this stage
            sumSpeed += speed
            countSpeed += 1
            // Check max speed, min speed
            if LocalDataManager.ltTestResult.speedMax == 0 || (LocalDataManager.ltTestResult.speedMax ?? 0) < speed {
                LocalDataManager.ltTestResult.speedMax = speed
            }
            if LocalDataManager.ltTestResult.speedMin == 0 || ((LocalDataManager.ltTestResult.speedMin ?? 0) > speed && speed != 0 ) {
                LocalDataManager.ltTestResult.speedMin = speed
            }
            // Save data
            LocalDataManager.ltTestLocationList.append(LocationModel(latitude: currentLocation.coordinate.latitude, longitude: currentLocation.coordinate.longitude, time: Date().currentTimeMillis()))
            distance += distanceDelta // km
            LocalDataManager.ltTestResult.totalDistance = distance
            testProgress.setSpeed(value: speed)
            let targetDistance = LocalDataManager.ltTestAnalysis.speed * Double((Double(Constants.LT_TEST_PROGRESS_TIME_COUNTER) / Constants.H_TO_S_COEFFICIENT))
//                testProgress.setValue(value: distance * 100 / targetDistance)
            if targetDistance == 0 {
                testProgress.setValue(value: distance * 100)
            } else {
                testProgress.setValue(value: distance * 100 / targetDistance)
            }
            // Show data
            Functions.showLog(title: "Location update distanceDelta = \(distanceDelta) speed \(speed) targetDistance = \(targetDistance)", message: "")
            distanceLabel.text = "\(Functions.kmToMile(km: distance))"
        }
        oldLocation = currentLocation
        oldDate = newDate
    }
}
