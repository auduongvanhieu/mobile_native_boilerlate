import Foundation

protocol LTTestRXExerciseConfirmViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: LTTestRXExerciseConfirmViewModelState)
}

enum LTTestRXExerciseConfirmViewModelState {
    case network(state: NetworkState)
}

class LTTestRXExerciseConfirmViewModel {
    
    weak var delegate: LTTestRXExerciseConfirmViewModelDelegate?
    
    private var state: LTTestRXExerciseConfirmViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    func postExercisePrescription(exercisePresciption: ExercisePresciptionModel, completion: (() -> Void)?) {
        state = .network(state: .loading)
        LTTestServices.postExercisePrescription(exercisePresciption: exercisePresciption,
            success: { [weak self] _ in
                self?.state = .network(state: .hideLoading)
                Functions.showLog(title: "postExercisePrescriptionSuccess", message: "")
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "postExercisePrescriptionError", message: error)
            }
        )
    }
}
