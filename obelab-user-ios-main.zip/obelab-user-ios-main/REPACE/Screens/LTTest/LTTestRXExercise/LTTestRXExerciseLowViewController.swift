import Foundation
import UIKit

class LTTestRXExerciseLowViewController: BaseViewController {
    
    @IBOutlet weak var headerBack: HeaderBack!
    @IBOutlet weak var timeTopLabel: UILabel!
    @IBOutlet weak var speedTopLabel: UILabel!
    @IBOutlet weak var minTopLabel: UILabel!
    @IBOutlet weak var heartRateTopLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var speedLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    @IBOutlet weak var weekLabel: UILabel!
    @IBOutlet weak var weekEndLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var topInfoShareView: TopInfoShare!
    @IBOutlet weak var topInfoShareHeight: NSLayoutConstraint!

    @IBOutlet weak var lblUnitInSpeed: UILabel!
    @IBOutlet weak var lblUnitPrescriptionSpeed: UILabel!
    @IBOutlet weak var lblLowIntensityGuide: UILabel!
    @IBOutlet weak var lblLowIntensityTopGuide: UILabel!
    
    var prescription: ExercisePresciptionModel! = ExercisePresciptionModel()
    var purpose: Int32 = 0
    var viewModel = LTTestRXExerciseConfirmViewModel()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
        setUpData()
    }
    
    func setUpView() {
        // Header
        headerBack.delegate = self
        // Other
        heartRateTopLabel.text = "< -"
        lblUnitPrescriptionSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitInSpeed.text = "\(Functions.showUnitLabel(isSpeed: true)) speed"
        lblLowIntensityGuide.text = "lblLowIntensityGuide".localized
        lblLowIntensityTopGuide.text = "lblLowIntensityTopGuide".localized
    }
    
    func setUpData() {
        timeTopLabel.text = "\(prescription.leTime ?? 0)"
//        speedTopLabel.text = "\(prescription.leSpeed ?? 0)"
        minTopLabel.text = "\(prescription.leMin ?? 0)"
        timeLabel.text = "\(prescription.leTime ?? 0)"
        speedLabel.text = "\(Functions.kmToMile(km: prescription.leSpeed))" // " "\(prescription.leSpeed ?? 0)"
        speedTopLabel.text = speedLabel.text
        minLabel.text = "\((Double(prescription.leMin ?? 0) / 60).to1Decimal)"
        weekLabel.text = "\(prescription.leWeek ?? 0)"
        weekEndLabel.text = "\(prescription.leWeek ?? 0)"
    }
    
    @IBAction func onClickConfirm(_ sender: Any) {
        showMessage(title: "", message: "For best results we suggest you to complete the sessions. Your RX Exercise session will be initialized.\nDo you want to proceed?", buttonTitle: "cancel".localized, handle: nil) { _ in
            self.viewModel.postExercisePrescription(exercisePresciption: self.prescription, completion: {
                self.uploadPrescriptionFinish()
            })
        }
//        let alert = UIAlertController(title: "", message: "For best results we suggest you to complete the sessions. Your RX Exercise session will be initialized.\nDo you want to proceed?", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//            self.viewModel.postExercisePrescription(exercisePresciption: self.prescription, completion: {
//                self.uploadPrescriptionFinish()
//            })
//        }))
//        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
//        self.present(alert, animated: true, completion: nil)
    }
    
    func uploadPrescriptionFinish() {
        LocalDataManager.ltTestPurpose = self.purpose
        LocalDataManager.ltTestPrescription = self.prescription
        if let viewController = self.navigationController?.viewControllers.first(where: {$0.isKind(of: MainViewController.self) == true}) as? MainViewController {
            if viewController.openFlag == true {
                viewController.openOrCloseSideMenu()
            }
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 2])
            self.navigationController?.popToViewController(viewController, animated: true)
        } else {
            let last = LocalDataManager.lastConnectedBleDeviceId
            LocalDataManager.lastConnectedBleDeviceId = ""
            let peripheralTemp = BluetoothHelper.peripheral
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.RESET_MAINVIEWCONTROLLER, object: nil, userInfo: nil)
            AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: false), with: .reset)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                LocalDataManager.lastConnectedBleDeviceId = last
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 2])
                if let peripheral = peripheralTemp {
                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA: peripheral])
                }
            }
        }
    }
}

extension LTTestRXExerciseLowViewController: HeaderBackDelegate {
    func onClickBack() {}
    
    func onClickShare() {
        topInfoShareHeight.constant = UI.View.topInfoHeight
        topInfoShareView.isHidden = false
        let shareImage = self.contentView.takeScreenshot()
        let shareAll = [shareImage] as [Any]
        let activityViewController = UIActivityViewController(activityItems: shareAll, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.topInfoShareHeight.constant = 0
            self.topInfoShareView.isHidden = true
        }
    }
}
