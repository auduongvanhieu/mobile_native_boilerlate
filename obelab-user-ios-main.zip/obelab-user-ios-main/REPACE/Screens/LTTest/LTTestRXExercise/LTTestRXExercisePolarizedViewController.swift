import Foundation
import UIKit

class LTTestRXExercisePolarizedViewController: BaseViewController {
    
    @IBOutlet weak var headerBack: HeaderBack!
    @IBOutlet weak var weekLabel: UILabel!
    @IBOutlet weak var weekEndLabel: UILabel!
    @IBOutlet weak var min1Label: UILabel!
    @IBOutlet weak var min2Label: UILabel!
    @IBOutlet weak var min3Label: UILabel!
    @IBOutlet weak var min4Label: UILabel!
    @IBOutlet weak var min5Label: UILabel!
    @IBOutlet weak var min6Label: UILabel!
    @IBOutlet weak var speed1Label: UILabel!
    @IBOutlet weak var speed2Label: UILabel!
    @IBOutlet weak var speed3Label: UILabel!
    @IBOutlet weak var speed4Label: UILabel!
    @IBOutlet weak var speed5Label: UILabel!
    @IBOutlet weak var speed6Label: UILabel!
    @IBOutlet weak var hr1Label: UILabel!
    @IBOutlet weak var hr2Label: UILabel!
    @IBOutlet weak var hr3Label: UILabel!
    @IBOutlet weak var hr4Label: UILabel!
    @IBOutlet weak var hr5Label: UILabel!
    @IBOutlet weak var hr6Label: UILabel!
    @IBOutlet weak var hrTitle1Label: UILabel!
    @IBOutlet weak var hrTitle2Label: UILabel!
    @IBOutlet weak var hrTitle3Label: UILabel!
    @IBOutlet weak var hrTitle4Label: UILabel!
    @IBOutlet weak var hrTitle5Label: UILabel!
    @IBOutlet weak var hrTitle6Label: UILabel!
    @IBOutlet weak var minTitle1Label: UILabel!
    @IBOutlet weak var minTitle2Label: UILabel!
    @IBOutlet weak var minTitle3Label: UILabel!
    @IBOutlet weak var minTitle4Label: UILabel!
    @IBOutlet weak var minTitle5Label: UILabel!
    @IBOutlet weak var minTitle6Label: UILabel!
    
    @IBOutlet weak var lblUnitSpeed1: UILabel!
    @IBOutlet weak var lblUnitSpeed7: UILabel!
    @IBOutlet weak var lblUnitSpeed6: UILabel!
    @IBOutlet weak var lblUnitSpeed5: UILabel!
    @IBOutlet weak var lblUnitSpeed4: UILabel!
    @IBOutlet weak var lblUnitSpeed3: UILabel!
    @IBOutlet weak var lblUnitSpeed2: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var topInfoShareView: TopInfoShare!
    @IBOutlet weak var topInfoShareHeight: NSLayoutConstraint!
    
    @IBOutlet weak var lblTopPolarizedGuide: UILabel!
    @IBOutlet weak var lblLowIntensity: UILabel!
    var minLabelList: [UILabel] = []
    var minTitleLabelList: [UILabel] = []
    var speedLabelList: [UILabel] = []
    var hrLabelList: [UILabel] = []
    var hrTitleLabelList: [UILabel] = []
    
    var prescription: ExercisePresciptionModel! = ExercisePresciptionModel()
    var exerciseSessionList: [ExerciseSessionModel] = []
    var purpose: Int32 = 0
    let repaceLibrary = RepaceLibrary()
    var protocolValue = LocalDataManager.ltTestProtocol.protocolValue
    var onset: Double?
    var viewModel = LTTestRXExerciseConfirmViewModel()

    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpView()
        setUpData()
    }
    
    func setUpView() {
        // Header
        headerBack.delegate = self
        lblLowIntensity.text = "lblLowIntensity".localized
        lblTopPolarizedGuide.text = "lblTopPolarizedGuide".localized
    }
    
    func setUpData() {
        // Set up UI List
        minLabelList.append(min1Label)
        minLabelList.append(min2Label)
        minLabelList.append(min3Label)
        minLabelList.append(min4Label)
        minLabelList.append(min5Label)
        minLabelList.append(min6Label)
        minTitleLabelList.append(minTitle1Label)
        minTitleLabelList.append(minTitle2Label)
        minTitleLabelList.append(minTitle3Label)
        minTitleLabelList.append(minTitle4Label)
        minTitleLabelList.append(minTitle5Label)
        minTitleLabelList.append(minTitle6Label)
        speedLabelList.append(speed1Label)
        speedLabelList.append(speed2Label)
        speedLabelList.append(speed3Label)
        speedLabelList.append(speed4Label)
        speedLabelList.append(speed5Label)
        speedLabelList.append(speed6Label)
        hrLabelList.append(hr1Label)
        hrLabelList.append(hr2Label)
        hrLabelList.append(hr3Label)
        hrLabelList.append(hr4Label)
        hrLabelList.append(hr5Label)
        hrLabelList.append(hr6Label)
        hrTitleLabelList.append(hrTitle1Label)
        hrTitleLabelList.append(hrTitle2Label)
        hrTitleLabelList.append(hrTitle3Label)
        hrTitleLabelList.append(hrTitle4Label)
        hrTitleLabelList.append(hrTitle5Label)
        hrTitleLabelList.append(hrTitle6Label)
        lblUnitSpeed1.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed2.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed3.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed4.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed5.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed6.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed7.text = Functions.showUnitLabel(isSpeed: true)
        // Set data on text
        if let ptWeek = prescription.ptWeek {
            weekLabel.text = "\(ptWeek)"
            weekEndLabel.text = "\(ptWeek)"
        } else {
            weekLabel.text = nil
            weekEndLabel.text = nil
        }
        
        // Get Prescription Table
        guard let onset = onset else {
            return
        }
        let protocolValue = Int32(self.protocolValue)
        let row1 = repaceLibrary.getPrescriptionTable(1, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow1", message: row1)
        let row2 = repaceLibrary.getPrescriptionTable(2, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow2", message: row2)
        let row3 = repaceLibrary.getPrescriptionTable(3, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow3", message: row3)
        let row4 = repaceLibrary.getPrescriptionTable(4, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow4", message: row4)
        let row5 = repaceLibrary.getPrescriptionTable(5, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow5", message: row5)
        let row6 = repaceLibrary.getPrescriptionTable(6, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow6", message: row6)
        let row7 = repaceLibrary.getPrescriptionTable(7, protocolValue, purpose, onset)
        Functions.showLog(title: "prescriptionRow7", message: row7)
        // Add exercise session to list
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row1.section), time: Int(row1.time), speed: Double(row1.speed), heartRate: Int(row1.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row2.section), time: Int(row2.time), speed: Double(row2.speed), heartRate: Int(row2.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row3.section), time: Int(row3.time), speed: Double(row3.speed), heartRate: Int(row3.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row4.section), time: Int(row4.time), speed: Double(row4.speed), heartRate: Int(row4.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row5.section), time: Int(row5.time), speed: Double(row5.speed), heartRate: Int(row5.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row6.section), time: Int(row6.time), speed: Double(row6.speed), heartRate: Int(row6.heartRate)))
        exerciseSessionList.append(ExerciseSessionModel(session: Int(row7.section), time: Int(row7.time), speed: Double(row7.speed), heartRate: Int(row7.heartRate)))
        prescription.session = exerciseSessionList
        // Set prescription on view
        for index in 0...5 {
            let time = exerciseSessionList[index].time ?? 0
            minLabelList[index].text = time > 0 ? "\(time)" : "rest".localized
            let speed = Functions.kmToMile(km: exerciseSessionList[index].speed) // exerciseSessionList[index].speed ?? 0.0
            speedLabelList[index].text = speed > 0 ? "\(speed.to1Decimal)" : "  -"
            let heartRate = exerciseSessionList[index].heartRate ?? 0
            hrLabelList[index].text = heartRate > 0 ? "< \(heartRate)" : "  -"
            if exerciseSessionList[index].time == 0 {
                minTitleLabelList[index].isHidden = true
                hrTitleLabelList[index].isHidden = true
            }
        }
    }
    
    @IBAction func onClickConfirm(_ sender: Any) {
        showMessage(title: "", message: "For best results we suggest you to complete the sessions. Your RX Exercise session will be initialized.\nDo you want to proceed?", buttonTitle: "cancel".localized, handle: nil) { _ in
            self.viewModel.postExercisePrescription(exercisePresciption: self.prescription, completion: {
                self.finishUploadPrescription()
            })
        }
//        let alert = UIAlertController(title: "", message: "For best results we suggest you to complete the sessions. Your RX Exercise session will be initialized.\nDo you want to proceed?", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//            self.viewModel.postExercisePrescription(exercisePresciption: self.prescription, completion: {
//                self.finishUploadPrescription()
//            })
//        }))
//        alert.addAction(UIAlertAction(title: "cancel".localized, style: .default, handler: nil))
//        self.present(alert, animated: true, completion: nil)
    }
    
    private func finishUploadPrescription() {
        LocalDataManager.ltTestPurpose = self.purpose
        LocalDataManager.ltTestPrescription = self.prescription
        if let viewController = self.navigationController?.viewControllers.first(where: {$0.isKind(of: MainViewController.self) == true}) as? MainViewController {
            if viewController.openFlag == true {
                viewController.openOrCloseSideMenu()
            }
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 2])
            self.navigationController?.popToViewController(viewController, animated: true)
        } else {
            let last = LocalDataManager.lastConnectedBleDeviceId
            LocalDataManager.lastConnectedBleDeviceId = ""
            let peripheralTemp = BluetoothHelper.peripheral
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.RESET_MAINVIEWCONTROLLER, object: nil, userInfo: nil)
            AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: true), with: .reset)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                LocalDataManager.lastConnectedBleDeviceId = last
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 2])
                if let peripheral = peripheralTemp {
                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA: peripheral])
                }
            }
        }
    }
}

extension LTTestRXExercisePolarizedViewController: HeaderBackDelegate {
    func onClickBack() {}
    
    func onClickShare() {
        topInfoShareHeight.constant = UI.View.topInfoHeight
        topInfoShareView.isHidden = false
        let shareImage = self.contentView.takeScreenshot()
        let shareAll = [shareImage] as [Any]
        let activityViewController = UIActivityViewController(activityItems: shareAll, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        self.present(activityViewController, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.topInfoShareHeight.constant = 0
            self.topInfoShareView.isHidden = true
        }
    }
}
