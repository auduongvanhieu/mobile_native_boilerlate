import Foundation
import UIKit

class LTTestRXExerciseViewController: BaseViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var centerView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var topButton: UIButton!
    @IBOutlet weak var centerButton: UIButton!
    @IBOutlet weak var bottomButton: UIButton!
    @IBOutlet weak var topImageView: UIImageView!
    @IBOutlet weak var centerImageView: UIImageView!
    @IBOutlet weak var bottomImageView: UIImageView!
    @IBOutlet weak var topTitleLabel: UILabel!
    @IBOutlet weak var centerTitleLabel: UILabel!
    @IBOutlet weak var bottomTitleLabel: UILabel!
    @IBOutlet weak var topContentTextView: UITextView!
    @IBOutlet weak var centerContentTextView: UITextView!
    @IBOutlet weak var bottomContentTextView: UITextView!
    
    let repaceLibrary = RepaceLibrary()
    // Set before come this page
    var protocolValue = LocalDataManager.ltTestProtocol.protocolValue
    // onset is set before come
    var onset: Double?
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setUpView()
        setUpData()
    }
    
    func setUpView() {
        topView.layer.cornerRadius = UI.Button.cornerRadius
        centerView.layer.cornerRadius = UI.Button.cornerRadius
        bottomView.layer.cornerRadius = UI.Button.cornerRadius
        topButton.layer.cornerRadius = UI.Button.cornerRadius
        centerButton.layer.cornerRadius = UI.Button.cornerRadius
        bottomButton.layer.cornerRadius = UI.Button.cornerRadius
        // Set button onClick event
        topButton.addTarget(self, action: #selector(onClickTop), for: .touchUpInside)
        centerButton.addTarget(self, action: #selector(onClickCenter), for: .touchUpInside)
        bottomButton.addTarget(self, action: #selector(onClickBottom), for: .touchUpInside)
    }
    
    func setUpData() {
        // Reset Prescription
        bottomContentTextView.text = "bottomContentTextView".localized
        centerContentTextView.text = "centerContentTextView".localized
        topContentTextView.text = "topContentTextView".localized
        guard let onset = onset else { return }
//        LocalDataManager.ltTestPrescription = ExercisePresciptionModel()
        // Set button depend on purpose
        var ltTestPurpose = repaceLibrary.getPurpose(Int32(protocolValue), onset)
        if ltTestPurpose.purpose.0 == 0 && ltTestPurpose.purpose.0 == 0 && ltTestPurpose.purpose.0 == 0 {
            ltTestPurpose = repaceLibrary.getPurpose(Int32(protocolValue), onset)
        }
        Functions.showLog(title: "ltTestPurpose protocolValue = \(protocolValue) onset = \(onset)", message: ltTestPurpose)
        if ltTestPurpose.purpose.0 == LTTestConstants.PURPOSE_GENERAL_VALUE || ltTestPurpose.purpose.1 == LTTestConstants.PURPOSE_GENERAL_VALUE || ltTestPurpose.purpose.2 == LTTestConstants.PURPOSE_GENERAL_VALUE {
            setTopEnable()
        } else {
            setTopDisable()
        }
        if ltTestPurpose.purpose.0 == LTTestConstants.PURPOSE_WEIGHT_LOSS_VALUE || ltTestPurpose.purpose.1 == LTTestConstants.PURPOSE_WEIGHT_LOSS_VALUE || ltTestPurpose.purpose.2 == LTTestConstants.PURPOSE_WEIGHT_LOSS_VALUE {
            setCenterEnable()
        } else {
            setCenterDisable()
        }
        if ltTestPurpose.purpose.0 == LTTestConstants.PURPOSE_MAXIMAL_VALUE || ltTestPurpose.purpose.1 == LTTestConstants.PURPOSE_MAXIMAL_VALUE || ltTestPurpose.purpose.2 == LTTestConstants.PURPOSE_MAXIMAL_VALUE {
            setBottomEnable()
        } else {
            setBottomDisable()
        }
    }
    
    @objc func onClickTop(_ sender: UIButton) {
        guard let onset = onset else { return }
        let prescription = repaceLibrary.getPrescription(Int32(protocolValue), LTTestConstants.PURPOSE_GENERAL_VALUE, onset)
        goToPrescriptionDetail(prescription: prescription, purpose: LTTestConstants.PURPOSE_GENERAL_VALUE)
    }
    
    @objc func onClickCenter(_ sender: UIButton) {
        guard let onset = onset else { return }
        let prescription = repaceLibrary.getPrescription(Int32(protocolValue), LTTestConstants.PURPOSE_WEIGHT_LOSS_VALUE, onset)
        goToPrescriptionDetail(prescription: prescription, purpose: LTTestConstants.PURPOSE_WEIGHT_LOSS_VALUE)
    }
    
    @objc func onClickBottom(_ sender: UIButton) {
        guard let onset = onset else { return }
        let prescription = repaceLibrary.getPrescription(Int32(protocolValue), LTTestConstants.PURPOSE_MAXIMAL_VALUE, onset)
        goToPrescriptionDetail(prescription: prescription, purpose: LTTestConstants.PURPOSE_MAXIMAL_VALUE)
    }
    
    func goToPrescriptionDetail(prescription: LTPrescription, purpose: Int32) {
        Functions.showLog(title: "prescription", message: prescription)
        let prescriptionModel = ExercisePresciptionModel(type: Int(prescription.type), leSpeed: prescription.leSpeed, leWeek: Int(prescription.leWeek), leTime: Int(prescription.leTime), leMin: Int(prescription.leMin), ptSpeed: prescription.ptSpeed, ptWeek: Int(prescription.ptWeek), ptTime: Int(prescription.ptTime), ptMin: Int(prescription.ptMin), ptIndex: prescription.ptIndex)
        if prescriptionModel.type == LTTestConstants.PRESCRIPTION_TYPE_LOW {
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExerciseLow(prescription: prescriptionModel, purpose: purpose), with: .push)
        } else {
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExercisePolarized(prescription: prescriptionModel, purpose: purpose, onset: onset, protocolValue: self.protocolValue), with: .push)
        }
    }
    
    func setTopEnable() {
        topView.layer.backgroundColor = UI.Color.exercisePurposeGeneralBg.cgColor
        topImageView.image = UI.Image.img_general_performance
        topTitleLabel.textColor = UIColor.white
        topContentTextView.textColor = UIColor.white
        topButton.isEnabled = true
    }
    
    func setCenterEnable() {
        centerView.layer.backgroundColor = UI.Color.exercisePurposeWeightLossBg.cgColor
        centerImageView.image = UI.Image.img_weight_loss
        centerTitleLabel.textColor = UIColor.white
        centerContentTextView.textColor = UIColor.white
        centerButton.isEnabled = true
    }
    
    func setBottomEnable() {
        bottomView.layer.backgroundColor = UI.Color.exercisePurposeMaximalBg.cgColor
        bottomImageView.image = UI.Image.img_max_earobic_performance
        bottomTitleLabel.textColor = UIColor.white
        bottomContentTextView.textColor = UIColor.white
        bottomButton.isEnabled = true
    }
    
    func setTopDisable() {
        topView.layer.backgroundColor = UI.Color.exercisePurposeDisableBg.cgColor
        topImageView.image = UI.Image.img_general_performance_disable
        topTitleLabel.textColor = UI.Color.txtPlaceholderColor
        topContentTextView.textColor = UI.Color.txtPlaceholderColor
        topButton.isEnabled = false
    }
    
    func setCenterDisable() {
        centerView.layer.backgroundColor = UI.Color.exercisePurposeDisableBg.cgColor
        centerImageView.image = UI.Image.img_weight_loss_disable
        centerTitleLabel.textColor = UI.Color.txtPlaceholderColor
        centerContentTextView.textColor = UI.Color.txtPlaceholderColor
        centerButton.isEnabled = false
    }
    
    func setBottomDisable() {
        bottomView.layer.backgroundColor = UI.Color.exercisePurposeDisableBg.cgColor
        bottomImageView.image = UI.Image.img_max_earobic_performance_disable
        bottomTitleLabel.textColor = UI.Color.txtPlaceholderColor
        bottomContentTextView.textColor = UI.Color.txtPlaceholderColor
        bottomButton.isEnabled = false
    }
}
