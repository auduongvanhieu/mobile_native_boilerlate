import Foundation
import UIKit

class LTTestPerformanceResultCell: UITableViewCell {
    @IBOutlet var stageLabel: UILabel!
    @IBOutlet var speedLabel: UILabel!
    @IBOutlet var distanceLabel: UILabel!
    
    override func layoutSubviews() {
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
    }
}
