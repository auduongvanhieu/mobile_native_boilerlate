import Foundation
import UIKit
import MapboxMaps
import CoreLocation
import Charts

class LTTestResultViewController: BaseViewController {
    
    var isJustFinishLTTest = true
    var viewModel = LTTestResultViewModel()
    var isExpanded: Bool = false
    var blurEffectView: UIVisualEffectView?
    // var isShare = false
    var ltTestResult: LTTestResultModel! = LTTestResultModel()
    var tableViewHeight = CGFloat(0)
    var chartSmO2Values: [ChartDataEntry] = []
    var chartLactateValues: [BarChartDataEntry] = []
    var lineChartView = LineChartView()
//    var lastViewHeight : CGFloat = 0
    var minSpace: Double?
    
    private var isHiddenSync: Bool = true {
        didSet {
            self.updateSyncUI()
        }
    }
    
    internal var mapView: MapView!
    static var shareImage: UIImage?
    @IBOutlet weak var ctHeightMapBox: NSLayoutConstraint!
    @IBOutlet weak var performanceViewHeight: NSLayoutConstraint!
    @IBOutlet weak var btnMoreInfo: UIButton!
    @IBOutlet weak var tvGuide: UITextView!
    @IBOutlet weak var vwGuideContainer: UIView!
    @IBOutlet weak var ctGuideContainerHeight: NSLayoutConstraint!
    @IBOutlet weak var chartView: UIView!
    @IBOutlet weak var mapUIView: UIView!
    @IBOutlet weak var topLeftImageView: UIImageView!
    @IBOutlet weak var topRightImageView: UIImageView!
    @IBOutlet weak var bottomLeftImageView: UIImageView!
    @IBOutlet weak var bottomRightImageView: UIImageView!
    @IBOutlet weak var headerBack: HeaderBack!
    @IBOutlet weak var todayLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var lastStageLabel: UILabel!
    @IBOutlet weak var maxSpeedLabel: UILabel!
    @IBOutlet weak var totalDurationLabel: UILabel!
    @IBOutlet weak var totalDistanceLabel: UILabel!
    @IBOutlet weak var performanceTableView: UITableView!
    @IBOutlet weak var onsetLabel: UILabel!
    @IBOutlet weak var mmolLabel: UILabel!
    @IBOutlet weak var minSmo2Label: UILabel!
    @IBOutlet weak var maxSmo2Label: UILabel!
    @IBOutlet weak var avgSmo2Label: UILabel!
    @IBOutlet weak var minHeartRateLabel: UILabel!
    @IBOutlet weak var maxHeartRateLabel: UILabel!
    @IBOutlet weak var avgHeartRateLabel: UILabel!
    @IBOutlet weak var heartRate4mmolLabel: UILabel!
    @IBOutlet weak var heartOnsetLabel: UILabel!
    @IBOutlet weak var paceLabel: UILabel!
    @IBOutlet weak var vwChartContainer: UIStackView!
    @IBOutlet weak var lbExerciseInfo: UILabel!
    @IBOutlet weak var btnExerciseDescription: DesignableButton!
    
    @IBOutlet weak var ctTitleTop: NSLayoutConstraint!
    @IBOutlet weak var ctTitleHeight: NSLayoutConstraint!
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbUserName: UILabel!
    @IBOutlet weak var heightExerciseInfo: NSLayoutConstraint!
    
    @IBOutlet weak var lblUnitMaxSpeed: UILabel!
    @IBOutlet weak var lblUnitDistance: UILabel!
    @IBOutlet weak var lblUnitSpeed: UILabel!
    @IBOutlet weak var lblUnitTotalDistance: UILabel!
    @IBOutlet weak var lblUnit4MMol: UILabel!
    @IBOutlet weak var lblUnitOnset: UILabel!
    @IBOutlet weak var btnSync: UIView!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpView()
        viewModel.delegate = self
        viewModel.getLTTestResult()
    }
    
    func setUpView() {
        // Header
        headerBack.delegate = self
        // Content View
        ctGuideContainerHeight.constant = 88
        ctTitleHeight.constant = 0
        performanceViewHeight.constant = 180 + self.tableViewHeight
        performanceTableView.delegate = self
        performanceTableView.dataSource = self
        // Unit
        lblUnitMaxSpeed.text = Functions.showUnitLabel(isSpeed: true)
        lblUnitSpeed.text = lblUnitMaxSpeed.text
        lblUnitOnset.text = lblUnitMaxSpeed.text
        lblUnit4MMol.text = lblUnitMaxSpeed.text
        lblUnitDistance.text = Functions.showUnitLabel(isSpeed: false)
        lblUnitTotalDistance.text = lblUnitDistance.text
        btnSync.layer.cornerRadius = 12.0
        btnSync.clipsToBounds = true
        // Chart
        initChart()
        tvGuide.text = "tvGuide".localized
    }
    
    func bindData() {
        // Set now date
        if viewModel.ltTestTemp == nil {
            lbUserName.text = ltTestResult.member?.nickname ?? ""
            todayLabel.text = Functions.getNowDateStr()
        } else {
            todayLabel.text = Functions.convertDateStrToProfileDateStr(dateStr: ltTestResult.createdAt ?? "")
            lbUserName.text = ltTestResult.member?.nickname
        }
        btnExerciseDescription.isEnabled = viewModel.ltTestTemp?.isFromLocal == false
        btnExerciseDescription.backgroundColor = btnExerciseDescription.isEnabled == false ? UI.Color.btnBgDisableColor : UI.Color.btnBgColor
        tvGuide.isHidden = true
        // Set LT Test Performance
        lastStageLabel.text = "\(ltTestResult.stageCnt ?? 0)"
        let totalDuration = ltTestResult.totalDuration ?? 0
        let minutes = totalDuration > 200 ? totalDuration / 60 : totalDuration
        let km = Functions.kmToMile(km: ltTestResult.totalDistance).to1Decimal
        totalDurationLabel.text = "\(minutes)"
        // Lactate Threshold Info.
        maxSpeedLabel.text = "\(Functions.kmToMile(km: ltTestResult.speedMax).to1Decimal)"
        totalDistanceLabel.text = "\(km)"
        onsetLabel.text = "\(Functions.kmToMile(km: ltTestResult.onset).to1Decimal)"
        mmolLabel.text = "\(Functions.kmToMile(km: ltTestResult.mol).to1Decimal)"
        // SmO2
        minSmo2Label.text = "\(ltTestResult.smo2Min?.to1Decimal ?? 0.0)"
        maxSmo2Label.text = "\(ltTestResult.smo2Max?.to1Decimal ?? 0.0)"
        avgSmo2Label.text = "\(ltTestResult.smo2Avg?.to1Decimal ?? 0.0)"
        
        // Exercise Info.
        let minHeartRate = Int((ltTestResult.heartRateMin ?? 0).rounded(.toNearestOrAwayFromZero))
        let maxHeartRate = Int((ltTestResult.heartRateMax ?? 0).rounded(.toNearestOrAwayFromZero))
        let avgHeartRate = Int((ltTestResult.heartRateAvg ?? 0).rounded(.toNearestOrAwayFromZero))
        minHeartRateLabel.text = minHeartRate == 0 ? "-" : "\(minHeartRate)"
        maxHeartRateLabel.text = maxHeartRate == 0 ? "-" : "\(maxHeartRate)"
        avgHeartRateLabel.text = avgHeartRate == 0 ? "-" : "\(avgHeartRate)"
        
        heartRate4mmolLabel.text = "-"
        heartOnsetLabel.text = "-"
        if km != 0 {
            let pace = Double(minutes) / km
            let paceDownDouble = pace.rounded(.down)
            let paceDown = Int(paceDownDouble)
            let second = Int(((pace - paceDownDouble) * 60).rounded())
            paceLabel.text = "\(paceDown)’ \(second)’’"
        } else {
            paceLabel.text = nil
        }
        // Chart
        self.setChartData()
        
        // Map
        var ltTestType = LocalDataManager.ltTestType
        if viewModel.ltTestTemp != nil {
            ltTestType = viewModel.ltTestResult?.testTypeID ?? ""
        }
        if ltTestType == LTTestConstants.TREADMILL_TEST {
            ctHeightMapBox.constant = 0
        } else {
            ctHeightMapBox.constant = 240
            setupMapBox()
        }
        if ltTestResult.stage?.isEmpty == false {
            tableViewHeight = CGFloat(((ltTestResult.stage?.count ?? 0) + 1) * 32)
            performanceViewHeight.constant = 180 + self.tableViewHeight
            performanceTableView.reloadData()
        }
    }
    
    // MARK: MAPBOX
    func setupMapBox() {
        mapUIView.layer.cornerRadius = UI.View.radius
        var locationList: [LocationModel]
        if viewModel.ltTestTemp != nil {
            locationList = viewModel.ltTestResult?.listLocation ?? []
        } else {
            locationList = LocalDataManager.ltTestLocationList
        }
        let myResourceOptions = ResourceOptions(accessToken: MapConstants.MAP_KEY)
        let locationCenter = locationList.isEmpty == false ? CLLocationCoordinate2D(latitude: locationList[0].latitude ?? 0, longitude: locationList[0].longitude ?? 0) : CLLocationCoordinate2D(latitude: MapConstants.CENTER_LAT, longitude: MapConstants.CENTER_LON)
        let cameraOptions = CameraOptions(center: locationCenter, zoom: 18, bearing: 0, pitch: 0)
        let myMapInitOptions = MapInitOptions(resourceOptions: myResourceOptions, cameraOptions: cameraOptions, styleURI: StyleURI(rawValue: StyleURI.dark.rawValue))
        mapView = MapView(frame: mapUIView.bounds, mapInitOptions: myMapInitOptions)
        mapView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        mapView.layer.cornerRadius = UI.View.radius
        mapUIView.addSubview(mapView)
        mapUIView.addSubview(topLeftImageView)
        mapUIView.addSubview(topRightImageView)
        mapUIView.addSubview(bottomLeftImageView)
        mapUIView.addSubview(bottomRightImageView)
        // Draw line for map
        var lineCoordinates: [CLLocationCoordinate2D] = []
        locationList.forEach { (element) in
            lineCoordinates.append(CLLocationCoordinate2DMake(element.latitude ?? 0, element.longitude ?? 0))
        }
        var lineAnnotation = PolylineAnnotation(lineCoordinates: lineCoordinates)
        lineAnnotation.lineColor = StyleColor(.yellow)
        lineAnnotation.lineWidth = 5
        let lineAnnnotationManager = mapView.annotations.makePolylineAnnotationManager()
        lineAnnnotationManager.annotations = [lineAnnotation]
        // Set camera depend sharp
        if locationList.isEmpty == false {
            Functions.showLog(title: "locationList", message: Functions.structToJsonStr(locationList))
            let startPoint = CLLocationCoordinate2D(latitude: locationList[0].latitude ?? 0, longitude: locationList[0].longitude ?? 0)
            let endPoint = CLLocationCoordinate2D(latitude: locationList[locationList.count - 1].latitude ?? 0, longitude: locationList[locationList.count - 1 ].longitude ?? 0)
            // Set camera depend sharp
            let bounds = CoordinateBounds(southwest: startPoint, northeast: endPoint)
            _ = mapView.mapboxMap.camera(for: bounds, padding: .zero, bearing: 0, pitch: 0)
            // Set start point and end point
            var startPointAnnotation = PointAnnotation(coordinate: startPoint)
            if let image = UI.Icon.ic_map_start {
                startPointAnnotation.image = .init(image: image, name: "start")
            }
            startPointAnnotation.iconAnchor = .bottom
            startPointAnnotation.iconSize = 0.05
            var endPointAnnotation = PointAnnotation(coordinate: endPoint)
            if let image = UI.Icon.ic_map_stop {
                endPointAnnotation.image = .init(image: image, name: "end")
            }
            endPointAnnotation.iconAnchor = .bottom
            endPointAnnotation.iconSize = 0.05
            let pointAnnotationManager = mapView.annotations.makePointAnnotationManager()
            pointAnnotationManager.annotations = [startPointAnnotation, endPointAnnotation]
        }
    }
    
    // MARK: CHART
    func initChart() {
        lineChartView.legend.enabled = false
        lineChartView.leftAxis.labelTextColor = .white
        lineChartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.valueFormatter = self
        lineChartView.xAxis.labelTextColor = .white
        lineChartView.xAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.rightAxis.labelTextColor = .white
        lineChartView.xAxis.spaceMin = 0.3
        lineChartView.xAxis.spaceMax = 0.3
        lineChartView.rightAxis.axisMinimum = 0
        lineChartView.rightAxis.axisMaximum = 200
        lineChartView.leftAxis.axisMinimum = 0
        lineChartView.leftAxis.axisMaximum = 100
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.granularityEnabled = true
        lineChartView.xAxis.granularity = 1
        lineChartView.doubleTapToZoomEnabled = false
        lineChartView.scaleXEnabled = false
        lineChartView.scaleYEnabled = false
        lineChartView.dragEnabled = false
        vwChartContainer.addArrangedSubview(lineChartView)
        self.setChartData()
    }
        
    func setChartData() {
        var smo2List: [SmO2ChartModel] = []
        var lactateList: [SmO2ChartModel] = []
        if viewModel.ltTestTemp != nil {
            smo2List = viewModel.ltTestResult?.listSmo2 ?? []
            lactateList = viewModel.ltTestResult?.listLactate ?? []
        } else {
            smo2List = ltTestResult.listSmo2 ?? []
            lactateList = ltTestResult.listLactate ?? []
        }
        var index: Double = 0
        var maxSmO = 0.0
        var minSmO = 0.0
        if !smo2List.isEmpty {
            chartSmO2Values.removeAll()
            for month in smo2List {
                let score = month.score ?? 0.0
                minSmO = index == 0 ? score : Double.minimum(score, minSmO)
                maxSmO = Double.maximum(score, maxSmO)
                chartSmO2Values.append(BarChartDataEntry(x: index, y: Double(month.score ?? 0)))
                index += 1
            }
        }
        var maxLac = 0.0
        index = 0
        if !lactateList.isEmpty {
            chartLactateValues.removeAll()
            for month in lactateList {
                let lacScore = Double(month.score ?? 0)
                maxLac = Double.maximum(maxLac, lacScore)
                chartLactateValues.append(BarChartDataEntry(x: index, y: lacScore))
                index += 1
            }
        }
        let set1 = LineChartDataSet(entries: chartSmO2Values, label: "SmO2")
        set1.setColor(UI.Color.blueColor)
        set1.drawValuesEnabled = false
        set1.lineWidth = 2
        set1.circleColors = [UI.Color.blueColor]
        if smo2List.count == 1 {
            set1.circleRadius = 2
            set1.circleHoleRadius = 2
        } else {
            set1.circleRadius = 0
            set1.circleHoleRadius = 0
        }
        let set6 = LineChartDataSet(entries: chartLactateValues, label: "Lactate Onset")
        set6.setColor(UI.Color.orangeColor)
        set6.drawValuesEnabled = false
        set6.lineWidth = 2
        set6.circleColors = [UI.Color.orangeColor]
        set6.axisDependency = .right
        if lactateList.count == 1 {
            set6.circleRadius = 2
            set6.circleHoleRadius = 2
        } else {
            set6.circleRadius = 0
            set6.circleHoleRadius = 0
        }
        minSmO *= 0.9
        maxSmO *= 1.1
        maxLac *= 1.1
        maxSmO = maxSmO.rounded(.up)
        maxLac = maxLac.rounded(.up)
        lineChartView.leftAxis.axisMinimum = minSmO.to1Decimal
        lineChartView.leftAxis.axisMaximum = maxSmO.to1Decimal
        lineChartView.rightAxis.axisMaximum = maxLac.to1Decimal
        lineChartView.xAxis.labelCount = smo2List.count
        lineChartView.data = LineChartData(dataSets: [set1, set6])
    }
    
    @IBAction func btnMoreInfo_Click(_ sender: Any) {
        let options: UIView.AnimationOptions = [.curveEaseInOut]
        var height: CGFloat = 88
        
        if #available(iOS 13.0, *) {
            let window = UIApplication.shared.windows.first
            let topPadding = window?.safeAreaInsets.top
            let bottomPadding = window?.safeAreaInsets.bottom
            height -= CGFloat(topPadding ?? 0) + CGFloat(bottomPadding ?? 0)
        }
        
        var blurAlpha: CGFloat = 0.0
        isExpanded = !isExpanded
        if isExpanded {
            tvGuide.isHidden = false
            height = 390
            blurAlpha = 1
            btnMoreInfo.setImage(#imageLiteral(resourceName: "ic_close_circle"), for: UIControl.State.normal)
        } else {
            height = 90
            blurAlpha = 0
            btnMoreInfo.setImage(#imageLiteral(resourceName: "ic_help_circle"), for: UIControl.State.normal)
        }
        
        UIView.animate(withDuration: 0.5, delay: 0, options: options, animations: { [weak self] in
            guard let self = self else { return }
            self.tvGuide?.alpha = blurAlpha
            self.ctGuideContainerHeight.constant = height
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    @IBAction func btnExercisePrescription_Click(_ sender: Any) {
        if let protocolValue = ltTestResult.protocolType {
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExerciseFromLTTestResult(onset: ltTestResult.onset ?? 0, protocolValue: protocolValue), with: .push)
        } else {
            AppNavigator.shared.navigate(to: LTTestRoutes.ltTestRXEExerciseFromLTTestResult(onset: ltTestResult.onset ?? 0, protocolValue: LocalDataManager.ltTestProtocol.protocolValue), with: .push)
        }
    }
    
    @IBAction func didTouchSync(_ sender: Any) {
        viewModel.didTouchSync()
    }
    
    private func updateSyncUI() {
        btnSync.isHidden = self.isHiddenSync
        btnExerciseDescription.isEnabled = self.isHiddenSync
        btnExerciseDescription.backgroundColor = self.isHiddenSync == false ? UI.Color.btnBgDisableColor : UI.Color.btnBgColor
        if isJustFinishLTTest {
            headerBack.hideLeftButton = self.isHiddenSync
        } else {
            headerBack.hideLeftButton = false
        }
    }
}

extension LTTestResultViewController: HeaderBackDelegate {
    
    func onClickBack() { }
    
    func onClickShare() {
        setupShareView(true)
        let shareImage = self.contentView.takeScreenshot()
        shareOtherApp(text: nil, shareImage: shareImage, completion: {[weak self] in
            guard let self = self else { return }
            self.setupShareView(false)
        }, isJustShareImage: true)
    }

    func setupShareView(_ isShare: Bool) {
        if isShare {
            btnMoreInfo.isHidden = true
            mapUIView.isHidden = true
            lbUserName.isHidden = false
            btnExerciseDescription.isHidden = true
            lbExerciseInfo.isHidden = true
            lbTitle.isHidden = false
            ctTitleHeight.constant = 30
            ctTitleTop.constant = 20
            heightExerciseInfo.constant = 0
        } else {
            btnMoreInfo.isHidden = false
            let ltTestType = LocalDataManager.ltTestType
            if ltTestType == LTTestConstants.TREADMILL_TEST {
                mapUIView.isHidden = true
            } else {
                mapUIView.isHidden = false
            }
            lbUserName.isHidden = true
            btnExerciseDescription.isHidden = false
            lbExerciseInfo.isEnabled = false
            lbTitle.isHidden = true
            heightExerciseInfo.constant = 250
            ctTitleHeight.constant = 0
            ctTitleTop.constant = 0
        }
    }
}

extension LTTestResultViewController: LTTestResultViewModelDelegate {
    func didUpdateState(to state: LTTestResultViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getLTTestResultSuccess:
            ltTestResult = viewModel.ltTestResult
            Functions.showLog(title: "ltTestResult", message: Functions.structToJsonStr(ltTestResult))
            self.bindData()
        case .hideSync(let isHidden):
            self.isHiddenSync = isHidden
        case .failWithMessage(let alertString):
            showMessage(title: "Data upload fail", message: alertString, buttonTitle: "Retry", handle: { _ in
                // Retry
                self.viewModel.didTouchRetry()
            }, handlerOK: { _ in
                self.viewModel.didTouchOK()
            })
        case .exerciseUploading:
            showMessage(title: "", message: "Exercise is uploading, please wait")
        case .failAPI(let errSTr):
            showMessage(title: "API Error", message: errSTr)
        }
    }
}

extension LTTestResultViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ltTestResult?.stage?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "LTTestPerformanceResultCell", for: indexPath) as? LTTestPerformanceResultCell else {
            return UITableViewCell()
        }
        if let stageInLtTest = ltTestResult?.stage, stageInLtTest.count > indexPath.row {
            let data = stageInLtTest[indexPath.row]
            let stage = data.stage ?? 0
            cell.stageLabel.text = stage > 9 ? "\(stage)" : "0\(stage)"
            cell.speedLabel.text = "\(data.speed?.to1Decimal ?? 0.0)"
            cell.distanceLabel.text = "\(data.distance?.to1Decimal ?? 0.0)"
            // Set selection bacground
            let backgroundView = UIView()
            backgroundView.backgroundColor = UI.Color.inputBgColor
            cell.selectedBackgroundView = backgroundView
        }
        return cell
    }
}

extension LTTestResultViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        String(Int(value) + 1)
    }
}
