import Foundation
import CloudKit

protocol LTTestResultViewModelDelegate: NetworkStatusDelegate {
    func didUpdateState(to state: LTTestResultViewModelState)
}

enum LTTestResultViewModelState {
    case network(state: NetworkState)
    case getLTTestResultSuccess
    case hideSync(isHidden: Bool)
    case failWithMessage(message: String)
    case failAPI(errSTr: String)
    case exerciseUploading
}

class LTTestResultViewModel {
    
    var ltTestTemp: LTTestHistoryTempModel?
    var ltTestResult: LTTestResultModel?
    var object: ResultExerciseObject?
    
    weak var delegate: LTTestResultViewModelDelegate?
    
    private var state: LTTestResultViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    func getLTTestResult() {
        var ltTestID: Int?
        if let ltTestTemp = ltTestTemp {
            if ltTestTemp.isFromLocal == true {
                if let idExercise = ltTestTemp.id {
                    if idExercise == 0 {
                        if let ltTestResult = BluetoothHelper.ltTestResult {
                            self.ltTestResult = ltTestResult
                            checkUploadData(isShowAlert: false)
                            self.sortStageResult()
                            self.state = .hideSync(isHidden: true)
                        } else {
                            Functions.showLog(title: "Error function getLTTestResult in LTTestResultViewModel", message: "")
                        }
                    } else {
                        loadLocalDB(idExercise: idExercise, isFirstTime: true)
                    }
                }
            } else {
                ltTestID = ltTestTemp.id
             }
        } 
        if let ltTestID = ltTestID {
            LTTestServices.getLTTestResult(id: ltTestID,
                success: {[weak self] res in
                    guard let self = self else { return }
                    self.ltTestResult = res
                    self.sortStageResult()
                    self.state = .network(state: .hideLoading)
                    self.state = .hideSync(isHidden: true)
                },
                failure: { [weak self] error in
                    self?.state = .network(state: .error(error.localizedDescription))
                    Functions.showLog(title: "getLTTestResultError", message: error)
                }
            )
        }
    }
    
    private func loadLocalDB(idExercise: Int, isFirstTime: Bool) {
        if let object = RealmHelper.share.getExerciseByID(isLTTest: true, idExercise: idExercise) as? LTTestResultObject {
            if isFirstTime {
                self.ltTestResult = object.convertToLTTestResultModel(isPostToServer: false)
                self.sortStageResult()
            }
            self.object = object
            self.state = .hideSync(isHidden: false)
            if object.isLock == true {
                Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { _ in
                    self.loadLocalDB(idExercise: idExercise, isFirstTime: false)
                }
            }
        } else {
            if let ltTestResult = BluetoothHelper.ltTestResult {
                self.ltTestResult = ltTestResult
                checkUploadData(isShowAlert: false)
                self.sortStageResult()
            } else {
                Functions.showLog(title: "Error function getLTTestResult in LTTestResultViewModel", message: "")
            }
            self.state = .hideSync(isHidden: true)
        }
    }
    
    private func sortStageResult() {
        var stages = self.ltTestResult?.stage
        stages = stages?.sorted(by: {($0.stage ?? 0) <= ($1.stage ?? 0)})
        if LocalDataManager.unit != Constants.UNIT_METRIC {
            stages = stages?.map({ model in
                var newModel = model
                newModel.speed = Functions.kmToMile(km: newModel.speed).to1Decimal
                newModel.distance = Functions.kmToMile(km: newModel.distance).to1Decimal
                return newModel
            })
        }
        self.ltTestResult?.stage = stages
        let min = self.ltTestResult?.smo2Min ?? 0
        let max = self.ltTestResult?.smo2Max ?? 0
        self.ltTestResult?.smo2Min = min != 0 ? min : max
        self.state = .getLTTestResultSuccess
    }
    
    private func checkUploadData(isShowAlert: Bool) {
        if let idExercise = ltTestResult?.id {
            if let object = RealmHelper.share.getExerciseByID(isLTTest: true, idExercise: idExercise) {
                self.object = object
                self.state = .hideSync(isHidden: false)
                if object.isLock && isShowAlert {
                    self.state = .exerciseUploading
                }
            } else {
                self.state = .hideSync(isHidden: true)
            }
        }
    }
    
    func didTouchSync() {
        Functions.showLog(title: "Mytv didTouchSync", message: "")
        FileHelper.writeStringToLogFile(title: "LTTestResultViewModel didTouchSync", content: "")
        uploadData()
    }
    
    func didTouchRetry() {
        FileHelper.writeStringToLogFile(title: "LTTestResultViewModel didTouchRetry", content: "")
        Functions.showLog(title: "Mytv didTouchRetry", message: "")
        uploadData()
    }
    
    private func uploadData() {
        if let object = object {
            if object.isInvalidated == false {
                if object.isAttachCreatedAt == false {
                    object.addPostCreatedAt()
                }
                if object.isLock == false {
                    upload()
                } else {
                    self.state = .exerciseUploading
                }
            } else {
                self.state = .hideSync(isHidden: true)
            }
        }
    }
    
    private func upload() {
        guard let object = object,
            object.isInvalidated == false else {
            return
        }
        self.state = .network(state: .loading)
        RealmHelper.share.saveExercise(isLTTest: true, idExercise: object.id, isFailByConnection: { isFailByConnection in
            Functions.showLog(title: "Fail isFailByConnection ", message: isFailByConnection)
            if let isFailByConnection = isFailByConnection as? Bool {
                self.state = .failWithMessage(message: "noInternetPostLTTest".localized)
                FileHelper.writeStringToLogFile(title: "LTTestResultViewModel upload local data fail exercise id \(object.id) with isFailByConnection = \(isFailByConnection)", content: "")
            } else if let errStr = isFailByConnection as? String {
                self.state = .failAPI(errSTr: errStr)
                FileHelper.writeStringToLogFile(title: "LTTestResultViewModel upload local data fail exercise id \(object.id) with isFailByConnection = \(errStr)", content: "")
            } else if let err = isFailByConnection as? Error {
                self.state = .failAPI(errSTr: err.localizedDescription)
                FileHelper.writeStringToLogFile(title: "LTTestResultViewModel upload local data fail exercise id \(object.id) with isFailByConnection = \(err.localizedDescription)", content: "")
            } else {
                self.state = .failAPI(errSTr: "Unknown error")
                FileHelper.writeStringToLogFile(title: "LTTestResultViewModel upload local data fail exercise id \(object.id) with isFailByConnection Unknown error", content: "")
            }
            self.state = .network(state: .hideLoading)
        }, completion: { _ in
            self.state = .network(state: .hideLoading)
            self.state = .hideSync(isHidden: true)
            FileHelper.writeStringToLogFile(title: "LTTestResultViewModel upload local data success", content: "")
        }, updatePercent: {percent in
            self.state = .network(state: .loadingPercent(percent: percent))
        })
    }
    
    func didTouchOK() {
        FileHelper.writeStringToLogFile(title: "LTTestResultViewModel didTouchOK", content: "")
        Functions.showLog(title: "Mytv didTouchOK", message: "")
        if let object = object,
           object.isInvalidated {
            object.addPostCreatedAt()
        }
    }
}
