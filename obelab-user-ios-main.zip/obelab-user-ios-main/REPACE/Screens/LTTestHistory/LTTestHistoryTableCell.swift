//
//  LTTestHistoryTableCell.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/22/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

protocol LTTestHistoryTableCellDelegate: NSObjectProtocol {
    func detailItemClick(_ model: LTTestHistoryTempModel?)
}

class LTTestHistoryTableCell: UITableViewCell {
    
    weak var delegate: LTTestHistoryTableCellDelegate?
    var history: LTTestHistoryTempModel?
    @IBOutlet weak var lbDate: UILabel!
    @IBOutlet weak var lbStage: UILabel!
    @IBOutlet weak var lbLactateOnset: UILabel!
    @IBOutlet weak var lbSmO2Avg: UILabel!
    @IBOutlet weak var lblUnit: UILabel!
    @IBOutlet weak var btnMore: UIButton!
    
    @IBAction func btnMore_Click(_ sender: Any) {
        delegate?.detailItemClick(self.history)
    }
    
    override func awakeFromNib() {
       super.awakeFromNib()
    }
    
    func bindData(history: LTTestHistoryTempModel) {
        self.history = history
        lblUnit.text = Functions.showUnitLabel(isSpeed: true)
        self.btnMore.tag = history.id ?? 0
        self.lbStage.text = String(history.stage ?? 0)
        let lactateOnset = "\(Functions.kmToMile(km: history.lactateOnset).to1Decimal)" //String(format: "%.1f", history.lactateOnset ?? 0)
        self.lbLactateOnset.text = lactateOnset
//        self.lbLactateOnset.text = String(history.lactateOnset ?? 0)
        self.lbSmO2Avg.text = String(format: "%.1f", history.smO2Avg ?? 0)
        self.lbDate.text = Functions.convertDateStrToProfileDateStr(dateStr: history.date ?? "")
        self.contentView.sizeToFit()
    }
}
