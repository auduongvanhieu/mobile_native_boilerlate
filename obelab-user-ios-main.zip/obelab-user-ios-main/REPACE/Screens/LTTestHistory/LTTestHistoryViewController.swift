//
//  LTTestHistoryViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/22/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit
import Charts

class LTTestHistoryViewController: BaseViewController {
    
    var months: [String] = []
    var chartSmO2Values: [BarChartDataEntry] = []
    var chartLactateValues: [BarChartDataEntry] = []
    
    @IBOutlet weak var lblUnitSpeed: UILabel!
    let refreshControl = UIRefreshControl()
    var viewModel: LTTestHistoryViewModel!
    var lineChartView = LineChartView()
    
    @IBOutlet weak var vwChartContainer: UIStackView!
    @IBOutlet weak var tableLTTestHistory: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel = LTTestHistoryViewModel()
        viewModel.delegate = self
        initChart()
        setupTableView()
        onRefresh()
        lblUnitSpeed.text = Functions.showUnitLabel(isSpeed: true)
    }
    
    @objc private func onRefreshData(_ sender: Any) {
        onRefresh()
    }
    
    func onRefresh() {
        viewModel.ltTestHistoryList.removeAll()
        viewModel.page = 0
        viewModel.getLTTestHistoryList()
        setChartData()
    }
    
    func onLoadMore() {
        viewModel.page += 1
        viewModel.getLTTestHistoryList()
        setChartData()
    }
    
    func setupTableView() {
        // delegate & datasouce
        tableLTTestHistory.allowsSelection = false
        tableLTTestHistory.delegate = self
        tableLTTestHistory.dataSource = self
        // Add Refresh Control to Table View
        if #available(iOS 10.0, *) {
            tableLTTestHistory.refreshControl = refreshControl
        } else {
            tableLTTestHistory.addSubview(refreshControl)
        }
        tableLTTestHistory.separatorStyle = .none
        // Configure Refresh Control
        refreshControl.addTarget(self, action: #selector(onRefreshData(_:)), for: .valueChanged)
    }
    
    func initChart() {
        lineChartView.legend.enabled = false
        lineChartView.maxVisibleCount = 5
        // xaxis label center bar graph
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.xAxis.valueFormatter = self
        lineChartView.xAxis.drawGridLinesEnabled = false
        lineChartView.xAxis.labelTextColor = .white
        lineChartView.xAxis.labelFont = UIFont(name: AppFontName.boldButton, size: 12) ?? .systemFont(ofSize: 12)
        lineChartView.xAxis.spaceMin = 0.3
        lineChartView.xAxis.spaceMax = 0.3
        lineChartView.xAxis.granularityEnabled = true
        lineChartView.xAxis.granularity = 1
        // Left
        lineChartView.leftAxis.labelTextColor = .white
        lineChartView.leftAxis.labelFont = UIFont(name: AppFontName.regular, size: 10) ?? .systemFont(ofSize: 10)
        lineChartView.leftAxis.drawGridLinesEnabled = false
        lineChartView.leftAxis.axisMinimum = 0.0
        // Right
        lineChartView.rightAxis.labelTextColor = .white
        
        lineChartView.doubleTapToZoomEnabled = false
        lineChartView.scaleXEnabled = false
        lineChartView.scaleYEnabled = false
        lineChartView.dragEnabled = false
        vwChartContainer.addArrangedSubview(lineChartView)
    }
    
    func setChartData() {
        var maxLac = 0.0
        var minSmO = 0.0
        var maxSmO = 0.0
        var index: Double = 0
        if !self.viewModel.ltTestHistoryList.isEmpty {
            months.removeAll()
            chartLactateValues.removeAll()
            chartSmO2Values.removeAll()
            // Sort
            if self.viewModel.ltTestHistoryList.count > 4 {
                self.viewModel.ltTestHistoryList = Array(self.viewModel.ltTestHistoryList.prefix(4))
            }
            let listDataSort = self.viewModel.ltTestHistoryList.sorted { (current, next) -> Bool in
                if current.date == nil {
                    return true
                } else if next.date == nil {
                    return false
                }
                if let currentDate = current.date,
                   let nextDate = next.date,
                    let currentConvertDate = Functions.convertDateStrToDateISO8601(dateStr: currentDate),
                        let nextConvertDate = Functions.convertDateStrToDateISO8601(dateStr: nextDate) {
                    return currentConvertDate <= nextConvertDate
                }
                return false
            }
            for month in listDataSort {
                let monthStr = "\(Functions.convertDateStrUTCToDateStr(dateStr: month.date ?? "", formatStr: "MMM dd"))" //Functions.convertDateStrToDateStr(dateStr: month.date ?? "", formatStr: "MMM dd")
                months.append(monthStr)
                let lactateOnset = Functions.kmToMile(km: month.lactateOnset) // Double(month.lactateOnset ?? 0.0)
                maxLac = Double.maximum(maxLac, lactateOnset)
                chartLactateValues.append(BarChartDataEntry(x: index, y: lactateOnset))
                let smO2Avg = Double(month.smO2Avg ?? 0.0)
                minSmO = index == 0 ? smO2Avg : Double.minimum(minSmO, smO2Avg)
                maxSmO = Double.maximum(maxSmO, smO2Avg)
                chartSmO2Values.append(BarChartDataEntry(x: index, y: smO2Avg))
                index += 1
            }
        }
        let set1 = LineChartDataSet(entries: chartLactateValues, label: "Lactate Onset")
        set1.setColor(UI.Color.orangeColor)
        set1.drawValuesEnabled = false
        set1.lineWidth = 2
        set1.lineDashLengths = [6, 3]
        set1.circleColors = [UI.Color.orangeColor]
        set1.circleHoleColor = UI.Color.orangeColor
        set1.circleRadius = 4
        set1.circleHoleRadius = 0
        
        let set6 = LineChartDataSet(entries: chartSmO2Values, label: "SmO2")
        set6.setColor(UI.Color.lightBlueColor)
        set6.drawValuesEnabled = false
        set6.lineWidth = 2
        set6.circleColors = [UI.Color.lightBlueColor]
        set6.circleHoleColor = UI.Color.lightBlueColor
        set6.lineDashLengths = [6, 3]
        set6.circleRadius = 4
        set6.circleHoleRadius = 0
        set6.axisDependency = .right
        minSmO *= 0.9
        maxSmO *= 1.1
        maxLac *= 1.1
        maxSmO = maxSmO.rounded(.up)
        maxLac = maxLac.rounded(.up)
        lineChartView.leftAxis.axisMaximum = maxLac.to1Decimal
        lineChartView.rightAxis.axisMinimum = minSmO.to1Decimal
        lineChartView.rightAxis.axisMaximum = maxSmO.to1Decimal
        lineChartView.data = LineChartData(dataSets: [set1, set6])
        tableLTTestHistory.reloadData()
    }
}

extension LTTestHistoryViewController: LTTestHistoryViewModelDelegate {
    func didUpdateState(to state: LTTestHistoryViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getLTTestHistoryListSuccess:
            refreshControl.endRefreshing()
            setChartData()
        }
    }
}

extension LTTestHistoryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.ltTestHistoryList.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        160
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "LTTestHistoryTableCell", for: indexPath) as? LTTestHistoryTableCell {
            cell.bindData(history: self.viewModel.ltTestHistoryList[indexPath.row])
            cell.delegate = self
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        // UITableView only moves in one direction, y axis
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height

        // Change 10.0 to adjust the distance from bottom
        if maximumOffset - currentOffset <= 10.0 {
            self.viewModel.loadMoreHistoryList()
        }
    }
}

extension LTTestHistoryViewController: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        months[Int(value) % months.count]
    }
}

extension LTTestHistoryViewController: LTTestHistoryTableCellDelegate {
    func detailItemClick(_ model: LTTestHistoryTempModel?) {
        if let model = model {
            let detailPage = LTTestRoutes.ltTestResult.screen as? LTTestResultViewController ?? LTTestResultViewController()
            detailPage.viewModel = LTTestResultViewModel()
            detailPage.viewModel.ltTestTemp = model
            detailPage.isJustFinishLTTest = false
            
            self.navigationController?.pushViewController(detailPage, animated: true)
        }
    }
}
