//
//  LTTestHistoryModel.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/22/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//
import Foundation

protocol LTTestHistoryViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: LTTestHistoryViewModelState)
}

enum LTTestHistoryViewModelState {
    case getLTTestHistoryListSuccess
    case network(state: NetworkState)
}

class LTTestHistoryViewModel {
    
    private var state: LTTestHistoryViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: LTTestHistoryViewModelDelegate?
    
    var page = 0
    var ltTestHistoryList: [LTTestHistoryTempModel] = []
    var totalPages = 0
    
    func loadMoreHistoryList() {
        if page >= 0 {
            page += 1
            getLTTestHistoryList()
        }
    }
    
    func getLTTestHistoryList() {
        state = .network(state: .loading)
        let limit = page == 0 ? 4 : 10
        LTTestServices.getLtTestHistory(
            page: page,
            limit: limit,
            success: { [weak self] res in
                guard let self = self else { return }
                if res.count < limit {
                    self.page = -1
                }
                self.state = .network(state: .hideLoading)
                self.ltTestHistoryList += res
                self.getLocalDB()
                // self.totalPages = res.totalPages ?? 0
            },
            failure: { [weak self] error in
                self?.getLocalDB()
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    private func getLocalDB() {
        if let list = RealmHelper.share.getAllLTTestInLocalDB(),
           list.isEmpty == false {
            for element in list {
                if self.ltTestHistoryList.first(where: {$0.id == element.id && $0.isFromLocal == true}) == nil {
                    let newElement = element.convertToLTTestHistoryTempModel()
                    self.ltTestHistoryList.append(newElement)
                }
            }
        }
        self.ltTestHistoryList = self.ltTestHistoryList.sorted(by: { element1, element2 in
            guard let dateStr1 = element1.date,
                  let dateStr2 = element2.date,
                  let date1 = Functions.convertDateStrToDateISO8601(dateStr: dateStr1),
                  let date2 = Functions.convertDateStrToDateISO8601(dateStr: dateStr2) else {
                return false
            }
            return date1 >= date2
        })
        if self.ltTestHistoryList.count > 4 {
            self.ltTestHistoryList = Array(ltTestHistoryList.prefix(4))
        }
        self.state = .getLTTestHistoryListSuccess
    }
}
