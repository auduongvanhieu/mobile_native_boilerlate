//
//  MainTabBarViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 10/28/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController, UITabBarControllerDelegate {
    
    var mainViewController: MainViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(changeLanguage), name: NotificationCenterHelper.MAIN_TAB_CHANGE_LANGUAGE, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(changeTab(_:)), name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil)
    }
    
    @objc func changeLanguage() {
        if let viewControllers = self.viewControllers {
            var newViewControllers: [UIViewController] = []
            viewControllers.forEach { (viewController) in
                if let baseViewController = viewController as? BaseViewController {
                    // Home & Me ViewController
                    let resultViewController = baseViewController.copySelfForChangeLanguage()
                    newViewControllers.append(resultViewController)
                } else if let navi = viewController as? UINavigationController {
                    // LT Test & Execise ViewController
                    var newNavi: UINavigationController?
                    navi.viewControllers.forEach { (controller) in
                        if let baseViewController = controller as? BaseViewController {
                            let resultViewController = baseViewController.copySelfForChangeLanguage()
                            if newNavi == nil {
                                newNavi = UINavigationController(rootViewController: resultViewController)
                            } else {
                                newNavi?.pushViewController(resultViewController, animated: false)
                            }
                        }
                    }
                    if let newNavi = newNavi {
                        newViewControllers.append(newNavi)
                    }
                }
            }
            self.viewControllers = newViewControllers
        }
    }
    
    @objc func changeTab(_ notification: NSNotification) {
        if let tab = notification.userInfo?[NotificationCenterHelper.TAB_DATA] as? Int {
            Functions.showLog(title: "changeTab", message: tab)
            self.selectedIndex = tab
            if tab == 3 {
                self.mainViewController?.topNavBar?.lblTitle.text = "ME"
                self.mainViewController?.topNavBar.btnBluetooth.isHidden = true
            } else if tab == 2 {
                self.mainViewController?.topNavBar?.lblTitle.text = "EXERCISE"
                self.mainViewController?.topNavBar.btnBluetooth.isHidden = false
            } else {
                self.mainViewController?.topNavBar?.lblTitle.text = nil
            }
        }
    }
    
    // called whenever a tab button is tapped
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        mainViewController?.setTitle(viewController.title ?? "")
        if viewController.isKind(of: MeViewController.self) == true {
            mainViewController?.hideBluetooth(true)
        } else {
            mainViewController?.hideBluetooth(false)
        }
        if self.selectedIndex != 1 {
            if let viewControllers = self.viewControllers, viewControllers.count > 1 {
                if let controller = viewControllers[1] as? UINavigationController {
                    if let firstController = controller.viewControllers.first as? TestViewController {
                        firstController.isOpenedSetting = false
                    }
                }
            }
        }
        if tabBarController.selectedIndex == 1 {
            Functions.showLog(title: "selectedIndex", message: 1)
            LocalDataManager.actionType = Constants.ACTION_LT_TEST
        }
        if tabBarController.selectedIndex == 2 {
            Functions.showLog(title: "selectedIndex", message: 2)
            LocalDataManager.actionType = Constants.ACTION_EXERCISE
            self.mainViewController?.topNavBar?.lblTitle.text = "EXERCISE"
            self.mainViewController?.topNavBar.btnBluetooth.isHidden = false
        }
    }
    
    // alternate method if you need the tab bar item
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        // ...
    }
    
    func setMainController(_ main: MainViewController) {
        self.mainViewController = main
    }
}
