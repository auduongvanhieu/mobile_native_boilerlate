import Foundation
import UIKit
import CoreBluetooth

class MainViewController: BaseViewController {
    
    @IBOutlet weak var topNavBar: TopNavBar!
    @IBOutlet weak var tabbarContainerView: UIView!
    @IBOutlet weak var sideMenuView: UIView!
    
    // Start Ble
    var centralManager: CBCentralManager!
    var transferCharacteristic: CBCharacteristic?
    var writeIterationsComplete = 0
    var connectionIterationsComplete = 0
    let defaultIterations = 5
    var data = Data()
    var peripheralScannedTemp: CBPeripheral?
    // End Ble
    
    // MARK: - Variables
    var initialPos: CGPoint?
    var touchPos: CGPoint?
    let blackTransparentViewTag = 02271994
    let closeButtonTag = 02271995
    var openFlag: Bool = false
    var viewModel: MainViewModel!
    var isRequestNotificationRight = false
    var isDiscoverConnectedDevice = false

    lazy var frontVC: UIViewController? = {
        let front = self.storyboard?.instantiateViewController(withIdentifier: "FrontTabbar")
        (front as? MainTabBarController)?.setMainController(self)
        return front
    }()
    
    lazy var rearVC: UIViewController? = {
        let rear = self.storyboard?.instantiateViewController(withIdentifier: "rearVC")
        return rear
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Start connect watch
        WorkoutTracking.shared.authorizeHealthKit()
        WorkoutTracking.shared.observerHeartRateSamples()
        WatchKitConnection.shared.delegate = self
        // End connect watch

        displayTabbar()
        setUpNotifications()
//        setUpGestures()
        checkNotificationPermission()
        topNavBar.setTitle("")
        
        // Start Ble
        if centralManager == nil {
            centralManager = CBCentralManager(delegate: self, queue: nil)
        }
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(bleStartScan), name: NotificationCenterHelper.BLE_START_SCAN_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(bleStopScan), name: NotificationCenterHelper.BLE_STOP_SCAN_ACTION, object: nil)
        
//        NotificationCenter.default.removeObserver(self, name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(bleConnectDevice(_:)), name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(disconnectDevice), name: NotificationCenterHelper.BLE_DISCONNECT_DEVICE_DATA, object: nil)
        // End Ble
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(resetMainViewController), name: NotificationCenterHelper.RESET_MAINVIEWCONTROLLER, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.getProfile()
        self.tabBarController?.viewControllers = [self]
    }
    
    func checkNotificationPermission() {
        if isRequestNotificationRight {
            let center = UNUserNotificationCenter.current()
            center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
                if granted == true {
                    Functions.showLog(title: "checkNotificationPermission", message: granted)
                }
                DispatchQueue.main.async {
                    AppDelegate.shared.setupPushNotification()
                }
            }
        }
    }
    
    func setTitle(_ title: String) { topNavBar.setTitle(title) }
    func hideBluetooth(_ isHide: Bool) { topNavBar.hideBluetoothButton(isHide) }
    
    func setUpNotifications() {
        let notificationOpenOrCloseSideMenu = Notification.Name("notificationOpenOrCloseSideMenu")
        NotificationCenter.default.addObserver(self, selector: #selector(openOrCloseSideMenu), name: notificationOpenOrCloseSideMenu, object: nil)
        
        let notificationCloseSideMenu = Notification.Name("notificationCloseSideMenu")
        NotificationCenter.default.addObserver(self, selector: #selector(closeSideMenu), name: notificationCloseSideMenu, object: nil)
        
        let closeSideMenuWithoutAnimation = Notification.Name("notificationCloseSideMenuWithoutAnimation")
        NotificationCenter.default.addObserver(self, selector: #selector(closeWithoutAnimation), name: closeSideMenuWithoutAnimation, object: nil)
    }
    
    func setUpGestures() {
        let panGestureContainerView = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(panGesture:)))
        self.view.addGestureRecognizer(panGestureContainerView)
    }
    
    func displayTabbar() {
        // To display Tabbar in TabbarContainerView
        if let frontVc = frontVC {
            self.addChild(frontVc)
            frontVc.didMove(toParent: self)
            
            frontVc.view.frame = self.tabbarContainerView.bounds
            self.tabbarContainerView.insertSubview(frontVc.view, at: 0)
        }
    }
    
    func displaySideMenu() {
        if let rearVC = rearVC, !self.children.contains(rearVC) {
            self.addChild(rearVC)
            rearVC.didMove(toParent: self)
            
            rearVC.view.frame = self.sideMenuView.bounds
            self.sideMenuView.addSubview(rearVC.view)
            // topNavBar.setSideMenuOpen(true)
        }
    }
    
    func addBlackTransparentView() -> UIView {
        // Black Shadow on MainView(i.e on TabBarController) when side menu is opened.
        if let blackView = self.tabbarContainerView.viewWithTag(blackTransparentViewTag) {
            return blackView
        } else {
            let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
            let blurEffectView = UIVisualEffectView(effect: blurEffect)
            blurEffectView.frame = self.tabbarContainerView.bounds
            // blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            blurEffectView.tag = blackTransparentViewTag
            blurEffectView.alpha = 0
            blurEffectView.backgroundColor = UIColor.black
            let recognizer = UITapGestureRecognizer(target: self, action: #selector(closeSideMenu))
            blurEffectView.addGestureRecognizer(recognizer)
            return blurEffectView
        }
    }
    
    func addCloseButton() -> UIView {
        // Add close button
        if let closeButton = self.tabbarContainerView.viewWithTag(closeButtonTag) {
            return closeButton
        } else {
            let closeButton = UIButton(frame: CGRect(x: 18, y: 40, width: 30, height: 30))
            closeButton.setImage(#imageLiteral(resourceName: "ic_close"), for: UIButton.State.normal)
            closeButton.addTarget(self, action: #selector(closeSideMenu), for: .touchUpInside)
            closeButton.tag = closeButtonTag
            closeButton.alpha = 1
            // closeButton.backgroundColor = #colorLiteral(red: 0.1565435827, green: 0.1672128439, blue: 0.2882431746, alpha: 1)
            return closeButton
        }
    }
    
    // MARK: - Selector Methods
    @objc func openOrCloseSideMenu() {
        // Opens or Closes Side Menu On Click of Button
        if openFlag {
            // This closes Rear View
            let blackTransparentView = self.view.viewWithTag(self.blackTransparentViewTag)
            let closeButton = self.view.viewWithTag(self.closeButtonTag)
            UIView.animate(withDuration: 0.3, animations: {
                self.tabbarContainerView.frame = CGRect(x: 0, y: 0, width: self.tabbarContainerView.frame.size.width, height: self.tabbarContainerView.frame.size.height)
                blackTransparentView?.alpha = 0
                closeButton?.alpha = 0
                self.topNavBar.alpha = 1
            }, completion: { _ in
                blackTransparentView?.removeFromSuperview()
                self.openFlag = false
                self.isDiscoverConnectedDevice = false
            })
        } else {
            // This opens Rear View
            UIView.animate(withDuration: 0.0, animations: {
                self.displaySideMenu()
                let blackTransparentView = self.addBlackTransparentView()
                let closeButton = self.addCloseButton()
                self.tabbarContainerView.addSubview(blackTransparentView)
                self.tabbarContainerView.addSubview(closeButton)
            }, completion: { _ in
                UIView.animate(withDuration: 0.3, animations: {
                    self.addCloseButton().alpha = 1
                    self.topNavBar.alpha = 0
                    self.addBlackTransparentView().alpha = self.view.bounds.width * 0.8 / (self.view.bounds.width * 1.8)
                    self.tabbarContainerView.frame = CGRect(x: self.tabbarContainerView.bounds.size.width * 0.8, y: 0, width: self.tabbarContainerView.frame.size.width, height: self.tabbarContainerView.frame.size.height)
                }, completion: { (_) in
                    self.openFlag = true
                })
            })
        }
    }
    
    @objc func closeSideMenu() {
        // To close Side Menu
        let blackTransparentView = self.view.viewWithTag(self.blackTransparentViewTag)
        let closeButton = self.view.viewWithTag(self.closeButtonTag)
        UIView.animate(withDuration: 0.3, animations: {
            self.tabbarContainerView.frame = CGRect(x: 0, y: 0, width: self.tabbarContainerView.frame.size.width, height: self.tabbarContainerView.frame.size.height)
            blackTransparentView?.alpha = 0.0
            closeButton?.alpha = 0.0
            self.topNavBar.alpha = 1
        }, completion: { (_) in
            blackTransparentView?.removeFromSuperview()
            self.openFlag = false
            self.isDiscoverConnectedDevice = false
        })
    }
    
    @objc func resetMainViewController() {
        didLogoutApp()
    }
    
    @objc func closeWithoutAnimation() {
        // To close Side Menu without animation
        let blackTransparentView = self.view.viewWithTag(self.blackTransparentViewTag)
        let closeButton = self.view.viewWithTag(self.closeButtonTag)
        blackTransparentView?.alpha = 0
        blackTransparentView?.removeFromSuperview()
        closeButton?.alpha = 0
        closeButton?.removeFromSuperview()
        self.tabbarContainerView.frame = CGRect(x: 0, y: 0, width: self.tabbarContainerView.frame.size.width, height: self.tabbarContainerView.frame.size.height)
        self.openFlag = false
    }
    
    // MARK: - Pan Gesture
    @objc func handlePanGesture(panGesture: UIPanGestureRecognizer) {
        // For Pan Gesture
        touchPos = panGesture.location(in: self.view)
        let translation = panGesture.translation(in: self.view)
        // Add BlackShadowView
        let blackTransparentView = self.addBlackTransparentView()
        let closeButton = self.addCloseButton()
        self.tabbarContainerView.addSubview(blackTransparentView)
        self.tabbarContainerView.addSubview(closeButton)
        
        if panGesture.state == .began {
            initialPos = touchPos
        } else if panGesture.state == .changed {
            let touchPosition = self.view.bounds.width * 0.8
            if (initialPos?.x) ?? 0 > touchPosition && openFlag {
                // To Close Rear View
                if self.tabbarContainerView.frame.minX > 0 {
                    self.tabbarContainerView.center = CGPoint(x: self.tabbarContainerView.center.x + translation.x, y: self.tabbarContainerView.bounds.midY)
                    panGesture.setTranslation(CGPoint.zero, in: self.view)
                    blackTransparentView.alpha = self.tabbarContainerView.frame.minX / (self.view.bounds.width * 1.8)
                    closeButton.alpha = 1
                    topNavBar.alpha = 0
                }
            } else if !openFlag {
                // To Open Rear View
                if translation.x > 0.0 {
                    displaySideMenu()
                    self.tabbarContainerView.center = CGPoint(x: translation.x + self.tabbarContainerView.center.x, y: self.tabbarContainerView.bounds.midY)
                    panGesture.setTranslation(CGPoint.zero, in: self.view)
                    blackTransparentView.alpha = self.tabbarContainerView.frame.minX / (self.view.bounds.width * 1.8)
                    closeButton.alpha = 1
                    topNavBar.alpha = 0
                }
            }
        } else if panGesture.state == .ended {
            if self.tabbarContainerView.frame.minX > self.view.frame.midX {
                // Opens Rear View
                UIView.animate(withDuration: 0.2, animations: {
                    self.tabbarContainerView.frame = CGRect(x: self.view.frame.width * 0.8, y: 0, width: self.tabbarContainerView.bounds.width, height: self.tabbarContainerView.bounds.height)
                    blackTransparentView.alpha = self.tabbarContainerView.frame.minX / (self.view.bounds.width * 1.8)
                }, completion: { (_) in
                    self.openFlag = true
                })
            } else {
                // Closes Rear View
                UIView.animate(withDuration: 0.2, animations: {
                    self.tabbarContainerView.center = CGPoint(x: self.view.center.x, y: self.tabbarContainerView.bounds.midY)
                    blackTransparentView.alpha = 0
                    closeButton.alpha = 0
                    self.topNavBar.alpha = 1
                }, completion: { (_) in
                    blackTransparentView.removeFromSuperview()
                    self.openFlag = false
                })
            }
        }
    }
    
    func didLogoutApp() {
        BluetoothHelper.peripheral = nil
        BluetoothHelper.isConnectedDevice = false
        cleanup()
        centralManager = nil
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_START_SCAN_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_STOP_SCAN_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.BLE_DISCONNECT_DEVICE_DATA, object: nil)
        NotificationCenterHelper.nc.removeObserver(self, name: NotificationCenterHelper.RESET_MAINVIEWCONTROLLER, object: nil)
        let notificationOpenOrCloseSideMenu = Notification.Name("notificationOpenOrCloseSideMenu")
        NotificationCenter.default.removeObserver(self, name: notificationOpenOrCloseSideMenu, object: nil)
        let notificationCloseSideMenu = Notification.Name("notificationCloseSideMenu")
        NotificationCenter.default.removeObserver(self, name: notificationCloseSideMenu, object: nil)
        let closeSideMenuWithoutAnimation = Notification.Name("notificationCloseSideMenuWithoutAnimation")
        NotificationCenter.default.removeObserver(self, name: closeSideMenuWithoutAnimation, object: nil)
    }
}

extension MainViewController: CBCentralManagerDelegate {
    @objc func bleStartScan() {
        // self.centralManager = CBCentralManager(delegate: self, queue: nil)
        peripheralScannedTemp = nil
        self.centralManager?.scanForPeripherals(withServices: nil)
        Functions.showLog(title: "BLE -> ", message: "bleStartScan")
    }
    
    @objc func bleStopScan() {
        self.centralManager?.stopScan()
        Functions.showLog(title: "BLE -> ", message: "bleStopScan")
    }
    
    @objc func bleConnectDevice(_ notification: NSNotification) {
        cleanup()
        if let peripheral = notification.userInfo?[NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA] as? CBPeripheral {
            self.centralManager?.connect(peripheral)
        }
        Functions.showLog(title: "BLE -> ", message: "bleConnectDevice")
    }
    
    func retrievePeripheral() {
        let connectedPeripherals: [CBPeripheral] = (centralManager.retrieveConnectedPeripherals(withServices: [BluetoothHelper.SERVICE_UUID]))
        Functions.showLog(title: "BLE -> ", message: "Found connected Peripherals with transfer service: \(connectedPeripherals)")
        if let connectedPeripheral = connectedPeripherals.last {
            self.centralManager?.connect(connectedPeripheral)
        } else {
            centralManager.scanForPeripherals(withServices: [BluetoothHelper.SERVICE_UUID],
                                              options: [CBCentralManagerScanOptionAllowDuplicatesKey: true])
        }
    }
    
    @objc func disconnectDevice() {
        Functions.showLog(title: "disconnectDevice self = \(self)", message: "")
        LocalDataManager.lastConnectedBleDeviceId = ""
        cleanup()
    }
    
    private func cleanup() {
        // Don't do anything if we're not connected
        guard let discoveredPeripheral = BluetoothHelper.peripheral,
              (discoveredPeripheral.state == .connected || discoveredPeripheral.state == .disconnecting) else { return }
        for service in (discoveredPeripheral.services ?? [] as [CBService]) {
            for characteristic in (service.characteristics ?? [] as [CBCharacteristic]) {
                if characteristic.uuid == BluetoothHelper.WRITE_UUID && characteristic.isNotifying {
                    // It is notifying, so unsubscribe
                    BluetoothHelper.peripheral?.setNotifyValue(false, for: characteristic)
                }
            }
        }
        // If we've gotten this far, we're connected, but we're not subscribed, so we just disconnect
        centralManager.cancelPeripheralConnection(discoveredPeripheral)
    }
    
    private func writeData() {
        guard let discoveredPeripheral = BluetoothHelper.peripheral, let transferCharacteristic = transferCharacteristic else { return }
        // check to see if number of iterations completed and peripheral can accept more data
        while writeIterationsComplete < defaultIterations && discoveredPeripheral.canSendWriteWithoutResponse {
            let mtu = discoveredPeripheral.maximumWriteValueLength(for: .withoutResponse)
            var rawPacket = [UInt8]()
            let bytesToCopy: size_t = min(mtu, data.count)
            data.copyBytes(to: &rawPacket, count: bytesToCopy)
            let packetData = Data(bytes: &rawPacket, count: bytesToCopy)
//            let stringFromData = String(data: packetData, encoding: .utf8)
            discoveredPeripheral.writeValue(packetData, for: transferCharacteristic, type: .withoutResponse)
            writeIterationsComplete += 1
        }
        if writeIterationsComplete == defaultIterations {
            // Cancel our subscription to the characteristic
            discoveredPeripheral.setNotifyValue(false, for: transferCharacteristic)
        }
    }
    
    // centralManagerDidUpdateState is a required protocol method.
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch central.state {
        case .poweredOff:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "poweredOff")
            BluetoothHelper.isConnectedDevice = false
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
            FileHelper.writeStringToLogFile(title: Constants.POWERED_OFF, content: Constants.DEVICE_CONNECTED)
        case .poweredOn:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "poweredOn")
            centralManager?.scanForPeripherals(withServices: nil)
            retrievePeripheral()
        case .unsupported:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "unsupported")
            FileHelper.writeStringToLogFile(title: "unsupported", content: "")
        case .unauthorized:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "unauthorized")
            FileHelper.writeStringToLogFile(title: "unauthorized", content: "")
        case .unknown:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "unknown")
            FileHelper.writeStringToLogFile(title: "unknown", content: "")
        case .resetting:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "resetting")
            FileHelper.writeStringToLogFile(title: "resetting", content: "")
        @unknown default:
            Functions.showLog(title: "BLE -> centralManagerDidUpdateState", message: "error")
            FileHelper.writeStringToLogFile(title: "central.state", content: central.state.rawValue.description)
        }
    }
    
    //  This callback comes whenever a peripheral that is advertising the transfer serviceUUID is discovered
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        // Device is in range - have we already seen it?
        if peripheral.name != nil && peripheral.identifier.description != peripheralScannedTemp?.identifier.description {
            // Set peripheral to filter dupble
            peripheralScannedTemp = peripheral
            // And finally, connect to the peripheral.
            Functions.showLog(title: "BLE -> ", message: "Scanned perhiperal \(peripheral)")
            // centralManager.connect(peripheral, options: nil)
            if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
                self.centralManager?.stopScan()
            }
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_SCANNED_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_SCANNED_DATA: peripheral])
            if BluetoothHelper.isCurrentParingPage == false && peripheral.identifier.description == LocalDataManager.lastConnectedBleDeviceId {
                if openFlag {
                    isDiscoverConnectedDevice = true
                }
                Functions.showLog(title: "BLE -> ", message: "Scanned perhiperal connected \(peripheral.identifier.description)")
                self.centralManager?.connect(peripheral)
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        if openFlag && isDiscoverConnectedDevice {
            self.tabbarContainerView.frame = CGRect(x: self.tabbarContainerView.bounds.size.width * 0.8, y: 0, width: self.tabbarContainerView.frame.size.width, height: self.tabbarContainerView.frame.size.height)
        }
    }
    
    // If the connection fails for whatever reason, we need to deal with it.
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        Functions.showLog(title: "BLE -> ", message: "Failed to connect to \(peripheral). \(String(describing: error))")
        cleanup()
    }
    
    // Connected device
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        Functions.showLog(title: "BLE -> Connected device", message: peripheral)
        BluetoothHelper.isConnectedDevice = true
        BluetoothHelper.peripheral = peripheral
        FileHelper.writeStringToLogFile(title: Constants.DEVICE_CONNECTED, content: BluetoothHelper.getDeviceInfoStr(peripheral: peripheral))
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        // Stop scanning
        centralManager.stopScan()
        // set iteration info
        connectionIterationsComplete += 1
        writeIterationsComplete = 0
        // Clear the data that we may already have
        data.removeAll(keepingCapacity: false)
        // Make sure we get the discovery callbacks
        peripheral.delegate = self
        // Search only for services that match our UUID
        peripheral.discoverServices([BluetoothHelper.SERVICE_UUID, BluetoothHelper.WRITE_UUID, BluetoothHelper.NOTIFY_UUID])
        // Save device connected to local
        LocalDataManager.lastConnectedBleDeviceId = peripheral.identifier.description
    }
    
    // Disconnected device
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        Functions.showLog(title: "BLE -> ", message: "Perhiperal Disconnected")
        BluetoothHelper.peripheral = nil
        BluetoothHelper.isConnectedDevice = false
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        FileHelper.writeStringToLogFile(title: Constants.DEVICE_DISCONNECTED, content: "")
        if BluetoothHelper.isCurrentParingPage == false {
            if openFlag {
                openOrCloseSideMenu()
            }
            BluetoothHelper.showDisconnectedDeviceAlert(fromViewController: self)
            // We're disconnected, so start scanning again
            if connectionIterationsComplete < defaultIterations {
                retrievePeripheral()
            } else {
                Functions.showLog(title: "BLE -> ", message: "Connection iterations completed")
            }
            // force connect
            if BluetoothHelper.isExerciseProcessing == true {
                let uuid = peripheral.identifier
                let arrPer = central.retrievePeripherals(withIdentifiers: [uuid])
                if let per = arrPer.first {
                    central.connect(per, options: nil)
                }
            }
        }
    }
}

extension MainViewController: CBPeripheralDelegate {
    // The peripheral letting us know when services have been invalidated.
    func peripheral(_ peripheral: CBPeripheral, didModifyServices invalidatedServices: [CBService]) {
        for service in invalidatedServices where service.uuid == BluetoothHelper.SERVICE_UUID {
            Functions.showLog(title: "BLE -> ", message: "Transfer service is invalidated - rediscover services")
            peripheral.discoverServices([BluetoothHelper.SERVICE_UUID])
        }
    }
    
    // The Transfer Service was discovered
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { return }
        Functions.showLog(title: "BLE -> discoverServiceError", message: error.debugDescription)
        FileHelper.writeStringToLogFile(title: Constants.DISCOVER_SERVICE_ERROR, content: error.debugDescription)
        for service in services {
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    // The Transfer characteristic was discovered.
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        Functions.showLog(title: "BLE -> discoverServiceSuccess", message: "")
        guard let characteristics = service.characteristics else { return }
        for characteristic in characteristics {
            Functions.showLog(title: "BLE ->characteristic", message: characteristic)
            FileHelper.writeStringToLogFile(title: Constants.CHARACTERISTIC, content: "\(characteristic.uuid)")
            FileHelper.writeStringToLogFile(title: Constants.CHARACTERISTIC_PROPERTY, content: "\(characteristic.properties.rawValue.description)")
            if characteristic.properties.contains(.read) {
                Functions.showLog(title: "BLE -> characteristic.properties", message: "\(characteristic.uuid): properties contains .read")
                peripheral.readValue(for: characteristic)
            }
            if characteristic.properties.contains(.write) {
                Functions.showLog(title: "BLE -> characteristic.properties", message: "\(characteristic.uuid): properties contains .write")
                BluetoothHelper.characteristic = characteristic
            }
            if characteristic.properties.contains(.notify) {
                Functions.showLog(title: "BLE -> characteristic.properties", message: "\(characteristic.uuid): properties contains .notify")
                peripheral.setNotifyValue(true, for: characteristic)
            }
        }
        BluetoothHelper.restoreConnectDevice(fromViewController: self)
    }
    
    // This callback lets us know more data has arrived via notification on the characteristic
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        if BluetoothHelper.isConnectedDevice == true {
            guard let characteristicData = characteristic.value else { return }
            let byteArrayData = [UInt8](characteristicData)
            BluetoothHelper.checkRepaceData(byteArrayData: byteArrayData)
        } else if BluetoothHelper.isCurrentParingPage == true {
            cleanup()
        }
    }
    
    // The peripheral letting us know whether our subscribe/unsubscribe happened or not
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        // Deal with errors (if any)
        if let error = error {
            Functions.showLog(title: "BLE -> ", message: "Error changing notification state: \(error.localizedDescription)")
            return
        }
        // Exit if it's not the transfer characteristic
        guard characteristic.uuid == BluetoothHelper.WRITE_UUID else { return }
        if characteristic.isNotifying {
            // Notification has started
            Functions.showLog(title: "BLE -> ", message: "Notification began on  \(characteristic)")
        } else {
            // Notification has stopped, so disconnect from the peripheral
            Functions.showLog(title: "BLE -> ", message: "Notification stopped on \(characteristic). Disconnecting")
            cleanup()
        }
    }
    
    // This is called when peripheral is ready to accept more data when using write without response
    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        Functions.showLog(title: "BLE -> ", message: "Peripheral is ready, send data")
        writeData()
    }
}
extension MainViewController: WatchKitConnectionDelegate {
    func didFinishedActiveSession() {
        WatchKitConnection.shared.sendMessage(message: ["username": "nhathm" as AnyObject])
    }
    func getNewHeartRate(heartrate: Double) {
        // Functions.showLog(title: "HR -> Heart Rate Value", message: heartrate)
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.HR_RECEIVE_HEART_RATE_ACTION, object: nil, userInfo: [NotificationCenterHelper.HR_HEART_RATE_DATA: heartrate])
        if LocalDataManager.isSaveSmo2List == true && BluetoothHelper.isExerciseProcessing == true {
//            LocalDataManager.ltTestHRList.append(heartrate)
            RealmHelper.share.saveHeartrate(heartrate: heartrate, period: nil)
        }
    }
}
