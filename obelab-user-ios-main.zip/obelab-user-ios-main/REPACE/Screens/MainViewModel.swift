import Foundation

protocol MainViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: MainViewModelState)
}

enum MainViewModelState {
    case network(state: NetworkState)
}

class MainViewModel {
    
    private var state: MainViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: MainViewModelDelegate?
        
    func getProfile() {
        state = .network(state: .loading)
        UserServices.getMyProfile(
            success: { [weak self] _ in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
