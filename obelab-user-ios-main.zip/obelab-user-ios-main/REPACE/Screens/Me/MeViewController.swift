import Foundation
import UIKit
class MeViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var birthdayLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var heightLabel: UILabel!
    @IBOutlet weak var weightLabel: UILabel!
    @IBOutlet weak var versionLabel: UILabel!
    
    var viewModel = MeViewModel()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        if let controller = R.storyboard.main.meViewController() {
            return controller
        }
        return UIViewController()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.getData()
//        viewModel.getMemberSetting()
    }
    
    func setUpView() {
        // Content view
        topView.layer.cornerRadius = UI.View.radius
        bottomView.layer.cornerRadius = UI.View.radius
        // Avatar
        avatarImageView.layer.cornerRadius = avatarImageView.frame.width / 2
        // App version
        guard let versionName = Bundle.main.object(forInfoDictionaryKey: Constants.CFBundleShortVersionString) as? String else {
            return
        }
        versionLabel.text = "Ver \(versionName)"
    }
    
    func setUpProfile() {
        let profile = viewModel.profile
        if let avatarUrl = URL(string: profile?.avatar ?? Constants.AVATAR_DEFAULT) {
            avatarImageView.load(url: avatarUrl)
        }
        usernameLabel.text = profile?.nickname
        emailLabel.text = profile?.email
        birthdayLabel.text = Functions.convertDateStrToProfileDateStr(dateStr: profile?.birthday ?? Constants.DATE_DEFAULT)
        genderLabel.text = profile?.gender?.localized
        
       
        var height = Functions.getImperialHeightValue(cm: profile?.height)
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            height = "\(Functions.getHeightUnitValue(height: profile?.height ?? 0.0)) \(Functions.getHeightUnitName())"
        }
        if profile?.height != nil {
            heightLabel.text = height
        }
        if profile?.weight != nil {
            weightLabel.text = "\(Functions.getWeightUnitValue(weight: profile?.weight ?? 0.0)) \(Functions.getWeightUnitName())"
        }
    }
    
    @IBAction func onGoToProfileSetting(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.profileSetting, with: .push)
    }
    
    @IBAction func onGoToNotificationSetting(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.notificationSetting, with: .push)
    }
    
    @IBAction func onGoToNarrationGuide(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.narrationGuide, with: .push)
    }
    
    @IBAction func onGoToPreference(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.preference(memberSetting: nil, isDidSignup: true, target: nil), with: .push)
    }
    
    @IBAction func onGoToNotices(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.notices, with: .push)
    }
    
    @IBAction func onGoTotermOfUse(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.TERM), with: .push)
    }
    
    @IBAction func onGoToPrivacyPolicy(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.POLICY), with: .push)
    }
    
    @IBAction func onGoToHelp(_ sender: Any) {
        AppNavigator.shared.navigate(to: SettingRoutes.help, with: .push)
    }
}

extension MeViewController: MeViewModelDelegate {
    func didUpdateState(to state: MeViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMemberSettingSuccess:
            setUpProfile()
        }
    }
}
