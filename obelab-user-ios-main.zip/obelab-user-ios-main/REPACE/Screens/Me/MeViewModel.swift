import Foundation

protocol MeViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: MeViewModelState)
}

enum MeViewModelState {
    case getMemberSettingSuccess
    case network(state: NetworkState)
}

class MeViewModel {
    
    private var state: MeViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: MeViewModelDelegate?
    
    var profile = LocalDataManager.profile
    
    func getData() {
        state = .network(state: .loading)
        getProfile {
            self.getMemberSetting()
        }
    }
    
    func getMemberSetting() {
        UserServices.getMemberSetting(
            success: { [weak self] _ in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .getMemberSettingSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getMemberSettingError", message: error)
            })
    }
    
    func getProfile(completion: (() -> Void)?) {
        UserServices.getMyProfile(
            success: { [weak self] _ in
                guard let self = self else { return }
                self.profile = LocalDataManager.profile
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
