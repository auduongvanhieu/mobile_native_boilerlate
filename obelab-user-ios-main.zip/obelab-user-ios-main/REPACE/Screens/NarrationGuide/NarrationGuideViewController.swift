import Foundation
import UIKit

class NarrationGuideViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var guideButton: UIButton!
    
    var viewModel: NarrationGuideViewModel!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        viewModel.getMemberSetting()
    }
    
    func setUpView() {

    }
    
    @IBAction func onClickGuideSwitch(_ sender: Any) {
        if viewModel.memberSetting.guide == 0 {
            viewModel.memberSetting.guide = 1
        } else {
            viewModel.memberSetting.guide = 0
        }
        setUpSwitchButton()
        viewModel.updateNarrationGuide()
    }
    
    func setUpSwitchButton() {
        let imageOn = UIImage(named: "ic_switch_on.png")
        let imageOff = UIImage(named: "ic_switch_off.png")
        if viewModel.memberSetting.guide == 1 {
            guideButton.setBackgroundImage(imageOn, for: .normal)
        } else {
            guideButton.setBackgroundImage(imageOff, for: .normal)
        }
    }
}

extension NarrationGuideViewController: NarrationGuideViewModelDelegate {
    func didUpdateState(to state: NarrationGuideViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMemberSettingSuccess:
            setUpSwitchButton()
        }
    }
}
