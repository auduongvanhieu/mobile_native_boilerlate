import Foundation

protocol NarrationGuideViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: NarrationGuideViewModelState)
}

enum NarrationGuideViewModelState {
    case getMemberSettingSuccess
    case network(state: NetworkState)
}

class NarrationGuideViewModel {
    
    private var state: NarrationGuideViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: NarrationGuideViewModelDelegate?
    
    var memberSetting = MemberSetting()
    
    func getMemberSetting() {
        state = .network(state: .loading)
        UserServices.getMemberSetting(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.memberSetting = res
                self.state = .getMemberSettingSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getMemberSettingError", message: error)
            })
    }
    
    func updateNarrationGuide() {
        state = .network(state: .loading)
        LocalDataManager.volumeTurnOn = (memberSetting.guide ?? 0) == 1
        UserServices.updateMemberSetting(memberSetting: memberSetting,
            success: { [weak self] res in
                guard self != nil else { return }
                self?.state = .network(state: .hideLoading)
                Functions.showLog(title: "updateNarrationGuideSuccess", message: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "updateNarrationGuideError", message: error)
            })
    }
}
