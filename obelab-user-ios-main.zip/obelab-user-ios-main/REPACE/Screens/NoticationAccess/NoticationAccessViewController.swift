import Foundation
import UIKit
import UserNotifications

class NoticationAccessViewController: BaseViewController {
    
    @IBOutlet weak var allowButton: UIButton!
    
    var viewModel: NotificationAccessViewModel!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
    }
    
    func setUpView() {
        // Button
        allowButton.setRoundBorders(UI.Button.cornerRadius)
    }
    
    func registerForRemoteNotification() {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.sound, .alert, .badge]) { (granted, error) in
            Functions.showLog(title: "registerForRemoteNotificationsSuccess", message: granted)
            if granted == false {
                Functions.showLog(title: "registerForRemoteNotificationsError", message: error as Any)
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            } else {
                DispatchQueue.main.async {
                    self.viewModel.updateNotificationSetting()
                }
            }
        }
    }
    
    @IBAction func onClickAllow(_ sender: Any) {
        registerForRemoteNotification()
    }
    
    @IBAction func onClickLater(_ sender: Any) {
        AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: true), with: .reset)
    }
}

extension NoticationAccessViewController: NotificationAccessViewModelDelegate {
    func didUpdateState(to state: NotificationAccessViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .updateNotificationSettingSuccess:
            AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: false), with: .reset)
        case .updateNotificationSettingFail(message: let message):
            showToast(message: message)
        }
    }
}
