import Foundation

protocol NotificationAccessViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: NotificationAccessViewModelState)
}

enum NotificationAccessViewModelState {
    case updateNotificationSettingSuccess
    case updateNotificationSettingFail(message: String)
    case network(state: NetworkState)
}

class NotificationAccessViewModel {
    
    private var state: NotificationAccessViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: NotificationAccessViewModelDelegate?
    
    func showLoading() {
        state = .network(state: .loading)
    }
    
    func updateNotificationSetting() {
        state = .network(state: .loading)
        UserServices.updateNotificationSetting(pushNotice: 1, mailNotice: 1,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .updateNotificationSettingSuccess
                } else {
                    self.state = .updateNotificationSettingFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}

