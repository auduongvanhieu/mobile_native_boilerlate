import Foundation
import UIKit

class NoticeDetailViewController: BaseViewController, UIWebViewDelegate, UIScrollViewDelegate {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var contentTextview: UITextView!
    
    var noticeModel = NoticeModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
        setUpData()
    }
    
    func setUpView() {
        // Content
        contentTextview.layer.cornerRadius = UI.View.radius
        contentTextview.textContainerInset = UIEdgeInsets(top: UI.View.paddingText, left: UI.View.paddingText, bottom: UI.View.paddingText, right: UI.View.paddingText)
    }
    
    func setUpData() {
        titleLabel.text = noticeModel.title
        dateLabel.text = Functions.convertSqlDateToNoticeDateStr(sqlDate: noticeModel.updatedAt ?? Constants.SQL_DATE_DEFAULT)
        let htmlContent = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no'></head><body text=\"#FFFFFF\"  style='padding:16px;'>\(noticeModel.htmlContent ?? "")</body></html>"
        Functions.showLog(title: "htmlContent", message: htmlContent)
        contentTextview.text = htmlContent.htmlToString
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [self] in
            for constraint in self.contentView.constraints where constraint.identifier == "contentViewConstraint" {
                constraint.constant = titleLabel.layer.frame.height + contentTextview.layer.frame.height + 80
            }
//            for constraint in contentView.constraints {
//                if constraint.identifier == "contentViewConstraint" {
//                    constraint.constant = titleLabel.layer.frame.height + contentTextview.layer.frame.height + 80
//                }
//            }
            contentView.layoutIfNeeded()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.contentOffset.x > 0 {
            scrollView.contentOffset = CGPoint(x: 0, y: scrollView.contentOffset.y)
        }
    }
}
