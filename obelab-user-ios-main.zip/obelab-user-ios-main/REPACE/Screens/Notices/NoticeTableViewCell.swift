//
//  NoticeTableViewCell.swift
//  REPACE
//
//  Created by Van Huy Pham on 11/2/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import UIKit

class NoticeTableViewCell: UITableViewCell {

    @IBOutlet weak var tvTitle: UILabel!
    @IBOutlet weak var tvUpdateDt: UILabel!
    override func awakeFromNib() {
       super.awakeFromNib()
    }
    
    func bindData(notice: NoticeModel) {
        self.tvTitle.text = notice.title
        self.tvTitle.sizeToFit()
        self.tvUpdateDt.text = Functions.convertSqlDateToNoticeDateStr(sqlDate: notice.updatedAt ?? Constants.SQL_DATE_DEFAULT)
        self.contentView.sizeToFit()
    }
}
