import Foundation
import UIKit

class NoticesViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableNotices: UITableView!
    
    var viewModel: NoticesViewModel!
    let refreshControl = UIRefreshControl()
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setupTableView()
        onRefresh()
    }
    
    func setupTableView() {
        // delegate & datasouce
        tableNotices.delegate = self
        tableNotices.dataSource = self
        // Add Refresh Control to Table View
        if #available(iOS 10.0, *) {
            tableNotices.refreshControl = refreshControl
        } else {
            tableNotices.addSubview(refreshControl)
        }
        // Configure Refresh Control
        refreshControl.addTarget(self, action: #selector(onRefreshData(_:)), for: .valueChanged)
    }
    
    @objc private func onRefreshData(_ sender: Any) {
        onRefresh()
    }
    
    func onRefresh() {
        viewModel.noticeList.removeAll()
        viewModel.page = 0
        viewModel.getNoticeList()
    }
    
    func onLoadMore() {
        viewModel.page += 1
        viewModel.getNoticeList()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.noticeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Check if the last row number is the same as the last current data element
        if indexPath.row == self.viewModel.noticeList.count - 1 && self.viewModel.page < self.viewModel.totalPages {
            self.onLoadMore()
        }
        if let cell = tableView.dequeueReusableCell(withIdentifier: "noticeCellId", for: indexPath) as? NoticeTableViewCell {
            cell.bindData(notice: self.viewModel.noticeList[indexPath.row])
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        AppNavigator.shared.navigate(to: SettingRoutes.noticeDetail(noticeModel: self.viewModel.noticeList[indexPath.row]), with: .push)
    }
}

extension NoticesViewController: NoticesViewModelDelegate {
    func didUpdateState(to state: NoticesViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getNoticeListSuccess:
            refreshControl.endRefreshing()
            tableNotices.reloadData()
        }
    }
}
