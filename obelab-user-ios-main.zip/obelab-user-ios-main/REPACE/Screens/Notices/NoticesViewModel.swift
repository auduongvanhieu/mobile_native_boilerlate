import Foundation

protocol NoticesViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: NoticesViewModelState)
}

enum NoticesViewModelState {
    case getNoticeListSuccess
    case network(state: NetworkState)
}

class NoticesViewModel {
    
    private var state: NoticesViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: NoticesViewModelDelegate?
    
    var page = 0
    var noticeList: [NoticeModel] = []
    var totalPages = 0
    func getNoticeList() {
        state = .network(state: .loading)
        UserServices.getNoticeList(
            page: page,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.noticeList += res.data ?? []
                self.totalPages = res.totalPages ?? 0
                self.state = .getNoticeListSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}

