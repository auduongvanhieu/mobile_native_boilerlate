import Foundation
import UIKit

class NotificationSettingViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var row1ContentTextView: UITextView!
    @IBOutlet weak var row2ContentTextView: UITextView!
    @IBOutlet weak var pushButton: UIButton!
    @IBOutlet weak var emailButton: UIButton!
    
    var viewModel: NotificationSettingViewModel!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        viewModel.getMemberSetting()
    }
    
    func setUpView() {
        // Content
        row1ContentTextView.layer.cornerRadius = UI.View.radius
        row2ContentTextView.layer.cornerRadius = UI.View.radius
        row1ContentTextView.textContainerInset = UIEdgeInsets(top: UI.View.paddingText, left: UI.View.paddingText, bottom: UI.View.paddingText, right: UI.View.paddingText)
        row2ContentTextView.textContainerInset = UIEdgeInsets(top: UI.View.paddingText, left: UI.View.paddingText, bottom: UI.View.paddingText, right: UI.View.paddingText)
    }
    
    @IBAction func onClickPushSwitch(_ sender: Any) {
        if viewModel.memberSetting.pushNotice == 0 {
            viewModel.memberSetting.pushNotice = 1
        } else {
            viewModel.memberSetting.pushNotice = 0
        }
        setUpSwitchButton()
        viewModel.updateNotificationSetting()
    }
    
    @IBAction func onClickEmailSwitch(_ sender: Any) {
        if viewModel.memberSetting.mailNotice == 0 {
            viewModel.memberSetting.mailNotice = 1
        } else {
            viewModel.memberSetting.mailNotice = 0
        }
        setUpSwitchButton()
        viewModel.updateNotificationSetting()
    }
    
    func setUpSwitchButton() {
        let imageOn = UIImage(named: "ic_switch_on.png")
        let imageOff = UIImage(named: "ic_switch_off.png")
        if viewModel.memberSetting.pushNotice == 1 {
            pushButton.setBackgroundImage(imageOn, for: .normal)
        } else {
            pushButton.setBackgroundImage(imageOff, for: .normal)
        }
        if viewModel.memberSetting.mailNotice == 1 {
            emailButton.setBackgroundImage(imageOn, for: .normal)
        } else {
            emailButton.setBackgroundImage(imageOff, for: .normal)
        }
    }
}

extension NotificationSettingViewController: NotificationSettingViewModelDelegate {
    func didUpdateState(to state: NotificationSettingViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMemberSettingSuccess:
            setUpSwitchButton()
        }
    }
}
