import Foundation

protocol NotificationSettingViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: NotificationSettingViewModelState)
}

enum NotificationSettingViewModelState {
    case getMemberSettingSuccess
    case network(state: NetworkState)
}

class NotificationSettingViewModel {
    
    private var state: NotificationSettingViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: NotificationSettingViewModelDelegate?
    
    var memberSetting = MemberSetting()
    
    func getMemberSetting() {
        state = .network(state: .loading)
        UserServices.getMemberSetting(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.memberSetting = res
                self.state = .getMemberSettingSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "getMemberSettingError", message: error)
            })
    }
    
    func updateNotificationSetting() {
        state = .network(state: .loading)
        UserServices.updateNotificationSetting(pushNotice: memberSetting.pushNotice ?? 0, mailNotice: memberSetting.mailNotice ?? 0,
            success: { [weak self] res in
                guard self != nil else { return }
                self?.state = .network(state: .loading)
                Functions.showLog(title: "updateNotificationSettingSuccess", message: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
                Functions.showLog(title: "updateNotificationSettingError", message: error)
            })
    }
}

