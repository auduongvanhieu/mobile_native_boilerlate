//
//  BluetoothDeviceTableViewCell.swift
//  REPACE
//
//  Created by Macintosh on 10/22/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class BluetoothDeviceTableViewCell: UITableViewCell {
    @IBOutlet var deviceNameLabel: UILabel!
    @IBOutlet var deviceIdLabel: UILabel!
    @IBOutlet var connectButton: UIButton!
    
    var onClickConnect: (() -> Void)?

    override func layoutSubviews() {
        connectButton.setRoundBorders(UI.Button.cornerRadius)
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
    }
    
    @IBAction func onClickConnectAction(sender: UIButton) {
        onClickConnect?()
    }
}
