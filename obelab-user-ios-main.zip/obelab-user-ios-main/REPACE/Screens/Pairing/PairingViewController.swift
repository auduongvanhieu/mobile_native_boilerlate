import Foundation
import UIKit
import CoreBluetooth

class PairingViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var circleImageView: UIImageView!
    @IBOutlet weak var findDeviceImageView: UIImageView!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var devicesTableView: UITableView!
    @IBOutlet weak var pairingLabel: UILabel!
    @IBOutlet weak var makeSureLabel: UITextView!
    
    @IBOutlet weak var scrollView: UIScrollView!
    var viewModel: PairingViewModel!
    var goToHome = false
    var connectedIndex = -1
    var connectingIndex = -1
    var isActiveSearchButton: Bool = false {
        didSet {
            listenSearchButtonState(isActive: self.isActiveSearchButton)
        }
    }
    
    var deviceList: [CBPeripheral] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        BluetoothHelper.isCurrentParingPage = true
        if let peripheral = BluetoothHelper.peripheral {
            deviceList.append(peripheral)
            connectedIndex = 0
            devicesTableView.reloadData()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        BluetoothHelper.isCurrentParingPage = false
//        NotificationCenter.default.removeObserver(self, name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil)
        
    }
    
    // MARK: - Lifecycle Events
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(connectedDevice), name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(scannedDevice(_:)), name: NotificationCenterHelper.BLE_SCANNED_ACTION, object: nil)
        viewModel.getPairingVideo()
        setUpView()
        setUpAppState()
        setUpTimeForSearch()
        NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_START_SCAN_ACTION, object: nil)
    }
    
    func setUpView() {
        // Bluetooth view
        devicesTableView.setRoundBorders(UI.Button.cornerRadius)
        // Button
        btnSearch.setRoundBorders(UI.Button.cornerRadius)
        setCheckButton(enabled: false)
        // Rotate
        findDeviceImageView.rotate()
    }
    
    func setUpTimeForSearch() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 30) {[weak self] in
            guard let self = self else { return }
            if self.connectedIndex == -1 {
                self.setCheckButton(enabled: true)
                 NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_STOP_SCAN_ACTION, object: nil)
                self.findDeviceImageView.stopRotate()
            }
        }
    }
    
    func setUpAppState() {
        NotificationCenter.default.addObserver(
            forName: UIApplication.willEnterForegroundNotification,
            object: nil,
            queue: .main
        ) { _ in
            if UIApplication.shared.applicationState == .background {
                Functions.showLog(title: "applicationState", message: "background")
                self.devicesTableView.layer.frame = CGRect(x: self.devicesTableView.frame.origin.x, y: self.devicesTableView.frame.origin.y, width: self.devicesTableView.frame.width, height: 0)
                self.findDeviceImageView.rotate()
                self.deviceList.removeAll()
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_START_SCAN_ACTION, object: nil)
            }
        }
    }
    
    func setCheckButton(enabled: Bool) {
        btnSearch.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnSearch.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnSearch.setTitleColor(titleColor, for: .normal)
        isActiveSearchButton = enabled
    }
    
    @IBAction func onClickSearchOrNext(sender: UIButton) {
        if connectedIndex == -1 {
            deviceList.removeAll()
            NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_START_SCAN_ACTION, object: nil)
            findDeviceImageView.rotate()
            setCheckButton(enabled: false)
            setUpTimeForSearch()
        } else {
            if goToHome == true {
                for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: MainViewController.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
                
//                AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: false, isAddObserver: true), with: .reset)
            } else {
                AppNavigator.shared.navigate(to: AuthRoutes.notificationAccess, with: .push)
            }
        }
    }
        
    // MARK: - Scanned
    @objc func scannedDevice(_ notification: NSNotification) {
        if let peripheral = notification.userInfo?[NotificationCenterHelper.BLE_SCANNED_DATA] as? CBPeripheral {
            if(deviceList.contains(where: { device in device.identifier == peripheral.identifier }) == false && peripheral.name != nil) {
                if peripheral.name?.lowercased().contains("repace") ?? false {
                    Functions.showLog(title: "BLE -> Add device to list ", message: peripheral)
                    deviceList.append(peripheral)
                }
                devicesTableView.reloadData()
                devicesTableView.layer.frame = CGRect(x: devicesTableView.frame.origin.x, y: devicesTableView.frame.origin.y, width: devicesTableView.frame.width, height: CGFloat( deviceList.count <= 3 ? deviceList.count * 40 + 2 : 122))
                devicesTableView.isHidden = false
            }
        }
    }
    
    // MARK: - Connected
    @objc func connectedDevice() {
        if BluetoothHelper.isConnectedDevice {
            if let peripheral = BluetoothHelper.peripheral {
                if let index = deviceList.firstIndex(where: {$0.identifier.description == peripheral.identifier.description}) {
                    connectingIndex = -1
                    connectedIndex = index
                } else {
                    connectedIndex = deviceList.count
                    deviceList.append(peripheral)
                }
            }
            if connectingIndex != -1 {
                connectedIndex = connectingIndex
                connectingIndex = -1
            }
            setCheckButton(enabled: true)
            btnSearch.setTitle("title_next".localized, for: .normal)
            self.devicesTableView.reloadData()
            self.devicesTableView.isHidden = true
            self.circleImageView.image = UIImage(named: "img_circle_find_device_complete.png")
            self.findDeviceImageView.isHidden = true
            self.makeSureLabel.isHidden = true
            self.pairingLabel.text = "pairingscreen_connection_complete".localized
            self.pairingLabel.textColor = UI.Color.btnBgColor
        } else {
            connectedIndex = -1
            self.devicesTableView.reloadData()
        }
    }
    
    private func listenSearchButtonState(isActive: Bool) {
        findDeviceImageView.isHidden = isActive
    }
}

extension PairingViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.deviceList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "BluetoothDeviceTableViewCell", for: indexPath) as? BluetoothDeviceTableViewCell else {
            return UITableViewCell()
        }
        let row = indexPath.row
        let peripheral = self.deviceList[row]
        cell.deviceNameLabel.text = peripheral.name
        cell.deviceIdLabel.text = Functions.getBluetoothDeviceId(identifier: peripheral.identifier.uuidString) 
        // Set selection bacground
        let backgroundView = UIView()
        backgroundView.backgroundColor = UI.Color.inputBgColor
        cell.selectedBackgroundView = backgroundView
        if connectingIndex >= 0 {
            if row == connectingIndex {
                cell.connectButton.backgroundColor = UI.Color.btnBgColor
                cell.connectButton.setTitle("connecting".localized, for: .normal)
                cell.connectButton.isEnabled = false
            } else {
                cell.connectButton.backgroundColor = UI.Color.btnBgDisableColor
                cell.connectButton.setTitle("connect".localized, for: .normal)
                cell.connectButton.isEnabled = false
            }
        } else if connectedIndex >= 0 {
            if row == connectedIndex {
                cell.connectButton.backgroundColor = UI.Color.btnBgColor
                cell.connectButton.setTitle("Disconnect".localized, for: .normal)
                cell.connectButton.isEnabled = true
            } else {
                cell.connectButton.backgroundColor = UI.Color.btnBgDisableColor
                cell.connectButton.setTitle("connect".localized, for: .normal)
                cell.connectButton.isEnabled = false
            }
        } else {
            cell.connectButton.backgroundColor = UI.Color.btnBgColor
            cell.connectButton.setTitle("connect".localized, for: .normal)
            cell.connectButton.isEnabled = true
        }
        // Button connect
        cell.onClickConnect = {
            var isConnectOther = true
            if self.connectedIndex > -1 {
                // Disconnect old device
                Functions.showLog(title: "onClickDisconnect", message: "OK")
                isConnectOther = self.connectedIndex != row
                self.connectedIndex = -1
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_DISCONNECT_DEVICE_DATA, object: nil, userInfo: nil)
                self.devicesTableView.reloadData()
            }
            if isConnectOther {
                // Connect
                Functions.showLog(title: "onClickConnect", message: "OK")
                self.connectingIndex = row
                NotificationCenterHelper.nc.post(name: NotificationCenterHelper.BLE_CONNECT_DEVICE_ACTION, object: nil, userInfo: [NotificationCenterHelper.BLE_CONNECT_DEVICE_DATA: peripheral])
                self.devicesTableView.reloadData()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                    if self.connectingIndex >= 0 {
                        self.connectingIndex = -1
                        self.devicesTableView.reloadData()
                    }
                }
            }
        }
        return cell
    }
}
