import Foundation

protocol PairingViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: PairingViewModelState)
}

enum PairingViewModelState {
    case getPairingVideoSuccess
    case network(state: NetworkState)
}

class PairingViewModel {
    
    private var state: PairingViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: PairingViewModelDelegate?
    
    var pairingVideo = CommonCode()
    
    func getPairingVideo() {
        state = .network(state: .loading)
        GeneralServices.getPairingVideo(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.pairingVideo = res
                self.state = .getPairingVideoSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
