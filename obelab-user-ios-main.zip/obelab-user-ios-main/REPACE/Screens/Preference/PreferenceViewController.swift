import Foundation
import DropDown
import UIKit

protocol PreferenceViewControllerDelegate: NSObjectProtocol {
    func didChangeSetting(preferenceViewModel: PreferenceViewModel)
}

class PreferenceViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var btnChooseLanguage: UIButton!
    @IBOutlet weak var btnChooseUnit: UIButton!
    @IBOutlet weak var btnChooseProfileDisclosure: UIButton!
    
    @IBOutlet weak var lblTitleUnit: UILabel!
    @IBOutlet weak var lblTitleLang: UILabel!
    @IBOutlet weak var lblTitleProfil: UILabel!
    
    @IBOutlet weak var headerBack: HeaderBack!
    var viewModel: PreferenceViewModel!
    weak var delegate: PreferenceViewControllerDelegate?
    
    let languageNameList = ["english".localized, "korea".localized]
    let unitNameList = ["metric".localized, "imperial".localized]
    let profileDisclosureNameList = ["all".localized, "friends".localized, "none".localized]
    
    let languageList = [Constants.LANGUAGE_EN, Constants.LANGUAGE_KO]
    let unitList = [Constants.UNIT_METRIC, Constants.UNIT_IMPERIAL]
    let profileDisclosureList = [Constants.PROFILE_DISCLOSURE_ALL, Constants.PROFILE_DISCLOSURE_FRIEND, Constants.PROFILE_DISCLOSURE_NONE]
    
    let chooseLanguageDropDown = DropDown()
    let chooseUnitDropDown = DropDown()
    let chooseProfileDisclosureDropDown = DropDown()
    var chooseType: Int = 0
    
    var languageSelected: Int?
    var unitSelected: Int?
    var profileSelected: Int?

    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        viewModel.getMemberSetting()
    }
    
    func reloadText() {
        headerBack.title = "title_preference".localized
        lblTitleLang.text = "Language Setting".localized
        lblTitleUnit.text = "Units of Measure".localized
        lblTitleProfil.text = "Profile Disclosure".localized
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setUpMemberSetting()
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let page = R.storyboard.setting.preferenceViewController() else {
            return UIViewController()
        }
        page.viewModel = self.viewModel
        page.delegate = self.delegate
        return page
    }
    
    func setUpView() {
        // Button
        btnChooseLanguage.setRoundBorders(UI.Button.cornerRadius)
        btnChooseUnit.setRoundBorders(UI.Button.cornerRadius)
        btnChooseProfileDisclosure.setRoundBorders(UI.Button.cornerRadius)
        // Dropdown
        setupChooseLanguageDropDown()
        setupChooseUnitDropDown()
        setupChooseProfileDisclosureDropDown()
    }
    
    @IBAction func onClickChooseLanguage(_ sender: Any) {
        chooseLanguageDropDown.show()
    }
    
    @IBAction func onClickChooseUnit(_ sender: Any) {
        chooseUnitDropDown.show()
    }
    
    @IBAction func onClickChooseProfileDisclosure(_ sender: Any) {
        chooseProfileDisclosureDropDown.show()
    }
    
    func setupChooseLanguageDropDown() {
        chooseLanguageDropDown.anchorView = btnChooseLanguage
        chooseLanguageDropDown.bottomOffset = CGPoint(x: 0, y: btnChooseLanguage.bounds.height + 8)
        chooseLanguageDropDown.dataSource = languageNameList
        chooseLanguageDropDown.selectionAction = { [weak self] (index, item) in
            guard let self = self else { return }
            if self.languageList[index] != LocalDataManager.language {
                self.chooseType = 1
                let oldLanguage = LocalDataManager.language
                self.viewModel.memberSetting.language = self.languageList[index]
                self.viewModel.updateMemberSetting {
                    LocalDataManager.language = self.languageList[index]
                    self.btnChooseLanguage.setTitle(item, for: .normal)
                    self.delegate?.didChangeSetting(preferenceViewModel: self.viewModel ?? PreferenceViewModel())
    //                let selectedLanguage = RKLocalization.sharedInstance.getLanguage()
    //                RKLocalization.sharedInstance.setLanguage(language: LocalDataManager.language ?? "en") // did set when set LocalDataManager.language
                    self.reloadText()
                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_LANGUAGE_ACTION, object: nil)
                } fail: {
                    self.chooseLanguageDropDown.selectRow(at: nil)
                    self.viewModel.memberSetting.language = oldLanguage
                    if let index = self.languageList.firstIndex(where: {$0 == oldLanguage}) {
                        self.chooseLanguageDropDown.selectRow(index)
                    }
                }
            }
        }
        chooseLanguageDropDown.cellHeight = 40
        chooseLanguageDropDown.width = 120
        chooseLanguageDropDown.backgroundColor = UI.Color.inputBgColor
        chooseLanguageDropDown.selectionBackgroundColor = UI.Color.dropdownSelectedBgColor
        chooseLanguageDropDown.cornerRadius = UI.Button.cornerRadius
        chooseLanguageDropDown.textColor = .white
        chooseLanguageDropDown.selectedTextColor = .white
        chooseLanguageDropDown.shadowColor = UI.Color.transparentColor
    }
    
    func setupChooseUnitDropDown() {
        chooseUnitDropDown.anchorView = btnChooseUnit
        chooseUnitDropDown.bottomOffset = CGPoint(x: 0, y: btnChooseLanguage.bounds.height + 8)
        chooseUnitDropDown.dataSource = unitNameList
        chooseUnitDropDown.selectionAction = { [weak self] (index, item) in
            guard let self = self else { return }
            self.chooseType = 2
            let oldUnit = self.viewModel.memberSetting.unit
            self.viewModel.memberSetting.unit = self.unitList[index]
            self.viewModel.updateMemberSetting {
                self.btnChooseUnit.setTitle(item, for: .normal)
                self.delegate?.didChangeSetting(preferenceViewModel: self.viewModel)
            } fail: {
                self.chooseUnitDropDown.selectRow(at: nil)
                self.viewModel.memberSetting.unit = oldUnit
                if let index = self.unitList.firstIndex(where: {$0 == oldUnit}) {
                    self.chooseUnitDropDown.selectRow(index)
                }
            }
        }
        chooseUnitDropDown.cellHeight = 40
        chooseUnitDropDown.width = 120
        chooseUnitDropDown.backgroundColor = UI.Color.inputBgColor
        chooseUnitDropDown.selectionBackgroundColor = UI.Color.dropdownSelectedBgColor
        chooseUnitDropDown.cornerRadius = UI.Button.cornerRadius
        chooseUnitDropDown.textColor = .white
        chooseUnitDropDown.selectedTextColor = .white
        chooseUnitDropDown.shadowColor = UI.Color.transparentColor
    }
    
    func setupChooseProfileDisclosureDropDown() {
        chooseProfileDisclosureDropDown.anchorView = btnChooseProfileDisclosure
        chooseProfileDisclosureDropDown.bottomOffset = CGPoint(x: 0, y: btnChooseLanguage.bounds.height + 8)
        chooseProfileDisclosureDropDown.dataSource = profileDisclosureNameList
        chooseProfileDisclosureDropDown.selectionAction = { [weak self] (index, item) in
            guard let self = self else { return }
            self.chooseType = 3
            let oldValue = self.viewModel.memberSetting.profileDisclosure
            self.viewModel.memberSetting.profileDisclosure = self.profileDisclosureList[index]
            self.viewModel.updateMemberSetting {
                self.btnChooseProfileDisclosure.setTitle(item, for: .normal)
                self.delegate?.didChangeSetting(preferenceViewModel: self.viewModel)
            } fail: {
                self.chooseProfileDisclosureDropDown.selectRow(at: nil)
                self.viewModel.memberSetting.profileDisclosure = oldValue
                if let index = self.profileDisclosureList.firstIndex(where: {$0 == oldValue}) {
                    self.chooseProfileDisclosureDropDown.selectRow(index)
                }
            }
        }
        chooseProfileDisclosureDropDown.cellHeight = 40
        chooseProfileDisclosureDropDown.width = 120
        chooseProfileDisclosureDropDown.backgroundColor = UI.Color.inputBgColor
        chooseProfileDisclosureDropDown.selectionBackgroundColor = UI.Color.dropdownSelectedBgColor
        chooseProfileDisclosureDropDown.cornerRadius = UI.Button.cornerRadius
        chooseProfileDisclosureDropDown.textColor = .white
        chooseProfileDisclosureDropDown.selectedTextColor = .white
        chooseProfileDisclosureDropDown.shadowColor = UI.Color.transparentColor
    }
    
    func setUpMemberSetting() {
        for (index, item) in languageList.enumerated() where item == viewModel.memberSetting.language {
            chooseLanguageDropDown.selectRow(at: index)
            btnChooseLanguage.setTitle(languageNameList[index], for: .normal)
        }
        for (index, item) in unitList.enumerated() where item == viewModel.memberSetting.unit {
            chooseUnitDropDown.selectRow(at: index)
            btnChooseUnit.setTitle(unitNameList[index], for: .normal)
        }
        for (index, item) in profileDisclosureList.enumerated() where item == viewModel.memberSetting.profileDisclosure {
            chooseProfileDisclosureDropDown.selectRow(at: index)
            btnChooseProfileDisclosure.setTitle(profileDisclosureNameList[index], for: .normal)
        }
    }
    
    func restartApplication() {
        let window = UIApplication.shared.keyWindow
        let controller = SplashViewController()
        window?.rootViewController = controller
        window?.makeKeyAndVisible()
    }
}

extension PreferenceViewController: PreferenceViewModelDelegate {
    func didUpdateState(to state: PreferenceViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getMemberSettingSuccess:
            setUpMemberSetting()
        case .updateMemberSettingFail(let msg):
            showToast(message: msg)
        case .updateMemberSettingSuccess:
            break
//            if chooseType == 1 {
//                AppNavigator.shared.navigate(to: AuthRoutes.splash, with: .reset)
//            }
        }
    }
}
