import Foundation
import UIKit

protocol PreferenceViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: PreferenceViewModelState)
}

enum PreferenceViewModelState {
    case getMemberSettingSuccess
    case updateMemberSettingSuccess
    case updateMemberSettingFail(message: String)
    case network(state: NetworkState)
}

class PreferenceViewModel {
    
    private var state: PreferenceViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: PreferenceViewModelDelegate?
    
    var memberSetting: MemberSetting!
    var isDidSignup: Bool = false
    
    func getMemberSetting() {
        if isDidSignup {
            state = .network(state: .loading)
            UserServices.getMemberSetting(
                success: { [weak self] res in
                    guard let self = self else { return }
                    self.state = .network(state: .hideLoading)
                    self.memberSetting = res
                    LocalDataManager.language = res.language
                    self.state = .getMemberSettingSuccess
                },
                failure: { [weak self] error in
                    self?.state = .network(state: .hideLoading)
                    self?.state = .network(state: .error(error.localizedDescription))
                })
        } else if memberSetting != nil {
            self.state = .getMemberSettingSuccess
        }
    }
    
    func updateMemberSetting(completion: (() -> Void)?,
                             fail: (() -> Void)?) {
        if isDidSignup == true {
            state = .network(state: .loading)
            UserServices.updateMemberSetting(memberSetting: memberSetting,
                                             success: { [weak self] res in
                                                guard let self = self else { return }
                                                self.state = .network(state: .hideLoading)
                                                if res.success == false {
                                                    self.state = .updateMemberSettingFail(message: res.msg ?? "")
                                                    fail?()
                                                } else {
                                                    self.state = .updateMemberSettingSuccess
                                                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.MAIN_TAB_CHANGE_LANGUAGE, object: nil, userInfo: nil)
                                                    completion?()
                                                }
                                             },
                                             failure: { [weak self] error in
                                                self?.state = .network(state: .hideLoading)
                                                self?.state = .network(state: .error(error.localizedDescription))
                                                fail?()
                                             })
        } else {
            LocalDataManager.unit = memberSetting.unit
            LocalDataManager.language = memberSetting.language
            self.state = .updateMemberSettingSuccess
        }
    }
}
