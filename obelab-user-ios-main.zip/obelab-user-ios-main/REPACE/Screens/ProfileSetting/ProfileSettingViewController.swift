import Foundation
import UIKit
import ActionSheetPicker_3_0
import AWSS3
import YPImagePicker

class ProfileSettingViewController: BaseViewController, ChooseHeightWeightDialogDelegate, ChooseGenderDialogDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var nickNameField: UITextField!
    @IBOutlet weak var birthdateField: UITextField!
    @IBOutlet weak var genderField: UITextField!
    @IBOutlet weak var heightField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    var viewModel = ProfileSettingViewModel()
    var dialogType = Constants.UNIT_TYPE_HEIGHT
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
        setUpData()
        viewModel.getHeightWeight()
    }
    
    func setUpView() {
        // Avatar
        avatarImageView.layer.cornerRadius = avatarImageView.frame.width / 2
        // Nickname
        nickNameField.layer.cornerRadius = UI.Button.cornerRadius
        nickNameField.setPlaceholder(color: UI.Color.txtPlaceholderColor)
        // Birthdate
        birthdateField.layer.cornerRadius = UI.Button.cornerRadius
        birthdateField.setPlaceholder(color: UI.Color.txtPlaceholderColor)
        // Gender
        genderField.layer.cornerRadius = UI.Button.cornerRadius
        genderField.setPlaceholder(color: UI.Color.txtPlaceholderColor)
        // Height
        heightField.layer.cornerRadius = UI.Button.cornerRadius
        heightField.setPlaceholder(color: UI.Color.txtPlaceholderColor)
        // Weight
        weightField.layer.cornerRadius = UI.Button.cornerRadius
        weightField.setPlaceholder(color: UI.Color.txtPlaceholderColor)
        // Save Button
        saveButton.layer.cornerRadius = UI.Button.cornerRadius
    }
    
    func setUpData() {
        let profile = viewModel.profile
        emailLabel.text = profile?.email
        nickNameField.text = profile?.nickname
        birthdateField.text = Functions.convertDateStrToProfileDateStr(dateStr: profile?.birthday ?? "")
        genderField.text = profile?.gender?.localized
        var height = Functions.getImperialHeightValue(cm: profile?.height)
        let unit = LocalDataManager.unit
        if unit == Constants.UNIT_METRIC {
            height = "\(Functions.getHeightUnitValue(height: profile?.height ?? 0.0)) \(Functions.getHeightUnitName())"
        }
        if profile?.height != nil {
            heightField.text = height
        }
        if profile?.weight != nil {
            weightField.text = "\(Functions.getWeightUnitValue(weight: profile?.weight ?? 0.0)) \(Functions.getWeightUnitName())"
        }
        
        if let avatarUrl = URL(string: profile?.avatar ?? Constants.AVATAR_DEFAULT_EDDITING) {
            avatarImageView.load(url: avatarUrl)
        }
    }
    
    func setSaveButton(enabled: Bool) {
        saveButton.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        saveButton.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        saveButton.setTitleColor(titleColor, for: .normal)
    }
    
    // MARK: - Actions
    @IBAction func onNickNameChanged(_ sender: UITextField) {
        let newValue = sender.text ?? ""
        viewModel.profile?.nickname = newValue
        setSaveButton(enabled: viewModel.hasValidNickname)
    }
    
    @IBAction func onChooseAvatar(_ sender: Any) {
        showChooseImage()
    }
    
    @IBAction func onChooseBirthdate(_ sender: Any) {
        showDatePicker()
    }
    
    @IBAction func onChooseGender(_ sender: Any) {
        showGenderPicker()
    }
    
    @IBAction func onChooseHeight(_ sender: Any) {
        showHeightPicker()
    }
    
    @IBAction func onChooseWeight(_ sender: Any) {
        showWeightPicker()
    }
    
    @IBAction func onClickSave(_ sender: Any) {
        viewModel.updateProfile()
    }
    
    @IBAction func onClickLogOut(_ sender: Any) {
        LocalDataManager.token = ""
        LocalDataManager.profile = UserInfo()
        LocalDataManager.unit = Constants.UNIT_METRIC
        LocalDataManager.language = Constants.LANGUAGE_EN
        BluetoothHelper.resetLtTestData()
        BluetoothHelper.resetExerciseData()
        if let main = self.navigationController?.viewControllers.first as? MainViewController {
            main.didLogoutApp()
        }
        AppNavigator.shared.navigate(to: AuthRoutes.welcome, with: .reset)
    }
    
    func showChooseImage() {
        var config = YPImagePickerConfiguration()
        config.startOnScreen = .library
        config.showsPhotoFilters = false
        let picker = YPImagePicker(configuration: config)
        picker.didFinishPicking { [unowned picker] items, _ in
            if let photo = items.singlePhoto {
                self.avatarImageView.image = photo.image
                self.viewModel.uploadImageToS3(image: photo.image)
            }
            picker.dismiss(animated: true, completion: nil)
        }
        present(picker, animated: true, completion: nil)
    }
    
    func showDatePicker() {
        let selectedDate = Functions.convertDateStrToDate(dateStr: self.viewModel.profile?.birthday ?? Constants.DATE_DEFAULT)
        let datePicker = ActionSheetDatePicker(title: "",
                                               datePickerMode: UIDatePicker.Mode.date,
                                               selectedDate: selectedDate,
                                               doneBlock: { _, date, _ in
                                                if let date = date as? Date {
                                                    var components = DateComponents()
                                                    components.day = 1
                                                    let dateSelected = Calendar.current.date(byAdding: components, to: date)
                                                    self.viewModel.profile?.birthday = Functions.convertOptionalDateStrToDateStr(optionalDateStr: dateSelected.debugDescription)
                                                    self.birthdateField.text = Functions.convertDateStrToProfileDateStr(dateStr: self.viewModel.profile?.birthday ?? Constants.DATE_DEFAULT)
                                                }
                                               },
                                               cancel: { _ in
                                                Functions.showLog(title: "", message: "Press cancel date picker")
                                               },
                                               origin: self.view.superview)
        var components = DateComponents()
        components.day = 0
        let maxDate = Calendar.current.date(byAdding: components, to: Date())
        datePicker?.maximumDate = maxDate ?? Date()
        datePicker?.show()
    }
    
    func showGenderPicker() {
        let genderList = ["male".localized, "female".localized, "other".localized]
        var selectedIndex = 0
        if let selected = genderList.firstIndex(where: {$0 == viewModel.profile?.gender}) {
            selectedIndex = selected
        }
        ChooseGenderDialogViewController.showPopup(parentVC: self, selectedIndex: selectedIndex)
    }
    
    func showHeightPicker() {
        dialogType = Constants.UNIT_TYPE_HEIGHT
        let dataList = viewModel.heightList
//        let dataList = Functions.getHeightUnitName() == UnitConstants.CM ? viewModel.heightList : viewModel.heightInList
        var height = viewModel.profile?.height
        if height == nil || height == 0.0 {
            height = Constants.HEIGHT_DEFAULT
        }
        ChooseHeightWeightDialogViewController.showPopupInUnit(parentVC: self, dataList: dataList, currentValue: height, unitType: Constants.UNIT_TYPE_HEIGHT)
    }
    
    func showWeightPicker() {
        dialogType = Constants.UNIT_TYPE_WEIGHT
        var weight = viewModel.profile?.weight
        if weight == nil || weight == 0.0 {
            weight = Constants.WEIGHT_DEFAULT
        }
        ChooseHeightWeightDialogViewController.showPopupInUnit(parentVC: self, dataList: viewModel.weightList, currentValue: weight, unitType: Constants.UNIT_TYPE_WEIGHT)
    }
    
    func onChooseHeightWeight(selectedIndex: Int, selectedValue: Double) {
        Functions.showLog(title: "onChooseHeightWeight", message: selectedIndex)
                if dialogType == Constants.UNIT_TYPE_HEIGHT {
                    viewModel.profile?.height = selectedValue
                    var height = Functions.getImperialHeightValue(cm: viewModel.profile?.height)
                    let unit = LocalDataManager.unit
                    if unit == Constants.UNIT_METRIC {
                        height = "\(Functions.getHeightUnitValue(height: viewModel.profile?.height ?? 0.0)) \(Functions.getHeightUnitName())"
                    }
                    self.heightField.text = "\(height)"
                } else {
                    viewModel.profile?.weight = selectedValue
                    self.weightField.text = "\(Functions.getWeightUnitValue(weight: viewModel.profile?.weight ?? 0.0)) \(Functions.getWeightUnitName())"
                }
    }
    
    func onChooseGender(selectedIndex: Int, selectedValue: String) {
        let genderList = ["male".localized, "female".localized, "other".localized]
        Functions.showLog(title: "onChooseGender", message: selectedIndex)
        viewModel.profile?.gender = genderList[selectedIndex]
        genderField.text = selectedValue
    }
}

extension ProfileSettingViewController: ProfileSettingViewModelDelegate {
    func didUpdateState(to state: ProfileSettingViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .updateProfileSuccess(message: let message):
            showToast(message: message)
            AppNavigator.shared.pop()
        case .updateProfileFail(message: let message):
            showToast(message: message)
        }
    }
}
