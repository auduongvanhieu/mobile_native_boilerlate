import Foundation
import UIKit

protocol ProfileSettingViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: ProfileSettingViewModelState)
}

enum ProfileSettingViewModelState {
    case updateProfileSuccess(message: String)
    case updateProfileFail(message: String)
    case network(state: NetworkState)
}

class ProfileSettingViewModel {
    
    private var state: ProfileSettingViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: ProfileSettingViewModelDelegate?
    
    var profile = LocalDataManager.profile
    
    var heightList: [Double] = []
//    var heightInList: [Double] = []
    var weightList: [Double] = []
    
    var hasValidNickname: Bool {
        profile?.nickname?.isNicknameFormatted() == true
    }
    
    func updateProfile() {
        state = .network(state: .loading)
        UserServices.updateProfile(profile: profile ?? UserInfo(), success: { [weak self] res in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            if res.success == true {
                self.state = .updateProfileSuccess(message: res.msg ?? "")
            } else {
                self.state = .updateProfileFail(message: res.msg ?? "")
            }
        },
        failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
    
    func uploadImageToS3(image: UIImage) {
        state = .network(state: .loading)
        AWSS3Manager.shared.uploadImage(image: image, progress: { uploadProgress in
//            guard let strongSelf = self else { return }
            Functions.showLog(title: "S3UploadProgress", message: uploadProgress)
        }, completion: {[weak self] (uploadedFileUrl, error) in
            guard let self = self else { return }
            if let finalPath = uploadedFileUrl as? String { // 3
                Functions.showLog(title: "S3FinalPath", message: finalPath)
                self.profile?.avatar = finalPath
                self.updateProfile()
            } else {
                Functions.showLog(title: "S3Error", message: error as Any)
            }
            self.state = .network(state: .hideLoading)
        })
    }
    
    func getHeightWeight() {
        state = .network(state: .loading)
        GeneralServices.getHeightWeight( success: { [weak self] (heightList, weightList) in
            guard let self = self else { return }
            self.state = .network(state: .hideLoading)
            self.heightList = heightList
            self.weightList = weightList
//            var heightOld = 0.0
//            self.heightList.forEach { (item) in
//                if Functions.cmToIn(cm: item) != heightOld {
//                    self.heightInList.append(item)
//                    heightOld = Functions.cmToIn(cm: item)
//                }
//            }
//            for (index, item) in self.heightList.enumerated() {
//                if(Functions.cmToIn(cm: item) != heightOld) {
//                    self.heightInList.append(item)
//                    heightOld = Functions.cmToIn(cm: item)
//                }
//            }
        },
        failure: { [weak self] error in
            self?.state = .network(state: .hideLoading)
            self?.state = .network(state: .error(error.localizedDescription))
        })
    }
}
