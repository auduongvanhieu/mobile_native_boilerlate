import UIKit
import SkyFloatingLabelTextField
import Firebase
import GoogleSignIn
import FirebaseAuth
import FBSDKLoginKit
import AuthenticationServices

class SignInViewController: BaseViewController, UITextFieldDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var emailField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordField: SkyFloatingLabelTextField!
    @IBOutlet weak var socialGoogleView: UIView!
    @IBOutlet weak var socialFacebookView: UIView!
    @IBOutlet weak var socialAppleView: UIView!
    @IBOutlet weak var bottomPasswordField: NSLayoutConstraint!
    @IBOutlet weak var topPasswordField: NSLayoutConstraint!
    @IBOutlet weak var topEmailField: NSLayoutConstraint!
    @IBOutlet weak var bottomEmailField: NSLayoutConstraint!
    
    var viewModel: SignInViewModel!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        passwordField.delegate = self
        emailField.delegate = self
        setUpView()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: false)
    }
    
    private func textFieldEditing(_ textField: UITextField, isBegin: Bool) {
        var isEmpty = false
        if isBegin == false {
            isEmpty = (textField.text ?? "").isEmpty
        }
        if textField == passwordField {
            adjustContraintsOfTextField(isEmpty, top: topPasswordField, bottom: bottomPasswordField)
        } else if textField == emailField {
            adjustContraintsOfTextField(isEmpty, top: topEmailField, bottom: bottomEmailField)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == passwordField {
            let offsetToUpdate = viewModel.password.index(viewModel.password.startIndex, offsetBy: range.location)
            if string.isEmpty {
                viewModel.password.remove(at: offsetToUpdate)
                setLoginButton(enabled: viewModel.hasValidCredentials)
                return true
            } else {
                viewModel.password.insert(contentsOf: string, at: offsetToUpdate)
            }
            var hashPassword = ""
            for _ in 0 ..< viewModel.password.count { hashPassword += "⁎" }
            textField.text = hashPassword
            setLoginButton(enabled: viewModel.hasValidCredentials)
            return false
        }
        return true
    }
    
    private func adjustContraintsOfTextField(_ isEmpty: Bool, top: NSLayoutConstraint, bottom: NSLayoutConstraint) {
        top.constant = isEmpty ? -2 : 2
        bottom.constant = isEmpty ? 12 : 0
    }
    
    func setUpView() {
        // Button Login
        btnLogin.setRoundBorders(UI.Button.cornerRadius)
        setLoginButton(enabled: false)
        // Input Field
        emailView.layer.cornerRadius = UI.Button.cornerRadius
        emailField.text = Constants.IS_DEV ? "auduongphong@gmail.com" : ""
        emailField.lineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedTitleColor = UI.Color.btnBgColor
        emailField.titleColor = UI.Color.txtFloatTitleColor
        emailField.textColor = UIColor.white
        emailField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        passwordView.layer.cornerRadius = UI.Button.cornerRadius
        passwordField.lineColor = UIColor.white.withAlphaComponent(0.0)
        passwordField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        passwordField.selectedTitleColor = UI.Color.btnBgColor
        passwordField.titleColor = UI.Color.txtFloatTitleColor
        passwordField.textColor = UIColor.white
        passwordField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        // Button social
        socialGoogleView.layer.cornerRadius = UI.Button.cornerRadius
        socialGoogleView.layer.borderWidth = 1
        socialGoogleView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        socialFacebookView.layer.cornerRadius = UI.Button.cornerRadius
        socialFacebookView.layer.borderWidth = 1
        socialFacebookView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        socialAppleView.layer.cornerRadius = UI.Button.cornerRadius
        socialAppleView.layer.borderWidth = 1
        socialAppleView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    // MARK: - Actions
    @IBAction func credentialsChanged(_ sender: UITextField) {
        let newValue = sender.text ?? ""
        switch sender {
        case emailField:
            viewModel.email = newValue
            setLoginButton(enabled: viewModel.hasValidCredentials)
        default: break
        }
    }
    
    @IBAction func tapOnSignInButton(_ sender: Any) {
        view.endEditing(true)
        if !viewModel.hasValidEmail {
            showToast(message: "invalid_email".localized)
            emailView.layer.borderWidth = 1
            emailView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            emailField.titleColor = UI.Color.txtErrorColor
        } else if !viewModel.hasValidPassword {
            showToast(message: "invalid_password".localized)
            passwordView.layer.borderWidth = 1
            passwordView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            passwordField.titleColor = UI.Color.txtErrorColor
        } else {
            emailField.titleColor = UI.Color.txtFloatTitleColor
            passwordField.titleColor = UI.Color.txtFloatTitleColor
            emailView.layer.borderWidth = 0
            passwordView.layer.borderWidth = 0
            viewModel.login()
        }
    }
    
    func setLoginButton(enabled: Bool) {
        btnLogin.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnLogin.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnLogin.setTitleColor(titleColor, for: .normal)
    }
    
    @IBAction func onEmailFocus(_ sender: Any) {
        emailView.layer.borderWidth = 1
        emailView.layer.borderColor = UI.Color.btnBgColor.cgColor
        emailField.selectedTitleColor = UI.Color.btnBgColor
        emailField.titleColor = UI.Color.txtFloatTitleColor
        passwordView.layer.borderWidth = 0
    }
    
    @IBAction func onPasswordFocus(_ sender: Any) {
        emailView.layer.borderWidth = 0
        passwordField.selectedTitleColor = UI.Color.btnBgColor
        passwordField.titleColor = UI.Color.txtFloatTitleColor
        passwordView.layer.borderWidth = 1
        passwordView.layer.borderColor = UI.Color.btnBgColor.cgColor
    }
    
    @IBAction func onClickForgetPassword(_ sender: Any) {
        AppNavigator.shared.navigate(to: AuthRoutes.forgetPassword, with: .push)
    }
    
    @IBAction func onClickGoogle(_ sender: Any) {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        let config = GIDConfiguration(clientID: clientID)
        
        GIDSignIn.sharedInstance.signIn(with: config, presenting: self) { [unowned self] user, error in
            if let error = error {
                Functions.showLog(title: "GoogleSignInError", message: error)
                return
            }
            guard let user = user else { return }
            
            let id = user.userID
            let email = user.profile?.email
            Functions.showLog(title: "GoogleSignInUserID", message: id ?? "")
            Functions.showLog(title: "GoogleSignInEmail", message: email ?? "")
            self.viewModel.loginSocial(id: id ?? "", socialType: Constants.ACCOUNT_TYPE_GOOGLE, email: email ?? "")
        }
    }
    
    @IBAction func onClickFacebook(_ sender: Any) {
        let loginManager = LoginManager()
        if AccessToken.current != nil {
            // Perform log out
            loginManager.logOut()
        } else {
            loginManager.logIn(permissions: [], from: self) { [weak self] (result, error) in
                // Check for error
                guard error == nil else {
                    Functions.showLog(title: "FacebookLoginError", message: error as Any)
                    return
                }
                // Check for cancel
                guard let result = result, !result.isCancelled else {
                    Functions.showLog(title: "FacebookLoginCancel", message: "")
                    return
                }
                // Load profile
                GraphRequest(graphPath: "me", parameters: ["fields": "id,email"]).start(completionHandler: { _, result, _ in
                    if let data = result as? NSDictionary {
                        let id = data.object(forKey: "id") as? String
                        let email = data.object(forKey: "email") as? String
                        Functions.showLog(title: "FacebookLoginId", message: id as Any)
                        Functions.showLog(title: "FacebookLoginEmail", message: email as Any)
                        self?.viewModel.loginSocial(id: id ?? "", socialType: Constants.ACCOUNT_TYPE_FACEBOOK, email: email ?? "")
                    }
                })
            }
        }
    }
    
    @available(iOS 13.0, *)
    @IBAction func onClickApple(_ sender: Any) {
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.email]
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = self
        authorizationController.performRequests()
    }
}

extension SignInViewController: SignInViewModelDelegate {
    func didUpdateState(to state: SignInViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .signInSuccess:
            viewModel.postFCMToken(completion: {
                AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: true), with: .reset)
            })
        case .signInFail(let msg):
            showToast(message: msg)
            passwordView.layer.borderWidth = 1
            passwordView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            passwordField.titleColor = UI.Color.txtErrorColor
        case .loginSocialSuccess(isExist: let isExist, id: let id, socialType: let socialType, email: let email):
            viewModel.postFCMToken {
                if isExist == true {
                    AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: true), with: .reset)
                } else {
                    AppNavigator.shared.navigate(to: AuthRoutes.signUpCheck(id: id, socialType: socialType, email: email), with: .push)
                }
            }
        }
    }
}

extension SignInViewController: ASAuthorizationControllerDelegate {
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as?  ASAuthorizationAppleIDCredential {
            let id = appleIDCredential.user
            let email = appleIDCredential.email
            Functions.showLog(title: "AppleLoginId", message: id)
            Functions.showLog(title: "AppleLoginEmail", message: email ?? "")
            viewModel.loginSocial(id: id, socialType: Constants.ACCOUNT_TYPE_APPLE, email: email ?? "")
        }
    }
}
