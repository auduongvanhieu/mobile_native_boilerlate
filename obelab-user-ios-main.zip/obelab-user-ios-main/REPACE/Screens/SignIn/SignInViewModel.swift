import Foundation

protocol SignInViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: SignInViewModelState)
}

enum SignInViewModelState {
    case signInSuccess
    case signInFail(message: String)
    case loginSocialSuccess(isExist: Bool, id: String, socialType: String, email: String)
    case network(state: NetworkState)
}

class SignInViewModel {
    
    typealias Completion = (() -> ())?
    
    private var state: SignInViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: SignInViewModelDelegate?
    
    var email = ""
    var password = ""
    
    var hasValidCredentials: Bool {
        !email.isEmpty && !password.isEmpty
    }
    
    var hasValidEmail: Bool {
        email.isEmailFormatted()
    }
    
    var hasValidPassword: Bool {
        password.isPasswordFormatted()
    }
    
    func login() {
        state = .network(state: .loading)
        AuthenticationServices.login(
            email: email,
            password: password,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .signInSuccess
                } else {
                    self.state = .signInFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func loginSocial(id: String, socialType: String, email: String) {
        state = .network(state: .loading)
        AuthenticationServices.loginSocial(id: id, socialType: socialType,
            success: { [weak self] isExist in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .loginSocialSuccess(isExist: isExist, id: id, socialType: socialType, email: email)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    func postFCMToken(completion: Completion) {
        state = .network(state: .loading)
        AuthenticationServices.postFCMToken(
            success: { [weak self] _ in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                completion?()
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
