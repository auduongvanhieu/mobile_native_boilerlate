import UIKit
import SkyFloatingLabelTextField
import Atributika
import Firebase
import GoogleSignIn
import FirebaseAuth
import FBSDKLoginKit
import AuthenticationServices

class SignUpViewController: BaseViewController, UITextFieldDelegate {
    
    // MARK: - Outlets
    @IBOutlet weak var btnCheckBox: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var passwordConfirmView: UIView!
    @IBOutlet weak var emailField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordField: SkyFloatingLabelTextField!
    @IBOutlet weak var passwordConfirmationField: SkyFloatingLabelTextField!
    @IBOutlet weak var termAndPolicyView: UIView!
    @IBOutlet weak var socialGoogleView: UIView!
    @IBOutlet weak var socialFacebookView: UIView!
    @IBOutlet weak var socialAppleView: UIView!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var topPasswordConfirmField: NSLayoutConstraint!
    @IBOutlet weak var bottomPasswordConfirmField: NSLayoutConstraint!
    @IBOutlet weak var bottomPasswordField: NSLayoutConstraint!
    @IBOutlet weak var topPasswordField: NSLayoutConstraint!
    @IBOutlet weak var bottomEmailField: NSLayoutConstraint!
    @IBOutlet weak var topEmailField: NSLayoutConstraint!
    var viewModel: SignUpViewModel!
    var isCheckAgreement = false
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        emailField.delegate = self
        passwordField.delegate = self
        passwordConfirmationField.delegate = self
        
        setUpView()
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let signUp = R.storyboard.auth.signUpViewController() else {
            return UIViewController()
        }
        signUp.viewModel = self.viewModel
        signUp.isCheckAgreement = self.isCheckAgreement
        return signUp
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        emailField.text = self.viewModel.email
        var hashPassword = String()
        for _ in 0..<viewModel.password.count {  hashPassword += "⁎" }
        passwordField.text = hashPassword
        passwordConfirmationField.text = hashPassword
        adjustContraintsOfTextField(self.viewModel.email, top: topEmailField, bottom: bottomEmailField)
        adjustContraintsOfTextField(hashPassword, top: topPasswordField, bottom: bottomPasswordField)
        adjustContraintsOfTextField(hashPassword, top: topPasswordConfirmField, bottom: bottomPasswordConfirmField)
        setUpCheckBox()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textFieldEditing(textField, isBegin: false)
    }
    
    private func textFieldEditing(_ textField: UITextField, isBegin: Bool) {
        var isEmpty = false
        if isBegin == false {
            isEmpty = (textField.text ?? "").isEmpty
        }
        let text = isEmpty ? "" : " "
        if textField == passwordField {
            adjustContraintsOfTextField(text, top: topPasswordField, bottom: bottomPasswordField)
        } else if textField == passwordConfirmationField {
            adjustContraintsOfTextField(text, top: topPasswordConfirmField, bottom: bottomPasswordConfirmField)
        } else if textField == emailField {
            adjustContraintsOfTextField(text, top: topEmailField, bottom: bottomEmailField)
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == passwordField {
            let offsetToUpdate = viewModel.password.index(viewModel.password.startIndex, offsetBy: range.location)
            if string.isEmpty {
                viewModel.password.remove(at: offsetToUpdate)
                setSignUpButton()
                return true
            } else {
                viewModel.password.insert(contentsOf: string, at: offsetToUpdate)
                setSignUpButton()
            }
            var hashPassword = String()
            for _ in 0..<viewModel.password.count {  hashPassword += "⁎" }
            textField.text = hashPassword
            return false
        } else if textField == passwordConfirmationField {
            var hashPassword = String()
            let offsetToUpdate = viewModel.passwordConfirmation.index(viewModel.passwordConfirmation.startIndex, offsetBy: range.location)
            if string.isEmpty {
                viewModel.passwordConfirmation.remove(at: offsetToUpdate)
                setSignUpButton()
                return true
            } else {
                viewModel.passwordConfirmation.insert(contentsOf: string, at: offsetToUpdate)
                setSignUpButton()
            }
            for _ in 0..<viewModel.passwordConfirmation.count {  hashPassword += "⁎" }
            textField.text = hashPassword
            return false
        }
        return true
    }
    
    func setUpView() {
        // Button
        btnSignUp.setRoundBorders(UI.Button.cornerRadius)
        setSignUpButton()
        // Button social
        socialGoogleView.layer.cornerRadius = UI.Button.cornerRadius
        socialGoogleView.layer.borderWidth = 1
        socialGoogleView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        socialFacebookView.layer.cornerRadius = UI.Button.cornerRadius
        socialFacebookView.layer.borderWidth = 1
        socialFacebookView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        socialAppleView.layer.cornerRadius = UI.Button.cornerRadius
        socialAppleView.layer.borderWidth = 1
        socialAppleView.layer.borderColor = UIColor.white.withAlphaComponent(0.3).cgColor
        // Input Field
        emailView.layer.cornerRadius = UI.Button.cornerRadius
        emailField.lineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        emailField.selectedTitleColor = UI.Color.btnBgColor
        emailField.titleColor = UI.Color.txtFloatTitleColor
        emailField.textColor = UIColor.white
        emailField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        passwordView.layer.cornerRadius = UI.Button.cornerRadius
        passwordField.lineColor = UIColor.white.withAlphaComponent(0.0)
        passwordField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        passwordField.selectedTitleColor = UI.Color.btnBgColor
        passwordField.titleColor = UI.Color.txtFloatTitleColor
        passwordField.textColor = UIColor.white
        passwordField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        passwordConfirmView.layer.cornerRadius = UI.Button.cornerRadius
        passwordConfirmationField.lineColor = UIColor.white.withAlphaComponent(0.0)
        passwordConfirmationField.selectedLineColor = UIColor.white.withAlphaComponent(0.0)
        passwordConfirmationField.selectedTitleColor = UI.Color.btnBgColor
        passwordConfirmationField.titleColor = UI.Color.txtFloatTitleColor
        passwordConfirmationField.textColor = UIColor.white
        passwordConfirmationField.titleFont = UIFont(name: AppFontName.regular, size: 11) ?? UIFont.systemFont(ofSize: 11)
        // Term and policy
        let termAndPolicyLable = AttributedLabel()
        termAndPolicyLable.numberOfLines = 0
        let all = Style.font(.systemFont(ofSize: 14)).foregroundColor(.white)
        let link = Style("a").underlineStyle(.single)
            .foregroundColor(.blue, .highlighted)
        termAndPolicyLable.attributedText = "term_and_policy".localized
            .style(tags: link)
            .styleHashtags(link)
            .styleMentions(link)
            .styleLinks(link)
            .styleAll(all)
        termAndPolicyLable.onClick = { _, detection in
            switch detection.type {
            case .tag(let tag):
                if tag.attributes["href"] == "term" {
                    Functions.showLog(title: "Go to", message: "term")
                    AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.TERM), with: .push)
                } else {
                    Functions.showLog(title: "Go to", message: "policy")
                    AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.POLICY), with: .push)
                }
            default: break
            }
        }
        termAndPolicyLable.layer.frame = CGRect( x: 0.0, y: 0.0, width: termAndPolicyView.frame.width, height: termAndPolicyView.frame.height)
        termAndPolicyLable.sizeToFit()
        termAndPolicyView.addSubview(termAndPolicyLable)
    }
    
    private func adjustContraintsOfTextField(_ updatedText: String, top: NSLayoutConstraint, bottom: NSLayoutConstraint) {
        top.constant = updatedText.isEmpty ? -2 : 2
        bottom.constant = updatedText.isEmpty ? 12 : 0
    }
    
    // MARK: - Actions
    @IBAction func formEditingChange(_ sender: UITextField) {
        let newValue = sender.text ?? ""
        switch sender {
        case emailField:
            viewModel.email = newValue
            setSignUpButton()
        default: break
        }
    }
    
    func setUpCheckBox() {
        if isCheckAgreement == true {
            btnCheckBox.setImage(UIImage(named: "ic_check_true.png"), for: .normal)
        } else {
            btnCheckBox.setImage(UIImage(named: "ic_check_false.png"), for: .normal)
        }
        setSignUpButton()
    }
    
    @IBAction func onClickCheck(_ sender: Any) {
        Functions.showLog(title: "onClickCheck", message: "")
        isCheckAgreement = !isCheckAgreement
        setUpCheckBox()
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        if !viewModel.hasValidEmail {
            showToast(message: "invalid_email".localized)
            emailView.layer.borderWidth = 1
            emailView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            emailField.titleColor = UI.Color.txtErrorColor
        } else if !viewModel.hasValidPassword {
            showToast(message: "invalid_password".localized)
            passwordView.layer.borderWidth = 1
            passwordView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            emailField.titleColor = UI.Color.txtFloatTitleColor
            passwordField.titleColor = UI.Color.txtErrorColor
        } else if !viewModel.hasValidPasswordConfirm {
            showToast(message: "invalid_password_confirm".localized)
            passwordConfirmView.layer.borderWidth = 1
            emailField.titleColor = UI.Color.txtFloatTitleColor
            passwordField.titleColor = UI.Color.txtFloatTitleColor
            passwordConfirmView.layer.borderColor = UI.Color.txtErrorColor.cgColor
            passwordConfirmationField.titleColor = UI.Color.txtErrorColor
        } else {
            emailField.titleColor = UI.Color.txtFloatTitleColor
            passwordField.titleColor = UI.Color.txtFloatTitleColor
            passwordConfirmationField.titleColor = UI.Color.txtFloatTitleColor
            emailView.layer.borderWidth = 0
            passwordView.layer.borderWidth = 0
            passwordConfirmView.layer.borderWidth = 0
            viewModel.checkEmail()
        }
    }
    
    @IBAction func onClickGoogle(_ sender: Any) {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        let config = GIDConfiguration(clientID: clientID)
        
        GIDSignIn.sharedInstance.signIn(with: config, presenting: self) { [unowned self] user, error in
            if let error = error {
                Functions.showLog(title: "GoogleSignInError", message: error)
                return
            }
            guard let user = user else { return }
            
            let id = user.userID
            let email = user.profile?.email
            Functions.showLog(title: "GoogleSignInUserID", message: id as Any)
            Functions.showLog(title: "GoogleSignInEmail", message: email as Any)
            self.viewModel.loginSocial(id: id ?? "", socialType: Constants.ACCOUNT_TYPE_GOOGLE, email: email ?? "")
        }
    }
    
    @IBAction func onClickFacebook(_ sender: Any) {
        let loginManager = LoginManager()
        if AccessToken.current != nil {
            // Perform log out
            loginManager.logOut()
        } else {
            loginManager.logIn(permissions: [], from: self) { [weak self] (result, error) in
                // Check for error
                guard error == nil else {
                    Functions.showLog(title: "FacebookLoginError", message: error as Any)
                    return
                }
                // Check for cancel
                guard let result = result, !result.isCancelled else {
                    Functions.showLog(title: "FacebookLoginCancel", message: "")
                    return
                }
                // Load profile
                GraphRequest(graphPath: "me", parameters: ["fields": "id,email"]).start(completionHandler: {_, result, _ in
                    if let data = result as? NSDictionary {
                        let id = data.object(forKey: "id") as? String
                        let email = data.object(forKey: "email") as? String
                        Functions.showLog(title: "FacebookLoginId", message: id as Any)
                        Functions.showLog(title: "FacebookLoginEmail", message: email as Any)
                        self?.viewModel.loginSocial(id: id ?? "", socialType: Constants.ACCOUNT_TYPE_FACEBOOK, email: email ?? "")
                    }
                })
            }
        }
    }
    
    @available(iOS 13.0, *)
    @IBAction func onClickApple(_ sender: Any) {
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.email]
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = self
        authorizationController.performRequests()
    }
    
    func setSignUpButton() {
        let enabled = isCheckAgreement == true && viewModel.checkInputText()
        btnSignUp.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnSignUp.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnSignUp.setTitleColor(titleColor, for: .normal)
    }
    
    @IBAction func onEmailFocus(_ sender: Any) {
        emailView.layer.borderWidth = 1
        emailView.layer.borderColor = UI.Color.btnBgColor.cgColor
        passwordView.layer.borderWidth = 0
        passwordConfirmView.layer.borderWidth = 0
    }
    
    @IBAction func onPasswordFocus(_ sender: Any) {
        emailView.layer.borderWidth = 0
        passwordView.layer.borderWidth = 1
        passwordView.layer.borderColor = UI.Color.btnBgColor.cgColor
        passwordConfirmView.layer.borderWidth = 0
        
    }
    
    @IBAction func onPasswordConfirmFocus(_ sender: Any) {
        emailView.layer.borderWidth = 0
        passwordView.layer.borderWidth = 0
        passwordConfirmView.layer.borderWidth = 1
        passwordConfirmView.layer.borderColor = UI.Color.btnBgColor.cgColor
    }
}

extension SignUpViewController: SignUpViewModelDelegate {    
    func didUpdateState(to state: SignUpViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .signUpSuccess:
//            viewModel.postFCMToken()
            AppNavigator.shared.navigate(to: AuthRoutes.enterNickname(email: viewModel.email, password: viewModel.password), with: .push)
        case .signUpFail(let msg):
            emailField.becomeFirstResponder()
            showToast(message: msg)
        case .loginSocialSuccess(isExist: let isExist, id: let id, socialType: let socialType, email: let email):
            viewModel.postFCMToken()
            if isExist == true {
                AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: true), with: .reset)
            } else {
                AppNavigator.shared.navigate(to: AuthRoutes.signUpCheck(id: id, socialType: socialType, email: email), with: .push)
            }
        case .postFCMTokenSuccess:
            break
        }
    }
}

extension SignUpViewController: ASAuthorizationControllerDelegate {
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as?  ASAuthorizationAppleIDCredential {
            let id = appleIDCredential.user
            let email = appleIDCredential.email
            Functions.showLog(title: "AppleLoginId", message: id)
            Functions.showLog(title: "AppleLoginEmail", message: email as Any)
            viewModel.loginSocial(id: id, socialType: Constants.ACCOUNT_TYPE_APPLE, email: email ?? "")
        }
    }
}
