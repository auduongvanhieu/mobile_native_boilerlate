//
//  SignUpViewModel.swift
//  REPACE
//
//  Created by German on 8/21/18.
//  Copyright © 2018 Rootstrap Inc. All rights reserved.
//

import Foundation

protocol SignUpViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: SignUpViewModelState)
}

enum SignUpViewModelState {
    case postFCMTokenSuccess
    case signUpSuccess
    case signUpFail(message: String)
    case loginSocialSuccess(isExist: Bool, id: String, socialType: String, email: String)
    case network(state: NetworkState)
}

class SignUpViewModel {
    
    private var state: SignUpViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: SignUpViewModelDelegate?
    
    var email = ""
    
    var password = ""
    
    var passwordConfirmation = ""
    
    var hasValidEmail: Bool {
        email.isEmailFormatted()
    }
    
    var hasValidPassword: Bool {
        password.isPasswordFormatted()
    }
    
    var hasValidPasswordConfirm: Bool {
        password == passwordConfirmation
    }
    
    func checkInputText() -> Bool {
        email.isEmpty == false && password.isEmpty == false && passwordConfirmation.isEmpty == false
    }
    
    func checkEmail() {
        state = .network(state: .loading)
        AuthenticationServices.checkEmail(
            email: email,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .signUpSuccess
                } else {
                    self.state = .signUpFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func signup() {
        state = .network(state: .loading)
        AuthenticationServices.signUp(
            email: email,
            password: password,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .signUpSuccess
                } else {
                    self.state = .signUpFail(message: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func loginSocial(id: String, socialType: String, email: String) {
        state = .network(state: .loading)
        AuthenticationServices.loginSocial(id: id, socialType: socialType,
            success: { [weak self] isExist in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .loginSocialSuccess(isExist: isExist, id: id, socialType: socialType, email: email)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    func postFCMToken() {
        state = .network(state: .loading)
        AuthenticationServices.postFCMToken(
            success: { [weak self] _ in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .postFCMTokenSuccess
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
