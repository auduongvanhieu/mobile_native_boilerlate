import Foundation
import UIKit
import Atributika

class SignUpCheckViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var btnCheckBox: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var termAndPolicyView: UIView!

    var viewModel: SignUpCheckViewModel!
    var isCheckAgreement = false

    var id: String = ""
    var socialType: String = ""
    var email: String = ""
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        
        setUpView()
    }
    
    func setUpView() {
        // Button
        btnSignUp.setRoundBorders(UI.Button.cornerRadius)
        setSignUpButton(enabled: false)
        // Term and policy
        let termAndPolicyLable = AttributedLabel()
        termAndPolicyLable.numberOfLines = 0
        let all = Style.font(.systemFont(ofSize: 14)).foregroundColor(.white)
        let link = Style("a").underlineStyle(.single)
            .foregroundColor(.blue, .highlighted)
        termAndPolicyLable.attributedText = "term_and_policy".localized
            .style(tags: link)
            .styleHashtags(link)
            .styleMentions(link)
            .styleLinks(link)
            .styleAll(all)
        termAndPolicyLable.onClick = { _, detection in
            switch detection.type {
            case .tag(let tag):
                if tag.attributes["href"] == "term" {
                    Functions.showLog(title: "Go to", message: "term")
                    AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.TERM), with: .push)
                } else {
                    Functions.showLog(title: "Go to", message: "policy")
                    AppNavigator.shared.navigate(to: SettingRoutes.termOfUse(type: Constants.POLICY), with: .push)
                }
            default: break
            }
        }
        termAndPolicyLable.layer.frame = CGRect( x: 0.0, y: 0.0, width: termAndPolicyView.frame.width, height: termAndPolicyView.frame.height)
        termAndPolicyLable.sizeToFit()
        termAndPolicyView.addSubview(termAndPolicyLable)
    }
    
    func setSignUpButton(enabled: Bool) {
        btnSignUp.layer.backgroundColor = enabled ? UI.Color.btnBgColor.cgColor : UI.Color.btnBgDisableColor.cgColor
        btnSignUp.isEnabled = enabled
        let titleColor = enabled ? UIColor.white : UI.Color.btnTitleDisableColor
        btnSignUp.setTitleColor(titleColor, for: .normal)
    }
    
    func setUpCheckBox() {
        if isCheckAgreement == true {
            btnCheckBox.setImage(UIImage(named: "ic_check_true.png"), for: .normal)
        } else {
            btnCheckBox.setImage(UIImage(named: "ic_check_false.png"), for: .normal)
        }
        setSignUpButton(enabled: isCheckAgreement)
    }
    
    @IBAction func onClickCheck(_ sender: Any) {
        Functions.showLog(title: "onClickCheck", message: "")
        isCheckAgreement = !isCheckAgreement
        setUpCheckBox()
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        viewModel.registerSocial(id: id, socialType: socialType, email: email)
    }
}

extension SignUpCheckViewController: SignUpCheckViewModelDelegate {
    func didUpdateState(to state: SignUpCheckViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .registerSocialSuccess:
            AppNavigator.shared.navigate(to: AuthRoutes.enterNickname(email: "", password: ""), with: .push)
        case .registerSocialFail(msg: let msg):
            showToast(message: msg)
        }
    }
}
