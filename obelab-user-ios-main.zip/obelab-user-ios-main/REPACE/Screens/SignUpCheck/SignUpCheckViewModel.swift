import Foundation

protocol SignUpCheckViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: SignUpCheckViewModelState)
}

enum SignUpCheckViewModelState {
    case registerSocialSuccess
    case registerSocialFail(msg: String)
    case network(state: NetworkState)
}

class SignUpCheckViewModel {
    
    private var state: SignUpCheckViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: SignUpCheckViewModelDelegate?
    
    func registerSocial(id: String, socialType: String, email: String) {
        state = .network(state: .loading)
        AuthenticationServices.registerSocial(id: id, socialType: socialType, email: email,
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                if res.success == true {
                    self.state = .registerSocialSuccess
                } else {
                    self.state = .registerSocialFail(msg: res.msg ?? "")
                }
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}
