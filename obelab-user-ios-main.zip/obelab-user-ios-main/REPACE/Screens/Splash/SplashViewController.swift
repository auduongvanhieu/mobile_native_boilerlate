import Foundation
import UIKit

class SplashViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if LocalDataManager.isNotFirstOpenApp == false {
            LocalDataManager.isNotFirstOpenApp = true
            LocalDataManager.volumeTurnOn = false
            LocalDataManager.isShowLTTestGuide = true
        }
        checkConnection()
        RKLocalization.sharedInstance.setLanguage(language: LocalDataManager.language ?? "en")
//        let objects = RealmHelper.share.getAllLTTestInLocalDB(memberID: nil)
//        print(objects)
    }
    
    func checkConnection() {
        if Connectivity.isConnectedToInternet {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                if LocalDataManager.token != nil && (LocalDataManager.token?.isEmpty == false) {
                    if LocalDataManager.profile?.nickname?.isEmpty == true {
                        AppNavigator.shared.navigate(to: AuthRoutes.enterNickname(email: "", password: ""), with: .reset)
                    } else {
                        AppNavigator.shared.navigate(to: MainRoutes.main(requestNotificationRight: false), with: .reset)
                    }
                } else {
                    AppNavigator.shared.navigate(to: AuthRoutes.welcome, with: .reset)
                }
            }
        } else {
            showNetWorkErrorAlert()
        }
    }
    
    func showNetWorkErrorAlert() {
        showMessage(title: "", message: "network_not_working".localized, handler: { _ in
            exit(-1)
        })
    }
}
