import UIKit

class TermOfUseViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var contentTextView: UITextView!
    @IBOutlet weak var headerBack: HeaderBack!
    
    var viewModel: TermOfUseViewModel!
    var type = Constants.TERM
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self

        setUpView()
        
        if type == Constants.TERM {
            viewModel.getTermOfUse()
        } else {
            viewModel.getPrivacyPolicy()
        }
    }
    
    func setUpView(){
        // Header
        if type == Constants.TERM {
            headerBack.titleLabel.text = "title_term_of_use".localized
        } else {
            headerBack.titleLabel.text = "title_privacy_policy".localized
        }
    }
}

extension TermOfUseViewController: TermOfUseViewModelDelegate {
    func didUpdateState(to state: TermOfUseViewModelState) {
        switch state {
        case .network(let networkStatus):
            networkStatusChanged(to: networkStatus)
        case .getTermOfUseSuccess(let termOfUse):
            Functions.showLog(title: "getTermOfUseSuccess", message: termOfUse.name ?? "")
            contentTextView.text = termOfUse.value?.htmlToString
        case .getPrivacyPolicySuccess(privacyPolicy: let privacyPolicy):
            Functions.showLog(title: "getPrivacyPolicySuccess", message: privacyPolicy.name ?? "")
            contentTextView.text = privacyPolicy.value?.htmlToString
        }
    }
}
