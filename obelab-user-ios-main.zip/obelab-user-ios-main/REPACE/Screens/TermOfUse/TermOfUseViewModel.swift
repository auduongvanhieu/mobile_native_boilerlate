import Foundation

protocol TermOfUseViewModelDelegate: AuthViewModelStateDelegate {
    func didUpdateState(to state: TermOfUseViewModelState)
}

enum TermOfUseViewModelState {
    case getTermOfUseSuccess(termOfUse: CommonCode)
    case getPrivacyPolicySuccess(privacyPolicy: CommonCode)
    case network(state: NetworkState)
}

class TermOfUseViewModel {
    
    private var state: TermOfUseViewModelState = .network(state: .idle) {
        didSet {
            delegate?.didUpdateState(to: state)
        }
    }
    
    weak var delegate: TermOfUseViewModelDelegate?
    
    func getTermOfUse() {
        state = .network(state: .loading)
        GeneralServices.getTermOfUse(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .getTermOfUseSuccess(termOfUse: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
    
    func getPrivacyPolicy() {
        state = .network(state: .loading)
        GeneralServices.getPrivacyPolicy(
            success: { [weak self] res in
                guard let self = self else { return }
                self.state = .network(state: .hideLoading)
                self.state = .getPrivacyPolicySuccess(privacyPolicy: res)
            },
            failure: { [weak self] error in
                self?.state = .network(state: .hideLoading)
                self?.state = .network(state: .error(error.localizedDescription))
            })
    }
}

