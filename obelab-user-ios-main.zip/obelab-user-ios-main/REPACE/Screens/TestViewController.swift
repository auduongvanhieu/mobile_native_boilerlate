//
//  TestViewController.swift
//  REPACE
//
//  Created by Van Huy Pham on 10/26/21.
//  Copyright © 2021 Rootstrap Inc. All rights reserved.
//

import Foundation
import UIKit

class TestViewController: BaseViewController {
    
    var viewModel: HomeViewModel!
    
    var isExpanded: Bool = false
    var blurEffectView: UIVisualEffectView?
    
    @IBOutlet weak var btnMoreInfo: UIButton!
    @IBOutlet weak var tvGuide: UITextView!
    @IBOutlet weak var vwGuideContainer: UIView!
    @IBOutlet weak var vwGuideBackground: UIView!
    @IBOutlet weak var ctGuideContainerHeight: NSLayoutConstraint!
    @IBOutlet weak var ctTvGuideTop: NSLayoutConstraint!
    @IBOutlet weak var tvGuideTitle: UILabel!
    @IBOutlet weak var btnStart: UIButton!
    @IBOutlet weak var topExpandView: NSLayoutConstraint!
    var currentTitle = "short_guide"
    var isOpenedSetting: Bool = false
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTransparentBackground()
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
//        checkConnection()
//        setButtonIsConnected()
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(checkConnection), name: NotificationCenterHelper.BLUETOOTH_CONNECTION_STATUS_ACTION, object: nil)
        NotificationCenterHelper.nc.addObserver(self, selector: #selector(reloadString), name: NotificationCenterHelper.CHANGE_LANGUAGE_ACTION, object: nil)
        tvGuide.isScrollEnabled = false
        self.tvGuide.text = "short_guide".localized
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let page = R.storyboard.main.testViewController() else {
            return UIViewController()
        }
        return page
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if isOpenedSetting == false {
            checkInfoInput()
        } else {
            let height = LocalDataManager.profile?.height ?? 0
            let weight = LocalDataManager.profile?.weight ?? 0
            if height != 0 && weight != 0 {
                checkConnection()
            }
        }
    }
    
    func setButtonIsConnected() {
        btnStart.isEnabled = true
        btnStart.setTitleColor(UIColor.white, for: .normal)
        btnStart.backgroundColor = UI.Color.btnBgColor
    }
    
    func setButtonIsDisconnected() {
        btnStart.isEnabled = false
        btnStart.setTitleColor(UI.Color.txtPlaceholderColor, for: .normal)
        btnStart.backgroundColor = UI.Color.btnBgDisableColor
    }
    
    @objc func reloadString() {
        self.tvGuide.text = self.currentTitle.localized
    }
    
    @objc func checkConnection() {
        if BluetoothHelper.isConnectedDevice || Constants.IS_DEV {
            setButtonIsConnected()
        } else {
            if Constants.IS_DEV {
                setButtonIsConnected()
            } else {
                setButtonIsDisconnected()
            }
        }
    }
    
    private func checkInfoInput() {
        let height = LocalDataManager.profile?.height ?? 0
        let weight = LocalDataManager.profile?.weight ?? 0
        if height == 0 || weight == 0 {
            setButtonIsDisconnected()
            showMessage(title: "title_alert_height_weight".localized, message: "message_alert_height_weight".localized, handler: { _ in
                DispatchQueue.main.async {
                    self.isOpenedSetting = true
                    AppNavigator.shared.navigate(to: SettingRoutes.profileSetting, with: .push)
//                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 3])
                }
            })
//            let alert = UIAlertController(title: "title_alert_height_weight".localized, message: "message_alert_height_weight".localized, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "ok".localized, style: .default, handler: { _ in
//                DispatchQueue.main.async {
//                    self.isOpenedSetting = true
//                    AppNavigator.shared.navigate(to: SettingRoutes.profileSetting, with: .push)
////                    NotificationCenterHelper.nc.post(name: NotificationCenterHelper.CHANGE_MAIN_TAB_ACTION, object: nil, userInfo: [NotificationCenterHelper.TAB_DATA: 3])
//                }
//            }))
//            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
        } else {
            checkConnection()
        }
    }
    
    @IBAction func btnStartClick(_ sender: Any) {
        if BluetoothHelper.isConnectedDevice == true || Constants.IS_DEV == true {
            let detailPage = LTTestRoutes.testSum.screen as? TestSummaryOffViewController ?? TestSummaryOffViewController()
            self.navigationController?.pushViewController(detailPage, animated: true)
//            AppNavigator.shared.navigate(to: LTTestRoutes.testSum, with: .push)
        } else {
            showDisconnectedDeviceAlert()
        }
    }
    
    @IBAction func btnMoreInfo_Click(_ sender: Any) {
        let options: UIView.AnimationOptions = [.curveEaseInOut]
        var blurAlpha: CGFloat = 0.0
        var title = ""
        
        if isExpanded {
            blurAlpha = 0.0
            btnMoreInfo.setImage(#imageLiteral(resourceName: "ic_help_circle"), for: UIControl.State.normal)
            title = "short_guide"
//            tvGuideTitle.isHidden = true
            ctTvGuideTop.constant = -35
            tvGuide.isScrollEnabled = false
            self.topExpandView.isActive = false
        } else {
            blurAlpha = 0.3
            btnMoreInfo.setImage(#imageLiteral(resourceName: "ic_close_circle"), for: UIControl.State.normal)
            title = "long_guide"
//            tvGuideTitle.isHidden = false
            ctTvGuideTop.constant = 0
            tvGuide.isScrollEnabled = true
            if let constraint = self.ctGuideContainerHeight {
                constraint.isActive = false
            }
        }
        
        UIView.animate(withDuration: 0.25,
                       delay: 0,
                       options: options,
                       animations: { [weak self] in
                        guard let self = self else { return }
            self.blurEffectView?.alpha = blurAlpha
            if self.isExpanded == false {
                self.topExpandView.isActive = true
            } else if let constraint = self.ctGuideContainerHeight {
                constraint.isActive = true
            }
            self.currentTitle = title
            self.tvGuide.text = self.currentTitle.localized
            self.tvGuideTitle.isHidden = self.isExpanded
            self.view.layoutIfNeeded()
        }, completion: { _ in
            self.isExpanded.toggle()
        })
    }
    
    func setupTransparentBackground() {
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.light)
        blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView?.frame = vwGuideBackground.bounds
        blurEffectView?.alpha = 0
        blurEffectView?.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurEffectView?.layer.cornerRadius = 8
        blurEffectView?.clipsToBounds = true
        if let blurEffectView = blurEffectView {
            vwGuideBackground.insertSubview(blurEffectView, at: 0)
        }
    }
}
