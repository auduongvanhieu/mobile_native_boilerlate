import Foundation
import UIKit

class TutorialViewController: BaseViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var btnNext: UIButton!
    
    // MARK: - Lifecycle Events
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
    }
    
    func setUpView() {
        // Button
        btnNext.setRoundBorders(UI.Button.cornerRadius)
    }
    
    @IBAction func onClickNext(_ sender: Any) {
        AppNavigator.shared.navigate(to: AuthRoutes.pairing(), with: .push)
    }
    
    @IBAction func onClickSkip(_ sender: Any) {
        AppNavigator.shared.navigate(to: AuthRoutes.notificationAccess, with: .push)
    }
}
