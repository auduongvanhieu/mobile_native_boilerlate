import Foundation
import UIKit

class WelcomeViewController: BaseViewController {
    
    @IBOutlet weak var btnLogIn: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var imvWelcome: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    func setUpUI() {
        btnLogIn.layer.cornerRadius = UI.Button.cornerRadius
        btnSignUp.layer.cornerRadius = UI.Button.cornerRadius
        btnSignUp.layer.borderWidth = 1
        btnSignUp.layer.borderColor = UI.Color.btnBgColor.cgColor
        imvWelcome.frame = CGRect( x: imvWelcome.frame.origin.x, y: imvWelcome.frame.origin.y, width: self.view.frame.width, height: self.view.frame.width * 1.07)
    }
    
    override func copySelfForChangeLanguage() -> UIViewController {
        guard let welcome = R.storyboard.auth.welcomeViewController() else {
            return UIViewController()
        }
        return welcome
    }
    
    @IBAction func onClickLogin(_ sender: Any) {
        AppNavigator.shared.navigate(to: AuthRoutes.signIn, with: .push)
    }
    
    @IBAction func onClickSignUp(_ sender: Any) {
        Functions.showLog(title: "onClickSignUp", message: "CMN")
        AppNavigator.shared.navigate(to: AuthRoutes.signUp, with: .push)
    }
}
