import Foundation
import WatchConnectivity

protocol WatchKitConnectionDelegate: class {
    func didFinishedActiveSession()
    func getNewHeartRate(heartrate: Double)
}

protocol WatchKitConnectionProtocol {
    func startSession()
    func sendMessage(message: [String : AnyObject], replyHandler: (([String : AnyObject]) -> Void)?, errorHandler: ((NSError) -> Void)?)
}

class WatchKitConnection: NSObject {
    static let shared = WatchKitConnection()
    weak var delegate: WatchKitConnectionDelegate?
    
    private override init() {
        super.init()
    }
    
    private let session: WCSession? = WCSession.isSupported() ? WCSession.default : nil
    
    private var validSession: WCSession? {
    #if os(iOS)
        if let session = session, session.isPaired, session.isWatchAppInstalled {
            return session
        }
    #elseif os(watchOS)
        return session
    #endif
        return nil
    }
    
    private var validReachableSession: WCSession? {
        if let session = validSession, session.isReachable {
            return session
        }
        return nil
    }
}

extension WatchKitConnection: WatchKitConnectionProtocol {
    func startSession() {
        session?.delegate = self
        session?.activate()
    }
    
    func sendMessage(message: [String: AnyObject],
                     replyHandler: (([String: AnyObject]) -> Void)? = nil,
                     errorHandler: ((NSError) -> Void)? = nil) {
        validReachableSession?.sendMessage(message, replyHandler: { (result) in
            Functions.showLog(title: "", message: result)
        }, errorHandler: { (error) in
            Functions.showLog(title: error.localizedDescription, message: error)
        })
    }
}

extension WatchKitConnection: WCSessionDelegate {
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        Functions.showLog(title: "HR -> activationDidCompleteWith", message: "")
        delegate?.didFinishedActiveSession()
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        Functions.showLog(title: "HR -> sessionDidBecomeInactive", message: "")
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        Functions.showLog(title: "HR -> sessionDidDeactivate", message: "")
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String: Any]) {
        Functions.showLog(title: "HR -> didReceiveMessage", message: message)
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String: Any], replyHandler: @escaping ([String : Any]) -> Void) {
        guard let heartReate = message.values.first as? String else {
            return
        }
        guard let heartReateDouble = Double(heartReate) else {
            return
        }
        delegate?.getNewHeartRate(heartrate: heartReateDouble)
    }
}
