import HealthKit

protocol WorkoutTrackingProtocol {
    func authorizeHealthKit()
    func observerHeartRateSamples()
}

class WorkoutTracking {
    static let shared = WorkoutTracking()
    let healthStore = HKHealthStore()
    var observerQuery: HKObserverQuery!
    
    init() {
    }
}

extension WorkoutTracking: WorkoutTrackingProtocol {
    func authorizeHealthKit() {
        if HKHealthStore.isHealthDataAvailable() {
            let infoToRead = Set([
                HKSampleType.quantityType(forIdentifier: .stepCount)!,
                HKSampleType.quantityType(forIdentifier: .heartRate)!,
                HKSampleType.workoutType()
            ])
            let infoToShare = Set([
                HKSampleType.quantityType(forIdentifier: .stepCount)!,
                HKSampleType.quantityType(forIdentifier: .heartRate)!,
                HKSampleType.workoutType()
            ])
            healthStore.requestAuthorization(toShare: infoToShare, read: infoToRead) { (success, error) in
                if success {
                    self.observerHeartRateSamples()
                    Functions.showLog(title: "HR -> Authorization healthkit success", message: "")
                } else if let error = error {
                    Functions.showLog(title: "HR -> Authorization healthkit error", message: error)
                }
            }
        } else {
            Functions.showLog(title: "HR -> HealthKit not avaiable", message: "")
        }
    }
    
    func observerHeartRateSamples() {
        guard let heartRateSampleType = HKObjectType.quantityType(forIdentifier: .heartRate) else {
            return
        }
        if let observerQuery = observerQuery {
            healthStore.stop(observerQuery)
        }
        observerQuery = HKObserverQuery(sampleType: heartRateSampleType, predicate: nil) { [unowned self] (_, _, error) in
            if let error = error {
                Functions.showLog(title: "HR -> Query Error", message: error.localizedDescription)
                return
            }
            self.fetchLatestHeartRateSample { (sample) in
                guard let sample = sample else {
                    return
                }
                DispatchQueue.main.async {
                    let heartRateUnit = HKUnit.count().unitDivided(by: HKUnit.minute())
                    let heartRate = sample.quantity.doubleValue(for: heartRateUnit)
                    Functions.showLog(title: "HR -> Heart Rate Value", message: heartRate)
                }
            }
        }
        healthStore.execute(observerQuery)
        healthStore.enableBackgroundDelivery(for: heartRateSampleType, frequency: .immediate) { (success, error) in
            Functions.showLog(title: "success = \(success)", message: success)
            if let error = error {
                Functions.showLog(title: error.localizedDescription, message: error)
            }
        }
    }
}

extension WorkoutTracking {
    private func fetchLatestHeartRateSample(completionHandler: @escaping (_ sample: HKQuantitySample?) -> Void) {
        guard let sampleType = HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate) else {
            completionHandler(nil)
            return
        }
        let predicate = HKQuery.predicateForSamples(withStart: Date.distantPast, end: Date(), options: .strictEndDate)
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
        let query = HKSampleQuery(sampleType: sampleType,
                                  predicate: predicate,
                                  limit: Int(HKObjectQueryNoLimit),
                                  sortDescriptors: [sortDescriptor]) { (_, results, error) in
            if let error = error {
                Functions.showLog(title: "HR -> Sample Query Error", message: error.localizedDescription)
                return
            }
            if results?.isEmpty == false {
                completionHandler(results?[0] as? HKQuantitySample)
            }
        }
        healthStore.execute(query)
    }
}
