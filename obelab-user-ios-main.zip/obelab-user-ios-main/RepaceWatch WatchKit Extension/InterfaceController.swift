//
//  InterfaceController.swift
//  RepaceWatch WatchKit Extension
//
//  Created by ThienBanh on 25/01/2022.
//  Copyright © 2022 Rootstrap Inc. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var btnStop: WKInterfaceButton!
    @IBOutlet weak var btnStart: WKInterfaceButton!
    @IBOutlet weak var lblHeartRate: WKInterfaceLabel!
    var isStart = false
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        setTitle("REPACE")
        
        // Configure interface objects here.
        print("AWAKE")
        WorkoutTracking.authorizeHealthKit()
        WorkoutTracking.shared.startWorkOut()
        WorkoutTracking.shared.delegate = self
        
        WatchKitConnection.shared.delegate = self
        WatchKitConnection.shared.startSession()
    }
    
    override func willActivate() {
        super.willActivate()
        print("WILL ACTIVE")
        WorkoutTracking.shared.fetchStepCounts()
    }
    
    override func didDeactivate() {
        super.didDeactivate()
        print("DID DEACTIVE")
    }

    @IBAction func actionStart() {
        WorkoutTracking.shared.startWorkOut()
        setColorBtnStart(color: #colorLiteral(red: 0.1254901961, green: 0.5803921569, blue: 0.9803921569, alpha: 1), textColor: .black)
        
    }
    @IBAction func actionStop() {
        isStart = false
        setColorBtnStart(color: #colorLiteral(red: 0.1411764706, green: 0.1411764706, blue: 0.1411764706, alpha: 1), textColor: .white)
        WorkoutTracking.shared.stopWorkOut()
    }
    func setColorBtnStart(color: UIColor, textColor: UIColor){
        btnStart.setBackgroundColor(color)
        let paragraphStyle =  NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let font = UIFont.systemFont(ofSize: 18)
        let attributes:Dictionary = [NSAttributedString.Key.paragraphStyle:paragraphStyle ,  NSAttributedString.Key.font:font, NSAttributedString.Key.foregroundColor: textColor]
        let attributeString:NSAttributedString = NSAttributedString(string: "START", attributes: attributes)
        btnStart.setAttributedTitle(attributeString)
    }
}
extension InterfaceController: WorkoutTrackingDelegate {
    func didReceiveHealthKitHeartRate(_ heartRate: Double) {
        if !isStart{
            isStart = true
            setColorBtnStart(color: #colorLiteral(red: 0.1254901961, green: 0.5803921569, blue: 0.9803921569, alpha: 1), textColor: .black)
        }
        
        lblHeartRate.setText("\(Int(heartRate))")
        WatchKitConnection.shared.sendMessage(message: ["heartRate":
            "\(heartRate)" as AnyObject])
    }
    
    func didReceiveHealthKitStepCounts(_ stepCounts: Double) {
//        stepCountsLabel.setText("\(stepCounts) STEPS")
    }
}

extension InterfaceController: WatchKitConnectionDelegate {
    func didReceiveUserName(_ userName: String) {
//        userNameLabel.setText(userName)
    }
}
