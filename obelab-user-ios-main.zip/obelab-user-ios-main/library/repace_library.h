//
//  repace_library.h
//  repace.library
//
//  Created by obelab on 2021/08/31.
//

#import <Foundation/Foundation.h>


@interface RepaceLibrary : NSObject


typedef struct
{
    int     protocol;   // 프로코톨
    double  startSpeed; // 시작 속도
    int     heartRate;
} LTProtocol;

typedef struct
{
    bool    isNext;
    double  lactate;
    double  speed;
    double  onset;
    double  threshold;
} LTAnalysis;

typedef struct
{
    int     purpose[3];
} LTPurpose;

typedef struct
{
    int     type;        // 1: 저강도, 2: 양극화
    double  leSpeed;
    int     leWeek;
    int     leTime;
    int     leMin;
    double  ptSpeed;
    int     ptWeek;
    int     ptTime;
    int     ptMin;
    double  ptIndex;
} LTPrescription;


typedef struct
{
    int     section;
    int     time;
    double  speed;
    int     heartRate;
} LTTraining;



- (NSInteger) getBatteryLevel;
- (LTProtocol) getProtocol: (int) type : (int) age : (int) distance : (int) number : (double) time;
- (LTAnalysis) getAnalysis: (int) stage: (int) protocol: (double) lactate: (double) baselineSmo2: (double) currSmo2: (unsigned char**) rowData;
- (LTPurpose) getPurpose: (int) protocol : (double) speed;
- (LTPrescription) getPrescription: (int) protocol : (int) purpose : (double) speed;
- (LTTraining) getPrescriptionTable: (int) section : (int) protocol : (int) purpose : (double) speed;
- (double) getExercise: (int) age : (double) speed;



@end
